-- LOCAL TESTING ONLY (plain PostgreSQL + supabase_stub.sql). Do NOT run on Supabase.
-- French + ICT (0014): content, grades, access, explanations, audio, progress, parent report.
\set ON_ERROR_STOP 1
\set QUIET 1

-- installed by the migrations; run again here -> must be idempotent
\i ../migrations/20261012000014_french_ict.sql

create schema t14;
grant usage on schema t14 to authenticated, anon;
create function t14.login(p_uid uuid, p_anon boolean default false) returns void
language sql as $$
  select set_config('request.jwt.claims',
                    json_build_object('sub', p_uid, 'role', 'authenticated', 'is_anonymous', p_anon)::text, false)
$$;
create function t14.expect_error(p_sql text, p_msg text) returns void
language plpgsql as $$
begin
  execute p_sql;
  raise exception 'EXPECTED ERROR "%" but statement succeeded: %', p_msg, p_sql;
exception
  when others then
    if sqlerrm like 'EXPECTED ERROR%' then raise; end if;
    if sqlerrm <> p_msg then raise exception 'expected error "%", got "%" for: %', p_msg, sqlerrm, p_sql; end if;
end $$;
create function t14.ok(p_cond boolean, p_what text) returns void
language plpgsql as $$
begin
  if p_cond is not true then raise exception 'FAILED: %', p_what; end if;
  raise notice 'ok - %', p_what;
end $$;
create table t14.vars (k text primary key, v text);
grant all on t14.vars to authenticated, anon;
create function t14.v(p_k text) returns text language sql as $$ select v from t14.vars where k = p_k $$;
create function t14.put(p_k text, p_v text) returns void language sql as $$
  insert into t14.vars values (p_k, p_v) on conflict (k) do update set v = excluded.v $$;
create function t14.right_response(p_q text) returns jsonb language sql security definer as $$
  select case q.type
    when 'multiple_choice' then q.answer_key -> 'index'
    when 'reading'         then q.answer_key -> 'index'
    when 'true_false'      then q.answer_key -> 'value'
    when 'drag_drop'       then q.answer_key -> 'token'
    when 'matching'        then q.answer_key -> 'map'
    when 'ordering'        then q.answer_key -> 'order'
  end from public.questions q where q.id = p_q $$;
create function t14.course_ids(p_profile uuid) returns text[] language sql as $$
  select array_agg(c ->> 'id' order by c ->> 'id') from jsonb_array_elements(course_map(p_profile)) c $$;
create function t14.course(p_profile uuid, p_id text) returns jsonb language sql as $$
  select c from jsonb_array_elements(course_map(p_profile)) c where c ->> 'id' = p_id $$;
create function t14.progress(p_profile uuid, p_id text) returns jsonb language sql as $$
  select c from jsonb_array_elements(profile_report(p_profile) -> 'courses') c where c ->> 'id' = p_id $$;
grant execute on all functions in schema t14 to authenticated, anon;

-- ---------------------------------------------------------------- content (as owner)
do $$
declare
  n int;
  ids text[] := array['fr-g3', 'ict-g3', 'fr-g6', 'ict-g6'];
begin
  select count(*) into n from public.courses where id = any(ids);
  assert n = 4, 'courses ' || n;
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id = any(ids) and not q.archived;
  assert n = 340, 'questions ' || n;
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id = any(ids) and q.archived;
  assert n = 0, 'archived after rerun ' || n;
  select count(*) into n from public.lessons where course_id = any(ids) and (intro is null or archived);
  assert n = 0, 'lessons without explanation ' || n;
  -- every question grades its own key as right, and a wrong answer as wrong
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id = any(ids) and not app.grade(q.type, q.answer_key, case q.type
         when 'drag_drop' then q.answer_key->'token'
         when 'ordering' then q.answer_key->'order'
         when 'matching' then q.answer_key->'map'
         when 'reading' then q.answer_key->'index'
         when 'multiple_choice' then q.answer_key->'index'
         when 'true_false' then q.answer_key->'value' end);
  assert n = 0, 'self-grade failures ' || n;
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id = any(ids) and app.grade(q.type, q.answer_key, '"zzz-wrong"'::jsonb);
  assert n = 0, 'wrong answers graded right ' || n;
  -- the right answer is never in the visible payload of multiple choice (index only in the private key)
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id = any(ids) and (q.payload ? 'index' or q.payload ? 'answer');
  assert n = 0, 'answer in payload ' || n;
  -- French audio uses fr-FR, ICT none in French; listening questions exist in both French courses
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id like 'fr-%' and q.payload ? 'audio';
  assert n >= 30, 'french audio questions ' || n;
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id like 'fr-%' and q.payload ? 'audio' and q.payload ->> 'audio_lang' <> 'fr-FR';
  assert n = 0, 'audio lang';
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id like 'fr-%' and q.type = 'true_false' and q.correct_text not in ('صح', 'خطأ');
  assert n = 0, 'french tf text';
  -- source labels
  assert (select source_kind from public.courses where id = 'ict-g6') = 'book_topics', 'ict-g6 kind';
  assert (select count(*) from public.courses where id in ('fr-g3', 'fr-g6', 'ict-g3') and source_kind = 'supplementary') = 3, 'supplementary';
  assert (select count(*) from public.courses where source_kind = 'official') = 12, 'official book courses labelled';
  assert (select source_kind from public.courses where id = 'eng-lower') is null, 'starter course untouched';
  -- grades
  assert (select grade_min = 3 and grade_max = 3 from public.courses where id = 'fr-g3'), 'fr-g3 grade';
  assert (select grade_min = 6 and grade_max = 6 from public.courses where id = 'ict-g6'), 'ict-g6 grade';
  -- the old courses keep their questions
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id in ('eng-g3-t1', 'ar-g3', 'isl-g3', 'eng-g6-t1', 'math-g6-t1', 'ar-g6', 'isl-g6', 'soc-g6') and not q.archived;
  assert n = 1371, 'term-1 book questions untouched ' || n;
end $$;

insert into auth.users (id, email, is_anonymous) values
  ('00000000-0000-0000-0000-00000000000a', 'kareem@example.com', false),
  ('00000000-0000-0000-0000-0000000000c1', null, true),
  ('00000000-0000-0000-0000-00000000000b', 'bob@example.com', false);

set role authenticated;
select t14.login('00000000-0000-0000-0000-00000000000a');
select create_family('Junaid', 'Kareem', 'en', 'v1', '[
  {"display_name":"Omar","kind":"child","grade":6},
  {"display_name":"Yassin","kind":"child","grade":3,"ui_locale":"ar"}]');
select t14.put('omar',   (select id::text from profiles where display_name = 'Omar'));
select t14.put('yassin', (select id::text from profiles where display_name = 'Yassin'));
select t14.put('kareem', (select id::text from profiles where display_name = 'Kareem'));
select t14.put('code', create_pairing_code(t14.v('yassin')::uuid) ->> 'code');

-- ---------------------------------------------------------------- each child sees his own grade
select t14.ok('fr-g6' = any(t14.course_ids(t14.v('omar')::uuid)) and 'ict-g6' = any(t14.course_ids(t14.v('omar')::uuid)),
              'Omar (grade 6) has French and ICT grade 6');
select t14.ok(not ('fr-g3' = any(t14.course_ids(t14.v('omar')::uuid))) and not ('ict-g3' = any(t14.course_ids(t14.v('omar')::uuid))),
              'Omar does not get the grade 3 courses');
select t14.ok('fr-g3' = any(t14.course_ids(t14.v('yassin')::uuid)) and 'ict-g3' = any(t14.course_ids(t14.v('yassin')::uuid)),
              'Yassin (grade 3) has French and ICT grade 3');
select t14.ok(not ('fr-g6' = any(t14.course_ids(t14.v('yassin')::uuid))) and not ('ict-g6' = any(t14.course_ids(t14.v('yassin')::uuid))),
              'Yassin does not get the grade 6 courses');
select t14.ok(not exists (select 1 from jsonb_array_elements(course_map(t14.v('kareem')::uuid)) c
                           where c ->> 'subject' in ('french', 'ict')), 'the adult profile gets no school courses');
select t14.ok('ar-g3' = any(t14.course_ids(t14.v('yassin')::uuid)) and 'eng-g3-t1' = any(t14.course_ids(t14.v('yassin')::uuid)),
              'Yassin keeps his old courses');
select t14.ok(t14.course(t14.v('omar')::uuid, 'ict-g6') ->> 'source_kind' = 'book_topics'
          and t14.course(t14.v('omar')::uuid, 'fr-g6') ->> 'speech_lang' = 'fr-FR'
          and t14.course(t14.v('omar')::uuid, 'fr-g6') ->> 'source_note' is not null, 'course_map has source label and speech language');
select t14.ok(t14.course(t14.v('yassin')::uuid, 'fr-g3') -> 'units' -> 0 -> 'lessons' -> 0 ->> 'status' = 'available'
          and t14.course(t14.v('yassin')::uuid, 'fr-g3') -> 'units' -> 0 -> 'lessons' -> 1 ->> 'status' = 'locked',
              'first French lesson open, the next one locked');

-- ---------------------------------------------------------------- explanation
select t14.ok(lesson_intro(t14.v('yassin')::uuid, 'fr-g3.u1.l1') -> 'intro' -> 'vocab' -> 0 ->> 'w' = 'Bonjour'
          and lesson_intro(t14.v('yassin')::uuid, 'fr-g3.u1.l1') ->> 'speech_lang' = 'fr-FR', 'lesson_intro gives vocabulary + fr-FR');
select t14.expect_error(format($$ select lesson_intro(%L, 'fr-g6.u1.l1') $$, t14.v('yassin')), 'not_found');
select t14.expect_error(format($$ select lesson_intro(%L, 'nope') $$, t14.v('omar')), 'not_found');

-- ---------------------------------------------------------------- play the first French lesson (Yassin)
select t14.put('s1', start_lesson(t14.v('yassin')::uuid, 'fr-g3.u1.l1')::text);
select t14.ok(not (t14.v('s1')::jsonb::text like '%answer_key%'), 'the phone never gets the answer key');
select t14.ok(exists (select 1 from jsonb_array_elements(t14.v('s1')::jsonb -> 'questions') q
                       where q -> 'payload' ->> 'audio' = 'Bonsoir' and q -> 'payload' ->> 'audio_lang' = 'fr-FR'),
              'listening question carries its French audio');
select t14.put('a1', t14.v('s1')::jsonb ->> 'attempt_id');
-- first question wrong, the rest right
select submit_answer(t14.v('a1')::uuid, q ->> 'id',
         case when o = 1 then '"zzz-wrong"'::jsonb else t14.right_response(q ->> 'id') end)
  from jsonb_array_elements(t14.v('s1')::jsonb -> 'questions') with ordinality x(q, o);
select t14.put('f1', finish_lesson(t14.v('a1')::uuid)::text);
select t14.ok((t14.v('f1')::jsonb ->> 'stars')::int >= 1, 'stars given for the French lesson');
select t14.ok(t14.course(t14.v('yassin')::uuid, 'fr-g3') -> 'units' -> 0 -> 'lessons' -> 0 ->> 'status' = 'done'
          and t14.course(t14.v('yassin')::uuid, 'fr-g3') -> 'units' -> 0 -> 'lessons' -> 1 ->> 'status' = 'available',
              'lesson done and the next lesson opens');
select t14.ok(t14.course(t14.v('omar')::uuid, 'fr-g6') -> 'units' -> 0 -> 'lessons' -> 0 ->> 'status' = 'available'
          and t14.course(t14.v('omar')::uuid, 'fr-g6') -> 'units' -> 0 -> 'lessons' -> 1 ->> 'status' = 'locked',
              'Omar''s progress is separate');
-- replay is allowed
select t14.ok(start_lesson(t14.v('yassin')::uuid, 'fr-g3.u1.l1') ->> 'attempt_id' is not null, 'a finished lesson can be replayed');

-- ---------------------------------------------------------------- parent report per course
select t14.ok((t14.progress(t14.v('yassin')::uuid, 'fr-g3') ->> 'lessons_done')::int = 1
          and (t14.progress(t14.v('yassin')::uuid, 'fr-g3') ->> 'lessons_total')::int = 16, 'report: French 1 of 16 lessons');
select t14.ok((t14.progress(t14.v('yassin')::uuid, 'fr-g3') ->> 'score')::numeric between 0.5 and 0.99, 'report: French score');
select t14.ok(jsonb_array_length(t14.progress(t14.v('yassin')::uuid, 'fr-g3') -> 'to_review') = 1, 'report: the wrong item is listed to review');
select t14.ok(jsonb_array_length(t14.progress(t14.v('yassin')::uuid, 'fr-g3') -> 'tests') = 1
          and t14.progress(t14.v('yassin')::uuid, 'fr-g3') ->> 'last_activity' is not null, 'report: results and last activity');
select t14.ok(t14.progress(t14.v('yassin')::uuid, 'fr-g3') ->> 'next_lesson' = 'Je m''appelle… — اسمي…', 'report: next lesson');
select t14.ok((t14.progress(t14.v('yassin')::uuid, 'ict-g3') ->> 'lessons_done')::int = 0
          and t14.progress(t14.v('yassin')::uuid, 'ict-g3') ->> 'last_activity' is null, 'report: ICT not started yet');
select t14.ok((t14.progress(t14.v('omar')::uuid, 'fr-g6') ->> 'lessons_done')::int = 0, 'report: Omar''s French untouched');
select t14.ok(t14.progress(t14.v('omar')::uuid, 'fr-g3') is null, 'report: Omar has no grade-3 course');
select t14.ok(profile_report(t14.v('yassin')::uuid) ? 'skills' and profile_report(t14.v('yassin')::uuid) ? 'history',
              'report keeps its old parts');

-- ---------------------------------------------------------------- access
-- Yassin's phone: his own data only, no parent report
select t14.login('00000000-0000-0000-0000-0000000000c1', true);
select redeem_pairing_code(t14.v('code'), 'Yassin phone');
select t14.ok('fr-g3' = any(t14.course_ids(t14.v('yassin')::uuid)), 'Yassin phone sees his French');
select t14.expect_error(format($$ select course_map(%L) $$, t14.v('omar')), 'not_found');
select t14.expect_error(format($$ select lesson_intro(%L, 'fr-g6.u1.l1') $$, t14.v('omar')), 'not_found');
select t14.expect_error(format($$ select profile_report(%L) $$, t14.v('yassin')), 'parent_only');
-- another family
select t14.login('00000000-0000-0000-0000-00000000000b');
select t14.expect_error(format($$ select lesson_intro(%L, 'fr-g3.u1.l1') $$, t14.v('yassin')), 'not_found');
select t14.expect_error(format($$ select profile_report(%L) $$, t14.v('yassin')), 'parent_only');
-- anon cannot call it at all
reset role;
select t14.ok(not has_function_privilege('anon', 'public.lesson_intro(uuid, text)', 'execute'), 'anon cannot call lesson_intro');
select t14.ok(not has_function_privilege('authenticated', 'app.course_progress(uuid)', 'execute'), 'app.course_progress is private');

\echo 'ALL FRENCH + ICT DATABASE TESTS PASSED'
