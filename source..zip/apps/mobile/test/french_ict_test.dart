import 'package:family_learn/data/learning/learning_json.dart';
import 'package:family_learn/data/learning/question_codec.dart';
import 'package:family_learn/domain/questions.dart';
import 'package:family_learn/features/speak_game/pronunciation.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('French pronunciation', () {
    const checker = PronunciationChecker();

    test('accents are folded', () {
      expect(PronunciationChecker.normalize('Café, élève, garçon, sœur'), 'cafe eleve garcon soeur');
    });

    test('a French word said right is correct, with or without accents from the recogniser', () {
      expect(checker.check(target: 'Bonjour', alternatives: const [SpeechAlt('bonjour')], strictness: 0.75).result,
          SpeakResult.correct);
      expect(checker.check(target: 'la sœur', alternatives: const [SpeechAlt('la soeur')], strictness: 0.75).result,
          SpeakResult.correct);
      expect(checker.check(target: 'Je m\'appelle Yassin', alternatives: const [SpeechAlt("je m'appelle Yassin")], strictness: 0.75)
          .result, SpeakResult.correct);
    });

    test('a different word is not accepted, silence is unclear', () {
      expect(checker.check(target: 'Bonjour', alternatives: const [SpeechAlt('merci')], strictness: 0.75).result,
          isNot(SpeakResult.correct));
      expect(checker.check(target: 'Bonjour', alternatives: const [], strictness: 0.75).result, SpeakResult.unclear);
    });
  });

  group('French + ICT data from the server', () {
    test('listening audio is read from the payload', () {
      final q = questionFromJson({
        'id': 'fr-g3.u1.l1.q3',
        'type': 'multiple_choice',
        'skill': 'fr3.listen',
        'prompt': '🔊',
        'payload': {
          'options': ['a', 'b'],
          'audio': 'Bonsoir',
          'audio_lang': 'fr-FR',
        },
      });
      expect(q, isA<MultipleChoiceQuestion>());
      expect(q!.audio, 'Bonsoir');
      expect(q.audioLang, 'fr-FR');
      final plain = questionFromJson({'id': 'x', 'type': 'true_false', 'skill': 's', 'prompt': 'p', 'payload': {}});
      expect(plain!.audio, isNull);
    });

    test('course source label and speech language', () {
      final c = coursesFromJson([
        {
          'id': 'fr-g3', 'subject': 'french', 'title': 'French', 'level_label': 'P3',
          'source_kind': 'supplementary', 'source_note': 'note', 'edition': '2026/2027', 'speech_lang': 'fr-FR',
          'units': [],
        },
        {'id': 'eng-lower', 'subject': 'english', 'title': 'English', 'level_label': '', 'units': []},
      ]);
      expect(c.first.sourceKind, 'supplementary');
      expect(c.first.speechLang, 'fr-FR');
      expect(c.last.sourceKind, isNull);
    });

    test('lesson explanation', () {
      final i = lessonIntroFromJson({
        'speech_lang': 'fr-FR',
        'source_kind': 'supplementary',
        'intro': {
          'goals': ['g1'],
          'explain': 'شرح',
          'vocab': [
            {'w': 'Bonjour', 'ar': 'مرحبًا', 'say': 'بونجور'},
            {'w': 'Merci', 'ar': 'شكرًا'},
          ],
          'summary': 's',
        },
      });
      expect(i, isNotNull);
      expect(i!.vocab.length, 2);
      expect(i.vocab.first.say, 'بونجور');
      expect(i.vocab.last.say, isNull);
      expect(i.speechLang, 'fr-FR');
      expect(lessonIntroFromJson({'intro': null}), isNull);
    });

    test('per-course progress in the parent report', () {
      final r = reportFromJson({
        'minutes_by_day': [0, 0, 0, 0, 0, 0, 5],
        'courses': [
          {
            'id': 'fr-g3', 'title': 'French', 'subject': 'french', 'source_kind': 'supplementary',
            'lessons_total': 16, 'lessons_done': 4, 'score': 0.833,
            'last_activity': '2026-10-12T17:00:00+00:00', 'next_lesson': 'Ça va ?',
            'tests': [
              {'lesson': 'Bonjour', 'correct': 5, 'total': 6, 'finished_at': '2026-10-12T17:00:00+00:00'},
            ],
            'strong': ['التحية'], 'weak': [], 'to_review': ['Bonsoir = مساء الخير'],
          },
          {'id': 'ict-g3', 'title': 'ICT', 'subject': 'ict', 'lessons_total': 14, 'lessons_done': 0},
        ],
      });
      expect(r.courses.length, 2);
      expect(r.courses.first.completion, 0.25);
      expect(r.courses.first.tests.single.correct, 5);
      expect(r.courses.first.toReview.single, contains('Bonsoir'));
      expect(r.courses.last.started, isFalse);
      expect(r.courses.last.score, isNull);
    });

    test('an old server without per-course progress still works', () {
      expect(reportFromJson({'minutes_by_day': []}).courses, isEmpty);
    });
  });
}
