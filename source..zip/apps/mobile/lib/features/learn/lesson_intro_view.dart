import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/speech/speech_engine.dart';
import '../../core/text_dir.dart';
import '../../core/theme/app_theme.dart';
import '../../domain/learning.dart';
import '../../state/speak_game.dart' show speechEngineProvider;
import '../speak_game/pronunciation.dart';

// The lesson explanation shown before the exercises (French + ICT lessons have one):
// goals, explanation, new words (🔊 listen + 🎤 say it for French), examples, activity, summary.

/// Reads [text] aloud in [lang] with the device voice. Shows a note when there is no voice.
Future<void> speakText(BuildContext context, SpeechEngine engine, String text, String lang, {bool slow = false}) async {
  engine.unlockAudio();
  if (!engine.ttsSupported || (lang != 'en-US' && !engine.hasVoice(lang))) {
    final s = context.s;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('noVoice'))));
    if (!engine.ttsSupported) return;
  }
  engine.stopSpeaking();
  await engine.speak(text, lang: lang, rate: slow ? 0.5 : 0.8);
}

/// 🔊 / 🐢 buttons for a question that has listening audio.
class QuestionAudioBar extends ConsumerWidget {
  const QuestionAudioBar({super.key, required this.text, required this.lang});

  final String text;
  final String lang;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final engine = ref.watch(speechEngineProvider);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          FilledButton.icon(
            onPressed: () => speakText(context, engine, text, lang),
            icon: const Icon(Icons.volume_up),
            label: Text(s.t('listenAudio')),
          ),
          const SizedBox(width: 12),
          OutlinedButton.icon(
            onPressed: () => speakText(context, engine, text, lang, slow: true),
            icon: const Text('🐢'),
            label: Text(s.t('listenSlow')),
          ),
        ],
      ),
    );
  }
}

class LessonIntroView extends StatelessWidget {
  const LessonIntroView({super.key, required this.intro, required this.title, required this.onStart, this.startLabel});

  final LessonIntro intro;
  final String title;
  final VoidCallback onStart;
  final String? startLabel;

  String get _lang => intro.speechLang ?? 'en-US';

  /// French lessons get pronunciation practice; other courses only 🔊 for the terms.
  bool get _practice => _lang.startsWith('fr');

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    Widget card(String label, List<Widget> children, {Color? color}) => Card(
          margin: const EdgeInsets.fromLTRB(16, 8, 16, 4),
          color: color,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(label, style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                ...children,
              ],
            ),
          ),
        );
    Text rich(String t) => Text(t, textDirection: contentDir(t), style: context.text.bodyLarge);

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.only(bottom: 16),
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                child: Text('📖 $title', textDirection: contentDir(title), style: context.text.titleLarge),
              ),
              if (intro.sourceKind == 'supplementary' || intro.sourceKind == 'book_topics')
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                  child: Text(s.t('appWritten'), style: context.text.labelMedium?.copyWith(color: context.colors.outline)),
                ),
              if (intro.goals.isNotEmpty)
                card('🎯 ${s.t('goals')}', [for (final g in intro.goals) rich('• $g')]),
              if (intro.explain != null) card('💡 ${s.t('lessonExplain')}', [rich(intro.explain!)]),
              if (intro.vocab.isNotEmpty)
                card('🔤 ${s.t('introWords')}', [
                  for (final v in intro.vocab) _VocabRow(item: v, lang: _lang, practice: _practice),
                ]),
              if (intro.examples.isNotEmpty)
                card('🗒️ ${s.t('examples')}', [
                  for (final e in intro.examples) _ExampleRow(text: e, lang: _lang, speakable: _practice),
                ]),
              if (intro.activity != null) card('✋ ${s.t('activity')}', [rich(intro.activity!)]),
              if (intro.summary != null)
                card('📝 ${s.t('introSummary')}', [rich(intro.summary!)],
                    color: context.colors.primaryContainer.withValues(alpha: 0.35)),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          child: SizedBox(
            width: double.infinity,
            child: FilledButton(onPressed: onStart, child: Text(startLabel ?? s.t('startExercises'))),
          ),
        ),
      ],
    );
  }
}

class _ExampleRow extends ConsumerWidget {
  const _ExampleRow({required this.text, required this.lang, required this.speakable});

  final String text;
  final String lang;
  final bool speakable;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final engine = ref.watch(speechEngineProvider);
    // Only the French part is read (the text before an Arabic gloss, if any).
    final spoken = text.split(RegExp('[؀-ۿ]')).first.replaceAll('—', ' ').trim();
    return Row(
      children: [
        Expanded(child: Text(text, textDirection: contentDir(text), style: context.text.bodyLarge)),
        if (speakable && spoken.isNotEmpty)
          IconButton(
            tooltip: context.s.t('listenAudio'),
            icon: const Icon(Icons.volume_up_outlined),
            onPressed: () => speakText(context, engine, spoken, lang),
          ),
      ],
    );
  }
}

enum _Say { idle, listening, good, close, again, notHeard, blocked }

class _VocabRow extends ConsumerStatefulWidget {
  const _VocabRow({required this.item, required this.lang, required this.practice});

  final LessonWord item;
  final String lang;
  final bool practice;

  @override
  ConsumerState<_VocabRow> createState() => _VocabRowState();
}

class _VocabRowState extends ConsumerState<_VocabRow> {
  static const _checker = PronunciationChecker();
  _Say _state = _Say.idle;
  String _heard = '';
  String? _blockKey;
  StreamSubscription<SpeechEvent>? _sub;
  Timer? _stop;
  Completer<void>? _done;

  @override
  void dispose() {
    _stop?.cancel();
    _sub?.cancel();
    if (_done?.isCompleted == false) _done!.complete();
    super.dispose();
  }

  /// The words to say: the French text without "le / la" hints after a slash.
  String get _target => widget.item.word.split(' / ').first.replaceAll(RegExp(r'[?!.]'), '').trim();

  Future<void> _listen() async {
    final engine = ref.read(speechEngineProvider);
    engine.unlockAudio();
    if (!engine.recognitionSupported) {
      setState(() {
        _state = _Say.blocked;
        _blockKey = 'micNotSupported';
      });
      return;
    }
    engine.stopSpeaking();
    setState(() {
      _state = _Say.listening;
      _heard = '';
    });
    final alts = <SpeechAlt>[];
    String? error;
    final done = _done = Completer<void>();
    _sub = engine.listen(lang: widget.lang, continuous: _target.contains(' ')).listen(
      (e) {
        switch (e.type) {
          case SpeechEventType.partial:
          case SpeechEventType.finalResult:
            if (e.alternatives.isNotEmpty) {
              alts.addAll(e.alternatives);
              if (mounted) setState(() => _heard = e.alternatives.first.text);
              final v = _checker.check(target: _target, alternatives: alts, strictness: 0.75);
              if (v.result == SpeakResult.correct) engine.stop();
            }
          case SpeechEventType.error:
            error ??= e.error;
          case SpeechEventType.ended:
            if (!done.isCompleted) done.complete();
          case SpeechEventType.sound:
          case SpeechEventType.started:
            break;
        }
      },
      onDone: () {
        if (!done.isCompleted) done.complete();
      },
    );
    _stop = Timer(const Duration(seconds: 7), engine.stop);
    await done.future;
    _stop?.cancel();
    await _sub?.cancel();
    _sub = null;
    if (!mounted) return;
    if (alts.isEmpty) {
      setState(() {
        if (error == 'not-allowed' || error == 'service-not-allowed') {
          _state = _Say.blocked;
          _blockKey = 'micDenied';
        } else if (error == 'not-supported' || error == 'language-not-supported') {
          _state = _Say.blocked;
          _blockKey = 'micNotSupported';
        } else {
          _state = error == 'aborted' ? _Say.idle : _Say.notHeard;
        }
      });
      return;
    }
    final v = _checker.check(target: _target, alternatives: alts, strictness: 0.75);
    setState(() {
      _heard = v.heard;
      _state = switch (v.result) {
        SpeakResult.correct => _Say.good,
        SpeakResult.close => _Say.close,
        SpeakResult.wrong => _Say.again,
        SpeakResult.unclear => _Say.notHeard,
      };
    });
    if (v.result == SpeakResult.correct) engine.playSfx(Sfx.success);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final engine = ref.watch(speechEngineProvider);
    final v = widget.item;
    final feedback = switch (_state) {
      _Say.good => (s.t('sayGood'), AppTokens.good),
      _Say.close => (s.t('sayClose'), AppTokens.warn),
      _Say.again => (s.t('sayAgain'), AppTokens.bad),
      _Say.notHeard => (s.t('sayNotHeard'), AppTokens.warn),
      _Say.blocked => (s.t(_blockKey ?? 'micNotSupported'), AppTokens.warn),
      _ => null,
    };
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(v.word,
                        textDirection: TextDirection.ltr,
                        style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                    Text(v.meaning, textDirection: contentDir(v.meaning), style: context.text.bodyMedium),
                    if (v.say != null)
                      Text('🗣️ ${v.say}', textDirection: TextDirection.rtl,
                          style: context.text.bodySmall?.copyWith(color: context.colors.outline)),
                  ],
                ),
              ),
              IconButton(
                tooltip: s.t('listenAudio'),
                icon: const Icon(Icons.volume_up),
                onPressed: () => speakText(context, engine, _target, widget.lang),
              ),
              if (widget.practice)
                IconButton(
                  tooltip: s.t('sayIt'),
                  icon: Icon(_state == _Say.listening ? Icons.mic : Icons.mic_none,
                      color: _state == _Say.listening ? AppTokens.bad : null),
                  onPressed: _state == _Say.listening ? () => engine.stop() : _listen,
                ),
            ],
          ),
          if (feedback != null)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(
                [feedback.$1, if (_heard.isNotEmpty && _state != _Say.good) s.f('heard', [_heard])].join('  ·  '),
                style: context.text.bodySmall?.copyWith(color: feedback.$2, fontWeight: FontWeight.w600),
              ),
            ),
          if (_state == _Say.listening) const LinearProgressIndicator(minHeight: 2),
        ],
      ),
    );
  }
}

/// A small banner under the course title: where the content comes from.
class CourseSourceBanner extends StatelessWidget {
  const CourseSourceBanner({super.key, required this.kind, this.note, this.edition});

  final String? kind;
  final String? note;
  final String? edition;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final label = switch (kind) {
      'official' => s.t('srcOfficial'),
      'book_topics' => s.t('srcBookTopics'),
      'supplementary' => s.t('srcSupplementary'),
      _ => null,
    };
    if (label == null) return const SizedBox.shrink();
    final color = kind == 'official' ? AppTokens.good : AppTokens.warn;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: note == null
            ? null
            : () => showDialog<void>(
                  context: context,
                  builder: (c) => AlertDialog(
                    title: Text(label),
                    content: Text([note!, if (edition != null) edition!].join('\n\n'), textDirection: contentDir(note)),
                    actions: [TextButton(onPressed: () => Navigator.of(c).pop(), child: const Text('OK'))],
                  ),
                ),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.10),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color.withValues(alpha: 0.4)),
          ),
          child: Row(
            children: [
              Expanded(child: Text(label, style: context.text.bodySmall)),
              if (note != null) Icon(Icons.info_outline, size: 18, color: color),
            ],
          ),
        ),
      ),
    );
  }
}
