// Learning types that come from the server (Phase 4). Plain Dart.
// Courses reuse Course / Unit / LessonSummary from models.dart.

import 'models.dart';
import 'questions.dart';

/// A lesson opened on the server. Questions come WITHOUT their answers;
/// every answer is marked by the server.
class LessonSession {
  const LessonSession({required this.attemptId, required this.lessonId, required this.title, required this.questions});

  final String attemptId;
  final String lessonId;
  final String title;
  final List<Question> questions;
}

class AnswerResult {
  const AnswerResult({required this.correct, required this.correctText, this.explanation});

  final bool correct;
  final String correctText;
  final String? explanation;
}

class LessonOutcome {
  const LessonOutcome({
    required this.correct,
    required this.total,
    required this.xp,
    required this.coins,
    required this.stars,
    required this.wallet,
  });

  final int correct;
  final int total;
  final int xp;
  final int coins;
  final int stars;
  final ProfileWallet wallet;

  int get percent => total == 0 ? 0 : (correct * 100 / total).round();
}

/// Real totals for one profile (from finished lessons).
class ProfileWallet {
  const ProfileWallet({
    this.xp = 0,
    this.coins = 0,
    this.stars = 0,
    this.level = 1,
    this.streakDays = 0,
    this.minutesToday = 0,
    this.lessonsDone = 0,
  });

  final int xp;
  final int coins;
  final int stars;
  final int level;
  final int streakDays;
  final int minutesToday;
  final int lessonsDone;

  Wallet toWallet() => Wallet(xp: xp, coins: coins, stars: stars, level: level, streakDays: streakDays);
}

class RangeStats {
  const RangeStats({this.minutes = 0, this.questions = 0, this.correct = 0, this.accuracy});

  final int minutes;
  final int questions;
  final int correct;

  /// 0..1, null when there are no answers yet.
  final double? accuracy;
}

class HistoryEntry {
  const HistoryEntry({required this.lesson, required this.correct, required this.total, required this.finishedAt});

  final String lesson;
  final int correct;
  final int total;
  final DateTime finishedAt;
}

class SkillStat {
  const SkillStat({required this.code, required this.name, required this.answers, required this.accuracy});

  final String code;
  final String name;
  final int answers;
  final double accuracy;

  /// Weak = at least 3 answers and under 60% right (last 30 days).
  bool get isWeak => answers >= 3 && accuracy < 0.6;
}

/// Parent's view of one profile (last 30 days).
class ProfileReport {
  const ProfileReport({
    required this.minutesByDay,
    required this.today,
    required this.week,
    required this.month,
    required this.dailyGoal,
    required this.streakDays,
    required this.history,
    required this.skills,
    required this.toReview,
    this.courses = const [],
  });

  /// Last 7 days, oldest first; the last value is today.
  final List<int> minutesByDay;
  final RangeStats today;
  final RangeStats week;
  final RangeStats month;
  final int dailyGoal;
  final int streakDays;
  final List<HistoryEntry> history;
  final List<SkillStat> skills;
  final List<String> toReview;

  /// Progress in each course of the child (newest feature: French, ICT and all others).
  final List<CourseProgress> courses;

  int get minutesToday => minutesByDay.isEmpty ? 0 : minutesByDay.last;
  List<SkillStat> get weakSkills => skills.where((s) => s.isWeak).toList();
}

/// The first lesson that is in progress or available, across the profile's courses.
LessonSummary? nextLesson(List<Course> courses) {
  for (final wanted in [LessonStatus.inProgress, LessonStatus.available]) {
    for (final c in courses) {
      for (final u in c.units) {
        for (final l in u.lessons) {
          if (l.status == wanted) return l;
        }
      }
    }
  }
  return null;
}

/// One course in the parent report.
class CourseProgress {
  const CourseProgress({
    required this.id,
    required this.title,
    required this.subject,
    required this.lessonsTotal,
    required this.lessonsDone,
    this.sourceKind,
    this.score,
    this.lastActivity,
    this.nextLesson,
    this.tests = const [],
    this.strong = const [],
    this.weak = const [],
    this.toReview = const [],
  });

  final String id;
  final String title;
  final String subject;
  final String? sourceKind;
  final int lessonsTotal;
  final int lessonsDone;

  /// 0..1 over the finished lessons (best attempt of each); null = nothing finished yet.
  final double? score;
  final DateTime? lastActivity;
  final String? nextLesson;
  final List<HistoryEntry> tests;
  final List<String> strong;
  final List<String> weak;
  final List<String> toReview;

  double get completion => lessonsTotal == 0 ? 0 : lessonsDone / lessonsTotal;
  bool get started => lastActivity != null || lessonsDone > 0;
}

/// A word / term shown in a lesson explanation.
class LessonWord {
  const LessonWord({required this.word, required this.meaning, this.say});
  final String word;
  final String meaning;

  /// Pronunciation help in Arabic letters (French lessons).
  final String? say;
}

/// The explanation shown before a lesson's exercises.
class LessonIntro {
  const LessonIntro({
    this.goals = const [],
    this.explain,
    this.vocab = const [],
    this.examples = const [],
    this.activity,
    this.summary,
    this.speechLang,
    this.sourceKind,
  });

  final List<String> goals;
  final String? explain;
  final List<LessonWord> vocab;
  final List<String> examples;
  final String? activity;
  final String? summary;

  /// Language of the 🔊 buttons, e.g. 'fr-FR' (null = English).
  final String? speechLang;
  final String? sourceKind;

  bool get isEmpty =>
      goals.isEmpty && (explain ?? '').isEmpty && vocab.isEmpty && examples.isEmpty &&
      (activity ?? '').isEmpty && (summary ?? '').isEmpty;
}
