-- ---------------------------------------------------------------- per-course progress (parent report)
-- One row per course of the child: lessons done (or known from the placement test) of all lessons,
-- score of the finished lessons (best attempt of each), last activity, the next lesson,
-- strong / weak skills in this course (last 60 days, 3+ answers) and the items to review
-- (questions whose LAST answer was wrong, newest first).
create or replace function app.course_progress(p_profile uuid) returns jsonb
language sql stable security definer set search_path = '' as $$
  select coalesce(jsonb_agg(x.j order by x.pos, x.id), '[]'::jsonb) from (
    select c.position pos, c.id, jsonb_build_object(
      'id', c.id, 'title', c.title, 'subject', c.subject, 'source_kind', c.source_kind,
      'lessons_total', (select count(*) from public.lessons l where l.course_id = c.id and not l.archived),
      'lessons_done', (select count(*) from public.lessons l
                        where l.course_id = c.id and not l.archived
                          and (app.lesson_done(p_profile, l.id) or l.position <= app.placed_position(p_profile, c.id))),
      'score', (select case when sum(b.total) > 0 then round(sum(b.correct)::numeric / sum(b.total), 3) end
                  from (select distinct on (a.lesson_id) a.correct, a.total
                          from public.lesson_attempts a join public.lessons l on l.id = a.lesson_id
                         where a.profile_id = p_profile and l.course_id = c.id and a.finished_at is not null and a.total > 0
                         order by a.lesson_id, a.correct::numeric / a.total desc) b),
      'tests', (select coalesce(jsonb_agg(jsonb_build_object('lesson', t.title, 'correct', t.correct, 'total', t.total,
                                                             'finished_at', t.finished_at) order by t.finished_at desc), '[]'::jsonb)
                  from (select l.title, a.correct, a.total, a.finished_at
                          from public.lesson_attempts a join public.lessons l on l.id = a.lesson_id
                         where a.profile_id = p_profile and l.course_id = c.id and a.finished_at is not null
                         order by a.finished_at desc limit 5) t),
      'last_activity', (select max(greatest(a.started_at, coalesce(a.finished_at, a.started_at)))
                          from public.lesson_attempts a join public.lessons l on l.id = a.lesson_id
                         where a.profile_id = p_profile and l.course_id = c.id),
      'next_lesson', (select l.title from public.lessons l
                       where l.course_id = c.id and not l.archived
                         and not app.lesson_done(p_profile, l.id) and l.position > app.placed_position(p_profile, c.id)
                       order by l.position limit 1),
      'strong', (select coalesce(jsonb_agg(s.name order by s.acc desc), '[]'::jsonb) from (
                   select sk.name, count(*) filter (where an.is_correct)::numeric / count(*) acc
                     from public.answers an
                     join public.lesson_attempts a on a.id = an.attempt_id
                     join public.questions q on q.id = an.question_id
                     join public.lessons l on l.id = q.lesson_id
                     join public.skills sk on sk.code = q.skill
                    where a.profile_id = p_profile and l.course_id = c.id and an.answered_at > now() - interval '60 days'
                    group by sk.name having count(*) >= 3
                       and count(*) filter (where an.is_correct)::numeric / count(*) >= 0.85) s),
      'weak', (select coalesce(jsonb_agg(s.name order by s.acc), '[]'::jsonb) from (
                 select sk.name, count(*) filter (where an.is_correct)::numeric / count(*) acc
                   from public.answers an
                   join public.lesson_attempts a on a.id = an.attempt_id
                   join public.questions q on q.id = an.question_id
                   join public.lessons l on l.id = q.lesson_id
                   join public.skills sk on sk.code = q.skill
                  where a.profile_id = p_profile and l.course_id = c.id and an.answered_at > now() - interval '60 days'
                  group by sk.name having count(*) >= 3
                     and count(*) filter (where an.is_correct)::numeric / count(*) < 0.6) s),
      'to_review', (select coalesce(jsonb_agg(r.item order by r.at desc), '[]'::jsonb) from (
                      select left(case when q.payload ? 'audio' then (q.payload ->> 'audio') || ' = ' || q.correct_text
                                       else q.prompt || ' → ' || q.correct_text end, 90) item, z.at
                        from (select distinct on (an.question_id) an.question_id, an.is_correct, an.answered_at at
                                from public.answers an join public.lesson_attempts a on a.id = an.attempt_id
                               where a.profile_id = p_profile
                               order by an.question_id, an.answered_at desc) z
                        join public.questions q on q.id = z.question_id
                        join public.lessons l on l.id = q.lesson_id
                       where l.course_id = c.id and not z.is_correct
                       order by z.at desc limit 6) r)
    ) j
    from app.courses_for(p_profile) c) x
$$;

revoke all on function app.course_progress(uuid) from public, anon;

-- ---------------------------------------------------------------- lesson explanation
-- The explanation of a lesson of one of the profile's courses (null when the lesson has none),
-- with the course's speech language for the 🔊 buttons.
create or replace function public.lesson_intro(p_profile uuid, p_lesson text) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  v jsonb;
begin
  perform app.require_profile(p_profile);
  select jsonb_build_object('intro', l.intro, 'speech_lang', c.speech_lang, 'source_kind', c.source_kind,
                            'source_note', c.source_note)
    into v
    from public.lessons l join app.courses_for(p_profile) c on c.id = l.course_id
   where l.id = p_lesson and not l.archived;
  if v is null then perform app.fail('not_found'); end if;
  return v;
end $$;

revoke all on function public.lesson_intro(uuid, text) from public, anon;
grant execute on function public.lesson_intro(uuid, text) to authenticated;
