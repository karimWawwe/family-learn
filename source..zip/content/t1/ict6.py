# -*- coding: utf-8 -*-
"""ICT - Primary 6, Term 1 (Omar). Egypt MoE language schools, 2026/2027.

LESSON LIST: the Term-1 lesson titles of the Primary 6 ICT book (language schools), as listed
by the Egypt-curriculum classes on nagwa.com (two classes, same 12-session list) and matching the
table of contents of a 2027 study guide. The MoE e-library (ellibrary.moe.gov.eg) refused
access, so the BOOK PAGES WERE NOT READ: explanations and questions are written by the app on
each lesson's topic and must be checked against the book.
"""
from qh import QH

Q = QH("ict6.")

SKILLS = {
    "ict6.network": "Computer networks",
    "ict6.future": "Future technology",
    "ict6.access": "Technology for people with special needs",
    "ict6.search": "Digital search tools",
    "ict6.os": "Operating systems",
    "ict6.web": "Web design",
    "ict6.games": "Video games: fun and safety",
    "ict6.data": "Protecting my digital data",
    "ict6.cyber": "Cyber security",
    "ict6.money": "Online buying, selling and payment",
    "ict6.cloud": "Cloud computing and storage",
    "ict6.terms": "ICT terms",
}

NOTE = ("عناوين الدروس مطابقة لدروس الترم الأول في كتاب ICT للصف السادس (لغات) كما تعرضها منصة Nagwa للمنهج المصري. "
        "صفحات كتاب الوزارة لم تُقرأ (موقع مكتبة الوزارة رفض الوصول)، فالشرح والأسئلة من إعداد التطبيق وتحتاج مراجعة على الكتاب.")

COURSE = {
    "code": "ict-g6", "subject": "ict", "audience": "child", "grade_min": 6, "grade_max": 6,
    "title": "💻 ICT — Information and Communication Technology",
    "level": "Primary 6 · Term 1",
    "speech_lang": "en-US",
    "source_kind": "book_topics",
    "source_note": NOTE,
    "edition": "2026/2027 — الترم الأول",
    "units": [
        # ------------------------------------------------------------------ 1
        {"title": "Technology in our lives — التكنولوجيا في حياتنا", "lessons": [
            {"title": "Computer Networks — شبكات الحاسب", "minutes": 9,
             "intro": {
                 "goals": ["أعرف ما هي شبكة الحاسب وفوائدها", "أفرّق بين LAN وWAN", "أعرف دور الراوتر Router"],
                 "explain": "الشبكة (Network) هي جهازان أو أكثر متصلة ببعضها لتتبادل البيانات وتتشارك الموارد مثل الطابعة والملفات والإنترنت. "
                            "الشبكة المحلية LAN تغطي مكانًا صغيرًا مثل البيت أو المدرسة، والشبكة الواسعة WAN تغطي مدنًا ودولًا. "
                            "والإنترنت أكبر شبكة في العالم. يمكن أن يكون الاتصال سلكيًا (كابل) أو لاسلكيًا (Wi-Fi).",
                 "vocab": [
                     {"w": "Network", "ar": "شبكة: أجهزة متصلة تتبادل البيانات"},
                     {"w": "LAN (Local Area Network)", "ar": "شبكة محلية في مكان صغير"},
                     {"w": "WAN (Wide Area Network)", "ar": "شبكة واسعة بين مدن أو دول"},
                     {"w": "Router", "ar": "الراوتر: يوصل الأجهزة بالشبكة وبالإنترنت"},
                     {"w": "Wi-Fi", "ar": "اتصال لاسلكي بالشبكة"},
                     {"w": "Server", "ar": "الخادم: جهاز يقدّم خدمات وملفات لأجهزة أخرى"},
                 ],
                 "examples": ["أجهزة معمل الكمبيوتر في المدرسة المتصلة بطابعة واحدة = LAN",
                              "شبكة البنوك التي تربط فروعها في كل المحافظات = WAN"],
                 "activity": "اكتب أسماء 3 أجهزة في بيتك متصلة بالـ Wi-Fi.",
                 "summary": "Network = أجهزة متصلة · LAN صغيرة · WAN واسعة · الإنترنت أكبر شبكة · Router يوصلنا بالإنترنت",
             },
             "questions": [
                 Q.mc("network", "A computer network is:",
                      ["Two or more devices connected to share data", "One computer without internet", "A computer game", "A type of keyboard"], 0,
                      explain="الشبكة = جهازان أو أكثر متصلة لتبادل البيانات. (Network)"),
                 Q.mc("network", "The network in your school computer lab is a:", ["LAN", "WAN", "Website", "Browser"], 0,
                      explain="LAN = شبكة محلية في مكان صغير."),
                 Q.tf("network", "The Internet is the biggest network in the world.", True),
                 Q.mc("network", "Which device connects your home devices to the Internet?", ["Router", "Printer", "Speaker", "Scanner"], 0),
                 Q.match("terms", "Match the term with its meaning",
                         ["LAN", "WAN", "Wi-Fi"], ["Small area network", "Wide area network", "Wireless connection"]),
                 Q.mc("network", "One benefit of networks is:",
                      ["Sharing a printer between computers", "Making the screen bigger", "Charging the battery", "Cleaning the keyboard"], 0),
             ]},
            {"title": "Future Technology & Technology for People with Special Needs — تكنولوجيا المستقبل وذوو الهمم", "minutes": 9,
             "intro": {
                 "goals": ["أتعرف على أمثلة لتكنولوجيا المستقبل", "أعرف كيف تساعد التكنولوجيا ذوي الهمم"],
                 "explain": "من تكنولوجيا المستقبل: الذكاء الاصطناعي (AI) الذي يجعل الأجهزة تتعلم وتتخذ قرارات، "
                            "والروبوتات، والطباعة ثلاثية الأبعاد 3D Printing، والواقع الافتراضي VR، والمنازل الذكية Smart Homes. "
                            "والتكنولوجيا المساعدة تساعد ذوي الهمم: قارئ الشاشة Screen Reader يقرأ النص بصوت عالٍ لضعاف البصر، "
                            "وتحويل الكلام إلى نص Speech-to-text يساعد من لا يستطيع الكتابة، وشاشة برايل Braille display للمكفوفين.",
                 "vocab": [
                     {"w": "Artificial Intelligence (AI)", "ar": "الذكاء الاصطناعي"},
                     {"w": "Robot", "ar": "روبوت: آلة تنفذ مهامًا بالبرمجة"},
                     {"w": "Virtual Reality (VR)", "ar": "الواقع الافتراضي"},
                     {"w": "3D printer", "ar": "طابعة ثلاثية الأبعاد تصنع مجسمات"},
                     {"w": "Screen reader", "ar": "قارئ الشاشة لضعاف البصر"},
                     {"w": "Speech-to-text", "ar": "تحويل الكلام إلى نص مكتوب"},
                 ],
                 "examples": ["المساعد الصوتي في الهاتف يفهم كلامك = AI", "نظارة VR تجعلك تشعر أنك داخل متحف"],
                 "summary": "AI · Robots · VR · 3D printing · Smart homes — والتكنولوجيا المساعدة: Screen reader · Speech-to-text · Braille display",
             },
             "questions": [
                 Q.mc("future", "Technology that helps machines learn and make decisions is called:",
                      ["Artificial Intelligence", "A keyboard", "A cable", "A folder"], 0),
                 Q.mc("access", "A screen reader helps people who:", ["Can't see well", "Can't run", "Like games", "Have no internet"], 0,
                      explain="قارئ الشاشة يقرأ النصوص بصوت عالٍ لضعاف البصر."),
                 Q.mc("future", "Which device can make a real 3D model of a toy?", ["3D printer", "Mouse", "Speaker", "Router"], 0),
                 Q.tf("access", "Speech-to-text changes spoken words into written text.", True),
                 Q.match("future", "Match", ["VR headset", "Robot", "Smart home"],
                         ["Feel inside a virtual world", "Machine that does tasks", "House devices controlled by phone"]),
                 Q.tf("access", "Technology can only help people without disabilities.", False,
                      explain="التكنولوجيا المساعدة تساعد ذوي الهمم على التعلم والتواصل."),
             ]},
            {"title": "Digital Search Tools — أدوات البحث الرقمي", "minutes": 9,
             "intro": {
                 "goals": ["أستخدم محرك البحث بكلمات مفتاحية مناسبة", "أتأكد من صحة المعلومة ومصدرها"],
                 "explain": "محرك البحث Search Engine (مثل Google وBing) يبحث في مواقع الإنترنت. "
                            "نكتب كلمات مفتاحية Keywords قصيرة ومحددة بدل جملة طويلة. "
                            "وضع الكلمات بين علامتي تنصيص \"...\" يبحث عن العبارة نفسها بالضبط. "
                            "نستخدم الفلاتر (صور، أخبار، فيديو) لتضييق النتائج، ونتأكد أن المصدر موثوق ونقارن أكثر من مصدر.",
                 "vocab": [
                     {"w": "Search engine", "ar": "محرك البحث"},
                     {"w": "Keywords", "ar": "الكلمات المفتاحية"},
                     {"w": "Results", "ar": "نتائج البحث"},
                     {"w": "Reliable source", "ar": "مصدر موثوق"},
                     {"w": "Filter", "ar": "تصفية النتائج (صور، أخبار…)"},
                 ],
                 "examples": ["بدل «ما هو أطول نهر في قارة أفريقيا؟» اكتب: longest river Africa"],
                 "activity": "اكتب 3 كلمات مفتاحية للبحث عن «فوائد الطاقة الشمسية».",
                 "summary": "Search engine + Keywords قصيرة · \"...\" للعبارة الدقيقة · Filters · قارن المصادر",
             },
             "questions": [
                 Q.mc("search", "Which is a search engine?", ["Google", "Microsoft Word", "Paint", "Calculator"], 0),
                 Q.mc("search", "The best keywords to find the height of the Cairo Tower:",
                      ["Cairo Tower height", "I want to know something please", "tower", "Egypt"], 0,
                      explain="الكلمات المفتاحية الجيدة قصيرة ومحددة."),
                 Q.mc("search", "To search for an exact phrase, put it between:",
                      ["Quotation marks \" \"", "Brackets ( )", "Stars * *", "Nothing"], 0),
                 Q.tf("search", "Every website on the Internet gives correct information.", False,
                      explain="لازم نتأكد من المصدر ونقارن أكثر من موقع."),
                 Q.mc("search", "To see only pictures in the results, use the:", ["Images filter", "Delete key", "Printer", "Volume"], 0),
                 Q.order("search", "Put the search steps in order",
                         ["Open the search engine", "Type the keywords", "Press Enter", "Check the source of the result"]),
             ]},
            {"title": "How Operating Systems Work — كيف تعمل أنظمة التشغيل", "minutes": 9,
             "intro": {
                 "goals": ["أعرف وظيفة نظام التشغيل", "أذكر أمثلة لأنظمة التشغيل"],
                 "explain": "نظام التشغيل Operating System (OS) هو البرنامج الأساسي الذي يدير الجهاز: "
                            "يشغّل البرامج، وينظم الملفات والمجلدات، ويتحكم في المكونات (الذاكرة، الشاشة، لوحة المفاتيح)، "
                            "ويوفر واجهة نتعامل بها مع الجهاز. أمثلة: Windows وmacOS وLinux للحواسب، وAndroid وiOS للهواتف. "
                            "عند تشغيل الجهاز (Booting) يتم تحميل نظام التشغيل قبل باقي البرامج.",
                 "vocab": [
                     {"w": "Operating System (OS)", "ar": "نظام التشغيل"},
                     {"w": "Hardware", "ar": "المكونات المادية"},
                     {"w": "Software", "ar": "البرامج"},
                     {"w": "Booting", "ar": "إقلاع / بدء تشغيل الجهاز"},
                     {"w": "File / Folder", "ar": "ملف / مجلد"},
                     {"w": "Interface", "ar": "الواجهة التي نتعامل بها مع الجهاز"},
                 ],
                 "summary": "OS يدير الجهاز والبرامج والملفات · Windows / macOS / Linux / Android / iOS",
             },
             "questions": [
                 Q.mc("os", "Which of these is an operating system?", ["Android", "Keyboard", "Google", "Printer"], 0),
                 Q.mc("os", "The main job of the operating system is to:",
                      ["Manage the computer and run programs", "Print pictures only", "Clean the screen", "Make the computer heavier"], 0),
                 Q.match("os", "Match each device with an operating system it can use",
                         ["iPhone", "Laptop", "Android phone"], ["iOS", "Windows", "Android"]),
                 Q.tf("os", "When we turn on the computer, the operating system loads before our other programs.", True),
                 Q.mc("terms", "Programs like games and word processors are called:", ["Software", "Hardware", "Cables", "Routers"], 0),
                 Q.mc("os", "Where do we keep related files together?", ["In a folder", "In the speaker", "In the mouse", "In the cable"], 0),
             ]},
            {"title": "I'm a Web Designer — أنا مصمم مواقع", "minutes": 9,
             "intro": {
                 "goals": ["أعرف الفرق بين الموقع وصفحة الويب", "أتعرف على HTML والرابط Link والعنوان URL"],
                 "explain": "الموقع Website مجموعة صفحات ويب Web pages مرتبطة ببعضها. الصفحة الأولى اسمها Home page. "
                            "لكل موقع عنوان URL مثل www.example.com، ونفتحه بمتصفح Browser. "
                            "تُكتب صفحات الويب بلغة HTML، والروابط Links تنقلنا من صفحة لأخرى. "
                            "المصمم الجيد يجعل الموقع واضحًا وسهل الاستخدام ومناسبًا للهاتف والكمبيوتر.",
                 "vocab": [
                     {"w": "Website", "ar": "موقع إلكتروني"},
                     {"w": "Web page", "ar": "صفحة ويب"},
                     {"w": "Home page", "ar": "الصفحة الرئيسية"},
                     {"w": "URL", "ar": "عنوان الموقع"},
                     {"w": "Browser", "ar": "المتصفح (Chrome, Safari, Edge)"},
                     {"w": "HTML", "ar": "لغة كتابة صفحات الويب"},
                     {"w": "Link", "ar": "رابط ينقلك لصفحة أخرى"},
                 ],
                 "summary": "Website = صفحات · Home page · URL · Browser · HTML · Links",
             },
             "questions": [
                 Q.mc("web", "A website is:", ["A group of linked web pages", "One photo", "A computer part", "An operating system"], 0),
                 Q.mc("web", "We open websites using a:", ["Browser", "Printer", "Scanner", "Keyboard"], 0),
                 Q.mc("web", "Web pages are written in:", ["HTML", "Arabic numbers", "Paint", "Excel"], 0),
                 Q.mc("web", "The first page of a website is the:", ["Home page", "Last page", "Error page", "Folder"], 0),
                 Q.tf("web", "A link takes you from one page to another.", True),
                 Q.match("terms", "Match", ["URL", "Browser", "Link"], ["Website address", "Program to open websites", "Click to go to another page"]),
             ]},
            {"title": "Unit 1 review — مراجعة الوحدة الأولى", "minutes": 10,
             "intro": {"summary": "راجع: Networks · Future technology · Search tools · Operating systems · Web design"},
             "questions": [
                 Q.mc("network", "A network that connects branches of a company in different countries is a:", ["WAN", "LAN", "URL", "Folder"], 0),
                 Q.mc("access", "Which helps a blind student read digital text?", ["Screen reader / Braille display", "VR game", "Router", "3D printer"], 0),
                 Q.mc("search", "Which search is better?", ["solar energy benefits", "please tell me everything about energy", "a", "website"], 0),
                 Q.mc("os", "iOS is used on:", ["iPhone", "Printer", "Router", "Speaker"], 0),
                 Q.tf("web", "HTML is used to write web pages.", True),
                 Q.match("terms", "Match", ["AI", "OS", "LAN"], ["Machines that learn", "Manages the computer", "Network in one building"]),
                 Q.tf("search", "We should check more than one source.", True),
             ]},
        ]},
        # ------------------------------------------------------------------ 2
        {"title": "Safe in the digital world — الأمان في العالم الرقمي", "lessons": [
            {"title": "The World of Video Games: Fun and Safety — ألعاب الفيديو بأمان", "minutes": 9,
             "intro": {
                 "goals": ["أختار ألعابًا مناسبة لعمري", "ألعب بأمان وبوقت محدد"],
                 "explain": "ألعاب الفيديو ممتعة وتنمّي التفكير، لكن لها قواعد أمان: "
                            "نختار ألعابًا مناسبة لعمرنا (تصنيف العمر Age rating)، ونحدد وقت اللعب ونأخذ استراحة، "
                            "ولا نشارك معلوماتنا الشخصية مع لاعبين غرباء، ولا نشتري شيئًا داخل اللعبة (In-game purchases) دون إذن الوالدين، "
                            "ونبلغ شخصًا كبيرًا إذا ضايقنا أحد في اللعبة.",
                 "vocab": [
                     {"w": "Age rating", "ar": "تصنيف العمر المناسب للعبة"},
                     {"w": "Screen time", "ar": "وقت استخدام الشاشة"},
                     {"w": "In-game purchase", "ar": "الشراء داخل اللعبة"},
                     {"w": "Personal information", "ar": "المعلومات الشخصية (الاسم الكامل، العنوان، رقم الهاتف…)"},
                     {"w": "Report / Block", "ar": "الإبلاغ / الحظر"},
                 ],
                 "summary": "لعبة مناسبة لعمري · وقت محدد · لا معلومات شخصية · لا شراء بدون إذن · أبلّغ الكبار",
             },
             "questions": [
                 Q.mc("games", "Before playing a new game, check its:", ["Age rating", "Colour", "Price of the screen", "Keyboard"], 0),
                 Q.mc("games", "A player you don't know asks for your home address. You:",
                      ["Don't share it and tell an adult", "Send it quickly", "Send your phone number", "Share your password"], 0),
                 Q.tf("games", "You can buy things inside a game without asking your parents.", False),
                 Q.tf("games", "Taking breaks from screens is good for your eyes and body.", True),
                 Q.mc("games", "Someone is bullying you in an online game. The best action:",
                      ["Block, report and tell an adult", "Bully them back", "Give them your password", "Keep it secret"], 0),
             ]},
            {"title": "Protecting My Digital Data — حماية بياناتي الرقمية", "minutes": 9,
             "intro": {
                 "goals": ["أنشئ كلمة مرور قوية", "أحمي بياناتي بالنسخ الاحتياطي والتحديث"],
                 "explain": "البيانات الرقمية مثل الصور والملفات والحسابات يجب حمايتها. "
                            "كلمة المرور القوية Strong password طويلة (8 رموز أو أكثر) وتجمع حروفًا كبيرة وصغيرة وأرقامًا ورموزًا، "
                            "ولا تكون اسمك أو تاريخ ميلادك، ولا نشاركها مع أحد إلا الوالدين. "
                            "النسخ الاحتياطي Backup يحفظ نسخة من ملفاتك، وبرنامج مكافحة الفيروسات Antivirus وتحديث البرامج Updates يحميان الجهاز.",
                 "vocab": [
                     {"w": "Strong password", "ar": "كلمة مرور قوية"},
                     {"w": "Backup", "ar": "نسخة احتياطية"},
                     {"w": "Antivirus", "ar": "برنامج مكافحة الفيروسات"},
                     {"w": "Update", "ar": "تحديث البرنامج"},
                     {"w": "Two-step verification", "ar": "التحقق بخطوتين"},
                 ],
                 "summary": "كلمة مرور قوية وسرية · Backup · Antivirus · Updates · التحقق بخطوتين",
             },
             "questions": [
                 Q.mc("data", "Which password is the strongest?", ["Tg7#mP2x!q", "123456", "omar", "password"], 0),
                 Q.tf("data", "It is OK to share your password with your friends.", False,
                      explain="كلمة المرور سرية، نشاركها مع الوالدين فقط."),
                 Q.mc("data", "Keeping a copy of your files in another place is called:", ["Backup", "Delete", "Print", "Zoom"], 0),
                 Q.mc("data", "A program that protects the computer from viruses:", ["Antivirus", "Paint", "Browser", "Calculator"], 0),
                 Q.tf("data", "Updating programs helps fix security problems.", True),
                 Q.match("data", "Match", ["Backup", "Strong password", "Two-step verification"],
                         ["Copy of your files", "Long and hard to guess", "A code + your password"]),
             ]},
            {"title": "Be a Cyber Security Hero — كن بطل الأمن السيبراني", "minutes": 9,
             "intro": {
                 "goals": ["أتعرف على الفيروسات والرسائل المزيفة (Phishing)", "أعرف ماذا أفعل عند الشك"],
                 "explain": "الأمن السيبراني Cyber security هو حماية الأجهزة والبيانات من الهجمات. "
                            "البرامج الضارة Malware (مثل الفيروسات) قد تدخل من ملفات أو روابط مجهولة. "
                            "التصيد Phishing رسالة مزيفة تطلب كلمة المرور أو معلومات شخصية أو تقول «لقد ربحت جائزة!». "
                            "البطل لا يضغط على روابط مجهولة، ولا يفتح ملفات من غرباء، ويخبر شخصًا كبيرًا.",
                 "vocab": [
                     {"w": "Cyber security", "ar": "الأمن السيبراني"},
                     {"w": "Malware / Virus", "ar": "برنامج ضار / فيروس"},
                     {"w": "Phishing", "ar": "التصيد: رسالة مزيفة لسرقة البيانات"},
                     {"w": "Hacker", "ar": "مخترق"},
                     {"w": "Suspicious link", "ar": "رابط مشبوه"},
                 ],
                 "summary": "لا روابط مجهولة · لا ملفات من غرباء · لا أعطي كلمة المرور · أخبر الكبار",
             },
             "questions": [
                 Q.mc("cyber", "A message says: \"You won a free phone! Enter your password here.\" This is:",
                      ["Phishing", "A good offer", "An update", "A backup"], 0),
                 Q.mc("cyber", "What should you do with a link from someone you don't know?",
                      ["Don't click it and tell an adult", "Click it fast", "Send it to all friends", "Enter your password"], 0),
                 Q.tf("cyber", "A virus is a harmful program.", True),
                 Q.mc("cyber", "Cyber security means:", ["Protecting devices and data", "Playing online games", "Drawing on the computer", "Printing files"], 0),
                 Q.tf("cyber", "It is safe to open a file sent by a stranger.", False,
                      explain="الملفات من الغرباء قد تحتوي على فيروس. لا نفتحها ونخبر شخصًا كبيرًا."),
             ]},
            {"title": "Online Financial Trading — البيع والشراء والدفع الإلكتروني", "minutes": 9,
             "intro": {
                 "goals": ["أعرف معنى التجارة الإلكترونية والدفع الإلكتروني", "أعرف قواعد الأمان عند الشراء أونلاين"],
                 "explain": "التجارة الإلكترونية E-commerce هي البيع والشراء عبر الإنترنت. "
                            "ونستطيع الدفع إلكترونيًا بالبطاقة البنكية أو المحفظة الإلكترونية E-wallet. "
                            "قواعد الأمان: الشراء يكون مع ولي الأمر وبإذنه، ومن مواقع معروفة وموثوقة يبدأ عنوانها بـ https وبجانبه رمز القفل 🔒 — لكن https والقفل يعنيان أن الاتصال مشفّر فقط، ولا يضمنان أن الموقع صادق، "
                            "ولا نشارك بيانات البطاقة أو كلمات المرور أبدًا، ونحذر من العروض التي تبدو أجمل من الحقيقة.",
                 "vocab": [
                     {"w": "E-commerce", "ar": "التجارة الإلكترونية"},
                     {"w": "Online payment", "ar": "الدفع الإلكتروني"},
                     {"w": "E-wallet", "ar": "المحفظة الإلكترونية"},
                     {"w": "https / 🔒", "ar": "علامة الاتصال الآمن بالموقع"},
                     {"w": "Scam", "ar": "احتيال"},
                 ],
                 "summary": "E-commerce · Online payment · https 🔒 · بإذن الوالدين · لا أشارك بيانات البطاقة",
             },
             "questions": [
                 Q.mc("money", "Buying and selling on the Internet is called:", ["E-commerce", "Backup", "Booting", "HTML"], 0),
                 Q.mc("money", "A secure (encrypted) connection is shown when the address starts with:", ["https", "abc", "www.free", "123"], 0),
                 Q.tf("money", "Children should shop online only with a parent's permission.", True),
                 Q.mc("money", "A website sells a new phone for 10 pounds only! This may be:", ["A scam", "Normal", "An update", "A network"], 0,
                      explain="العرض الذي يبدو أجمل من الحقيقة قد يكون احتيالًا."),
                 Q.tf("money", "You can send your parent's card number to anyone who asks online.", False),
             ]},
            {"title": "Cloud Computing & Cloud Storage — الحوسبة السحابية", "minutes": 9,
             "intro": {
                 "goals": ["أعرف معنى الحوسبة السحابية", "أذكر أمثلة لتطبيقات التخزين السحابي ومزاياها"],
                 "explain": "الحوسبة السحابية Cloud computing هي استخدام برامج ومساحات تخزين موجودة على خوادم عبر الإنترنت بدل جهازك. "
                            "التخزين السحابي Cloud storage مثل Google Drive وOneDrive وiCloud وDropbox يحفظ ملفاتك أونلاين. "
                            "المزايا: الوصول لملفاتك من أي جهاز، ومشاركتها بسهولة، وعدم ضياعها إذا تلف الجهاز. "
                            "ونحتاج اتصالًا بالإنترنت وكلمة مرور قوية.",
                 "vocab": [
                     {"w": "Cloud computing", "ar": "الحوسبة السحابية"},
                     {"w": "Cloud storage", "ar": "التخزين السحابي"},
                     {"w": "Upload", "ar": "رفع ملف إلى السحابة"},
                     {"w": "Download", "ar": "تنزيل ملف إلى جهازك"},
                     {"w": "Share", "ar": "مشاركة"},
                 ],
                 "summary": "Cloud = خوادم عبر الإنترنت · Google Drive / OneDrive / iCloud · من أي جهاز · يحتاج إنترنت",
             },
             "questions": [
                 Q.mc("cloud", "Which is a cloud storage app?", ["Google Drive", "Calculator", "Paint", "Keyboard"], 0),
                 Q.mc("cloud", "One advantage of cloud storage:", ["Open your files from any device", "No need for Internet ever", "Makes files disappear", "Breaks the computer"], 0),
                 Q.mc("cloud", "Sending a file from your device to the cloud is:", ["Upload", "Download", "Delete", "Print"], 0),
                 Q.tf("cloud", "You usually need an Internet connection to use the cloud.", True),
                 Q.match("cloud", "Match", ["Upload", "Download", "Share"],
                         ["Device → cloud", "Cloud → device", "Let others see the file"]),
             ]},
            {"title": "Unit 2 review — مراجعة الوحدة الثانية", "minutes": 10,
             "intro": {"summary": "راجع: Video games safety · Protecting data · Cyber security · Online payment · Cloud"},
             "questions": [
                 Q.mc("data", "Which is a strong password?", ["S@fe2026Home!", "omar2014", "11111111", "abc"], 0),
                 Q.mc("cyber", "An email asks for your password to \"fix your account\". You should:",
                      ["Not reply and tell an adult", "Send the password", "Click every link", "Forward it to friends"], 0),
                 Q.mc("games", "Good gaming habit:", ["Set a time limit", "Play all night", "Talk to strangers about your school", "Buy items secretly"], 0),
                 Q.mc("money", "The padlock 🔒 next to a website address means:", ["The connection is secure", "The site is closed", "The site is a game", "No internet"], 0),
                 Q.mc("cloud", "OneDrive and iCloud are examples of:", ["Cloud storage", "Operating systems", "Search engines", "Viruses"], 0),
                 Q.tf("data", "A backup protects your files if your device is lost.", True),
                 Q.match("terms", "Match", ["Phishing", "Malware", "E-commerce"],
                         ["Fake message to steal data", "Harmful program", "Buying online"]),
             ]},
        ]},
    ],
}
