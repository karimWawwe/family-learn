# -*- coding: utf-8 -*-
"""Small helpers to write question lists (used by fr3, fr6, ict3, ict6).

    Q = QH("fr3.")
    Q.mc("greet", "prompt", ["a", "b"], 0, explain="...", audio="Bonjour")

`audio` = text the app reads aloud (🔊) with the course's speech language
(fr-FR for French). Lesson intros are plain dicts:
    {"goals": [...], "explain": "...", "vocab": [{"w": "Bonjour", "ar": "...", "say": "بونجور"}],
     "examples": [...], "activity": "...", "summary": "..."}
"""


class QH:
    def __init__(self, prefix):
        self.p = prefix

    def _extra(self, q, explain, hint, audio):
        if explain:
            q["explain"] = explain
        if hint:
            q["hint"] = hint
        if audio:
            q["audio"] = audio
        return q

    def mc(self, skill, prompt, options, answer, explain=None, hint=None, audio=None):
        return self._extra({"t": "mc", "skill": self.p + skill, "prompt": prompt, "options": options,
                            "answer": answer}, explain, hint, audio)

    def tf(self, skill, prompt, answer, explain=None, hint=None, audio=None):
        return self._extra({"t": "tf", "skill": self.p + skill, "prompt": prompt, "answer": answer},
                           explain, hint, audio)

    def match(self, skill, prompt, left, right, audio=None):
        return self._extra({"t": "match", "skill": self.p + skill, "prompt": prompt, "left": left,
                            "right": right}, None, None, audio)

    def order(self, skill, prompt, items, explain=None, audio=None):
        return self._extra({"t": "order", "skill": self.p + skill, "prompt": prompt, "order": items},
                           explain, None, audio)

    def drag(self, skill, prompt, before, after, tokens, answer, explain=None, hint=None, audio=None):
        return self._extra({"t": "drag", "skill": self.p + skill, "prompt": prompt, "before": before,
                            "after": after, "tokens": tokens, "answer": answer}, explain, hint, audio)

    def read(self, skill, prompt, passage, options, answer, explain=None, audio=None):
        return self._extra({"t": "read", "skill": self.p + skill, "prompt": prompt, "passage": passage,
                            "options": options, "answer": answer}, explain, None, audio)

    def listen(self, skill, audio, options, answer, prompt="🔊 استمع واختر ما سمعت:", explain=None):
        """Listening: the app reads `audio` aloud, the child picks what they heard / its meaning."""
        return self.mc(skill, prompt, options, answer, explain=explain, audio=audio)
