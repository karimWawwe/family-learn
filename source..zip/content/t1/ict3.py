# -*- coding: utf-8 -*-
"""ICT - Primary 3 (Yassin). SUPPLEMENTARY course written by the app.

In the Egyptian primary curriculum (Education 2.0) ICT starts in Primary 4: the Egypt-curriculum
classes on nagwa.com list ICT for Primary 4, 5 and 6 and none for Primary 3, and no MoE ICT book
for Primary 3 was found. This is a gentle starter path for a 9-year-old: computer parts, input /
output devices, mouse and keyboard, devices around us, staying safe online and thinking like a
programmer (steps, order, repeat, fixing mistakes). English terms with Arabic explanations,
like the Primary 4 language-schools book does.
"""
from qh import QH

Q = QH("ict3.")

SKILLS = {
    "ict3.parts": "Computer parts",
    "ict3.io": "Input and output devices",
    "ict3.mouse": "Using the mouse",
    "ict3.keys": "Using the keyboard",
    "ict3.devices": "Digital devices",
    "ict3.care": "Using devices well",
    "ict3.safe": "Staying safe online",
    "ict3.kind": "Being kind online",
    "ict3.algo": "Steps and order (algorithms)",
    "ict3.loop": "Repeat (loops)",
    "ict3.debug": "Finding mistakes (debugging)",
}

COURSE = {
    "code": "ict-g3", "subject": "ict", "audience": "child", "grade_min": 3, "grade_max": 3,
    "title": "💻 ICT — Information and Communication Technology",
    "level": "Primary 3 · مسار إضافي",
    "speech_lang": "en-US",
    "source_kind": "supplementary",
    "source_note": "مسار إضافي من إعداد التطبيق. مادة ICT في المنهج المصري (التعليم 2.0) تبدأ من الصف الرابع الابتدائي، "
                   "ولم يُعثر على كتاب وزارة ICT للصف الثالث. المسار تمهيدي: الحاسب ومكوناته، الأمان على الإنترنت، والتفكير البرمجي.",
    "edition": "2026/2027",
    "units": [
        # ------------------------------------------------------------------ 1
        {"title": "My computer — جهازي", "lessons": [
            {"title": "Parts of the computer — أجزاء الحاسب", "minutes": 7,
             "intro": {
                 "goals": ["أسمّي أجزاء الحاسب بالإنجليزية", "أعرف وظيفة كل جزء"],
                 "explain": "الحاسب له أجزاء: الشاشة Monitor نرى عليها الصور والكلام، لوحة المفاتيح Keyboard نكتب بها، "
                            "الفأرة Mouse نحرّك بها السهم ونضغط، وصندوق الحاسب System unit فيه «عقل» الجهاز، "
                            "والسماعات Speakers نسمع منها الصوت.",
                 "vocab": [
                     {"w": "Monitor", "ar": "الشاشة 🖥️"},
                     {"w": "Keyboard", "ar": "لوحة المفاتيح ⌨️"},
                     {"w": "Mouse", "ar": "الفأرة 🖱️"},
                     {"w": "System unit", "ar": "صندوق الحاسب"},
                     {"w": "Speakers", "ar": "السماعات 🔈"},
                     {"w": "Printer", "ar": "الطابعة 🖨️"},
                 ],
                 "activity": "أشِر إلى كل جزء في حاسب البيت أو المدرسة وقل اسمه بالإنجليزية.",
                 "summary": "Monitor · Keyboard · Mouse · System unit · Speakers · Printer",
             },
             "questions": [
                 Q.match("parts", "Match the word with the picture", ["Monitor", "Keyboard", "Mouse", "Printer"],
                         ["🖥️", "⌨️", "🖱️", "🖨️"]),
                 Q.mc("parts", "We type words with the:", ["Keyboard", "Monitor", "Speakers", "Printer"], 0,
                      explain="لوحة المفاتيح Keyboard للكتابة."),
                 Q.mc("parts", "We see pictures and words on the:", ["Monitor", "Mouse", "Keyboard", "Speakers"], 0),
                 Q.mc("parts", "We hear sounds from the:", ["Speakers", "Mouse", "Monitor", "Keyboard"], 0),
                 Q.tf("parts", "The printer puts our work on paper.", True),
             ]},
            {"title": "Input and output — إدخال وإخراج", "minutes": 8,
             "intro": {
                 "goals": ["أفرّق بين أجهزة الإدخال وأجهزة الإخراج"],
                 "explain": "أجهزة الإدخال Input devices ندخل بها المعلومات إلى الحاسب: لوحة المفاتيح، الفأرة، الميكروفون، الكاميرا. "
                            "أجهزة الإخراج Output devices يعطينا الحاسب النتيجة من خلالها: الشاشة، السماعات، الطابعة.",
                 "vocab": [
                     {"w": "Input", "ar": "إدخال: من المستخدم إلى الحاسب"},
                     {"w": "Output", "ar": "إخراج: من الحاسب إلى المستخدم"},
                     {"w": "Microphone", "ar": "الميكروفون 🎤 (إدخال)"},
                     {"w": "Camera", "ar": "الكاميرا 📷 (إدخال)"},
                 ],
                 "summary": "Input: Keyboard · Mouse · Microphone · Camera — Output: Monitor · Speakers · Printer",
             },
             "questions": [
                 Q.mc("io", "Which is an input device?", ["Keyboard", "Monitor", "Speakers", "Printer"], 0),
                 Q.mc("io", "Which is an output device?", ["Printer", "Mouse", "Microphone", "Camera"], 0),
                 Q.tf("io", "A microphone is an input device.", True, explain="الميكروفون يدخل صوتنا إلى الحاسب."),
                 Q.tf("io", "Speakers are input devices.", False, explain="السماعات تُخرج الصوت: Output."),
                 Q.match("io", "Input or output?", ["Microphone 🎤", "Printer 🖨️"], ["Input device", "Output device"]),
             ]},
            {"title": "Mouse and keyboard — الفأرة ولوحة المفاتيح", "minutes": 8,
             "intro": {
                 "goals": ["أعرف حركات الفأرة", "أعرف مفاتيح مهمة في لوحة المفاتيح"],
                 "explain": "Click ضغطة واحدة للاختيار، Double-click ضغطتان سريعتان لفتح ملف أو برنامج، "
                            "Drag السحب: نضغط ونحرك الشيء ثم نترك. "
                            "مفاتيح مهمة: Space مسافة بين الكلمات، Enter سطر جديد أو تأكيد، Backspace يمسح الحرف الذي قبل المؤشر، "
                            "Shift لكتابة حرف كبير.",
                 "vocab": [
                     {"w": "Click", "ar": "نقرة"}, {"w": "Double-click", "ar": "نقرتان سريعتان"},
                     {"w": "Drag", "ar": "سحب"}, {"w": "Space bar", "ar": "مفتاح المسافة"},
                     {"w": "Enter", "ar": "إدخال / سطر جديد"}, {"w": "Backspace", "ar": "مسح للخلف"},
                     {"w": "Shift", "ar": "لحرف كبير"},
                 ],
                 "summary": "Click · Double-click · Drag — Space · Enter · Backspace · Shift",
             },
             "questions": [
                 Q.mc("mouse", "To open a program on the desktop, we usually:", ["Double-click", "Shout", "Turn off", "Drag the screen"], 0),
                 Q.mc("keys", "Which key deletes the letter before the cursor?", ["Backspace", "Space bar", "Shift", "Enter"], 0),
                 Q.mc("keys", "Which key makes a space between words?", ["Space bar", "Backspace", "Enter", "Shift"], 0),
                 Q.mc("keys", "To write a capital letter like \"A\", hold:", ["Shift", "Enter", "Space bar", "Backspace"], 0),
                 Q.tf("mouse", "Drag means: press, move, then let go.", True),
                 Q.match("keys", "Match", ["Enter", "Backspace", "Space bar"], ["New line", "Delete", "Space"]),
             ]},
            {"title": "Unit 1 review — مراجعة الوحدة الأولى", "minutes": 8,
             "intro": {"summary": "راجع: أجزاء الحاسب · Input / Output · الفأرة ولوحة المفاتيح"},
             "questions": [
                 Q.mc("parts", "The \"brain\" of the computer is inside the:", ["System unit", "Mouse", "Speakers", "Printer"], 0),
                 Q.mc("io", "Which one is OUTPUT?", ["Monitor", "Keyboard", "Mouse", "Camera"], 0),
                 Q.mc("keys", "You finished a line and want a new one. Press:", ["Enter", "Shift", "Backspace", "Space bar"], 0),
                 Q.tf("io", "A camera puts pictures into the computer, so it is an input device.", True),
                 Q.match("parts", "Match", ["Mouse", "Speakers", "Keyboard"], ["Click and point", "Hear sounds", "Type letters"]),
             ]},
        ]},
        # ------------------------------------------------------------------ 2
        {"title": "Devices around us — أجهزة حولنا", "lessons": [
            {"title": "Digital devices — الأجهزة الرقمية", "minutes": 7,
             "intro": {
                 "goals": ["أتعرف على الأجهزة الرقمية حولي واستخداماتها"],
                 "explain": "الأجهزة الرقمية كثيرة: الحاسب المكتبي Desktop، الحاسب المحمول Laptop، الجهاز اللوحي Tablet، "
                            "الهاتف الذكي Smartphone، التلفاز الذكي Smart TV، والساعة الذكية Smartwatch. "
                            "نستخدمها للتعلم والتواصل واللعب والعمل.",
                 "vocab": [
                     {"w": "Laptop", "ar": "حاسب محمول 💻"}, {"w": "Tablet", "ar": "جهاز لوحي"},
                     {"w": "Smartphone", "ar": "هاتف ذكي 📱"}, {"w": "Smart TV", "ar": "تلفاز ذكي 📺"},
                     {"w": "Smartwatch", "ar": "ساعة ذكية ⌚"},
                 ],
                 "summary": "Desktop · Laptop · Tablet · Smartphone · Smart TV · Smartwatch",
             },
             "questions": [
                 Q.match("devices", "Match", ["Laptop", "Smartphone", "Smartwatch", "Smart TV"], ["💻", "📱", "⌚", "📺"]),
                 Q.mc("devices", "A computer we can carry and open like a book:", ["Laptop", "Desktop", "Printer", "Speaker"], 0),
                 Q.mc("devices", "Which device do we wear on the wrist?", ["Smartwatch", "Tablet", "Monitor", "Mouse"], 0),
                 Q.tf("devices", "We can use digital devices to learn.", True),
                 Q.mc("devices", "We call our grandmother with a:", ["Smartphone", "Mouse", "Printer", "Keyboard"], 0),
             ]},
            {"title": "Using devices well — أستخدم الأجهزة بشكل صحيح", "minutes": 7,
             "intro": {
                 "goals": ["أحافظ على جهازي", "أجلس جلسة صحيحة وأحدد وقت الشاشة"],
                 "explain": "نحافظ على الأجهزة: لا نأكل أو نشرب بجانبها، نغلقها بالطريقة الصحيحة (Shut down)، ونمسك الجهاز بيدين. "
                            "ونحافظ على صحتنا: نجلس وظهرنا مستقيم، والشاشة على بعد مناسب من العين، ونأخذ استراحة، "
                            "ونلتزم بوقت الشاشة الذي يحدده الوالدان.",
                 "vocab": [
                     {"w": "Shut down", "ar": "إيقاف التشغيل بشكل صحيح"},
                     {"w": "Screen time", "ar": "وقت الشاشة"},
                     {"w": "Break", "ar": "استراحة"},
                 ],
                 "summary": "لا طعام ولا شراب بجانب الجهاز · Shut down صحيح · ظهر مستقيم · استراحة · وقت محدد",
             },
             "questions": [
                 Q.tf("care", "It is OK to drink juice next to the keyboard.", False, explain="العصير قد ينسكب ويتلف الجهاز."),
                 Q.mc("care", "After using the computer for a long time, we should:", ["Take a break", "Sit closer to the screen", "Skip sleep", "Eat on the keyboard"], 0),
                 Q.mc("care", "The right way to turn off the computer:", ["Shut down", "Pull the cable", "Hit the screen", "Close the eyes"], 0),
                 Q.tf("care", "We should sit with a straight back.", True),
                 Q.tf("care", "We decide our screen time without our parents.", False),
             ]},
            {"title": "Unit 2 review — مراجعة الوحدة الثانية", "minutes": 7,
             "intro": {"summary": "راجع: الأجهزة الرقمية · العناية بالجهاز · وقت الشاشة"},
             "questions": [
                 Q.mc("devices", "A tablet is:", ["A flat touch-screen device", "A kind of printer", "A keyboard key", "A speaker"], 0),
                 Q.tf("care", "We hold a tablet with two hands.", True),
                 Q.mc("care", "Too much screen time can hurt our:", ["Eyes", "Shoes", "Books", "Pencils"], 0),
                 Q.match("devices", "Match", ["Desktop", "Smartphone", "Tablet"], ["Big computer on a desk", "Phone with apps", "Touch screen like a board"]),
             ]},
        ]},
        # ------------------------------------------------------------------ 3
        {"title": "Safe online — آمن على الإنترنت", "lessons": [
            {"title": "My personal information — معلوماتي الشخصية", "minutes": 7,
             "intro": {
                 "goals": ["أعرف ما هي المعلومات الشخصية", "لا أشاركها مع الغرباء"],
                 "explain": "المعلومات الشخصية Personal information مثل: اسمي الكامل، عنواني، رقم هاتفي، اسم مدرستي، كلمة المرور، صوري. "
                            "لا أشاركها مع أحد على الإنترنت، وأسأل والديّ قبل أي شيء.",
                 "vocab": [
                     {"w": "Personal information", "ar": "المعلومات الشخصية"},
                     {"w": "Password", "ar": "كلمة المرور (سرّ)"},
                     {"w": "Stranger", "ar": "شخص غريب"},
                     {"w": "Trusted adult", "ar": "شخص كبير أثق به (أبي، أمي، معلمي)"},
                 ],
                 "summary": "لا أشارك: الاسم الكامل · العنوان · الهاتف · المدرسة · كلمة المرور · الصور",
             },
             "questions": [
                 Q.mc("safe", "Which is personal information?", ["My home address", "The colour blue", "A cartoon name", "The number 5"], 0),
                 Q.mc("safe", "Someone online asks for your password. You:",
                      ["Say no and tell a trusted adult", "Give it to them", "Give half of it", "Change your name"], 0),
                 Q.tf("safe", "I can send my photo to a stranger online.", False),
                 Q.tf("safe", "I tell my parents if something online makes me feel bad.", True),
                 Q.mc("safe", "A trusted adult is:", ["My mother or father", "A stranger in a game", "A pop-up message", "An unknown caller"], 0),
             ]},
            {"title": "Be kind online — كن لطيفًا على الإنترنت", "minutes": 7,
             "intro": {
                 "goals": ["أتصرف بأدب على الإنترنت", "أعرف ماذا أفعل مع الرسائل المؤذية والإعلانات المنبثقة"],
                 "explain": "على الإنترنت نكون لطفاء كما في الحقيقة: نكتب كلامًا طيبًا، ولا نسخر من أحد. "
                            "إذا وصلتنا رسالة مؤذية لا نرد بالمثل، بل نخبر شخصًا كبيرًا. "
                            "وإذا ظهرت نافذة Pop-up تقول «اضغط هنا لتربح» لا نضغط عليها.",
                 "vocab": [
                     {"w": "Kind", "ar": "لطيف"}, {"w": "Mean message", "ar": "رسالة مؤذية"},
                     {"w": "Pop-up", "ar": "نافذة منبثقة / إعلان"},
                 ],
                 "summary": "أكتب كلامًا طيبًا · لا أرد على الإساءة · أخبر الكبار · لا أضغط على Pop-ups",
             },
             "questions": [
                 Q.mc("kind", "Your friend shares a drawing online. A kind comment:",
                      ["Nice work! I like the colours.", "This is ugly.", "Nobody likes it.", "Delete it."], 0),
                 Q.mc("kind", "Someone sends you a mean message. You:", ["Tell a trusted adult", "Send a mean message back", "Share it with everyone", "Keep it secret forever"], 0),
                 Q.tf("safe", "A pop-up says \"Click here to win a prize!\" — I should click it.", False),
                 Q.tf("kind", "We should be polite online, just like in real life.", True),
             ]},
            {"title": "Unit 3 review — مراجعة الوحدة الثالثة", "minutes": 7,
             "intro": {"summary": "راجع: المعلومات الشخصية · اللطف على الإنترنت · الشخص الكبير الموثوق"},
             "questions": [
                 Q.mc("safe", "Which is safe to share with a stranger online?", ["My favourite colour", "My password", "My address", "My phone number"], 0),
                 Q.tf("safe", "My password is a secret. I only share it with my parents.", True),
                 Q.mc("kind", "Good online behaviour:", ["Using kind words", "Laughing at others", "Sharing other people's photos", "Using bad words"], 0),
                 Q.mc("safe", "Something online scares you. First:", ["Tell a trusted adult", "Hide it", "Send it to friends", "Click more"], 0),
             ]},
        ]},
        # ------------------------------------------------------------------ 4
        {"title": "Think like a programmer — أفكر كمبرمج", "lessons": [
            {"title": "Steps in order — الخطوات بالترتيب (Algorithm)", "minutes": 8,
             "intro": {
                 "goals": ["أعرف أن الخوارزمية Algorithm خطوات مرتبة لحل مشكلة", "أرتّب خطوات مهمة يومية"],
                 "explain": "الحاسب لا يفكر وحده؛ ينفّذ الأوامر خطوة خطوة. الخوارزمية Algorithm قائمة خطوات مرتبة لعمل شيء. "
                            "إذا تغيّر الترتيب قد لا تنجح المهمة: لا نلبس الحذاء قبل الجورب!",
                 "vocab": [
                     {"w": "Algorithm", "ar": "خوارزمية: خطوات مرتبة"},
                     {"w": "Step", "ar": "خطوة"},
                     {"w": "Order / Sequence", "ar": "الترتيب / التسلسل"},
                     {"w": "Instruction / Command", "ar": "أمر"},
                 ],
                 "examples": ["غسل اليدين: افتح الصنبور ← ضع الصابون ← افرك يديك ← اشطفهما ← جففهما"],
                 "summary": "Algorithm = خطوات بالترتيب · الترتيب مهم",
             },
             "questions": [
                 Q.mc("algo", "An algorithm is:", ["Steps in the right order", "A computer mouse", "A colour", "A game prize"], 0),
                 Q.order("algo", "Put the steps in order: brushing teeth",
                         ["Pick up your toothbrush", "Put toothpaste on the brush", "Brush your teeth", "Rinse your mouth"]),
                 Q.order("algo", "Put the steps in order: planting a seed",
                         ["Dig a small hole", "Put the seed in", "Cover it with soil", "Water it"]),
                 Q.tf("algo", "The order of the steps does not matter.", False, explain="الترتيب مهم جدًا في الخوارزمية."),
                 Q.mc("algo", "A computer follows instructions:", ["Step by step", "Randomly", "Only on Fridays", "Without any order"], 0),
             ]},
            {"title": "Moving the robot — نحرّك الروبوت", "minutes": 8,
             "intro": {
                 "goals": ["أعطي أوامر حركة واضحة", "أستخدم التكرار Repeat"],
                 "explain": "نستطيع أن نوجّه روبوتًا بأوامر: Move forward (تقدّم خطوة)، Turn left (استدر يسارًا)، Turn right (استدر يمينًا). "
                            "إذا تكرر نفس الأمر نستخدم Repeat: بدل كتابة «تقدّم» 4 مرات نكتب Repeat 4 → Move forward. "
                            "وهذا اسمه حلقة تكرار Loop.",
                 "vocab": [
                     {"w": "Move forward", "ar": "تقدّم للأمام"}, {"w": "Turn left", "ar": "استدر يسارًا"},
                     {"w": "Turn right", "ar": "استدر يمينًا"}, {"w": "Repeat / Loop", "ar": "كرّر / حلقة تكرار"},
                 ],
                 "summary": "Move forward · Turn left · Turn right · Repeat = Loop",
             },
             "questions": [
                 Q.mc("loop", "Instead of writing \"Move forward\" 5 times, we can write:",
                      ["Repeat 5: Move forward", "Turn left 5", "Stop", "Move back"], 0),
                 Q.mc("loop", "Doing the same command again and again is called a:", ["Loop", "Mouse", "Printer", "Folder"], 0),
                 Q.mc("algo", "The door is on the robot's right side. To face the door, the robot should:",
                      ["Turn right", "Turn left", "Jump", "Sleep"], 0),
                 Q.tf("loop", "Repeat 3: Clap = clap, clap, clap.", True),
                 Q.match("algo", "Match", ["Move forward", "Turn left", "Repeat"], ["⬆️", "↩️", "🔁"]),
             ]},
            {"title": "Find the bug — أجد الخطأ (Debugging)", "minutes": 8,
             "intro": {
                 "goals": ["أعرف أن الخطأ في البرنامج اسمه Bug", "أجد الخطأ وأصلحه"],
                 "explain": "أحيانًا لا يعمل البرنامج كما نريد لأن فيه خطأ Bug: خطوة ناقصة أو في غير مكانها. "
                            "إيجاد الخطأ وإصلاحه اسمه Debugging. المبرمج الجيد لا يغضب من الأخطاء؛ يجرب ويصلح ويتعلم.",
                 "vocab": [
                     {"w": "Bug", "ar": "خطأ في البرنامج"}, {"w": "Debugging", "ar": "إيجاد الخطأ وإصلاحه"},
                     {"w": "Test", "ar": "تجربة"},
                 ],
                 "summary": "Bug = خطأ · Debugging = أجد الخطأ وأصلحه · أجرّب مرة أخرى",
             },
             "questions": [
                 Q.mc("debug", "A mistake in a program is called a:", ["Bug", "Loop", "Mouse", "Robot"], 0),
                 Q.mc("debug", "Making a sandwich: 1) Eat it 2) Put cheese in the bread 3) Get the bread. What is the bug?",
                      ["The steps are in the wrong order", "There is no bug", "Cheese is blue", "Bread is a computer"], 0),
                 Q.mc("debug", "Finding and fixing mistakes is called:", ["Debugging", "Printing", "Shutting down", "Uploading"], 0),
                 Q.tf("debug", "Good programmers test their programs and fix bugs.", True),
                 Q.order("debug", "Fix the order: getting ready for school",
                         ["Wake up", "Put on your uniform", "Take your school bag", "Go to school"]),
             ]},
            {"title": "Unit 4 review — مراجعة الوحدة الرابعة", "minutes": 8,
             "intro": {"summary": "راجع: Algorithm · Repeat / Loop · Bug / Debugging"},
             "questions": [
                 Q.match("algo", "Match", ["Algorithm", "Loop", "Bug"], ["Steps in order", "Repeat commands", "A mistake"]),
                 Q.mc("loop", "Repeat 2: Jump — the robot jumps:", ["2 times", "1 time", "5 times", "0 times"], 0),
                 Q.order("algo", "Order: making tea with an adult",
                         ["Fill the kettle with water", "Boil the water", "Pour the hot water on the tea bag", "Wait and drink"]),
                 Q.tf("debug", "When a program has a bug, we give up.", False, explain="نجد الخطأ ونصلحه ونجرّب مرة أخرى."),
             ]},
        ]},
    ],
}
