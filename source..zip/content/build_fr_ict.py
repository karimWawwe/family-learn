#!/usr/bin/env python3
"""Builds French + ICT (content/t1/fr3.py, fr6.py, ict3.py, ict6.py) into
supabase/migrations/20261012000014_french_ict.sql

    python3 content/build_fr_ict.py

Yassin (Primary 3): fr-g3, ict-g3        Omar (Primary 6): fr-g6, ict-g6
Adds: subject 'french', course source labels (official / book_topics / supplementary),
lesson explanations (lessons.intro), 🔊 audio on questions (payload.audio + audio_lang),
lesson_intro(), per-course progress in profile_report(), source labels in course_map()
and cms_list_courses(). Only touches these 4 course ids. Safe to run again (progress is kept).
"""
import importlib
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
MIG = os.path.join(ROOT, "supabase", "migrations")
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "t1"))
import build_content as bc  # noqa: E402
from build_t1 import shuffle_options  # noqa: E402

SQL_OUT = os.path.join(MIG, "20261012000014_french_ict.sql")
# position inside each child's course list (Yassin 20-27, Omar 30-36, Term-2 books 40+)
KEYS = [("fr3", 26), ("ict3", 27), ("fr6", 35), ("ict6", 36)]
SOURCE_KINDS = {"official", "book_topics", "supplementary"}
INTRO_KEYS = {"goals", "explain", "vocab", "examples", "activity", "summary"}
AUDIO_OK = {"mc", "tf", "match", "order", "drag", "read"}


def check_intro(intro, where):
    assert isinstance(intro, dict) and intro, f"{where}: intro missing"
    assert set(intro) <= INTRO_KEYS, f"{where}: unknown intro keys {set(intro) - INTRO_KEYS}"
    for k in ("goals", "examples"):
        assert all(isinstance(x, str) and x for x in intro.get(k, [])), f"{where}: {k}"
    for v in intro.get("vocab", []):
        assert v.get("w") and v.get("ar") and set(v) <= {"w", "ar", "say"}, f"{where}: vocab {v}"


def build():
    skills, courses, units, lessons, questions = {}, [], [], [], []
    for key, position in KEYS:
        m = importlib.import_module(key)
        bc.SKILLS = m.SKILLS
        skills.update(m.SKILLS)
        c = m.COURSE
        assert c["source_kind"] in SOURCE_KINDS and c["source_note"], key
        lang = c["speech_lang"]
        courses.append({"id": c["code"], "subject": c["subject"], "title": c["title"], "level_label": c["level"],
                        "audience": c["audience"], "grade_min": c["grade_min"], "grade_max": c["grade_max"],
                        "position": position, "source_kind": c["source_kind"], "source_note": c["source_note"],
                        "edition": c["edition"], "speech_lang": lang})
        pos = 0
        for ui, u in enumerate(c["units"], start=1):
            uid = f"{c['code']}.u{ui}"
            units.append({"id": uid, "course_id": c["code"], "position": ui, "title": u["title"]})
            for li, l in enumerate(u["lessons"], start=1):
                pos += 1
                lid = f"{uid}.l{li}"
                check_intro(l["intro"], lid)
                lessons.append({"id": lid, "unit_id": uid, "course_id": c["code"], "position": pos,
                                "title": l["title"], "minutes": l["minutes"], "intro": l["intro"]})
                for qi, q in enumerate(l["questions"], start=1):
                    qid = f"{lid}.q{qi}"
                    q = shuffle_options(q, qid)
                    row = bc.convert(q, qid)
                    if q.get("audio"):
                        assert q["t"] in AUDIO_OK, qid
                        row["payload"] = dict(row["payload"], audio=q["audio"], audio_lang=lang)
                    if q["t"] == "tf" and c["subject"] == "french":
                        row["correct_text"] = "صح" if q["answer"] else "خطأ"
                    row["lesson_id"], row["position"] = lid, qi
                    questions.append(row)
    ids = [q["id"] for q in questions]
    assert len(ids) == len(set(ids))
    skill_rows = [{"code": k, "name": v, "subject": k.split(".")[0]} for k, v in skills.items()]
    return {"skills": skill_rows, "courses": courses, "units": units, "lessons": lessons, "questions": questions}


def latest_def(name, files):
    """The newest `create or replace function <name>(...) ... end $$;` among the migration files."""
    for f in reversed(files):
        with open(os.path.join(MIG, f), encoding="utf-8") as fh:
            sql = fh.read()
        m = re.search(r"^create or replace function " + re.escape(name) + r"\(.*?^end \$\$;", sql, re.S | re.M)
        if m:
            return m.group(0), f
    raise SystemExit(f"{name} not found")


def patch(text, old, new):
    assert text.count(old) == 1, f"patch target not found once: {old[:60]}"
    return text.replace(old, new)


def functions_sql():
    files = sorted(f for f in os.listdir(MIG) if f.endswith(".sql") and f < "20261012000014")
    out = []
    cm, f1 = latest_def("public.course_map", files)
    cm = patch(cm, "'id', c.id, 'subject', c.subject, 'title', c.title, 'level_label', c.level_label,",
               "'id', c.id, 'subject', c.subject, 'title', c.title, 'level_label', c.level_label,\n"
               "             'source_kind', c.source_kind, 'source_note', c.source_note, 'edition', c.edition,\n"
               "             'speech_lang', c.speech_lang,")
    out += [f"-- course_map(): as in {f1}, plus the course's source label and speech language.", cm, ""]
    pr, f2 = latest_def("public.profile_report", files)
    pr = patch(pr, "  return r;\nend $$;",
               "  r := r || jsonb_build_object('courses', app.course_progress(p_profile));\n  return r;\nend $$;")
    out += [f"-- profile_report(): as in {f2}, plus per-course progress ('courses').", pr, ""]
    cl, f3 = latest_def("public.cms_list_courses", files)
    cl = patch(cl, "'audience', coalesce(d.doc ->> 'audience', c.audience),",
               "'audience', coalesce(d.doc ->> 'audience', c.audience),\n"
               "               'source_kind', c.source_kind, 'source_note', c.source_note, 'edition', c.edition,")
    out += [f"-- cms_list_courses(): as in {f3}, plus the source label.", cl, ""]
    return "\n".join(out)


def write_sql(d):
    lit = bc.lit

    def doc(rows):
        return lit(json.dumps(rows, ensure_ascii=False, separators=(",", ":"))) + "::jsonb"

    def read(name):
        with open(os.path.join(HERE, name), encoding="utf-8") as fh:
            return fh.read()

    cids = ", ".join(lit(c["id"]) for c in d["courses"])
    out = [
        "-- ============================================================================",
        "--  Family Learn - French + ICT for Omar (Primary 6) and Yassin (Primary 3)",
        "--  (GENERATED by content/build_fr_ict.py from content/t1/fr3.py, fr6.py, ict3.py, ict6.py,",
        "--   content/fr_ict_schema.sql and content/fr_ict_functions.sql).",
        f"--  {len(d['courses'])} courses, {len(d['units'])} units, {len(d['lessons'])} lessons, {len(d['questions'])} questions.",
        "--  Only touches these courses: " + cids + " (plus the source label of the existing book courses).",
        "--  Safe to run more than once. Nothing is deleted; progress is kept.",
        "-- ============================================================================",
        "begin;",
        read("fr_ict_schema.sql"),
        "-- ---------------------------------------------------------------- content",
        "insert into public.skills (code, name, subject)",
        f"select code, name, subject from jsonb_to_recordset({doc(d['skills'])}) as x(code text, name text, subject text)",
        "on conflict (code) do update set name = excluded.name, subject = excluded.subject;",
        "",
        "insert into public.courses (id, subject, title, level_label, audience, grade_min, grade_max, position,",
        "                            source_kind, source_note, edition, speech_lang)",
        "select id, subject, title, level_label, audience, grade_min, grade_max, position, source_kind, source_note, edition, speech_lang",
        f"  from jsonb_to_recordset({doc(d['courses'])})",
        "    as x(id text, subject text, title text, level_label text, audience text, grade_min smallint, grade_max smallint,",
        "         position smallint, source_kind text, source_note text, edition text, speech_lang text)",
        "on conflict (id) do update set subject = excluded.subject, title = excluded.title, level_label = excluded.level_label,",
        "  audience = excluded.audience, grade_min = excluded.grade_min, grade_max = excluded.grade_max, position = excluded.position,",
        "  source_kind = excluded.source_kind, source_note = excluded.source_note, edition = excluded.edition,",
        "  speech_lang = excluded.speech_lang;",
        "",
        "insert into public.units (id, course_id, position, title)",
        f"select id, course_id, position, title from jsonb_to_recordset({doc(d['units'])}) as x(id text, course_id text, position smallint, title text)",
        "on conflict (id) do update set course_id = excluded.course_id, position = excluded.position, title = excluded.title, archived = false;",
        "",
        f"update public.lessons set position = position + 1000 where course_id in ({cids}) and not archived;",
        "insert into public.lessons (id, unit_id, course_id, position, title, minutes, intro)",
        "select id, unit_id, course_id, position, title, minutes, intro",
        f"  from jsonb_to_recordset({doc(d['lessons'])})",
        "    as x(id text, unit_id text, course_id text, position smallint, title text, minutes smallint, intro jsonb)",
        "on conflict (id) do update set unit_id = excluded.unit_id, course_id = excluded.course_id,",
        "  position = excluded.position, title = excluded.title, minutes = excluded.minutes, intro = excluded.intro, archived = false;",
        f"update public.lessons set archived = true where course_id in ({cids}) and position > 1000;",
        "",
        f"update public.questions set position = position + 1000 where not archived and lesson_id in (select id from public.lessons where course_id in ({cids}));",
        "insert into public.questions (id, lesson_id, position, type, skill, prompt, hint, payload, answer_key, correct_text, explanation)",
        "select id, lesson_id, position, type, skill, prompt, hint, payload, answer_key, correct_text, explanation",
        f"  from jsonb_to_recordset({doc(d['questions'])})",
        "    as x(id text, lesson_id text, position smallint, type text, skill text, prompt text, hint text,",
        "         payload jsonb, answer_key jsonb, correct_text text, explanation text)",
        "on conflict (id) do update set lesson_id = excluded.lesson_id, position = excluded.position, type = excluded.type,",
        "  skill = excluded.skill, prompt = excluded.prompt, hint = excluded.hint, payload = excluded.payload,",
        "  answer_key = excluded.answer_key, correct_text = excluded.correct_text, explanation = excluded.explanation, archived = false;",
        f"update public.questions set archived = true where position > 1000 and lesson_id in (select id from public.lessons where course_id in ({cids}));",
        "",
        read("fr_ict_functions.sql"),
        functions_sql(),
        "notify pgrst, 'reload schema';",
        "commit;",
    ]
    with open(SQL_OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")


if __name__ == "__main__":
    data = build()
    write_sql(data)
    size = os.path.getsize(SQL_OUT)
    print(f"ok: {len(data['courses'])} courses, {len(data['units'])} units, {len(data['lessons'])} lessons, "
          f"{len(data['questions'])} questions -> {SQL_OUT} ({size} bytes)")
