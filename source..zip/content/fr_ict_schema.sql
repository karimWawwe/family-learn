-- ---------------------------------------------------------------- schema (French + ICT, 0014)
-- New subject 'french' ('ict' is already allowed since 0012).
alter table public.courses drop constraint if exists courses_subject_check;
alter table public.courses add constraint courses_subject_check
  check (subject in ('english', 'math', 'business', 'arabic', 'religion', 'social', 'science', 'ict', 'french'));

-- Where the content comes from (shown to the parent / editor and as a note on the course page):
--   official      = lessons and questions built from the MoE school book pages
--   book_topics   = the book's lesson list, but the explanations / questions are written by the app
--   supplementary = extra path written by the app (not from an MoE book)
alter table public.courses add column if not exists source_kind  text;
alter table public.courses add column if not exists source_note  text;
alter table public.courses add column if not exists edition      text;
alter table public.courses add column if not exists speech_lang  text;   -- e.g. fr-FR: language of the 🔊 buttons
alter table public.courses drop constraint if exists courses_source_kind_check;
alter table public.courses add constraint courses_source_kind_check
  check (source_kind is null or source_kind in ('official', 'book_topics', 'supplementary'));

-- Lesson explanation shown before the exercises:
--   {"goals": [...], "explain": "...", "vocab": [{"w","ar","say"}], "examples": [...], "activity": "...", "summary": "..."}
alter table public.lessons add column if not exists intro jsonb;

-- The courses already built from the MoE book pages (0005 Term 2, 0012 Term 1). Only set when empty.
update public.courses
   set source_kind = 'official',
       source_note = coalesce(source_note, 'من صفحات كتاب الوزارة (مدارس اللغات). الأسئلة تدريبية من إعداد التطبيق على دروس الكتاب.'),
       edition     = coalesce(edition, case when id like '%-t1' or id in ('ar-g3', 'ar-g6', 'isl-g3', 'isl-g6', 'soc-g6')
                                            then '2026/2027 — الترم الأول' else 'الترم الثاني' end)
 where source_kind is null
   and id in ('eng-g3', 'math-g3', 'eng-g6', 'math-g6',
              'eng-g3-t1', 'ar-g3', 'isl-g3', 'eng-g6-t1', 'math-g6-t1', 'ar-g6', 'isl-g6', 'soc-g6');
