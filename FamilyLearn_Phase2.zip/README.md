# Family Learn — Phase 2 (UI & Navigation)

تطبيق Flutter حقيقي لـ iOS وAndroid. هذه المرحلة فيها كل الشاشات والتنقل والتصميمين (أطفال ومحترف) واللغتين (إنجليزي وعربي من اليمين لليسار).

**كل البيانات في هذه المرحلة MOCK DATA:**

- البيانات تجريبية ومكتوبة داخل `lib/data/mock/mock_data.dart`.
- كل شاشة فيها شريط أصفر مكتوب عليه «MOCK DATA».
- ما يتم حفظ أي شيء.

## ما يعمل الآن

- تسجيل الدخول وإنشاء العائلة: **واجهة فقط**. أي زر دخول يدخلك مباشرة.
- اختيار الـ Profile والرمز السري: أي 4 أرقام تفتح الحساب.
- الصفحة الرئيسية:
  - للأطفال: مهمة اليوم، XP، العملات، النجوم، والسلسلة.
  - للبالغ: خطة اليوم، ونسب الإتقان، والمراجعة.
- مسارات الدروس ومشغّل الدروس مع **11 نوع سؤال**:
  - Multiple Choice، True/False، Fill blank، Matching، Ordering، Drag & Drop، Typing، Listening، Speaking، Reading، Word Problem.
  - التحقق من الإجابة هنا مؤقت للواجهة فقط. المصحّح الحقيقي يجي في المرحلة 6.
- مراجعة اليوم، وبنك الكلمات، وتفاصيل الكلمة.
- المعلّم الذكي و Role-play مع تقرير التقييم. الردود كلها MOCK، والذكاء الاصطناعي الحقيقي في المرحلة 8.
- التقدّم، والأوسمة، والمتجر.
- لوحة الوالد، وتقرير كل طفل مع إعداداته. الطفل ما يقدر يفتح لوحة الوالد.
- الإعدادات: اللغة، والوضع الليلي.

## ما لا يعمل بعد (عن قصد)

| الميزة | المرحلة |
| --- | --- |
| حسابات حقيقية و Supabase | 3 |
| قاعدة البيانات والـ API | 4 |
| المحتوى من الـ CMS | 5 |
| الإتقان والمراجعة المتباعدة الحقيقية | 6 |
| الذكاء الاصطناعي | 8 |
| الصوت والنطق | 9 |
| العمل بدون إنترنت والإشعارات | 12 |

## التشغيل على جهازك (مرة واحدة)

1. ثبّت Flutter (نسخة 3.27 أو أحدث) من الموقع الرسمي docs.flutter.dev، وثبّت Android Studio.
2. افتح Terminal داخل المجلد `apps/mobile` ونفّذ:

```
flutter create . --org com.familylearn --platforms android,ios
flutter pub get
flutter test
flutter run
```

الأمر الأول ينشئ ملفات أندرويد و iOS فقط، وما يغيّر ملفات `lib`.

- **للتشغيل على جوال أندرويد:** فعّل «خيارات المطوّر» ثم «USB debugging»، ووصّل الجوال بالكمبيوتر.
- **للتشغيل على الآيفون:** تحتاج جهاز Mac وحساب Apple Developer.

## ملاحظة مهمة

الكود مكتوب بعناية، لكني ما قدرت أشغّل Flutter في بيئتي، لأن تنزيله محجوب هناك. عشان كذا أول تشغيل لـ `flutter test` على جهازك هو أول فحص فعلي للكود. إذا طلع أي خطأ، انسخه وأرسله لي وأصلّحه.

## البنية

```
apps/mobile/lib
  core/        theme (kid/pro), l10n (en/ar), router (go_router), widgets
  domain/      models + question types (plain Dart)
  data/mock/   MOCK DATA (removed in Phases 4-6)
  state/       session (Riverpod)
  features/    onboarding, profiles, placement, home, learn, questions,
               review, vocab, ai, progress, parent, settings, shell
```
