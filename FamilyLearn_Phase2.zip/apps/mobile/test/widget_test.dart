import 'package:family_learn/app.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

Future<void> _pumpApp(WidgetTester tester) async {
  tester.view.physicalSize = const Size(1170, 2532);
  tester.view.devicePixelRatio = 3.0;
  addTearDown(tester.view.reset);
  await tester.pumpWidget(const ProviderScope(child: FamilyLearnApp()));
  await tester.pumpAndSettle();
}

Future<void> _signInAndPick(WidgetTester tester, String name) async {
  await tester.tap(find.text('I already have an account'));
  await tester.pumpAndSettle();
  await tester.tap(find.widgetWithText(FilledButton, 'Sign in'));
  await tester.pumpAndSettle();
  expect(find.text("Who's learning?"), findsOneWidget);
  await tester.tap(find.text(name));
  await tester.pumpAndSettle();
  for (final d in ['1', '2', '3', '4']) {
    await tester.tap(find.text(d).last);
    await tester.pump();
  }
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('starts on the welcome screen with the preview banner', (tester) async {
    await _pumpApp(tester);
    expect(find.text('Learning for the whole family'), findsOneWidget);
    // The banner's own text is merged into the same semantics node, so match by pattern.
    expect(find.bySemanticsLabel(RegExp('mock data banner')), findsWidgets);
  });

  testWidgets('child profile opens the kid home with today\'s mission', (tester) async {
    await _pumpApp(tester);
    await _signInAndPick(tester, 'Omar');
    expect(find.text("Today's mission"), findsOneWidget);
    expect(find.byType(NavigationBar), findsOneWidget);
  });

  testWidgets('a child does not see the family dashboard', (tester) async {
    await _pumpApp(tester);
    await _signInAndPick(tester, 'Omar');
    await tester.tap(find.text('More'));
    await tester.pumpAndSettle();
    expect(find.text('Family dashboard'), findsNothing);
    expect(find.text('Shop'), findsOneWidget);
  });

  testWidgets('the parent sees the family dashboard', (tester) async {
    await _pumpApp(tester);
    await _signInAndPick(tester, 'Kareem');
    await tester.tap(find.text('More'));
    await tester.pumpAndSettle();
    expect(find.text('Family dashboard'), findsOneWidget);
  });

  testWidgets('a profile with Arabic UI switches to right-to-left', (tester) async {
    await _pumpApp(tester);
    await _signInAndPick(tester, 'Yassin');
    final dir = Directionality.of(tester.element(find.byType(NavigationBar)));
    expect(dir, TextDirection.rtl);
    expect(find.text('مهمة اليوم'), findsOneWidget);
  });
}
