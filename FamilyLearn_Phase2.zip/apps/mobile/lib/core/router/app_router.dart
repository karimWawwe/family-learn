import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/ai/roleplay_screens.dart';
import '../../features/ai/tutor_chat_screen.dart';
import '../../features/home/home_screen.dart';
import '../../features/learn/learn_screens.dart';
import '../../features/onboarding/onboarding_screens.dart';
import '../../features/parent/parent_screens.dart';
import '../../features/placement/placement_screens.dart';
import '../../features/profiles/profile_screens.dart';
import '../../features/progress/progress_screens.dart';
import '../../features/review/review_screen.dart';
import '../../features/settings/settings_screen.dart';
import '../../features/shell/main_shell.dart';
import '../../features/vocab/vocab_screens.dart';
import '../../state/session.dart';

class Routes {
  static const welcome = '/welcome';
  static const signIn = '/sign-in';
  static const signUp = '/sign-up';
  static const consent = '/consent';
  static const createFamily = '/create-family';
  static const profiles = '/profiles';
  static const pairDevice = '/pair-device';
  static const home = '/home';
  static const learn = '/learn';
  static const review = '/review';
  static const progress = '/progress';
  static const more = '/more';
  static const vocab = '/vocab';
  static const tutor = '/tutor';
  static const roleplay = '/roleplay';
  static const achievements = '/achievements';
  static const shop = '/shop';
  static const parent = '/parent';
  static const settings = '/settings';
  static const placementResult = '/placement-result';
  static const lessonComplete = '/lesson-complete';

  static String pin(String profileId) => '/pin/$profileId';
  static String placement(String profileId) => '/placement/$profileId';
  static String lesson(String lessonId) => '/lesson/$lessonId';
  static String placementRun(String profileId) => '/placement/$profileId/run';
  static String word(String word) => '/word/${Uri.encodeComponent(word)}';
  static String roleplayScenario(String code) => '/roleplay/$code';
  static String roleplayFeedback(String code) => '/roleplay/$code/feedback';
  static String childReport(String profileId) => '/parent/child/$profileId';

  static const _public = {welcome, signIn, signUp, consent, createFamily};
}

final _rootKey = GlobalKey<NavigatorState>(debugLabel: 'root');

final routerProvider = Provider<GoRouter>((ref) {
  final refresh = ValueNotifier<int>(0);
  ref.listen(sessionProvider, (_, __) => refresh.value++);
  ref.onDispose(refresh.dispose);

  return GoRouter(
    navigatorKey: _rootKey,
    initialLocation: Routes.welcome,
    refreshListenable: refresh,
    redirect: (context, state) {
      final s = ref.read(sessionProvider);
      final path = state.uri.path;
      final isPublic = Routes._public.contains(path);
      if (!s.signedIn) return isPublic ? null : Routes.welcome;
      if (isPublic) return s.profileId == null ? Routes.profiles : Routes.home;
      final needsProfile = !(path == Routes.profiles ||
          path == Routes.pairDevice ||
          path.startsWith('/pin/'));
      if (needsProfile && s.profileId == null) return Routes.profiles;
      return null;
    },
    routes: [
      GoRoute(path: Routes.welcome, builder: (_, __) => const WelcomeScreen()),
      GoRoute(path: Routes.signIn, builder: (_, __) => const SignInScreen()),
      GoRoute(path: Routes.signUp, builder: (_, __) => const SignUpScreen()),
      GoRoute(path: Routes.consent, builder: (_, __) => const ConsentScreen()),
      GoRoute(path: Routes.createFamily, builder: (_, __) => const CreateFamilyScreen()),
      GoRoute(path: Routes.profiles, builder: (_, __) => const ProfilePickerScreen()),
      GoRoute(path: '/pin/:id', builder: (_, st) => PinScreen(profileId: st.pathParameters['id']!)),
      GoRoute(path: Routes.pairDevice, builder: (_, __) => const PairDeviceScreen()),
      GoRoute(path: '/placement/:id', builder: (_, st) => PlacementIntroScreen(profileId: st.pathParameters['id']!)),
      GoRoute(
        path: '/placement/:id/run',
        builder: (_, st) => const LessonPlayerScreen(lessonId: 'placement', isPlacement: true),
      ),
      GoRoute(path: Routes.placementResult, builder: (_, __) => const PlacementResultScreen()),
      StatefulShellRoute.indexedStack(
        builder: (context, state, shell) => MainShell(shell: shell),
        branches: [
          StatefulShellBranch(routes: [GoRoute(path: Routes.home, builder: (_, __) => const HomeScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: Routes.learn, builder: (_, __) => const CourseMapScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: Routes.review, builder: (_, __) => const ReviewTodayScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: Routes.progress, builder: (_, __) => const ProgressScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: Routes.more, builder: (_, __) => const MoreScreen())]),
        ],
      ),
      GoRoute(path: '/lesson/:id', builder: (_, st) => LessonPlayerScreen(lessonId: st.pathParameters['id']!)),
      GoRoute(
        path: Routes.lessonComplete,
        builder: (_, st) => LessonCompleteScreen(result: st.extra is LessonResult ? st.extra! as LessonResult : const LessonResult(correct: 0, total: 0)),
      ),
      GoRoute(path: Routes.vocab, builder: (_, __) => const VocabularyScreen()),
      GoRoute(path: '/word/:word', builder: (_, st) => WordDetailScreen(word: st.pathParameters['word']!)),
      GoRoute(path: Routes.tutor, builder: (_, __) => const TutorChatScreen()),
      GoRoute(path: Routes.roleplay, builder: (_, __) => const RoleplayLibraryScreen()),
      GoRoute(path: '/roleplay/:code', builder: (_, st) => RoleplayConversationScreen(code: st.pathParameters['code']!)),
      GoRoute(path: '/roleplay/:code/feedback', builder: (_, st) => RoleplayFeedbackScreen(code: st.pathParameters['code']!)),
      GoRoute(path: Routes.achievements, builder: (_, __) => const AchievementsScreen()),
      GoRoute(path: Routes.shop, builder: (_, __) => const ShopScreen()),
      GoRoute(path: Routes.parent, builder: (_, __) => const ParentDashboardScreen()),
      GoRoute(path: '/parent/child/:id', builder: (_, st) => ChildReportScreen(profileId: st.pathParameters['id']!)),
      GoRoute(path: Routes.settings, builder: (_, __) => const SettingsScreen()),
    ],
  );
});
