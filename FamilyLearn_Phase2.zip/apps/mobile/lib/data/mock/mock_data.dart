// ============================================================================
//  MOCK DATA  -  Phase 2 preview only.
//  Nothing here is real learner data and nothing is saved.
//  Replaced by the local database + sync engine in Phases 4-6.
//  The app never depends on these names: screens receive LearnerProfile
//  objects and work for any number of adults and children.
// ============================================================================

import '../../domain/models.dart';
import '../../domain/questions.dart';

class MockData {
  static const bool isMock = true;

  static final List<LearnerProfile> profiles = [
    const LearnerProfile(
      id: 'p-adult-1',
      displayName: 'Kareem',
      kind: ProfileKind.adult,
      role: FamilyRole.parent,
      uiMode: UiMode.pro,
      uiLocale: 'en',
      avatarEmoji: '🧑‍💼',
      dailyMinutesGoal: 30,
      trackIds: ['c-business'],
    ),
    const LearnerProfile(
      id: 'p-child-1',
      displayName: 'Omar',
      kind: ProfileKind.child,
      role: FamilyRole.child,
      uiMode: UiMode.kid,
      uiLocale: 'en',
      avatarEmoji: '🦁',
      dailyMinutesGoal: 35,
      grade: 6,
      birthYear: 2014,
      trackIds: ['c-eng-g6', 'c-math-g6'],
    ),
    const LearnerProfile(
      id: 'p-child-2',
      displayName: 'Yassin',
      kind: ProfileKind.child,
      role: FamilyRole.child,
      uiMode: UiMode.kid,
      uiLocale: 'ar',
      avatarEmoji: '🐼',
      dailyMinutesGoal: 25,
      grade: 3,
      birthYear: 2017,
      trackIds: ['c-eng-g3', 'c-math-g3'],
    ),
  ];

  static LearnerProfile profileById(String id) =>
      profiles.firstWhere((p) => p.id == id, orElse: () => profiles.first);

  static List<LearnerProfile> childrenOf(LearnerProfile parent) =>
      parent.isParent ? profiles.where((p) => p.isChild).toList() : const [];

  // --------------------------------------------------------------- courses
  static const _lessonsA = [
    LessonSummary(id: 'l-1', title: 'Warm-up', minutes: 8, status: LessonStatus.done),
    LessonSummary(id: 'l-2', title: 'Practice', minutes: 10, status: LessonStatus.inProgress),
    LessonSummary(id: 'l-3', title: 'Challenge', minutes: 12, status: LessonStatus.available),
    LessonSummary(id: 'l-4', title: 'Unit quiz', minutes: 10, status: LessonStatus.locked),
  ];

  static final Map<String, Course> courses = {
    'c-business': const Course(
      id: 'c-business',
      subject: 'business',
      title: 'Business & Sales English',
      levelLabel: 'B1+',
      units: [
        Unit(id: 'u-b1', title: 'Talking to customers', lessons: _lessonsA),
        Unit(id: 'u-b2', title: 'Monthly sales meeting', lessons: _lessonsA),
        Unit(id: 'u-b3', title: 'Presenting a perfume', lessons: _lessonsA),
      ],
    ),
    'c-eng-g6': const Course(
      id: 'c-eng-g6',
      subject: 'english',
      title: 'English - Grade 6',
      levelLabel: 'Grade 6',
      units: [
        Unit(id: 'u-e61', title: 'Past simple stories', lessons: _lessonsA),
        Unit(id: 'u-e62', title: 'Reading for details', lessons: _lessonsA),
      ],
    ),
    'c-math-g6': const Course(
      id: 'c-math-g6',
      subject: 'math',
      title: 'Math in English - Grade 6',
      levelLabel: 'Grade 6',
      units: [
        Unit(id: 'u-m61', title: 'Fractions & decimals', lessons: _lessonsA),
        Unit(id: 'u-m62', title: 'Ratios & percentages', lessons: _lessonsA),
      ],
    ),
    'c-eng-g3': const Course(
      id: 'c-eng-g3',
      subject: 'english',
      title: 'English - Grade 3',
      levelLabel: 'Grade 3',
      units: [
        Unit(id: 'u-e31', title: 'Phonics: long vowels', lessons: _lessonsA),
        Unit(id: 'u-e32', title: 'My day', lessons: _lessonsA),
      ],
    ),
    'c-math-g3': const Course(
      id: 'c-math-g3',
      subject: 'math',
      title: 'Math in English - Grade 3',
      levelLabel: 'Grade 3',
      units: [
        Unit(id: 'u-m31', title: 'Telling the time', lessons: _lessonsA),
        Unit(id: 'u-m32', title: 'Money', lessons: _lessonsA),
      ],
    ),
  };

  static List<Course> coursesFor(LearnerProfile p) =>
      p.trackIds.map((id) => courses[id]).whereType<Course>().toList();

  // --------------------------------------------------------------- daily plan
  static List<DailyPlanItem> planFor(LearnerProfile p) {
    if (!p.isChild) {
      return const [
        DailyPlanItem(type: PlanItemType.vocabulary, title: 'Vocabulary', subtitle: '12 words due', minutes: 10, done: true),
        DailyPlanItem(type: PlanItemType.lesson, title: 'Business English', subtitle: 'Handling objections', minutes: 10, done: false, lessonId: 'l-2'),
        DailyPlanItem(type: PlanItemType.speaking, title: 'Speaking', subtitle: 'Role-play: customer complaint', minutes: 10, done: false),
      ];
    }
    if ((p.grade ?? 0) >= 6) {
      return const [
        DailyPlanItem(type: PlanItemType.lesson, title: 'English', subtitle: 'Past simple: irregular verbs', minutes: 15, done: true, lessonId: 'l-1'),
        DailyPlanItem(type: PlanItemType.lesson, title: 'Math', subtitle: 'Fractions: adding unlike denominators', minutes: 15, done: false, lessonId: 'l-2'),
        DailyPlanItem(type: PlanItemType.review, title: 'Review', subtitle: '8 items', minutes: 5, done: false),
      ];
    }
    return const [
      DailyPlanItem(type: PlanItemType.lesson, title: 'English', subtitle: 'Phonics: "ai" and "ay"', minutes: 10, done: false, lessonId: 'l-1'),
      DailyPlanItem(type: PlanItemType.lesson, title: 'Math', subtitle: 'Telling the time', minutes: 10, done: false, lessonId: 'l-2'),
      DailyPlanItem(type: PlanItemType.game, title: 'Game', subtitle: 'Word catcher', minutes: 5, done: false),
    ];
  }

  // --------------------------------------------------------------- mastery
  static List<SkillMastery> masteryFor(LearnerProfile p) {
    if (!p.isChild) {
      return const [
        SkillMastery(skillCode: 'eng.general', name: 'General English', subject: 'english', mastery: 0.78),
        SkillMastery(skillCode: 'biz.sales_vocab', name: 'Sales vocabulary', subject: 'business', mastery: 0.66),
        SkillMastery(skillCode: 'biz.meetings', name: 'Meetings', subject: 'business', mastery: 0.58),
        SkillMastery(skillCode: 'biz.perfume', name: 'Perfume industry', subject: 'business', mastery: 0.71),
        SkillMastery(skillCode: 'eng.speaking', name: 'Speaking', subject: 'english', mastery: 0.47),
        SkillMastery(skillCode: 'eng.pronunciation', name: 'Pronunciation', subject: 'english', mastery: 0.62),
      ];
    }
    if ((p.grade ?? 0) >= 6) {
      return const [
        SkillMastery(skillCode: 'eng.vocabulary', name: 'Vocabulary', subject: 'english', mastery: 0.84),
        SkillMastery(skillCode: 'eng.grammar', name: 'Grammar', subject: 'english', mastery: 0.74),
        SkillMastery(skillCode: 'eng.reading', name: 'Reading', subject: 'english', mastery: 0.69),
        SkillMastery(skillCode: 'eng.writing', name: 'Writing', subject: 'english', mastery: 0.52),
        SkillMastery(skillCode: 'math.fractions', name: 'Fractions', subject: 'math', mastery: 0.62),
        SkillMastery(skillCode: 'math.percentages', name: 'Percentages', subject: 'math', mastery: 0.41),
        SkillMastery(skillCode: 'math.geometry', name: 'Geometry', subject: 'math', mastery: 0.77),
        SkillMastery(skillCode: 'math.word_problems', name: 'Word problems', subject: 'math', mastery: 0.55),
      ];
    }
    return const [
      SkillMastery(skillCode: 'eng.phonics', name: 'Phonics', subject: 'english', mastery: 0.72),
      SkillMastery(skillCode: 'eng.vocabulary', name: 'Vocabulary', subject: 'english', mastery: 0.66),
      SkillMastery(skillCode: 'eng.spelling', name: 'Spelling', subject: 'english', mastery: 0.44),
      SkillMastery(skillCode: 'math.time', name: 'Time', subject: 'math', mastery: 0.58),
      SkillMastery(skillCode: 'math.money', name: 'Money', subject: 'math', mastery: 0.81),
      SkillMastery(skillCode: 'math.shapes', name: 'Shapes', subject: 'math', mastery: 0.88),
    ];
  }

  // --------------------------------------------------------------- vocabulary
  static final DateTime _now = DateTime(2026, 9, 26);

  static List<VocabItem> vocabFor(LearnerProfile p) {
    if (!p.isChild) {
      return [
        VocabItem(word: 'objection', meaningEn: 'a reason a customer gives for not buying', meaningAr: 'اعتراض', example: 'Handle the price objection calmly.', ipa: '/əbˈdʒek.ʃən/', difficulty: 3, mastery: 0.55, errors: 2, lastReview: _now.subtract(const Duration(days: 3)), nextReview: _now, domain: 'sales'),
        VocabItem(word: 'sillage', meaningEn: 'the trail of scent a perfume leaves', meaningAr: 'أثر العطر', example: 'This oud has a strong sillage.', ipa: '/siːˈjɑːʒ/', difficulty: 4, mastery: 0.4, errors: 3, lastReview: _now.subtract(const Duration(days: 1)), nextReview: _now, domain: 'perfume'),
        VocabItem(word: 'target', meaningEn: 'the sales amount you aim to reach', meaningAr: 'الهدف', example: 'We reached 92% of the monthly target.', ipa: '/ˈtɑː.ɡɪt/', difficulty: 1, mastery: 0.95, errors: 0, lastReview: _now.subtract(const Duration(days: 14)), nextReview: _now.add(const Duration(days: 16)), domain: 'sales'),
        VocabItem(word: 'footfall', meaningEn: 'the number of people entering a shop', meaningAr: 'عدد الزوار', example: 'Footfall dropped during the summer.', ipa: '/ˈfʊt.fɔːl/', difficulty: 3, mastery: 0.7, errors: 1, lastReview: _now.subtract(const Duration(days: 7)), nextReview: _now.add(const Duration(days: 7)), domain: 'business'),
        VocabItem(word: 'upsell', meaningEn: 'to sell a more expensive or extra item', meaningAr: 'بيع إضافي', example: 'Upsell a gift set with the perfume.', ipa: '/ˈʌp.sel/', difficulty: 2, mastery: 0.8, errors: 0, lastReview: _now.subtract(const Duration(days: 7)), nextReview: _now.add(const Duration(days: 7)), domain: 'sales'),
      ];
    }
    if ((p.grade ?? 0) >= 6) {
      return [
        VocabItem(word: 'numerator', meaningEn: 'the top number of a fraction', meaningAr: 'البسط', example: 'In 3/4, the numerator is 3.', ipa: '/ˈnjuː.mə.reɪ.tər/', difficulty: 2, mastery: 0.6, errors: 1, lastReview: _now.subtract(const Duration(days: 3)), nextReview: _now, domain: 'math'),
        VocabItem(word: 'journey', meaningEn: 'a trip from one place to another', meaningAr: 'رحلة', example: 'The journey took three hours.', ipa: '/ˈdʒɜː.ni/', difficulty: 2, mastery: 0.85, errors: 0, lastReview: _now.subtract(const Duration(days: 7)), nextReview: _now.add(const Duration(days: 7)), domain: 'general'),
        VocabItem(word: 'percentage', meaningEn: 'a part of 100', meaningAr: 'النسبة المئوية', example: '25% is a quarter.', ipa: '/pəˈsen.tɪdʒ/', difficulty: 2, mastery: 0.45, errors: 3, lastReview: _now.subtract(const Duration(days: 1)), nextReview: _now, domain: 'math'),
      ];
    }
    return [
      VocabItem(word: 'rain', meaningEn: 'water falling from clouds', meaningAr: 'مطر', example: 'I like the rain.', ipa: '/reɪn/', difficulty: 1, mastery: 0.7, errors: 1, lastReview: _now.subtract(const Duration(days: 3)), nextReview: _now, domain: 'phonics'),
      VocabItem(word: 'o\'clock', meaningEn: 'used to say the exact hour', meaningAr: 'تماماً (الساعة)', example: "It's three o'clock.", ipa: '/əˈklɒk/', difficulty: 1, mastery: 0.5, errors: 2, lastReview: _now.subtract(const Duration(days: 1)), nextReview: _now, domain: 'math'),
      VocabItem(word: 'play', meaningEn: 'to have fun with a game', meaningAr: 'يلعب', example: 'We play after school.', ipa: '/pleɪ/', difficulty: 1, mastery: 0.9, errors: 0, lastReview: _now.subtract(const Duration(days: 7)), nextReview: _now.add(const Duration(days: 7)), domain: 'phonics'),
    ];
  }

  // --------------------------------------------------------------- review
  static List<ReviewItem> reviewFor(LearnerProfile p) {
    final words = vocabFor(p).where((v) => !v.nextReview.isAfter(_now)).map(
          (v) => ReviewItem(
            title: v.word,
            kind: 'word',
            reason: v.errors >= 2 ? ReviewReason.recentError : ReviewReason.due,
            mastery: v.mastery,
          ),
        );
    final skills = masteryFor(p).where((s) => s.isWeak).map(
          (s) => ReviewItem(title: s.name, kind: 'skill', reason: ReviewReason.weak, mastery: s.mastery),
        );
    final all = [...skills, ...words]..sort((a, b) => a.mastery.compareTo(b.mastery));
    return all;
  }

  // --------------------------------------------------------------- gamification
  static Wallet walletFor(LearnerProfile p) => p.isChild
      ? Wallet(xp: (p.grade ?? 3) * 410, coins: 240, stars: 37, level: (p.grade ?? 3) + 2, streakDays: 6)
      : const Wallet(xp: 3120, coins: 0, stars: 0, level: 9, streakDays: 11);

  static List<Achievement> achievementsFor(LearnerProfile p) => const [
        Achievement(code: 'vocab_master', title: 'Vocabulary Master', emoji: '📚', earned: true),
        Achievement(code: 'math_explorer', title: 'Math Explorer', emoji: '🧭', earned: true),
        Achievement(code: 'reading_champion', title: 'Reading Champion', emoji: '🏆', earned: false),
        Achievement(code: 'grammar_star', title: 'Grammar Star', emoji: '⭐', earned: false),
        Achievement(code: 'streak_7', title: '7 Day Streak', emoji: '🔥', earned: false),
      ];

  static const shopItems = [
    ('Astronaut avatar', '🧑‍🚀', 120, false),
    ('Robot friend', '🤖', 200, true),
    ('Ocean background', '🌊', 80, false),
    ('Dragon character', '🐉', 300, false),
    ('Extra game time', '🎮', 150, false),
    ('Crown frame', '👑', 250, false),
  ];

  // --------------------------------------------------------------- AI / role-play
  static const scenarios = [
    RoleplayScenario(code: 'customer_conversation', title: 'Customer conversation', persona: 'A tourist looking for a gift', goal: 'Recommend 2 perfumes and close the sale', emoji: '🛍️'),
    RoleplayScenario(code: 'customer_complaint', title: 'Customer complaint', persona: 'An upset customer with a leaking bottle', goal: 'Calm the customer and offer a solution', emoji: '😠'),
    RoleplayScenario(code: 'monthly_sales_meeting', title: 'Monthly sales meeting', persona: 'Regional director', goal: 'Present results and next month\'s plan', emoji: '📊'),
    RoleplayScenario(code: 'supplier_negotiation', title: 'Supplier negotiation', persona: 'Packaging supplier', goal: 'Get a better price for 5,000 boxes', emoji: '🤝'),
    RoleplayScenario(code: 'performance_discussion', title: 'Performance discussion', persona: 'A salesperson below target', goal: 'Give clear, fair feedback and a plan', emoji: '🗣️'),
    RoleplayScenario(code: 'presenting_perfume', title: 'Presenting a perfume', persona: 'A mall buyer', goal: 'Describe notes, sillage and the story', emoji: '🌹'),
    RoleplayScenario(code: 'management_meeting', title: 'Management meeting', persona: 'CEO and finance manager', goal: 'Defend the budget for a new campaign', emoji: '🏢'),
    RoleplayScenario(code: 'marketing_discussion', title: 'Marketing discussion', persona: 'Marketing manager', goal: 'Agree on a Ramadan campaign', emoji: '📣'),
    RoleplayScenario(code: 'sales_report', title: 'Sales report', persona: 'Your manager', goal: 'Explain why a branch dropped 12%', emoji: '📉'),
    RoleplayScenario(code: 'new_branch', title: 'New branch', persona: 'Mall leasing manager', goal: 'Discuss location, rent and opening date', emoji: '🏬'),
  ];

  static const roleplayTranscript = [
    ChatMessage(fromLearner: false, text: 'Hi, I bought this perfume last week and the bottle is leaking. I am not happy.'),
    ChatMessage(fromLearner: true, text: 'I am very sorry for this. Can you show me the bottle please?'),
    ChatMessage(fromLearner: false, text: 'Here. I paid a lot for it.'),
    ChatMessage(fromLearner: true, text: 'Yes I see the problem. We can change it for you today, and I give you a free sample.'),
  ];

  static const feedbackGrammar = [
    ('and I give you a free sample', 'and I will give you a free sample'),
    ('I am very sorry for this', 'I am very sorry about this'),
  ];
  static const feedbackBetterWords = [
    ('change it', 'replace it'),
    ('problem', 'defect'),
  ];
  static const feedbackPhrases = [
    'I completely understand your frustration.',
    'Let me sort this out for you right away.',
  ];
  static const feedbackNewWords = ['replace', 'defect', 'frustration'];
  static const feedbackPronunciation = [
    ('bottle', 0.62),
    ('frustration', 0.71),
    ('sample', 0.93),
  ];

  static const tutorChat = [
    ChatMessage(fromLearner: true, text: 'Why is 1/2 + 1/3 not 2/5?'),
    ChatMessage(fromLearner: false, text: 'Great question! We can only add pieces of the same size. Halves and thirds are different sizes, so first we change both into sixths: 1/2 = 3/6 and 1/3 = 2/6. Now 3/6 + 2/6 = 5/6.'),
  ];

  // --------------------------------------------------------------- lesson questions
  static List<Question> lessonFor(LearnerProfile p) {
    if (!p.isChild) {
      return const [
        MultipleChoiceQuestion(id: 'q1', skill: 'biz.sales_vocab', prompt: 'A customer says the perfume is too expensive. This is a price ___.', options: ['objection', 'invoice', 'discount', 'margin'], correctIndex: 0, hint: 'It is something a customer raises before buying.', explanation: 'An objection is a reason a customer gives for not buying.'),
        FillBlankQuestion(id: 'q2', skill: 'eng.grammar', prompt: 'Complete the sentence.', before: 'Our sales ', after: ' by 8% last month.', accepted: ['increased', 'rose', 'grew'], hint: 'Past simple of "increase".'),
        OrderingQuestion(id: 'q3', skill: 'biz.meetings', prompt: 'Put the meeting steps in order.', correctOrder: ['Welcome everyone', 'Review last month', 'Discuss the new target', 'Agree on actions']),
        MatchingQuestion(id: 'q4', skill: 'biz.perfume', prompt: 'Match the perfume words.', left: ['top notes', 'base notes', 'sillage'], right: ['first scent you smell', 'scent that lasts longest', 'trail left behind']),
        SpeakingQuestion(id: 'q5', skill: 'eng.pronunciation', prompt: 'Say it clearly.', targetText: 'This fragrance has warm notes of oud and amber.'),
      ];
    }
    if ((p.grade ?? 0) >= 6) {
      return const [
        WordProblemQuestion(id: 'q1', skill: 'math.fractions', prompt: 'Sara ate 1/4 of a pizza and Ali ate 2/4. What fraction did they eat together? (write as a decimal)', answer: 0.75, hint: 'Same denominators: add the numerators.'),
        MultipleChoiceQuestion(id: 'q2', skill: 'math.fractions', prompt: 'What is 1/2 + 1/3?', options: ['2/5', '5/6', '2/6', '1/6'], correctIndex: 1, hint: 'Change both fractions to sixths.', explanation: '1/2 = 3/6 and 1/3 = 2/6, so the answer is 5/6.'),
        TrueFalseQuestion(id: 'q3', skill: 'math.percentages', prompt: '50% of 80 is 40.', answer: true),
        ReadingQuestion(id: 'q4', skill: 'eng.reading', prompt: 'Why did Maya go home early?', passage: 'Maya went to the park with her brother. After an hour, dark clouds covered the sky, so they went home before the rain started.', options: ['She was tired', 'It was going to rain', 'Her brother was hungry'], correctIndex: 1),
        DragDropQuestion(id: 'q5', skill: 'eng.grammar', prompt: 'Drag the correct verb.', before: 'Yesterday we ', after: ' to the museum.', tokens: ['go', 'went', 'going'], correctToken: 'went'),
        TypingQuestion(id: 'q6', skill: 'eng.spelling', prompt: 'Type the past simple of "buy".', accepted: ['bought']),
      ];
    }
    return const [
      ListeningQuestion(id: 'q1', skill: 'eng.phonics', prompt: 'Which word did you hear?', audioText: 'rain', options: ['ran', 'rain', 'run'], correctIndex: 1),
      MultipleChoiceQuestion(id: 'q2', skill: 'math.time', prompt: 'The short hand is on 3 and the long hand is on 12. What time is it?', options: ["12 o'clock", "3 o'clock", 'half past 3'], correctIndex: 1, hint: 'The long hand on 12 means "o\'clock".'),
      WordProblemQuestion(id: 'q3', skill: 'math.money', prompt: 'You have 5 coins of 10 baisa. How many baisa do you have?', answer: 50, unit: 'baisa'),
      MatchingQuestion(id: 'q4', skill: 'eng.vocabulary', prompt: 'Match the word to the picture.', left: ['🍎', '🐱', '☀️'], right: ['apple', 'cat', 'sun']),
      SpeakingQuestion(id: 'q5', skill: 'eng.pronunciation', prompt: 'Say the word.', targetText: 'play'),
    ];
  }

  // --------------------------------------------------------------- parent reports
  static ChildReport reportFor(LearnerProfile child) {
    final older = (child.grade ?? 0) >= 6;
    return ChildReport(
      profileId: child.id,
      minutesToday: older ? 22 : 18,
      minutesWeek: older ? 164 : 131,
      questionsWeek: older ? 212 : 158,
      accuracyWeek: older ? 0.78 : 0.83,
      dailyGoalMinutes: child.dailyMinutesGoal,
      streakDays: 6,
      minutesByDay: older ? const [30, 25, 0, 35, 28, 24, 22] : const [20, 18, 25, 10, 22, 18, 18],
      weakAreas: masteryFor(child).where((s) => s.isWeak).map((s) => s.name).toList(),
      toReview: reviewFor(child).take(4).map((r) => r.title).toList(),
      history: older
          ? const ['Today - Fractions practice (8/10)', 'Yesterday - Reading: The storm (5/6)', 'Wed - Unit quiz: Past simple (82%)']
          : const ['Today - Phonics "ai" (9/10)', 'Yesterday - Telling the time (6/8)', 'Wed - Word game (12 words)'],
    );
  }
}
