import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/mock/mock_data.dart';
import '../../domain/models.dart';
import '../../state/session.dart';

/// Parent-only. Phase 2 hides it in the UI; Phase 3-4 enforce it in the API and
/// in database RLS so a child session can never read another profile's data.
class ParentDashboardScreen extends ConsumerWidget {
  const ParentDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final s = context.s;
    if (!p.isParent) {
      return MockScaffold(title: s.t('parentDashboard'), body: const EmptyState(emoji: '🔒', message: 'Parents only'));
    }
    final children = MockData.childrenOf(p);
    return MockScaffold(
      title: s.t('parentDashboard'),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [for (final c in children) _ChildCard(child: c)],
      ),
    );
  }
}

class _ChildCard extends StatelessWidget {
  const _ChildCard({required this.child});

  final LearnerProfile child;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final r = MockData.reportFor(child);
    final goalPct = r.dailyGoalMinutes == 0 ? 0.0 : (r.minutesToday / r.dailyGoalMinutes).clamp(0.0, 1.0).toDouble();
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppTokens.radiusPro),
        onTap: () => context.push(Routes.childReport(child.id)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(child.avatarEmoji, style: const TextStyle(fontSize: 36)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(child.displayName, style: context.text.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                        Text('${s.t('grade')} ${child.grade} · 🔥 ${r.streakDays}'),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right),
                ],
              ),
              const SizedBox(height: 12),
              Text('${s.t('dailyGoal')}: ${s.f('minutesOfGoal', [r.minutesToday, r.dailyGoalMinutes])}'),
              const SizedBox(height: 6),
              LinearProgressIndicator(value: goalPct, minHeight: 8, borderRadius: BorderRadius.circular(8)),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _Mini(label: s.t('accuracy'), value: '${(r.accuracyWeek * 100).round()}%')),
                  Expanded(child: _Mini(label: s.t('questionsSolved'), value: '${r.questionsWeek}')),
                  Expanded(child: _Mini(label: s.t('studyTime'), value: s.f('minutes', [r.minutesWeek]))),
                ],
              ),
              if (r.weakAreas.isNotEmpty) ...[
                const SizedBox(height: 10),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final w in r.weakAreas)
                      Chip(
                        visualDensity: VisualDensity.compact,
                        avatar: const Icon(Icons.trending_down, size: 16, color: AppTokens.bad),
                        label: Text(w),
                      ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _Mini extends StatelessWidget {
  const _Mini({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(value, style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
        Text(label, style: context.text.bodySmall),
      ],
    );
  }
}

enum _Range { day, week, month }

class ChildReportScreen extends ConsumerStatefulWidget {
  const ChildReportScreen({super.key, required this.profileId});

  final String profileId;

  @override
  ConsumerState<ChildReportScreen> createState() => _ChildReportScreenState();
}

class _ChildReportScreenState extends ConsumerState<ChildReportScreen> {
  _Range _range = _Range.week;
  bool _aiEnabled = true;
  bool _notifications = true;
  double _goal = 30;

  @override
  void initState() {
    super.initState();
    _goal = MockData.profileById(widget.profileId).dailyMinutesGoal.toDouble();
  }

  @override
  Widget build(BuildContext context) {
    final me = ref.watch(currentProfileProvider);
    if (me == null) return const SizedBox.shrink();
    final s = context.s;
    final child = MockData.profileById(widget.profileId);
    // Only a parent may open a child's report, and only for a child in the same family.
    if (!me.isParent || !MockData.childrenOf(me).any((c) => c.id == child.id)) {
      return MockScaffold(title: s.t('parentDashboard'), body: const EmptyState(emoji: '🔒', message: 'Parents only'));
    }
    final r = MockData.reportFor(child);
    // MOCK: month figures are the week x 4.
    final minutes = switch (_range) { _Range.day => r.minutesToday, _Range.week => r.minutesWeek, _Range.month => r.minutesWeek * 4 };
    final questions = switch (_range) { _Range.day => (r.questionsWeek / 6).round(), _Range.week => r.questionsWeek, _Range.month => r.questionsWeek * 4 };
    final maxBar = r.minutesByDay.fold<int>(1, (m, v) => v > m ? v : m);

    return MockScaffold(
      title: '${child.avatarEmoji} ${child.displayName}',
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: SegmentedButton<_Range>(
              segments: [
                ButtonSegment(value: _Range.day, label: Text(s.t('today'))),
                ButtonSegment(value: _Range.week, label: Text(s.t('thisWeek'))),
                const ButtonSegment(value: _Range.month, label: Text('30d')),
              ],
              selected: {_range},
              onSelectionChanged: (v) => setState(() => _range = v.first),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                Expanded(child: StatTile(label: s.t('studyTime'), value: s.f('minutes', [minutes]), icon: Icons.timer_outlined)),
                Expanded(child: StatTile(label: s.t('questionsSolved'), value: '$questions', icon: Icons.quiz_outlined)),
                Expanded(child: StatTile(label: s.t('accuracy'), value: '${(r.accuracyWeek * 100).round()}%', icon: Icons.track_changes)),
              ],
            ),
          ),
          SectionTitle(s.t('studyTime')),
          SizedBox(
            height: 140,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  for (var i = 0; i < r.minutesByDay.length; i++)
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text('${r.minutesByDay[i]}', style: context.text.labelSmall),
                          const SizedBox(height: 4),
                          Container(
                            height: 90 * r.minutesByDay[i] / maxBar,
                            margin: const EdgeInsets.symmetric(horizontal: 6),
                            decoration: BoxDecoration(
                              color: r.minutesByDay[i] >= r.dailyGoalMinutes ? AppTokens.good : context.colors.primary,
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(i == r.minutesByDay.length - 1 ? s.t('today') : '-${r.minutesByDay.length - 1 - i}', style: context.text.labelSmall),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
          SectionTitle(s.t('weakAreas')),
          for (final sk in MockData.masteryFor(child).where((m) => m.isWeak)) MasteryBar(label: sk.name, value: sk.mastery),
          SectionTitle(s.t('topicsToReview')),
          for (final t in r.toReview) ListTile(dense: true, leading: const Icon(Icons.replay), title: Text(t, textDirection: TextDirection.ltr)),
          SectionTitle(s.t('learningHistory')),
          for (final h in r.history) ListTile(dense: true, leading: const Icon(Icons.history), title: Text(h, textDirection: TextDirection.ltr)),
          SectionTitle(s.f('childSettings', [child.displayName])),
          ListTile(
            title: Text(s.t('dailyGoal')),
            subtitle: Slider(
              value: _goal,
              min: 10,
              max: 60,
              divisions: 10,
              label: s.f('minutes', [_goal.round()]),
              onChanged: (v) => setState(() => _goal = v),
            ),
            trailing: Text(s.f('minutes', [_goal.round()])),
          ),
          SwitchListTile(value: _aiEnabled, onChanged: (v) => setState(() => _aiEnabled = v), title: Text(s.t('aiEnabled'))),
          SwitchListTile(value: _notifications, onChanged: (v) => setState(() => _notifications = v), title: Text(s.t('notifications'))),
          ListTile(
            leading: const Icon(Icons.forum_outlined),
            title: Text(s.t('aiLogs')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push(Routes.tutor),
          ),
          const PendingNote('uiOnly'),
        ],
      ),
    );
  }
}
