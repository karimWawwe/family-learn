import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../state/session.dart';

// Phase 2: these screens are UI only. Phase 3 connects them to Supabase Auth.

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return MockScaffold(
      bannerKey: 'uiOnly',
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Spacer(),
            const Text('👨‍👦‍👦📚', textAlign: TextAlign.center, style: TextStyle(fontSize: 72)),
            const SizedBox(height: 16),
            Text(s.t('appName'), textAlign: TextAlign.center, style: context.text.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Text(s.t('welcomeTitle'), textAlign: TextAlign.center, style: context.text.titleLarge),
            const SizedBox(height: 8),
            Text(s.t('welcomeBody'), textAlign: TextAlign.center, style: context.text.bodyLarge?.copyWith(color: context.colors.onSurfaceVariant)),
            const Spacer(),
            FilledButton(onPressed: () => context.push(Routes.signUp), child: Text(s.t('getStarted'))),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: () => context.push(Routes.signIn), child: Text(s.t('haveAccount'))),
            const SizedBox(height: 8),
            const _LanguageToggle(),
          ],
        ),
      ),
    );
  }
}

class _LanguageToggle extends ConsumerWidget {
  const _LanguageToggle();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isAr = context.s.isArabic;
    return TextButton(
      onPressed: () => ref.read(sessionProvider.notifier).setLocale(Locale(isAr ? 'en' : 'ar')),
      child: Text(isAr ? 'English' : 'العربية'),
    );
  }
}

class _AuthForm extends ConsumerWidget {
  const _AuthForm({required this.titleKey, required this.primaryKey, required this.onPrimary});

  final String titleKey;
  final String primaryKey;
  final void Function(WidgetRef ref, BuildContext context) onPrimary;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    return MockScaffold(
      title: s.t(titleKey),
      bannerKey: 'uiOnly',
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          TextField(
            keyboardType: TextInputType.emailAddress,
            autofillHints: const [AutofillHints.email],
            decoration: InputDecoration(labelText: s.t('email'), prefixIcon: const Icon(Icons.mail_outline)),
          ),
          const SizedBox(height: 12),
          TextField(
            obscureText: true,
            autofillHints: const [AutofillHints.password],
            decoration: InputDecoration(labelText: s.t('password'), prefixIcon: const Icon(Icons.lock_outline)),
          ),
          const SizedBox(height: 20),
          FilledButton(onPressed: () => onPrimary(ref, context), child: Text(s.t(primaryKey))),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: () => onPrimary(ref, context), icon: const Icon(Icons.apple), label: Text(s.t('continueWithApple'))),
          const SizedBox(height: 8),
          OutlinedButton.icon(onPressed: () => onPrimary(ref, context), icon: const Icon(Icons.g_mobiledata), label: Text(s.t('continueWithGoogle'))),
          const PendingNote('backendPending'),
        ],
      ),
    );
  }
}

class SignInScreen extends StatelessWidget {
  const SignInScreen({super.key});

  @override
  Widget build(BuildContext context) => _AuthForm(
        titleKey: 'signIn',
        primaryKey: 'signIn',
        onPrimary: (ref, _) => ref.read(sessionProvider.notifier).signIn(),
      );
}

class SignUpScreen extends StatelessWidget {
  const SignUpScreen({super.key});

  @override
  Widget build(BuildContext context) => _AuthForm(
        titleKey: 'signUp',
        primaryKey: 'continue',
        onPrimary: (_, ctx) => ctx.push(Routes.consent),
      );
}

class ConsentScreen extends StatefulWidget {
  const ConsentScreen({super.key});

  @override
  State<ConsentScreen> createState() => _ConsentScreenState();
}

class _ConsentScreenState extends State<ConsentScreen> {
  bool _agreed = false;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return MockScaffold(
      title: s.t('consentTitle'),
      bannerKey: 'uiOnly',
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const Icon(Icons.shield_outlined, size: 56),
          const SizedBox(height: 16),
          Text(s.t('consentBody'), style: context.text.bodyLarge),
          const SizedBox(height: 16),
          CheckboxListTile(
            value: _agreed,
            onChanged: (v) => setState(() => _agreed = v ?? false),
            title: Text(s.t('consentAgree')),
            controlAffinity: ListTileControlAffinity.leading,
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _agreed ? () => context.push(Routes.createFamily) : null,
            child: Text(s.t('continue')),
          ),
        ],
      ),
    );
  }
}

class CreateFamilyScreen extends ConsumerStatefulWidget {
  const CreateFamilyScreen({super.key});

  @override
  ConsumerState<CreateFamilyScreen> createState() => _CreateFamilyScreenState();
}

class _LearnerDraft {
  _LearnerDraft({this.name = '', this.isChild = true, this.grade = 3});
  String name;
  bool isChild;
  int grade;
}

class _CreateFamilyScreenState extends ConsumerState<CreateFamilyScreen> {
  final _learners = <_LearnerDraft>[_LearnerDraft(isChild: false), _LearnerDraft()];

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return MockScaffold(
      title: s.t('createFamily'),
      bannerKey: 'uiOnly',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(decoration: InputDecoration(labelText: s.t('familyName'))),
          const SizedBox(height: 16),
          for (var i = 0; i < _learners.length; i++) _learnerCard(context, i),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => setState(() => _learners.add(_LearnerDraft())),
            icon: const Icon(Icons.person_add_alt_1),
            label: Text(s.t('addLearner')),
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: () => ref.read(sessionProvider.notifier).signIn(),
            child: Text(s.t('createFamily')),
          ),
          const PendingNote('backendPending'),
        ],
      ),
    );
  }

  Widget _learnerCard(BuildContext context, int i) {
    final s = context.s;
    final d = _learners[i];
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(labelText: s.t('name')),
              onChanged: (v) => d.name = v,
            ),
            const SizedBox(height: 8),
            SegmentedButton<bool>(
              segments: [
                ButtonSegment(value: false, label: Text(s.t('adult'))),
                ButtonSegment(value: true, label: Text(s.t('child'))),
              ],
              selected: {d.isChild},
              onSelectionChanged: (v) => setState(() => d.isChild = v.first),
            ),
            if (d.isChild) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  Text(s.t('grade')),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Slider(
                      value: d.grade.toDouble(),
                      min: 1,
                      max: 12,
                      divisions: 11,
                      label: '${d.grade}',
                      onChanged: (v) => setState(() => d.grade = v.round()),
                    ),
                  ),
                  Text('${d.grade}'),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}
