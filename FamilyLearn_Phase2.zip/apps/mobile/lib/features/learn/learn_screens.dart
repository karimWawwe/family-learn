import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/mock/mock_data.dart';
import '../../domain/models.dart';
import '../../domain/questions.dart';
import '../../state/session.dart';
import '../questions/question_views.dart';

// ---------------------------------------------------------------- course map
class CourseMapScreen extends ConsumerWidget {
  const CourseMapScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final s = context.s;
    final courses = MockData.coursesFor(p);
    return DefaultTabController(
      length: courses.length,
      child: MockScaffold(
        title: s.t('courses'),
        body: Column(
          children: [
            TabBar(isScrollable: true, tabs: [for (final c in courses) Tab(text: c.title)]),
            Expanded(
              child: TabBarView(children: [for (final c in courses) _CoursePath(course: c)]),
            ),
          ],
        ),
      ),
    );
  }
}

class _CoursePath extends StatelessWidget {
  const _CoursePath({required this.course});

  final Course course;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Chip(avatar: const Icon(Icons.flag, size: 18), label: Text(course.levelLabel)),
        ),
        for (var u = 0; u < course.units.length; u++) ...[
          SectionTitle('${s.t('unit')} ${u + 1}: ${course.units[u].title}'),
          for (final l in course.units[u].lessons) _LessonTile(lesson: l),
        ],
      ],
    );
  }
}

class _LessonTile extends StatelessWidget {
  const _LessonTile({required this.lesson});

  final LessonSummary lesson;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final (IconData icon, Color color) = switch (lesson.status) {
      LessonStatus.done => (Icons.check_circle, AppTokens.good),
      LessonStatus.inProgress => (Icons.play_circle_fill, context.colors.primary),
      LessonStatus.available => (Icons.play_circle_outline, context.colors.primary),
      LessonStatus.locked => (Icons.lock_outline, context.colors.outline),
    };
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: ListTile(
        leading: Icon(icon, color: color, size: 32),
        title: Text(lesson.title),
        subtitle: Text(lesson.status == LessonStatus.locked ? s.t('locked') : s.f('minutes', [lesson.minutes])),
        enabled: lesson.status != LessonStatus.locked,
        onTap: () => context.push(Routes.lesson(lesson.id)),
      ),
    );
  }
}

// ---------------------------------------------------------------- lesson player
class LessonResult {
  const LessonResult({required this.correct, required this.total, this.isPlacement = false});
  final int correct;
  final int total;
  final bool isPlacement;
}

class LessonPlayerScreen extends ConsumerStatefulWidget {
  const LessonPlayerScreen({super.key, required this.lessonId, this.isPlacement = false});

  final String lessonId;
  final bool isPlacement;

  @override
  ConsumerState<LessonPlayerScreen> createState() => _LessonPlayerScreenState();
}

class _LessonPlayerScreenState extends ConsumerState<LessonPlayerScreen> {
  late final List<Question> _questions;
  int _index = 0;
  Object? _answer;
  bool? _result; // null = not checked yet
  bool _checked = false;
  int _correct = 0;
  bool _showHint = false;

  @override
  void initState() {
    super.initState();
    final p = ref.read(currentProfileProvider);
    _questions = p == null ? const [] : MockData.lessonFor(p);
  }

  Question get _q => _questions[_index];

  void _check() {
    final r = checkAnswer(_q, _answer);
    setState(() {
      _checked = true;
      _result = r;
      if (r ?? true) _correct++; // speaking counts as done until Phase 9 scoring
    });
  }

  void _next() {
    if (_index + 1 >= _questions.length) {
      final result = LessonResult(correct: _correct, total: _questions.length, isPlacement: widget.isPlacement);
      if (widget.isPlacement) {
        context.pushReplacement(Routes.placementResult);
      } else {
        context.pushReplacement(Routes.lessonComplete, extra: result);
      }
      return;
    }
    setState(() {
      _index++;
      _answer = null;
      _result = null;
      _checked = false;
      _showHint = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    if (_questions.isEmpty) {
      return const MockScaffold(title: '', body: SizedBox.shrink());
    }
    return MockScaffold(
      title: s.f('questionOf', [_index + 1, _questions.length]),
      actions: [
        if (_q.hint != null)
          IconButton(
            tooltip: s.t('hint'),
            icon: const Icon(Icons.lightbulb_outline),
            onPressed: () => setState(() => _showHint = true),
          ),
      ],
      body: Column(
        children: [
          LinearProgressIndicator(value: (_index + (_checked ? 1 : 0)) / _questions.length, minHeight: 6),
          if (_showHint && _q.hint != null)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: const Color(0xFFFFF8E1), borderRadius: BorderRadius.circular(12)),
              child: Text('💡 ${_q.hint!}', textDirection: TextDirection.ltr),
            ),
          Expanded(
            child: QuestionView(
              key: ValueKey(_q.id),
              question: _q,
              locked: _checked,
              onAnswer: (a) => setState(() => _answer = a),
            ),
          ),
          if (_checked) _FeedbackBar(question: _q, result: _result),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _checked ? _next : (_answer == null ? null : _check),
                child: Text(_checked ? s.t('next') : s.t('check')),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FeedbackBar extends StatelessWidget {
  const _FeedbackBar({required this.question, required this.result});

  final Question question;
  final bool? result;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final ok = result ?? true;
    final color = ok ? AppTokens.good : AppTokens.bad;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(14)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(ok ? Icons.check_circle : Icons.cancel, color: color),
              const SizedBox(width: 8),
              Text(ok ? s.t('correct') : s.t('notQuite'), style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 18)),
              const Spacer(),
              if (!ok)
                TextButton.icon(
                  onPressed: () => context.push(Routes.tutor),
                  icon: const Icon(Icons.smart_toy_outlined, size: 18),
                  label: Text(s.t('explain')),
                ),
            ],
          ),
          if (!ok) Text(s.f('correctAnswer', [correctAnswerText(question)]), textDirection: TextDirection.ltr),
          if (question.explanation != null) ...[
            const SizedBox(height: 4),
            Text(question.explanation!, textDirection: TextDirection.ltr, style: context.text.bodySmall),
          ],
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- lesson complete
class LessonCompleteScreen extends StatelessWidget {
  const LessonCompleteScreen({super.key, required this.result});

  final LessonResult result;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final pct = result.total == 0 ? 0 : (result.correct * 100 / result.total).round();
    // MOCK: 10 XP per correct answer. Real XP is written by the server (Phase 10).
    final xp = result.correct * 10;
    return MockScaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('🎉', style: TextStyle(fontSize: 80)),
              const SizedBox(height: 12),
              Text(s.t('lessonComplete'), style: context.text.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(child: StatTile(label: s.t('accuracy'), value: '$pct%', icon: Icons.track_changes)),
                  Expanded(child: StatTile(label: 'XP', value: s.f('xpEarned', [xp]), icon: Icons.bolt, color: AppTokens.xp)),
                ],
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: FilledButton(onPressed: () => context.go(Routes.home), child: Text(s.t('done'))),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
