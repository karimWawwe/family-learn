import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/widgets/common.dart';
import '../../state/session.dart';

class MainShell extends StatelessWidget {
  const MainShell({super.key, required this.shell});

  final StatefulNavigationShell shell;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Scaffold(
      body: shell,
      bottomNavigationBar: NavigationBar(
        selectedIndex: shell.currentIndex,
        onDestinationSelected: (i) => shell.goBranch(i, initialLocation: i == shell.currentIndex),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: s.t('navHome')),
          NavigationDestination(icon: const Icon(Icons.map_outlined), selectedIcon: const Icon(Icons.map), label: s.t('navLearn')),
          NavigationDestination(icon: const Icon(Icons.replay_circle_filled_outlined), selectedIcon: const Icon(Icons.replay_circle_filled), label: s.t('navReview')),
          NavigationDestination(icon: const Icon(Icons.insights_outlined), selectedIcon: const Icon(Icons.insights), label: s.t('navProgress')),
          NavigationDestination(icon: const Icon(Icons.menu), label: s.t('navMore')),
        ],
      ),
    );
  }
}

class MoreScreen extends ConsumerWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    return MockScaffold(
      title: s.t('navMore'),
      body: ListView(
        children: [
          ListTile(leading: const Icon(Icons.menu_book_outlined), title: Text(s.t('vocabulary')), onTap: () => context.push(Routes.vocab)),
          ListTile(leading: const Icon(Icons.smart_toy_outlined), title: Text(s.t('aiTutor')), onTap: () => context.push(Routes.tutor)),
          if (!p.isChild)
            ListTile(leading: const Icon(Icons.record_voice_over_outlined), title: Text(s.t('roleplay')), onTap: () => context.push(Routes.roleplay)),
          ListTile(leading: const Icon(Icons.emoji_events_outlined), title: Text(s.t('achievements')), onTap: () => context.push(Routes.achievements)),
          if (p.isChild)
            ListTile(leading: const Icon(Icons.storefront_outlined), title: Text(s.t('shop')), onTap: () => context.push(Routes.shop)),
          if (p.isParent)
            ListTile(leading: const Icon(Icons.family_restroom), title: Text(s.t('parentDashboard')), onTap: () => context.push(Routes.parent)),
          ListTile(leading: const Icon(Icons.flag_outlined), title: Text(s.t('placementTitle')), onTap: () => context.push(Routes.placement(p.id))),
          ListTile(leading: const Icon(Icons.settings_outlined), title: Text(s.t('settings')), onTap: () => context.push(Routes.settings)),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.switch_account_outlined),
            title: Text(s.t('switchProfile')),
            onTap: () {
              ref.read(sessionProvider.notifier).clearProfile();
              context.go(Routes.profiles);
            },
          ),
        ],
      ),
    );
  }
}
