import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/mock/mock_data.dart';
import '../../domain/models.dart';
import '../../state/session.dart';

class ProfilePickerScreen extends ConsumerWidget {
  const ProfilePickerScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final profiles = MockData.profiles;
    return MockScaffold(
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 24),
          Text(s.t('whoIsLearning'), textAlign: TextAlign.center, style: context.text.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 24),
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 16,
            runSpacing: 16,
            children: [
              for (final p in profiles)
                _ProfileTile(
                  profile: p,
                  onTap: () => context.push(Routes.pin(p.id)),
                ),
            ],
          ),
          const SizedBox(height: 32),
          TextButton.icon(
            onPressed: () => context.push(Routes.pairDevice),
            icon: const Icon(Icons.qr_code_2),
            label: Text(s.t('pairDevice')),
          ),
          TextButton(
            onPressed: () => ref.read(sessionProvider.notifier).signOut(),
            child: Text(s.t('signOut')),
          ),
        ],
      ),
    );
  }
}

class _ProfileTile extends StatelessWidget {
  const _ProfileTile({required this.profile, required this.onTap});

  final LearnerProfile profile;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = profile.isChild ? const Color(0xFFFFE8D6) : const Color(0xFFE3E9F2);
    return Semantics(
      button: true,
      label: profile.displayName,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: SizedBox(
          width: 130,
          child: Column(
            children: [
              Container(
                width: 110,
                height: 110,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(28)),
                child: Text(profile.avatarEmoji, style: const TextStyle(fontSize: 56)),
              ),
              const SizedBox(height: 8),
              Text(profile.displayName, style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
              Text(
                profile.isChild ? '${context.s.t('grade')} ${profile.grade}' : context.s.t('adult'),
                style: context.text.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PinScreen extends ConsumerStatefulWidget {
  const PinScreen({super.key, required this.profileId});

  final String profileId;

  @override
  ConsumerState<PinScreen> createState() => _PinScreenState();
}

class _PinScreenState extends ConsumerState<PinScreen> {
  String _pin = '';

  void _press(String d) {
    if (_pin.length >= 4) return;
    setState(() => _pin += d);
    if (_pin.length == 4) {
      // Phase 2: any 4 digits. Phase 3: Argon2-hashed PIN checked by the API,
      // 5 wrong attempts lock the profile for 15 minutes.
      ref.read(sessionProvider.notifier).selectProfile(widget.profileId);
      context.go(Routes.home);
    }
  }

  void _delete() {
    if (_pin.isEmpty) return;
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  @override
  Widget build(BuildContext context) {
    final p = MockData.profileById(widget.profileId);
    final s = context.s;
    return MockScaffold(
      title: p.displayName,
      body: Column(
        children: [
          const SizedBox(height: 24),
          Text(p.avatarEmoji, style: const TextStyle(fontSize: 64)),
          const SizedBox(height: 8),
          Text(s.t('enterPin'), style: context.text.titleLarge),
          Text(s.t('pinHint'), style: context.text.bodySmall),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 0; i < 4; i++)
                Container(
                  margin: const EdgeInsets.all(8),
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: i < _pin.length ? context.colors.primary : context.colors.surfaceContainerHighest,
                  ),
                ),
            ],
          ),
          const Spacer(),
          Directionality(
            textDirection: TextDirection.ltr,
            child: GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 16),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.4,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                for (final d in ['1', '2', '3', '4', '5', '6', '7', '8', '9'])
                  _Key(label: d, onTap: () => _press(d)),
                const SizedBox.shrink(),
                _Key(label: '0', onTap: () => _press('0')),
                _Key(icon: Icons.backspace_outlined, onTap: _delete),
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

class _Key extends StatelessWidget {
  const _Key({this.label, this.icon, required this.onTap});

  final String? label;
  final IconData? icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: context.colors.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Center(
          child: label != null
              ? Text(label!, style: context.text.headlineSmall)
              : Icon(icon),
        ),
      ),
    );
  }
}

class PairDeviceScreen extends StatelessWidget {
  const PairDeviceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return MockScaffold(
      title: s.t('pairDevice'),
      bannerKey: 'uiOnly',
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text(s.t('pairBody'), style: context.text.bodyLarge),
          const SizedBox(height: 24),
          Center(
            child: Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                border: Border.all(color: context.colors.outline, width: 2),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.qr_code_2, size: 180),
            ),
          ),
          const PendingNote('backendPending'),
        ],
      ),
    );
  }
}
