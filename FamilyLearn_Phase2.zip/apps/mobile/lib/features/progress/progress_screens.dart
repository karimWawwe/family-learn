import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/mock/mock_data.dart';
import '../../state/session.dart';

class ProgressScreen extends ConsumerWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final s = context.s;
    final wallet = MockData.walletFor(p);
    final skills = MockData.masteryFor(p);
    final subjects = <String>{for (final sk in skills) sk.subject}.toList();
    final badges = MockData.achievementsFor(p);

    return MockScaffold(
      title: s.t('myProgress'),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            child: Row(
              children: [
                Expanded(child: StatTile(label: s.f('level', [wallet.level]), value: '${wallet.xp}', icon: Icons.bolt, color: AppTokens.xp)),
                Expanded(child: StatTile(label: s.f('streak', [wallet.streakDays]), value: '🔥 ${wallet.streakDays}', icon: Icons.local_fire_department, color: AppTokens.warn)),
                if (p.isChild) Expanded(child: StatTile(label: s.t('coins'), value: '${wallet.coins}', icon: Icons.monetization_on, color: AppTokens.coin)),
              ],
            ),
          ),
          for (final subj in subjects) ...[
            SectionTitle(subj == 'math' ? 'Math' : subj == 'business' ? 'Business English' : 'English'),
            for (final sk in skills.where((x) => x.subject == subj)) MasteryBar(label: sk.name, value: sk.mastery),
          ],
          SectionTitle(
            s.t('achievements'),
            trailing: TextButton(onPressed: () => context.push(Routes.achievements), child: const Icon(Icons.chevron_right)),
          ),
          SizedBox(
            height: 96,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [for (final b in badges) _BadgeChip(emoji: b.emoji, title: b.title, earned: b.earned)],
            ),
          ),
        ],
      ),
    );
  }
}

class _BadgeChip extends StatelessWidget {
  const _BadgeChip({required this.emoji, required this.title, required this.earned});

  final String emoji;
  final String title;
  final bool earned;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: earned ? 1 : 0.35,
      child: Container(
        width: 96,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        child: Column(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 40)),
            Text(title, maxLines: 2, textAlign: TextAlign.center, style: context.text.labelSmall),
          ],
        ),
      ),
    );
  }
}

class AchievementsScreen extends ConsumerWidget {
  const AchievementsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final badges = MockData.achievementsFor(p);
    return MockScaffold(
      title: context.s.t('achievements'),
      body: GridView.count(
        crossAxisCount: 2,
        padding: const EdgeInsets.all(16),
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        children: [
          for (final b in badges)
            Card(
              child: Opacity(
                opacity: b.earned ? 1 : 0.4,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(b.emoji, style: const TextStyle(fontSize: 52)),
                    const SizedBox(height: 8),
                    Text(b.title, textAlign: TextAlign.center, style: context.text.titleSmall),
                    if (!b.earned) const Icon(Icons.lock_outline, size: 16),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class ShopScreen extends ConsumerWidget {
  const ShopScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final s = context.s;
    final wallet = MockData.walletFor(p);
    return MockScaffold(
      title: s.t('shop'),
      actions: [
        Padding(
          padding: const EdgeInsetsDirectional.only(end: 16),
          child: Center(child: Text('🪙 ${wallet.coins}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18))),
        ),
      ],
      body: GridView.count(
        crossAxisCount: 2,
        padding: const EdgeInsets.all(16),
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 0.85,
        children: [
          for (final item in MockData.shopItems)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(item.$2, style: const TextStyle(fontSize: 48)),
                    const SizedBox(height: 6),
                    Text(item.$1, textAlign: TextAlign.center, style: context.text.titleSmall),
                    const SizedBox(height: 8),
                    item.$4
                        ? Chip(label: Text(s.t('owned')))
                        : FilledButton.tonal(
                            // Phase 10: purchases are written by the server from the XP/coin ledger.
                            onPressed: wallet.coins >= item.$3 ? () {} : null,
                            child: Text('${s.t('buy')} 🪙 ${item.$3}'),
                          ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
