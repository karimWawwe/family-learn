import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/mock/mock_data.dart';
import '../domain/models.dart';

/// Phase 2: the session is local UI state only (MOCK DATA).
/// Phase 3 replaces this with Supabase Auth + child sessions issued by the API.
class SessionState {
  const SessionState({
    this.signedIn = false,
    this.profileId,
    this.localeOverride,
    this.themeMode = ThemeMode.light,
  });

  final bool signedIn;
  final String? profileId;
  final Locale? localeOverride;
  final ThemeMode themeMode;

  LearnerProfile? get profile => profileId == null ? null : MockData.profileById(profileId!);

  SessionState copyWith({
    bool? signedIn,
    String? profileId,
    bool clearProfile = false,
    Locale? localeOverride,
    ThemeMode? themeMode,
  }) =>
      SessionState(
        signedIn: signedIn ?? this.signedIn,
        profileId: clearProfile ? null : (profileId ?? this.profileId),
        localeOverride: localeOverride ?? this.localeOverride,
        themeMode: themeMode ?? this.themeMode,
      );
}

class SessionController extends Notifier<SessionState> {
  @override
  SessionState build() => const SessionState();

  void signIn() => state = state.copyWith(signedIn: true);

  void signOut() => state = const SessionState();

  /// Switching learner also resets any manual language choice, so each
  /// profile opens in its own UI language.
  void selectProfile(String id) => state = SessionState(
        signedIn: state.signedIn,
        profileId: id,
        themeMode: state.themeMode,
      );

  void clearProfile() => state = state.copyWith(clearProfile: true);

  void setLocale(Locale locale) => state = state.copyWith(localeOverride: locale);

  void setThemeMode(ThemeMode mode) => state = state.copyWith(themeMode: mode);
}

final sessionProvider = NotifierProvider<SessionController, SessionState>(SessionController.new);

/// The active learner. Screens under the shell always have one.
final currentProfileProvider = Provider<LearnerProfile?>((ref) => ref.watch(sessionProvider).profile);

/// UI locale: manual override, else the active profile's language, else English.
final localeProvider = Provider<Locale>((ref) {
  final s = ref.watch(sessionProvider);
  return s.localeOverride ?? Locale(s.profile?.uiLocale ?? 'en');
});
