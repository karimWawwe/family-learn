// Tests for the AI gateway (no network): AI_CHAT_TEST=1 deno test --allow-env index_test.ts
import { chatMessages, handle, keys, parseFeedback, type Prepared, systemPrompt } from "./index.ts";

function assert(cond: unknown, msg: string) {
  if (!cond) throw new Error("FAILED: " + msg);
}

const baseEnv: Record<string, string> = {
  ANTHROPIC_API_KEY: "test-key",
  SUPABASE_URL: "https://x.supabase.co",
  SUPABASE_PUBLISHABLE_KEYS: JSON.stringify({ default: "sb_publishable_abc" }),
  SUPABASE_SECRET_KEYS: JSON.stringify({ default: "sb_secret_xyz" }),
};
const env = (over: Record<string, string | undefined> = {}) => (n: string) => ({ ...baseEnv, ...over } as Record<string, string | undefined>)[n];

function prepared(over: Partial<Prepared> = {}): Prepared {
  return {
    conversation_id: "c1",
    kind: "tutor",
    profile: { name: "Yassin", kind: "child", grade: 3, ui_locale: "ar" },
    scenario: null,
    context: {},
    history: [{ role: "user", content: "ساعدني" }],
    remaining_today: 19,
    ...over,
  };
}

type Call = { url: string; init: RequestInit };
function fakeFetch(prep: unknown, claude: { status?: number; body: unknown }, finish: unknown = { ok: true, remaining_today: 18 }, prepStatus = 200) {
  const calls: Call[] = [];
  const f = (async (input: string | URL | Request, init?: RequestInit) => {
    const url = String(input);
    calls.push({ url, init: init ?? {} });
    if (url.endsWith("/rpc/ai_prepare")) return new Response(JSON.stringify(prep), { status: prepStatus });
    if (url.endsWith("/rpc/ai_finish")) return new Response(JSON.stringify(finish), { status: 200 });
    if (url.startsWith("https://api.anthropic.com/")) return new Response(JSON.stringify(claude.body), { status: claude.status ?? 200 });
    return new Response("{}", { status: 404 });
  }) as typeof fetch;
  return { f, calls };
}

const req = (body: unknown, auth = "Bearer user-jwt") =>
  new Request("https://x/functions/v1/ai-chat", { method: "POST", headers: { Authorization: auth, "Content-Type": "application/json" }, body: JSON.stringify(body) });

const claudeText = (text: string) => ({ body: { content: [{ type: "text", text }], usage: { input_tokens: 1000, output_tokens: 200 } } });

Deno.test("keys: new JSON keys and legacy keys", () => {
  assert(keys(env()).secret === "sb_secret_xyz" && keys(env()).publishable === "sb_publishable_abc", "new keys");
  const legacy = (n: string) => ({ SUPABASE_ANON_KEY: "anon", SUPABASE_SERVICE_ROLE_KEY: "service" } as Record<string, string>)[n];
  assert(keys(legacy).secret === "service" && keys(legacy).publishable === "anon", "legacy keys");
});

Deno.test("no API key -> ai_not_configured, no calls", async () => {
  const { f, calls } = fakeFetch({}, claudeText("x"));
  const r = await handle(req({ kind: "tutor", profile_id: "p" }), env({ ANTHROPIC_API_KEY: undefined }), f);
  assert(r.status === 503 && (await r.json()).error === "ai_not_configured", "503");
  assert(calls.length === 0, "nothing called");
});

Deno.test("not signed in -> 401", async () => {
  const { f } = fakeFetch({}, claudeText("x"));
  const r = await handle(req({ kind: "tutor" }, ""), env(), f);
  assert(r.status === 401, "401");
});

Deno.test("tutor: prepare as user, Claude, finish with the secret key, cost", async () => {
  const { f, calls } = fakeFetch(prepared(), claudeText("أهلًا! Bonjour تعني صباح الخير."));
  const r = await handle(req({ kind: "tutor", profile_id: "p", message: "ساعدني" }), env(), f);
  const j = await r.json();
  assert(r.status === 200 && j.reply.includes("Bonjour") && j.remaining_today === 18, "reply");
  const [prep, claude, fin] = calls;
  const ph = new Headers(prep.init.headers);
  assert(ph.get("Authorization") === "Bearer user-jwt" && ph.get("apikey") === "sb_publishable_abc", "prepare runs as the user");
  const ch = new Headers(claude.init.headers);
  assert(ch.get("x-api-key") === "test-key" && ch.get("anthropic-version") === "2023-06-01", "anthropic headers");
  const cb = JSON.parse(String(claude.init.body));
  assert(cb.model === "claude-haiku-5-5" && cb.max_tokens === 350 && cb.messages[0].role === "user", "child request");
  assert(cb.system.includes("Arabic") && cb.system.includes("[FLAG]"), "child safety + Arabic in the system prompt");
  const fh = new Headers(fin.init.headers);
  assert(fh.get("apikey") === "sb_secret_xyz" && !fh.get("Authorization"), "finish uses the secret key (new keys: no bearer)");
  const fb = JSON.parse(String(fin.init.body));
  assert(Math.abs(fb.p_cost - (1000 * 0.1 + 200 * 0.5) / 1e6) < 1e-9 && fb.p_role === "assistant" && fb.p_flagged === false, "cost and role");
});

Deno.test("legacy service key is also sent as bearer", async () => {
  const { f, calls } = fakeFetch(prepared(), claudeText("ok"));
  await handle(req({ kind: "tutor", profile_id: "p", message: "hi" }),
    env({ SUPABASE_SECRET_KEYS: undefined, SUPABASE_SERVICE_ROLE_KEY: "eyJservice" }), f);
  assert(new Headers(calls[2].init.headers).get("Authorization") === "Bearer eyJservice", "bearer legacy");
});

Deno.test("safety flag is removed from the reply and saved", async () => {
  const { f, calls } = fakeFetch(prepared(), claudeText("[FLAG] من فضلك أخبر أباك أو معلمك الآن."));
  const j = await (await handle(req({ kind: "tutor", profile_id: "p", message: "x" }), env(), f)).json();
  assert(j.flagged === true && !j.reply.includes("[FLAG]"), "flag hidden");
  assert(JSON.parse(String(calls[2].init.body)).p_flagged === true, "flag saved");
});

Deno.test("limit / access errors from the database pass through", async () => {
  const { f, calls } = fakeFetch({ code: "P0001", message: "ai_daily_limit" }, claudeText("x"), {}, 400);
  const r = await handle(req({ kind: "tutor", profile_id: "p", message: "x" }), env(), f);
  assert(r.status === 400 && (await r.json()).error === "ai_daily_limit", "limit");
  assert(calls.length === 1, "Claude not called");
});

Deno.test("Anthropic errors become friendly codes", async () => {
  for (const [status, type, code] of [[401, "authentication_error", "ai_key_invalid"], [529, "overloaded_error", "ai_busy"],
                                      [400, "invalid_request_error", "ai_error"]] as const) {
    const { f, calls } = fakeFetch(prepared(), { status, body: { error: { type, message: "x" } } });
    const r = await handle(req({ kind: "tutor", profile_id: "p", message: "x" }), env(), f);
    assert((await r.json()).error === code, code);
    assert(calls.length === 2, "nothing saved for a failed call");
  }
  const { f } = fakeFetch(prepared(), { status: 400, body: { error: { type: "invalid_request_error", message: "Your credit balance is too low" } } });
  assert((await (await handle(req({ kind: "tutor", profile_id: "p", message: "x" }), env(), f)).json()).error === "ai_no_credit", "credit");
});

Deno.test("role-play: AI speaks first, French scenario, no corrections", async () => {
  const p = prepared({
    kind: "roleplay", history: [],
    profile: { name: "Omar", kind: "child", grade: 6, ui_locale: "en" },
    scenario: { code: "kid6_fr_cafe", lang: "fr", title: "Au café", persona: "Un serveur", goal: "Commander" },
  });
  const m = chatMessages(p);
  assert(m.length === 1 && m[0].role === "user" && m[0].content.includes("first line"), "opening request");
  const sys = systemPrompt(p);
  assert(sys.includes("Speak ONLY French") && sys.includes("Do not correct"), "french role-play prompt");
  const { f, calls } = fakeFetch(p, claudeText("Bonjour ! Vous désirez ?"));
  const j = await (await handle(req({ kind: "roleplay", profile_id: "p", context: { scenario: "kid6_fr_cafe" } }), env(), f)).json();
  assert(j.reply.startsWith("Bonjour"), "opening line");
  assert(JSON.parse(String(calls[0].init.body)).p_message === null, "no learner message");
});

Deno.test("history is merged so roles alternate and ends with the user", () => {
  const m = chatMessages(prepared({
    kind: "roleplay",
    scenario: { code: "x", lang: "en", title: "t", persona: "p", goal: "g" },
    history: [{ role: "assistant", content: "Hi" }, { role: "user", content: "a" }, { role: "user", content: "b" }],
  }));
  assert(m.map((x) => x.role).join(",") === "user,assistant,user" && m[2].content === "a\nb", "alternating");
});

Deno.test("feedback: JSON parsed, cached feedback skips Claude", async () => {
  const fb = parseFeedback('Here: {"summary":"Bravo","goal_reached":true,"grammar":[["je suis 12 ans","j\'ai 12 ans"]],"phrases":["Je voudrais…"],"new_words":["serveur — نادل"]}');
  assert(fb.summary === "Bravo" && (fb.grammar as string[][])[0][1] === "j'ai 12 ans" && fb.goal_reached === true, "parsed");
  assert(parseFeedback("not json at all").summary === "not json at all", "fallback summary");
  const { f, calls } = fakeFetch({ conversation_id: "c", kind: "feedback", cached_feedback: { summary: "old" } }, claudeText("x"));
  const j = await (await handle(req({ kind: "feedback", profile_id: "p", conversation_id: "c" }), env(), f)).json();
  assert(j.feedback.summary === "old" && calls.length === 1, "cached");
});

Deno.test("tutor prompt: no answer before answering, answer after, religion rule", () => {
  const before = systemPrompt(prepared({ context: { question: "Q?", answered: false, subject: "french" } }));
  assert(before.includes("do NOT give the answer"), "hint only");
  const after = systemPrompt(prepared({ context: { question: "Q?", answered: true, learner_was_right: false, correct_answer: "Bonsoir", subject: "religion" } }));
  assert(after.includes("Correct answer: Bonsoir") && after.includes("never invent"), "answer + religion");
  const adult = systemPrompt(prepared({ profile: { name: "Karim", kind: "adult", grade: null, ui_locale: "en" } }));
  assert(!adult.includes("[FLAG]") && adult.includes("sales manager"), "adult prompt");
});
