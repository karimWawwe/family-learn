-- LOCAL TESTING ONLY (plain PostgreSQL + supabase_stub.sql). Do NOT run on Supabase.
-- Bedtime stories + parent follow report.
\set ON_ERROR_STOP 1
\set QUIET 1

create schema tb;
grant usage on schema tb to authenticated, anon;
create function tb.login(p_uid uuid, p_anon boolean default false) returns void
language sql as $$
  select set_config('request.jwt.claims',
                    json_build_object('sub', p_uid, 'role', 'authenticated', 'is_anonymous', p_anon)::text, false)
$$;
create function tb.expect_error(p_sql text, p_msg text) returns void
language plpgsql as $$
begin
  execute p_sql;
  raise exception 'EXPECTED ERROR "%" but statement succeeded: %', p_msg, p_sql;
exception
  when others then
    if sqlerrm like 'EXPECTED ERROR%' then raise; end if;
    if sqlerrm <> p_msg then raise exception 'expected error "%", got "%" for: %', p_msg, sqlerrm, p_sql; end if;
end $$;
create function tb.ok(p_cond boolean, p_what text) returns void
language plpgsql as $$
begin
  if p_cond is not true then raise exception 'FAILED: %', p_what; end if;
  raise notice 'ok - %', p_what;
end $$;
create table tb.vars (k text primary key, v text);
grant all on tb.vars to authenticated, anon;
create function tb.v(p_k text) returns text language sql as $$ select v from tb.vars where k = p_k $$;
grant execute on all functions in schema tb to authenticated, anon;

insert into auth.users (id, email, is_anonymous) values
  ('00000000-0000-0000-0000-00000000000a', 'kareem@example.com', false),
  ('00000000-0000-0000-0000-0000000000c1', null, true),
  ('00000000-0000-0000-0000-0000000000c2', null, true),
  ('00000000-0000-0000-0000-00000000000b', 'bob@example.com', false);

set role authenticated;
select tb.login('00000000-0000-0000-0000-00000000000a');
select create_family('Junaid', 'Kareem', 'en', 'v1', '[
  {"display_name":"Omar","kind":"child","grade":6},
  {"display_name":"Yassin","kind":"child","grade":3,"ui_locale":"ar"}]');
insert into tb.vars select 'omar',   id::text from profiles where display_name = 'Omar';
insert into tb.vars select 'yassin', id::text from profiles where display_name = 'Yassin';
insert into tb.vars select 'kareem', id::text from profiles where display_name = 'Kareem';
insert into tb.vars select 'code_y', create_pairing_code(tb.v('yassin')::uuid) ->> 'code';
insert into tb.vars select 'code_o', create_pairing_code(tb.v('omar')::uuid) ->> 'code';
select tb.login('00000000-0000-0000-0000-0000000000c1', true);
select redeem_pairing_code(tb.v('code_y'), 'Yassin phone');
select tb.login('00000000-0000-0000-0000-0000000000c2', true);
select redeem_pairing_code(tb.v('code_o'), 'Omar phone');

-- ---------------------------------------------------------------- empty report first
select tb.login('00000000-0000-0000-0000-00000000000a');
select tb.ok((parent_follow(tb.v('yassin')::uuid, 'week') -> 'current' ->> 'days_used')::int = 0, 'new child: 0 days');
select tb.ok(parent_follow(tb.v('yassin')::uuid, 'week') -> 'last_story' = 'null'::jsonb
             or parent_follow(tb.v('yassin')::uuid, 'week') -> 'last_story' is null, 'new child: no last story');
select tb.ok(parent_follow(tb.v('yassin')::uuid, 'week') -> 'suggestion' ->> 'id' = 's01-honest-rabbit', 'suggests the first story');

-- ---------------------------------------------------------------- Yassin listens on his phone
select tb.login('00000000-0000-0000-0000-0000000000c1', true);
select tb.ok(jsonb_array_length(bedtime_state(tb.v('yassin')::uuid) -> 'stories') = 39, '39 stories for Yassin (with the 25 prophets stories)');
select tb.expect_error($$ select * from public.bedtime_listens $$, 'permission denied for table bedtime_listens');
select tb.expect_error(format($$ select bedtime_state(%L) $$, tb.v('omar')), 'not_found');
select tb.expect_error(format($$ select bedtime_start(%L, 's01-honest-rabbit') $$, tb.v('omar')), 'not_found');

insert into tb.vars select 'l1', bedtime_start(tb.v('yassin')::uuid, 's01-honest-rabbit') ->> 'listen_id';
select bedtime_progress(tb.v('l1')::uuid, 3, 120);
select tb.ok((bedtime_start(tb.v('yassin')::uuid, 's01-honest-rabbit') ->> 'listen_id') = tb.v('l1'), 're-opening continues the same listen');
select tb.ok((bedtime_start(tb.v('yassin')::uuid, 's01-honest-rabbit') ->> 'page')::int = 3, 'continues at the saved page');
select bedtime_progress(tb.v('l1')::uuid, 5, 90);  -- seconds never go down
select bedtime_complete(tb.v('l1')::uuid, 240, true);
select bedtime_favorite(tb.v('yassin')::uuid, 's01-honest-rabbit', true);
insert into tb.vars select 'l2', bedtime_start(tb.v('yassin')::uuid, 's04-kitten-rain') ->> 'listen_id';
select bedtime_progress(tb.v('l2')::uuid, 2, 60);
-- a speaking-game try (for minutes and last activity)
select speak_record_attempt(tb.v('yassin')::uuid, 'y1-sounds', 'stop', 'stop', 1, 'correct', 1);

select tb.ok((bedtime_state(tb.v('yassin')::uuid) -> 'last' ->> 'story_id') = 's04-kitten-rain', 'last story saved');
select tb.ok((select (s ->> 'favorite')::boolean from jsonb_array_elements(bedtime_state(tb.v('yassin')::uuid) -> 'stories') s
               where s ->> 'id' = 's01-honest-rabbit'), 'favourite saved');
select tb.ok((select (s ->> 'completed')::int from jsonb_array_elements(bedtime_state(tb.v('yassin')::uuid) -> 'stories') s
               where s ->> 'id' = 's01-honest-rabbit') = 1, 'completion saved');

-- Omar's phone cannot touch Yassin's listen
select tb.login('00000000-0000-0000-0000-0000000000c2', true);
select tb.expect_error(format($$ select bedtime_progress(%L, 1, 10) $$, tb.v('l1')), 'not_found');
select tb.expect_error(format($$ select parent_follow(%L, 'week') $$, tb.v('omar')), 'parent_only');
select tb.ok((select count(*) from jsonb_array_elements(bedtime_state(tb.v('omar')::uuid) -> 'stories') s
               where (s ->> 'completed')::int > 0) = 0, 'Omar has his own (empty) progress');

-- ---------------------------------------------------------------- parent report
select tb.login('00000000-0000-0000-0000-00000000000a');
insert into tb.vars select 'rep', parent_follow(tb.v('yassin')::uuid, 'week')::text;
select tb.ok((tb.v('rep')::jsonb -> 'current' ->> 'stories_listened')::int = 2, 'report: 2 stories listened');
select tb.ok((tb.v('rep')::jsonb -> 'current' ->> 'stories_completed')::int = 1, 'report: 1 story completed');
select tb.ok((tb.v('rep')::jsonb -> 'current' ->> 'minutes_stories')::int = 5, 'report: 5 story minutes (240+60 s)');
select tb.ok((tb.v('rep')::jsonb -> 'current' ->> 'days_used')::int = 1, 'report: 1 day used');
select tb.ok((tb.v('rep')::jsonb -> 'current' ->> 'minutes_total')::int >= 5, 'report: total minutes include stories + speaking');
select tb.ok((tb.v('rep')::jsonb -> 'current' -> 'values') = '["الصدق"]'::jsonb, 'report: value learned');
select tb.ok((tb.v('rep')::jsonb -> 'last_story' ->> 'title') = 'القطّةُ الصغيرةُ والمطر', 'report: last story');
select tb.ok(jsonb_array_length(tb.v('rep')::jsonb -> 'favorites') = 1, 'report: favourites');
select tb.ok((tb.v('rep')::jsonb ->> 'top_value') = 'الصدق', 'report: top value');
select tb.ok((tb.v('rep')::jsonb -> 'suggestion' ->> 'id') <> 's01-honest-rabbit', 'report: suggestion is an unfinished story');
select tb.ok((tb.v('rep')::jsonb -> 'progress' ->> 'story_points')::int = 20, 'report: progress points from stories');
select tb.ok((tb.v('rep')::jsonb -> 'last_activity' ->> 'kind') in ('story', 'speak'), 'report: last activity');
select tb.ok(jsonb_array_length(tb.v('rep')::jsonb -> 'by_day') = 7, 'report: 7 days series');
select tb.ok((tb.v('rep')::jsonb -> 'previous' ->> 'stories_completed')::int = 0, 'report: previous period empty');
select tb.ok(jsonb_array_length(parent_follow(tb.v('yassin')::uuid, 'month') -> 'by_day') = 30, 'month: 30 days series');
select tb.ok((parent_follow(tb.v('yassin')::uuid, 'day') -> 'current' ->> 'stories_completed')::int = 1, 'day report');
select tb.ok((parent_follow(tb.v('omar')::uuid, 'week') -> 'current' ->> 'stories_listened')::int = 0, 'Omar report separate');

-- another family: nothing
select tb.login('00000000-0000-0000-0000-00000000000b');
select create_family('Other', 'Bob', 'en', 'v1', '[]');
select tb.expect_error(format($$ select parent_follow(%L, 'week') $$, tb.v('yassin')), 'not_found');
reset role;
set role anon;
select tb.expect_error(format($$ select parent_follow(%L, 'week') $$, tb.v('yassin')), 'permission denied for function parent_follow');
reset role;

-- re-run keeps progress
\ir ../migrations/20261001000007_bedtime_and_follow.sql
select tb.ok((select count(*) from public.bedtime_listens) = 2, 'progress kept after re-run');
select tb.ok((select count(*) from public.bedtime_stories where published) = 39, 'stories replaced');
\ir ../migrations/20261004000010_prophets_stories.sql
select tb.ok((select count(*) from public.bedtime_listens) = 2, 'progress kept after the prophets update');
select tb.ok((select count(*) from public.bedtime_stories where published and kind = 'prophet') = 25, '25 prophets stories');
select 'ALL BEDTIME + FOLLOW TESTS PASSED';
