#!/usr/bin/env bash
# LOCAL TESTING ONLY: runs all migrations + tests on throwaway PostgreSQL
# databases (needs PostgreSQL 15+ and psql). Not needed for Supabase.
set -euo pipefail
cd "$(dirname "$0")"

fresh_db() {
  dropdb --if-exists "$1" && createdb "$1"
  psql -q -v ON_ERROR_STOP=1 -d "$1" -f supabase_stub.sql
  for f in ../migrations/*.sql; do psql -q -v ON_ERROR_STOP=1 -d "$1" -f "$f" >/dev/null; done
}

# the starter content must be safe to run twice
fresh_db family_learn_test
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -f ../migrations/20260926000003_phase4_starter_content.sql >/dev/null
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -o /dev/null -f phase3_accounts_test.sql
dropdb family_learn_test

fresh_db family_learn_test
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -o /dev/null -f phase4_learning_test.sql
dropdb family_learn_test

fresh_db family_learn_test
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -o /dev/null -f phase5_cms_test.sql
dropdb family_learn_test

fresh_db family_learn_test
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -o /dev/null -f speak_game_test.sql
dropdb family_learn_test

fresh_db family_learn_test
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -o /dev/null -f bedtime_follow_test.sql
dropdb family_learn_test

# stages upgrade on top of the old speaking game (0001-0007 only, then 0008 inside the test)
dropdb --if-exists family_learn_test && createdb family_learn_test
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -f supabase_stub.sql
for f in ../migrations/*.sql; do case "$f" in *000008_*) ;; *) psql -q -v ON_ERROR_STOP=1 -d family_learn_test -f "$f" >/dev/null;; esac; done
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -o /dev/null -f speak_stages_test.sql
dropdb family_learn_test

# math games + prophets (0001-0008 first, then 0009 inside the test)
dropdb --if-exists family_learn_test && createdb family_learn_test
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -f supabase_stub.sql
for f in ../migrations/*.sql; do case "$f" in *000009_*) ;; *) psql -q -v ON_ERROR_STOP=1 -d family_learn_test -f "$f" >/dev/null;; esac; done
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -o /dev/null -f math_games_test.sql
dropdb family_learn_test

# Phase 6: review box, review sessions, placement, daily plan (and safe to run twice)
fresh_db family_learn_test
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -f ../migrations/20261008000011_phase6_daily_plan.sql >/dev/null
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -o /dev/null -f phase6_plan_test.sql
dropdb family_learn_test

# Term-1 books (0012): all answer keys self-grade, safe to run twice
fresh_db family_learn_test
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -o /dev/null -f term1_books_test.sql
dropdb family_learn_test
