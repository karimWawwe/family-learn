#!/usr/bin/env bash
# LOCAL TESTING ONLY: runs all migrations + tests on throwaway PostgreSQL
# databases (needs PostgreSQL 15+ and psql). Not needed for Supabase.
set -euo pipefail
cd "$(dirname "$0")"

fresh_db() {
  dropdb --if-exists "$1" && createdb "$1"
  psql -q -v ON_ERROR_STOP=1 -d "$1" -f supabase_stub.sql
  for f in ../migrations/*.sql; do psql -q -v ON_ERROR_STOP=1 -d "$1" -f "$f" >/dev/null; done
}

# the starter content must be safe to run twice
fresh_db family_learn_test
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -f ../migrations/20260926000003_phase4_starter_content.sql >/dev/null
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -o /dev/null -f phase3_accounts_test.sql
dropdb family_learn_test

fresh_db family_learn_test
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -o /dev/null -f phase4_learning_test.sql
dropdb family_learn_test

fresh_db family_learn_test
psql -q -v ON_ERROR_STOP=1 -d family_learn_test -o /dev/null -f phase5_cms_test.sql
dropdb family_learn_test
