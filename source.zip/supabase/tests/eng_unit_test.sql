-- LOCAL TESTING ONLY. Math games, prophets stories, follow report with math, Yassin name.
\set ON_ERROR_STOP 1
\set QUIET 1

create schema tm;
grant usage on schema tm to authenticated, anon;
create function tm.login(p_uid uuid, p_anon boolean default false) returns void
language sql as $$
  select set_config('request.jwt.claims',
                    json_build_object('sub', p_uid, 'role', 'authenticated', 'is_anonymous', p_anon)::text, false)
$$;
create function tm.expect_error(p_sql text, p_msg text) returns void
language plpgsql as $$
begin
  execute p_sql;
  raise exception 'EXPECTED ERROR "%" but statement succeeded: %', p_msg, p_sql;
exception
  when others then
    if sqlerrm like 'EXPECTED ERROR%' then raise; end if;
    if sqlerrm <> p_msg then raise exception 'expected error "%", got "%" for: %', p_msg, sqlerrm, p_sql; end if;
end $$;
create function tm.ok(p_cond boolean, p_what text) returns void
language plpgsql as $$
begin
  if p_cond is not true then raise exception 'FAILED: %', p_what; end if;
  raise notice 'ok - %', p_what;
end $$;
create table tm.vars (k text primary key, v text);
grant all on tm.vars to authenticated, anon;
create function tm.v(p_k text) returns text language sql as $$ select v from tm.vars where k = p_k $$;
grant execute on all functions in schema tm to authenticated, anon;

insert into auth.users (id, email, is_anonymous) values
  ('00000000-0000-0000-0000-00000000000a', 'kareem@example.com', false),
  ('00000000-0000-0000-0000-0000000000c1', null, true),
  ('00000000-0000-0000-0000-0000000000c2', null, true);

set role authenticated;
select tm.login('00000000-0000-0000-0000-00000000000a');
select create_family('Junaid', 'Kareem', 'en', 'v1', '[
  {"display_name":"Omar","kind":"child","grade":6},
  {"display_name":"yasen","kind":"child","grade":3,"ui_locale":"ar"}]');
insert into tm.vars select 'omar',   id::text from profiles where display_name = 'Omar';
insert into tm.vars select 'yassin', id::text from profiles where display_name = 'yasen';
insert into tm.vars select 'code_y', create_pairing_code(tm.v('yassin')::uuid) ->> 'code';
insert into tm.vars select 'code_o', create_pairing_code(tm.v('omar')::uuid) ->> 'code';
select tm.login('00000000-0000-0000-0000-0000000000c1', true);
select redeem_pairing_code(tm.v('code_y'), 'Yassin phone');
select tm.login('00000000-0000-0000-0000-0000000000c2', true);
select redeem_pairing_code(tm.v('code_o'), 'Omar phone');
reset role;


set role authenticated;
-- Yassin's phone: own progress only
select tm.login('00000000-0000-0000-0000-0000000000c1', true);
select tm.ok((eng_unit_state(tm.v('yassin')::uuid, 'caps_finance') ->> 'read')::boolean = false, 'starts empty');
select eng_unit_log(tm.v('yassin')::uuid, 'caps_finance', 'rules', 'read', true, 0);
select eng_unit_log(tm.v('yassin')::uuid, 'caps_finance', 'ex1', 'answer', false, 3);
select eng_unit_log(tm.v('yassin')::uuid, 'caps_finance', 'ex1', 'answer', true, 2);
select eng_unit_log(tm.v('yassin')::uuid, 'caps_finance', 'vid_22', 'video', true, 0);
insert into tm.vars select 'st', eng_unit_log(tm.v('yassin')::uuid, 'caps_finance', 'vid_22', 'video', true, 0)::text;
select tm.ok((tm.v('st')::jsonb ->> 'read')::boolean, 'rules read');
select tm.ok(tm.v('st')::jsonb -> 'videos' = '["vid_22"]'::jsonb, 'video counted once');
select tm.ok((tm.v('st')::jsonb -> 'items' -> 0 ->> 'attempts')::int = 2, '2 attempts');
select tm.ok((tm.v('st')::jsonb -> 'items' -> 0 ->> 'wrong')::int = 1, '1 wrong');
select tm.ok((tm.v('st')::jsonb -> 'items' -> 0 ->> 'best_stars')::int = 2, 'best stars 2');
select tm.ok((tm.v('st')::jsonb -> 'items' -> 0 ->> 'solved')::boolean, 'solved');
select tm.expect_error($$select eng_unit_state(tm.v('omar')::uuid, 'caps_finance')$$, 'not_found');
select tm.expect_error($$select eng_unit_log(tm.v('yassin')::uuid, 'caps_finance', 'ex11', 'answer', true, 3)$$, 'not_found');
select tm.expect_error($$select eng_unit_log(tm.v('yassin')::uuid, 'caps_finance', 'vid_22', 'answer', true, 3)$$, 'not_found');
select tm.expect_error($$select eng_unit_log(tm.v('yassin')::uuid, 'other', 'ex1', 'answer', true, 3)$$, 'not_found');
-- parent sees both children
select tm.login('00000000-0000-0000-0000-00000000000a');
select tm.ok(jsonb_array_length(eng_unit_state(tm.v('yassin')::uuid, 'caps_finance') -> 'items') = 1, 'parent reads Yassin');
select tm.ok(jsonb_array_length(eng_unit_state(tm.v('omar')::uuid, 'caps_finance') -> 'items') = 0, 'Omar separate');
reset role;
