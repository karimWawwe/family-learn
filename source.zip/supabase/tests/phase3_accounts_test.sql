-- LOCAL TESTING ONLY (plain PostgreSQL + supabase_stub.sql). Do NOT run on Supabase.
-- Run: supabase/tests/run_local_tests.sh
\set ON_ERROR_STOP 1
\set QUIET 1

create schema tests;
grant usage on schema tests to authenticated, anon;

-- act as a user: sub + anonymous flag go into the JWT claims, like Supabase does
create function tests.login(p_uid uuid, p_anon boolean default false) returns void
language sql as $$
  select set_config('request.jwt.claims',
                    json_build_object('sub', p_uid, 'role', 'authenticated', 'is_anonymous', p_anon)::text, false)
$$;

create function tests.expect_error(p_sql text, p_msg text) returns void
language plpgsql as $$
begin
  execute p_sql;
  raise exception 'EXPECTED ERROR "%" but statement succeeded: %', p_msg, p_sql;
exception
  when others then
    if sqlerrm like 'EXPECTED ERROR%' then raise; end if;
    if sqlerrm <> p_msg then
      raise exception 'expected error "%", got "%" for: %', p_msg, sqlerrm, p_sql;
    end if;
end $$;

create function tests.ok(p_cond boolean, p_what text) returns void
language plpgsql as $$
begin
  if p_cond is not true then raise exception 'FAILED: %', p_what; end if;
  raise notice 'ok - %', p_what;
end $$;

grant execute on all functions in schema tests to authenticated, anon;
create table tests.vars (k text primary key, v text);
grant all on tests.vars to authenticated;

insert into auth.users (id, email, is_anonymous) values
  ('00000000-0000-0000-0000-00000000000a', 'kareem@example.com', false),   -- parent A
  ('00000000-0000-0000-0000-00000000000b', 'other@example.com',  false),   -- parent B (another family)
  ('00000000-0000-0000-0000-0000000000c1', null, true),                    -- Omar's phone
  ('00000000-0000-0000-0000-0000000000c2', null, true),                    -- attacker phone
  ('00000000-0000-0000-0000-0000000000c3', null, true);                    -- Yassin's phone

set role authenticated;

-- ---------------------------------------------------------------- family creation
select tests.login('00000000-0000-0000-0000-00000000000a');
select tests.ok((my_context() ->> 'role') is null, 'new parent has no family yet');

select tests.expect_error($$ select create_family('Junaid', 'Kareem', 'en', '', '[]') $$, 'consent_required');
select tests.expect_error($$ select create_family('', 'Kareem', 'en', 'v1', '[]') $$, 'invalid_family');
select tests.expect_error($$ select create_family('Junaid', 'Kareem', 'en', 'v1',
  '[{"display_name":"Omar","kind":"child"}]') $$, 'grade_required');
select tests.ok(not exists (select 1 from families), 'failed creation leaves nothing behind');

insert into tests.vars
select 'fam_a', create_family('Junaid', 'Kareem', 'en', 'v1', '[
  {"display_name":"Omar",   "kind":"child", "grade":6, "ui_locale":"en", "avatar_emoji":"🦁"},
  {"display_name":"Yassin", "kind":"child", "grade":3, "ui_locale":"ar", "avatar_emoji":"🐼"}]')::text;

select tests.ok((my_context() ->> 'role') = 'parent', 'creator is parent');
select tests.ok((select count(*) from profiles) = 3, 'parent sees 3 profiles');
select tests.ok((select count(*) from profiles where role = 'parent') = 1, 'one parent profile');
select tests.expect_error($$ select create_family('Again', 'Kareem', 'en', 'v1', '[]') $$, 'already_in_family');

insert into tests.vars select 'omar',   id::text from profiles where display_name = 'Omar';
insert into tests.vars select 'yassin', id::text from profiles where display_name = 'Yassin';
insert into tests.vars select 'kareem', id::text from profiles where display_name = 'Kareem';

-- private tables are unreachable
select tests.expect_error($$ select * from profile_secrets $$, 'permission denied for table profile_secrets');
select tests.expect_error($$ select * from pairing_codes $$,   'permission denied for table pairing_codes');
select tests.expect_error($$ insert into profiles (family_id, display_name, kind) values
  ((select v::uuid from tests.vars where k='fam_a'), 'X', 'adult') $$, 'permission denied for table profiles');
select tests.expect_error($$ update profiles set has_pin = false $$, 'permission denied for table profiles');

-- parent can edit allowed columns
update profiles set daily_minutes_goal = 35 where display_name = 'Omar';
select tests.ok((select daily_minutes_goal from profiles where display_name = 'Omar') = 35, 'parent updates a goal');

-- anonymous users cannot create families
select tests.login('00000000-0000-0000-0000-0000000000c2', true);
select tests.expect_error($$ select create_family('Evil', 'X', 'en', 'v1', '[]') $$, 'parent_account_required');

-- ---------------------------------------------------------------- other family is invisible
select tests.login('00000000-0000-0000-0000-00000000000b');
select create_family('Other', 'Bob', 'en', 'v1', '[{"display_name":"Kid","kind":"child","grade":2}]');
select tests.ok((select count(*) from profiles) = 2, 'parent B sees only own 2 profiles');
select tests.ok(not exists (select 1 from profiles where display_name = 'Omar'), 'parent B cannot see Omar');
update profiles set display_name = 'Hacked' where id = (select v::uuid from tests.vars where k = 'omar');
select tests.expect_error(format($$ select set_profile_pin(%L, '1111') $$, (select v from tests.vars where k='omar')), 'not_found');
select tests.expect_error(format($$ select create_pairing_code(%L) $$, (select v from tests.vars where k='omar')), 'not_found');
select tests.expect_error(format($$ select verify_profile_pin(%L, '1111') $$, (select v from tests.vars where k='omar')), 'not_found');

select tests.login('00000000-0000-0000-0000-00000000000a');
select tests.ok((select display_name from profiles where display_name = 'Omar') = 'Omar', 'Omar was not renamed by parent B');

-- ---------------------------------------------------------------- PINs
select tests.ok((verify_profile_pin((select v::uuid from tests.vars where k='omar'), null) ->> 'ok')::boolean,
                'no PIN set -> open');
select tests.expect_error(format($$ select set_profile_pin(%L, '12a4') $$, (select v from tests.vars where k='omar')), 'invalid_pin');
select set_profile_pin((select v::uuid from tests.vars where k='omar'), '2468');
select tests.ok((select has_pin from profiles where display_name = 'Omar'), 'has_pin flag set');
select tests.ok((verify_profile_pin((select v::uuid from tests.vars where k='omar'), '2468') ->> 'ok')::boolean, 'right PIN ok');
select tests.ok((verify_profile_pin((select v::uuid from tests.vars where k='omar'), '0000') ->> 'attempts_left')::int = 4, 'wrong PIN -> 4 left');
select verify_profile_pin((select v::uuid from tests.vars where k='omar'), '0000') from generate_series(1, 3);
select tests.ok((verify_profile_pin((select v::uuid from tests.vars where k='omar'), '0000') ->> 'locked_until') is not null, '5th wrong PIN locks');
select tests.ok(not (verify_profile_pin((select v::uuid from tests.vars where k='omar'), '2468') ->> 'ok')::boolean, 'locked even with right PIN');

-- (unlock by parent re-setting the PIN)
select set_profile_pin((select v::uuid from tests.vars where k='omar'), '2468');
select tests.ok((verify_profile_pin((select v::uuid from tests.vars where k='omar'), '2468') ->> 'ok')::boolean, 'reset PIN unlocks');

-- ---------------------------------------------------------------- pairing a child's phone
select tests.expect_error(format($$ select create_pairing_code(%L) $$, (select v from tests.vars where k='kareem')), 'not_found');
insert into tests.vars select 'code_omar', create_pairing_code((select v::uuid from tests.vars where k='omar')) ->> 'code';
select tests.ok((select v from tests.vars where k='code_omar') ~ '^[0-9]{6}$', 'code is 6 digits');

-- a parent account cannot redeem
select tests.expect_error(format($$ select redeem_pairing_code(%L) $$, (select v from tests.vars where k='code_omar')), 'child_device_only');

-- Omar's phone
select tests.login('00000000-0000-0000-0000-0000000000c1', true);
select tests.ok((my_context() ->> 'role') is null, 'fresh phone not linked');
select tests.ok(not exists (select 1 from profiles), 'unlinked phone sees no profiles');
select tests.ok((redeem_pairing_code('999999') ->> 'error') = 'invalid_code'
                or (select v from tests.vars where k='code_omar') = '999999', 'wrong code refused');
select tests.ok((redeem_pairing_code((select v from tests.vars where k='code_omar'), 'Omar iPhone') ->> 'ok')::boolean, 'right code links phone');
select tests.ok((my_context() ->> 'role') = 'child_device', 'phone is child_device');
select tests.ok((select count(*) from profiles) = 1 and (select display_name from profiles) = 'Omar', 'child phone sees only Omar');
select tests.ok((select count(*) from family_members) = 1, 'child phone sees only its own membership');
select tests.ok(not exists (select 1 from families where name = 'Other'), 'child phone cannot see other family');
update profiles set display_name = 'Boss';
select tests.ok((select display_name from profiles) = 'Omar', 'child cannot rename itself');
select tests.expect_error(format($$ select set_profile_pin(%L, '1111') $$, (select v from tests.vars where k='omar')), 'parent_only');
select tests.expect_error(format($$ select create_pairing_code(%L) $$, (select v from tests.vars where k='yassin')), 'parent_only');
select tests.expect_error(format($$ select verify_profile_pin(%L, '1111') $$, (select v from tests.vars where k='yassin')), 'not_found');
select tests.ok((verify_profile_pin((select v::uuid from tests.vars where k='omar'), '2468') ->> 'ok')::boolean, 'child phone checks own PIN');
select tests.expect_error($$ select add_profile('{"display_name":"X","kind":"child","grade":1}') $$, 'parent_only');
select tests.expect_error(format($$ select redeem_pairing_code(%L) $$, (select v from tests.vars where k='code_omar')), 'already_linked');
select touch_device();

-- code is single-use
select tests.login('00000000-0000-0000-0000-0000000000c2', true);
select tests.ok((redeem_pairing_code((select v from tests.vars where k='code_omar')) ->> 'error') = 'invalid_code', 'used code cannot be reused');
-- rate limit: 5 tries per 15 min
select redeem_pairing_code('000001'), redeem_pairing_code('000002'), redeem_pairing_code('000003'), redeem_pairing_code('000005');
select tests.ok((redeem_pairing_code('000004') ->> 'error') = 'too_many_attempts', 'rate limit: 6th try in 15 min blocked');

-- expired code
select tests.login('00000000-0000-0000-0000-00000000000a');
insert into tests.vars select 'code_yassin', create_pairing_code((select v::uuid from tests.vars where k='yassin')) ->> 'code';
reset role;
update pairing_codes set expires_at = now() - interval '1 second' where profile_id = (select v::uuid from tests.vars where k='yassin');
set role authenticated;
select tests.login('00000000-0000-0000-0000-0000000000c3', true);
select tests.ok((redeem_pairing_code((select v from tests.vars where k='code_yassin')) ->> 'error') = 'invalid_code', 'expired code refused');

-- a new code replaces the old one
select tests.login('00000000-0000-0000-0000-00000000000a');
insert into tests.vars select 'code_y1', create_pairing_code((select v::uuid from tests.vars where k='yassin')) ->> 'code';
insert into tests.vars select 'code_y2', create_pairing_code((select v::uuid from tests.vars where k='yassin')) ->> 'code';
select tests.login('00000000-0000-0000-0000-0000000000c3', true);
select tests.ok((redeem_pairing_code((select v from tests.vars where k='code_y1')) ->> 'ok')::boolean is not true
                or (select v from tests.vars where k='code_y1') = (select v from tests.vars where k='code_y2'), 'older code replaced');
select tests.ok((redeem_pairing_code((select v from tests.vars where k='code_y2')) ->> 'ok')::boolean, 'newest code works');
select tests.ok((select display_name from profiles) = 'Yassin', 'Yassin phone sees Yassin');

-- ---------------------------------------------------------------- parent manages devices
select tests.login('00000000-0000-0000-0000-00000000000a');
select tests.ok((select count(*) from family_members where role = 'child_device') = 2, 'parent sees 2 linked phones');
select tests.ok((select device_name from family_members where profile_id = (select v::uuid from tests.vars where k='omar')) = 'Omar iPhone', 'device name stored');
select unlink_device('00000000-0000-0000-0000-0000000000c1');
select tests.login('00000000-0000-0000-0000-0000000000c1', true);
select tests.ok(not exists (select 1 from profiles), 'unlinked phone loses access immediately');
select tests.ok((my_context() ->> 'role') is null, 'unlinked phone has no role');

select tests.login('00000000-0000-0000-0000-00000000000a');
select tests.expect_error(format($$ select delete_profile(%L) $$, (select v from tests.vars where k='kareem')), 'not_found');
select add_profile('{"display_name":"Mona","kind":"adult","ui_locale":"ar"}');
select tests.ok((select count(*) from profiles) = 4, 'parent adds an adult learner');
select delete_profile((select v::uuid from tests.vars where k='yassin'));
select tests.ok((select count(*) from family_members where role = 'child_device') = 0, 'deleting a profile unlinks its phone');

-- ---------------------------------------------------------------- anon role (not signed in)
reset role;
set role anon;
select tests.expect_error($$ select my_context() $$, 'permission denied for function my_context');
select tests.expect_error($$ select * from profiles $$, 'permission denied for table profiles');
reset role;

\echo 'ALL PHASE 3 DATABASE TESTS PASSED'
