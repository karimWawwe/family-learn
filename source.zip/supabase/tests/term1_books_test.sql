-- Term-1 books (0012): installed by the migrations; run again here -> must be idempotent.
\i ../migrations/20261008000012_term1_books.sql
do $$
declare
  n int;
  ids text[] := array['ar-g3','isl-g3','eng-g3-t1','ar-g6','isl-g6','soc-g6','eng-g6-t1','math-g6-t1'];
begin
  select count(*) into n from public.courses where id = any(ids);
  assert n = 8, 'courses ' || n;
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id = any(ids) and not q.archived;
  assert n = 1371, 'questions ' || n;
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id = any(ids) and q.archived;
  assert n = 0, 'archived after rerun ' || n;
  -- every multiple-choice / true-false key grades its own correct answer as right
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id = any(ids) and q.type = 'multiple_choice'
     and not app.grade(q.type, q.answer_key, to_jsonb((q.answer_key->>'index')::int));
  assert n = 0, 'mc self-grade failures ' || n;
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id = any(ids) and q.type = 'true_false'
     and not app.grade(q.type, q.answer_key, q.answer_key->'value');
  assert n = 0, 'tf self-grade failures ' || n;
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id = any(ids) and not app.grade(q.type, q.answer_key, case q.type
         when 'drag_drop' then q.answer_key->'token'
         when 'ordering' then q.answer_key->'order'
         when 'matching' then q.answer_key->'map'
         when 'word_problem' then q.answer_key->'value'
         when 'fill_blank' then q.answer_key->'accepted'->0
         when 'reading' then q.answer_key->'index'
         when 'multiple_choice' then q.answer_key->'index'
         when 'true_false' then q.answer_key->'value' end);
  assert n = 0, 'self-grade failures (all types) ' || n;
  -- Arabic true/false shows صح / خطأ
  select count(*) into n from public.questions q join public.lessons l on l.id = q.lesson_id
   where l.course_id in ('ar-g3','isl-g3','ar-g6','isl-g6','soc-g6') and q.type = 'true_false'
     and q.correct_text not in ('صح', 'خطأ');
  assert n = 0, 'arabic tf text ' || n;
  -- grades: P3 courses for grade 3, P6 for grade 6
  select count(*) into n from public.courses where id = any(ids) and grade_min <> grade_max;
  assert n = 0, 'grade range';
end $$;
