-- LOCAL TESTING ONLY. Run on a database with migrations 0001-0007 ONLY
-- (run_local_tests.sh does this): plays a little with the OLD rule, then installs
-- 0008 (stages) and checks unlocking by stars, replays, best results, isolation.
\set ON_ERROR_STOP 1
\set QUIET 1

create schema tg;
grant usage on schema tg to authenticated, anon;
create function tg.login(p_uid uuid, p_anon boolean default false) returns void
language sql as $$
  select set_config('request.jwt.claims',
                    json_build_object('sub', p_uid, 'role', 'authenticated', 'is_anonymous', p_anon)::text, false)
$$;
create function tg.expect_error(p_sql text, p_msg text) returns void
language plpgsql as $$
begin
  execute p_sql;
  raise exception 'EXPECTED ERROR "%" but statement succeeded: %', p_msg, p_sql;
exception
  when others then
    if sqlerrm like 'EXPECTED ERROR%' then raise; end if;
    if sqlerrm <> p_msg then raise exception 'expected error "%", got "%" for: %', p_msg, sqlerrm, p_sql; end if;
end $$;
create function tg.ok(p_cond boolean, p_what text) returns void
language plpgsql as $$
begin
  if p_cond is not true then raise exception 'FAILED: %', p_what; end if;
  raise notice 'ok - %', p_what;
end $$;
create table tg.vars (k text primary key, v text);
grant all on tg.vars to authenticated, anon;
create function tg.v(p_k text) returns text language sql as $$ select v from tg.vars where k = p_k $$;
-- a stage of the state by id
create function tg.lv(p uuid, id text) returns jsonb language sql as $$
  select l from jsonb_array_elements(public.speak_game_state(p) -> 'levels') l where l ->> 'id' = id $$;
grant execute on all functions in schema tg to authenticated, anon;

insert into auth.users (id, email, is_anonymous) values
  ('00000000-0000-0000-0000-00000000000a', 'kareem@example.com', false);
set role authenticated;
select tg.login('00000000-0000-0000-0000-00000000000a');
select create_family('Junaid', 'Kareem', 'en', 'v1', '[
  {"display_name":"Omar","kind":"child","grade":6},
  {"display_name":"Yassin","kind":"child","grade":3,"ui_locale":"ar"}]');
insert into tg.vars select 'omar',   id::text from profiles where display_name = 'Omar';
insert into tg.vars select 'yassin', id::text from profiles where display_name = 'Yassin';

-- OLD rule (0006): Omar finishes o1-art and o2-inventions with 1 star each
select speak_finish_level(tg.v('omar')::uuid, 'o1-art', 30, 1, 8, 1, 20);
select speak_finish_level(tg.v('omar')::uuid, 'o2-inventions', 30, 1, 8, 1, 20);
reset role;

-- ---------------------------------------------------------------- install stages
\ir ../migrations/20261002000008_speak_stages.sql

set role authenticated;
select tg.login('00000000-0000-0000-0000-00000000000a');

-- Omar keeps everything that was open before (even with only 2 stars)
select tg.ok((tg.lv(tg.v('omar')::uuid, 'o1-art') ->> 'unlocked')::boolean, 'Omar: played stage stays open');
select tg.ok((tg.lv(tg.v('omar')::uuid, 'o2-inventions') ->> 'unlocked')::boolean, 'Omar: 2nd played stage stays open');
select tg.ok((tg.lv(tg.v('omar')::uuid, 'o3-egypt') ->> 'unlocked')::boolean, 'Omar: the stage that was next stays open');
select tg.ok((speak_game_state(tg.v('omar')::uuid) ->> 'stars')::int = 2, 'Omar: 2 stars');
select tg.ok(jsonb_array_length(speak_game_state(tg.v('omar')::uuid) -> 'levels') = 28, 'Omar: 28 stages');
select tg.ok((speak_game_state(tg.v('omar')::uuid) -> 'levels' -> 0 ->> 'id') = 'o0-warmup', 'Omar: easy warm-up comes first');

-- Yassin (new rule): stage 2 needs 2 stars in total
select tg.ok((tg.lv(tg.v('yassin')::uuid, 'y1-sounds') ->> 'unlocked')::boolean, 'Yassin: first stage open');
select tg.ok((tg.lv(tg.v('yassin')::uuid, 'y1b-colors') ->> 'required_stars')::int = 2, 'stage 2 needs 2 stars');
select tg.ok(not (tg.lv(tg.v('yassin')::uuid, 'y1b-colors') ->> 'unlocked')::boolean, 'Yassin: stage 2 locked');
select speak_finish_level(tg.v('yassin')::uuid, 'y1-sounds', 40, 1, 8, 2, 20);
select tg.ok(not (tg.lv(tg.v('yassin')::uuid, 'y1b-colors') ->> 'unlocked')::boolean, 'one star is not enough yet');
select tg.expect_error(format($$ select speak_finish_level(%L, 'y1b-colors', 40, 3, 6, 6, 6) $$, tg.v('yassin')), 'lesson_locked');
-- replay stage 1 and do better
insert into tg.vars select 'after', speak_finish_level(tg.v('yassin')::uuid, 'y1-sounds', 150, 3, 8, 8, 9)::text;
select tg.ok((tg.v('after')::jsonb ->> 'stars')::int = 3, 'best stars kept: 3');
select tg.ok((tg.v('after')::jsonb ->> 'points')::int = 150, 'best points kept: 150');
select tg.ok((tg.lv(tg.v('yassin')::uuid, 'y1b-colors') ->> 'unlocked')::boolean, 'enough stars -> stage 2 opens by itself');
select tg.ok((tg.lv(tg.v('yassin')::uuid, 'y1-sounds') ->> 'plays')::int = 2, 'replays counted');
select tg.ok((tg.lv(tg.v('yassin')::uuid, 'y1-sounds') ->> 'best_points')::int = 150, 'best points per stage');
-- a weaker replay changes nothing
select speak_finish_level(tg.v('yassin')::uuid, 'y1-sounds', 20, 1, 8, 1, 30);
select tg.ok((speak_game_state(tg.v('yassin')::uuid) ->> 'stars')::int = 3, 'weaker replay keeps 3 stars');
select tg.ok((speak_game_state(tg.v('yassin')::uuid) ->> 'points')::int = 150, 'weaker replay keeps best points');
-- stage 3 needs stage 2 finished AND 4 stars
select tg.ok((tg.lv(tg.v('yassin')::uuid, 'y1c-numbers') ->> 'required_stars')::int = 4, 'stage 3 needs 4 stars');
select tg.ok(not (tg.lv(tg.v('yassin')::uuid, 'y1c-numbers') ->> 'unlocked')::boolean, 'stage 3 locked before stage 2 is done');
select speak_finish_level(tg.v('yassin')::uuid, 'y1b-colors', 30, 1, 6, 1, 12);
select tg.ok((tg.lv(tg.v('yassin')::uuid, 'y1c-numbers') ->> 'unlocked')::boolean, 'stage 2 done + 4 stars -> stage 3 open');
select tg.ok(exists (select 1 from jsonb_array_elements(speak_game_state(tg.v('yassin')::uuid) -> 'levels') l
                      where (l ->> 'required_stars')::int > 0 and not (l ->> 'unlocked')::boolean), 'later stages still locked');
select tg.ok((speak_game_state(tg.v('omar')::uuid) ->> 'stars')::int = 2, 'Omar unchanged by Yassin');

-- follow report uses best points per stage
select tg.ok((parent_follow(tg.v('yassin')::uuid, 'week') -> 'progress' ->> 'speak_points')::int = 180, 'follow: 150 + 30 best points');
reset role;

-- re-run: nothing is locked again, progress kept
\ir ../migrations/20261002000008_speak_stages.sql
set role authenticated;
select tg.login('00000000-0000-0000-0000-00000000000a');
select tg.ok((tg.lv(tg.v('omar')::uuid, 'o3-egypt') ->> 'unlocked')::boolean, 'after re-run: still open');
select tg.ok((speak_game_state(tg.v('yassin')::uuid) ->> 'stars')::int = 4, 'after re-run: stars kept');
reset role;
select 'ALL SPEAK STAGES TESTS PASSED';
