-- LOCAL TESTING ONLY (plain PostgreSQL + supabase_stub.sql). Do NOT run on Supabase.
-- Phase 6: review box, review sessions, placement test, daily plan.
\set ON_ERROR_STOP 1
\set QUIET 1

create schema t6;
grant usage on schema t6 to authenticated, anon;
create function t6.login(p_uid uuid, p_anon boolean default false) returns void
language sql as $$
  select set_config('request.jwt.claims',
                    json_build_object('sub', p_uid, 'role', 'authenticated', 'is_anonymous', p_anon)::text, false)
$$;
create function t6.expect_error(p_sql text, p_msg text) returns void
language plpgsql as $$
begin
  execute p_sql;
  raise exception 'EXPECTED ERROR "%" but statement succeeded: %', p_msg, p_sql;
exception
  when others then
    if sqlerrm like 'EXPECTED ERROR%' then raise; end if;
    if sqlerrm <> p_msg then raise exception 'expected error "%", got "%" for: %', p_msg, sqlerrm, p_sql; end if;
end $$;
create function t6.ok(p_cond boolean, p_what text) returns void
language plpgsql as $$
begin
  if p_cond is not true then raise exception 'FAILED: %', p_what; end if;
  raise notice 'ok - %', p_what;
end $$;
create table t6.vars (k text primary key, v text);
grant all on t6.vars to authenticated, anon;
create function t6.v(p_k text) returns text language sql as $$ select v from t6.vars where k = p_k $$;
create function t6.put(p_k text, p_v text) returns void language sql as $$
  insert into t6.vars values (p_k, p_v) on conflict (k) do update set v = excluded.v $$;

-- right / wrong answers built from the private key (runs as owner)
create function t6.right_response(p_q text) returns jsonb language sql security definer as $$
  select case q.type
    when 'multiple_choice' then q.answer_key -> 'index'
    when 'reading'         then q.answer_key -> 'index'
    when 'listening'       then q.answer_key -> 'index'
    when 'true_false'      then q.answer_key -> 'value'
    when 'fill_blank'      then to_jsonb(q.answer_key -> 'accepted' ->> 0)
    when 'typing'          then to_jsonb(q.answer_key -> 'accepted' ->> 0)
    when 'drag_drop'       then q.answer_key -> 'token'
    when 'word_problem'    then to_jsonb((q.answer_key ->> 'value'))
    when 'matching'        then q.answer_key -> 'map'
    when 'ordering'        then q.answer_key -> 'order'
  end from public.questions q where q.id = p_q $$;
create function t6.wrong_response(p_q text) returns jsonb language sql as $$ select '"zzz-wrong"'::jsonb $$;
-- backdate review items so they are due (owner only)
create function t6.make_due(p_profile uuid) returns void language sql security definer as $$
  update public.review_items set due_on = current_date - 1 where profile_id = p_profile and due_on is not null $$;
grant execute on all functions in schema t6 to authenticated, anon;

insert into auth.users (id, email, is_anonymous) values
  ('00000000-0000-0000-0000-00000000000a', 'kareem@example.com', false),
  ('00000000-0000-0000-0000-0000000000c1', null, true),
  ('00000000-0000-0000-0000-00000000000b', 'bob@example.com', false);

set role authenticated;
select t6.login('00000000-0000-0000-0000-00000000000a');
select create_family('Junaid', 'Kareem', 'en', 'v1', '[
  {"display_name":"Omar","kind":"child","grade":6},
  {"display_name":"Yassin","kind":"child","grade":3,"ui_locale":"ar"}]');
select t6.put('omar',   (select id::text from profiles where display_name = 'Omar'));
select t6.put('yassin', (select id::text from profiles where display_name = 'Yassin'));
select t6.put('kareem', (select id::text from profiles where display_name = 'Kareem'));
select t6.put('code', create_pairing_code(t6.v('yassin')::uuid) ->> 'code');
select t6.login('00000000-0000-0000-0000-0000000000c1', true);
select redeem_pairing_code(t6.v('code'), 'Yassin phone');

-- ---------------------------------------------------------------- new child: plan + placement suggestion
select t6.ok((daily_plan(t6.v('yassin')::uuid) ->> 'suggest_placement')::boolean, 'new child: placement suggested');
select t6.ok((daily_plan(t6.v('yassin')::uuid) ->> 'due_review')::int = 0, 'new child: nothing to review');
select t6.ok(exists (select 1 from jsonb_array_elements(daily_plan(t6.v('yassin')::uuid) -> 'tasks') t
                      where t ->> 'kind' = 'lesson' and t ->> 'lesson_id' is not null), 'plan has a next lesson');
select t6.ok(exists (select 1 from jsonb_array_elements(daily_plan(t6.v('yassin')::uuid) -> 'tasks') t
                      where t ->> 'kind' = 'speak'), 'plan has the speaking game');
select t6.ok(not exists (select 1 from jsonb_array_elements(daily_plan(t6.v('yassin')::uuid) -> 'tasks') t
                          where t ->> 'kind' = 'review'), 'no review task when nothing is due');
select t6.ok(start_review(t6.v('yassin')::uuid) -> 'session_id' = 'null'::jsonb, 'empty review makes no session');

-- the phone cannot use Omar's profile
select t6.expect_error(format($$ select daily_plan(%L) $$, t6.v('omar')), 'not_found');
select t6.expect_error(format($$ select start_placement(%L) $$, t6.v('omar')), 'not_found');

-- ---------------------------------------------------------------- a lesson fills the review box
select t6.put('l1', (select l ->> 'id' from jsonb_array_elements(course_map(t6.v('yassin')::uuid)) c,
                     jsonb_array_elements(c -> 'units') u, jsonb_array_elements(u -> 'lessons') l
                     where l ->> 'status' = 'available' limit 1));
select t6.put('s1', start_lesson(t6.v('yassin')::uuid, t6.v('l1'))::text);
select t6.put('a1', t6.v('s1')::jsonb ->> 'attempt_id');
select t6.put('qs', (t6.v('s1')::jsonb -> 'questions')::text);
-- first question wrong, the rest right
select submit_answer(t6.v('a1')::uuid, q ->> 'id',
         case when o = 1 then t6.wrong_response(q ->> 'id') else t6.right_response(q ->> 'id') end)
  from jsonb_array_elements(t6.v('qs')::jsonb) with ordinality x(q, o);
select finish_lesson(t6.v('a1')::uuid);
reset role;
select t6.ok((select count(*) from public.review_items where profile_id = t6.v('yassin')::uuid)
             = jsonb_array_length(t6.v('qs')::jsonb), 'every answered question is in the review box');
select t6.ok((select box = 1 and due_on = current_date + 1 from public.review_items
               where profile_id = t6.v('yassin')::uuid and question_id = t6.v('qs')::jsonb -> 0 ->> 'id'),
             'wrong answer: box 1, back tomorrow');
select t6.ok((select bool_and(box = 3 and due_on = current_date + 7) from public.review_items
               where profile_id = t6.v('yassin')::uuid and question_id <> t6.v('qs')::jsonb -> 0 ->> 'id'
                 and (select type from public.questions where id = question_id) <> 'speaking'),
             'right answers: box 3, back in 7 days');
select t6.ok((select count(*) from public.review_items where profile_id = t6.v('omar')::uuid) = 0, 'Omar''s box untouched');
set role authenticated;
select t6.login('00000000-0000-0000-0000-0000000000c1', true);

select t6.ok((review_overview(t6.v('yassin')::uuid) ->> 'due_today')::int = 0, 'nothing due today yet');
select t6.ok((review_overview(t6.v('yassin')::uuid) ->> 'due_tomorrow')::int = 1, 'one question due tomorrow');
select t6.ok(not (daily_plan(t6.v('yassin')::uuid) ->> 'suggest_placement')::boolean, 'after a lesson no placement nag');
select t6.ok(exists (select 1 from jsonb_array_elements(daily_plan(t6.v('yassin')::uuid) -> 'tasks') t
                      where t ->> 'kind' = 'lesson' and (t ->> 'done')::boolean), 'lesson task done today');

-- ---------------------------------------------------------------- review session
select t6.make_due(t6.v('yassin')::uuid);
select t6.ok((review_overview(t6.v('yassin')::uuid) ->> 'due_today')::int = jsonb_array_length(t6.v('qs')::jsonb), 'all due after backdating');
select t6.ok(exists (select 1 from jsonb_array_elements(daily_plan(t6.v('yassin')::uuid) -> 'tasks') t
                      where t ->> 'kind' = 'review' and not (t ->> 'done')::boolean), 'plan shows review to do');
select t6.put('r1', start_review(t6.v('yassin')::uuid, 3)::text);
select t6.ok(jsonb_array_length(t6.v('r1')::jsonb -> 'questions') = 3, 'review limited to 3');
select t6.ok(t6.v('r1')::jsonb -> 'questions' -> 0 ->> 'id' = t6.v('qs')::jsonb -> 0 ->> 'id', 'weakest (box 1) comes first');
select t6.ok(not (t6.v('r1') like '%answer_key%') and not (t6.v('r1') like '%accepted%'), 'no answer keys in review');
select t6.put('rs', t6.v('r1')::jsonb ->> 'session_id');
select t6.expect_error(format($$ select submit_practice_answer(%L, 'nope', '1') $$, t6.v('rs')), 'not_found');
-- box-1 question answered right -> box 2 (3 days); second right -> box 4
select t6.ok((submit_practice_answer(t6.v('rs')::uuid, t6.v('r1')::jsonb -> 'questions' -> 0 ->> 'id',
               t6.right_response(t6.v('r1')::jsonb -> 'questions' -> 0 ->> 'id')) ->> 'correct')::boolean, 'review right answer');
select t6.ok(not (submit_practice_answer(t6.v('rs')::uuid, t6.v('r1')::jsonb -> 'questions' -> 1 ->> 'id',
               t6.wrong_response('x')) ->> 'correct')::boolean, 'review wrong answer');
select t6.ok(not (submit_practice_answer(t6.v('rs')::uuid, t6.v('r1')::jsonb -> 'questions' -> 1 ->> 'id',
               t6.right_response(t6.v('r1')::jsonb -> 'questions' -> 1 ->> 'id')) ->> 'correct')::boolean, 'first review answer counts');
select t6.put('rf', finish_practice(t6.v('rs')::uuid)::text);
select t6.ok((t6.v('rf')::jsonb ->> 'correct')::int = 1 and (t6.v('rf')::jsonb ->> 'total')::int = 3, 'review score 1/3');
select t6.ok((t6.v('rf')::jsonb ->> 'xp')::int = 5 and (t6.v('rf')::jsonb ->> 'coins')::int = 3, 'review xp 5, coins 3');
select t6.ok(finish_practice(t6.v('rs')::uuid) ->> 'xp' = '5', 'finishing twice = same result');
select t6.expect_error(format($$ select submit_practice_answer(%L, %L, '1') $$, t6.v('rs'), t6.v('r1')::jsonb -> 'questions' -> 2 ->> 'id'), 'lesson_finished');
reset role;
select t6.ok((select box = 2 and due_on = current_date + 3 from public.review_items
               where profile_id = t6.v('yassin')::uuid and question_id = t6.v('r1')::jsonb -> 'questions' -> 0 ->> 'id'),
             'review right: box up, due in 3 days');
select t6.ok((select box = 1 and due_on = current_date + 1 and lapses >= 1 from public.review_items
               where profile_id = t6.v('yassin')::uuid and question_id = t6.v('r1')::jsonb -> 'questions' -> 1 ->> 'id'),
             'review wrong: back to box 1');
set role authenticated;
select t6.login('00000000-0000-0000-0000-0000000000c1', true);
select t6.ok(exists (select 1 from jsonb_array_elements(daily_plan(t6.v('yassin')::uuid) -> 'tasks') t
                      where t ->> 'kind' = 'review' and (t ->> 'done')::boolean), 'review task done today');
select t6.ok((profile_wallet(t6.v('yassin')::uuid) ->> 'xp')::int >= 5, 'wallet includes review xp');
select t6.ok(jsonb_array_length(review_overview(t6.v('yassin')::uuid) -> 'skills') >= 1, 'mastery per skill listed');

-- mastery: keep answering right until mastered
reset role;
update public.review_items set box = 5, due_on = current_date
 where profile_id = t6.v('yassin')::uuid and question_id = t6.v('qs')::jsonb -> 2 ->> 'id';
set role authenticated;
select t6.login('00000000-0000-0000-0000-0000000000c1', true);
select t6.put('r2', start_review(t6.v('yassin')::uuid, 20)::text);
select submit_practice_answer((t6.v('r2')::jsonb ->> 'session_id')::uuid, t6.v('qs')::jsonb -> 2 ->> 'id',
                              t6.right_response(t6.v('qs')::jsonb -> 2 ->> 'id'));
select finish_practice((t6.v('r2')::jsonb ->> 'session_id')::uuid);
reset role;
select t6.ok((select box = 6 and due_on is null from public.review_items
               where profile_id = t6.v('yassin')::uuid and question_id = t6.v('qs')::jsonb -> 2 ->> 'id'), 'box 5 right -> mastered');
set role authenticated;

-- ---------------------------------------------------------------- placement test (Omar, from the parent account)
select t6.login('00000000-0000-0000-0000-00000000000a');
select t6.ok((daily_plan(t6.v('omar')::uuid) ->> 'suggest_placement')::boolean, 'Omar: placement suggested');
select t6.put('p1', start_placement(t6.v('omar')::uuid)::text);
select t6.ok(jsonb_array_length(t6.v('p1')::jsonb -> 'questions') between 4 and 20, 'placement has 4-20 questions');
select t6.ok(not (t6.v('p1') like '%answer_key%'), 'no answer keys in placement');
select t6.ok(not exists (select 1 from jsonb_array_elements(t6.v('p1')::jsonb -> 'questions') q where q ->> 'type' in ('speaking', 'listening')),
             'no speaking/listening in placement');
-- answer every placement question right
select submit_practice_answer((t6.v('p1')::jsonb ->> 'session_id')::uuid, q ->> 'id', t6.right_response(q ->> 'id'))
  from jsonb_array_elements(t6.v('p1')::jsonb -> 'questions') q;
select t6.put('pf', finish_practice((t6.v('p1')::jsonb ->> 'session_id')::uuid)::text);
select t6.ok(jsonb_array_length(t6.v('pf')::jsonb -> 'placements') >= 2, 'placement result per course');
select t6.ok((select bool_and((p ->> 'placed_position')::int > 0) from jsonb_array_elements(t6.v('pf')::jsonb -> 'placements') p),
             'all right -> every course starts further on');
select t6.ok(exists (select 1 from jsonb_array_elements(course_map(t6.v('omar')::uuid)) c,
                      jsonb_array_elements(c -> 'units') u, jsonb_array_elements(u -> 'lessons') l
                      where l ->> 'status' = 'placed'), 'known lessons show as placed');
select t6.put('placed_course', t6.v('pf')::jsonb -> 'placements' -> 0 ->> 'course_id');
select t6.put('placed_pos',    t6.v('pf')::jsonb -> 'placements' -> 0 ->> 'placed_position');
select t6.ok((select l ->> 'status' from jsonb_array_elements(course_map(t6.v('omar')::uuid)) c,
                jsonb_array_elements(c -> 'units') u, jsonb_array_elements(u -> 'lessons') l
               where c ->> 'id' = t6.v('placed_course')
               order by (select position from public.lessons where id = l ->> 'id')
               offset t6.v('placed_pos')::int limit 1) = 'available', 'lesson right after the placed ones is open');
select t6.ok((select l.position > app.placed_position(t6.v('omar')::uuid, l.course_id)
               from public.lessons l
              where l.id = (select t ->> 'lesson_id' from jsonb_array_elements(daily_plan(t6.v('omar')::uuid) -> 'tasks') t
                             where t ->> 'kind' = 'lesson')), 'plan''s next lesson comes after the placed ones');
-- a worse retake never moves the start back
select t6.put('p2', start_placement(t6.v('omar')::uuid)::text);
select submit_practice_answer((t6.v('p2')::jsonb ->> 'session_id')::uuid, q ->> 'id', t6.wrong_response('x'))
  from jsonb_array_elements(t6.v('p2')::jsonb -> 'questions') q;
select t6.put('pf2', finish_practice((t6.v('p2')::jsonb ->> 'session_id')::uuid)::text);
select t6.ok((select (p ->> 'placed_position')::int from jsonb_array_elements(t6.v('pf2')::jsonb -> 'placements') p
               where p ->> 'course_id' = t6.v('placed_course')) = t6.v('placed_pos')::int, 'worse retake keeps the start');
select t6.ok(not (daily_plan(t6.v('omar')::uuid) ->> 'suggest_placement')::boolean, 'no placement nag once taken');

-- placed lessons can be started (they are open)
select t6.ok(start_lesson(t6.v('omar')::uuid,
               (select l.id from public.lessons l where l.course_id = t6.v('placed_course') and not l.archived
                 order by l.position offset 1 limit 1)) ->> 'attempt_id' is not null, 'a placed lesson can be played');

-- streak counts a review day
reset role;
select t6.ok(app.streak(t6.v('yassin')::uuid) >= 1, 'streak counts');

-- ---------------------------------------------------------------- other family
set role authenticated;
select t6.login('00000000-0000-0000-0000-00000000000b');
select create_family('Other', 'Bob', 'en', 'v1', '[]');
select t6.expect_error(format($$ select daily_plan(%L) $$, t6.v('yassin')), 'not_found');
select t6.expect_error(format($$ select review_overview(%L) $$, t6.v('yassin')), 'not_found');
select t6.expect_error(format($$ select finish_practice(%L) $$, t6.v('rs')), 'not_found');
select t6.expect_error($$ select * from public.review_items $$, 'permission denied for table review_items');

reset role;
\echo ALL PHASE 6 DATABASE TESTS PASSED
