-- LOCAL TESTING ONLY (plain PostgreSQL + supabase_stub.sql). Do NOT run on Supabase.
-- AI (0015): access, limits, budget, answer reveal, service-only saving, parent logs.
\set ON_ERROR_STOP 1
\set QUIET 1

-- installed by the migrations; run again here -> must be idempotent
\i ../migrations/20261014000015_ai_tutor.sql

create schema t15;
grant usage on schema t15 to authenticated, anon, service_role;
create function t15.login(p_uid uuid, p_anon boolean default false) returns void
language sql as $$
  select set_config('request.jwt.claims',
                    json_build_object('sub', p_uid, 'role', 'authenticated', 'is_anonymous', p_anon)::text, false)
$$;
create function t15.expect_error(p_sql text, p_msg text) returns void
language plpgsql as $$
begin
  execute p_sql;
  raise exception 'EXPECTED ERROR "%" but statement succeeded: %', p_msg, p_sql;
exception
  when others then
    if sqlerrm like 'EXPECTED ERROR%' then raise; end if;
    if sqlerrm <> p_msg and not (p_msg = 'permission' and sqlerrm like 'permission denied%') then
      raise exception 'expected error "%", got "%" for: %', p_msg, sqlerrm, p_sql;
    end if;
end $$;
create function t15.ok(p_cond boolean, p_what text) returns void
language plpgsql as $$
begin
  if p_cond is not true then raise exception 'FAILED: %', p_what; end if;
  raise notice 'ok - %', p_what;
end $$;
create table t15.vars (k text primary key, v text);
grant all on t15.vars to authenticated, anon, service_role;
create function t15.v(p_k text) returns text language sql as $$ select v from t15.vars where k = p_k $$;
create function t15.put(p_k text, p_v text) returns void language sql as $$
  insert into t15.vars values (p_k, p_v) on conflict (k) do update set v = excluded.v $$;
create function t15.right_response(p_q text) returns jsonb language sql security definer as $$
  select case q.type
    when 'multiple_choice' then q.answer_key -> 'index'
    when 'reading'         then q.answer_key -> 'index'
    when 'true_false'      then q.answer_key -> 'value'
    when 'drag_drop'       then q.answer_key -> 'token'
    when 'matching'        then q.answer_key -> 'map'
    when 'ordering'        then q.answer_key -> 'order'
  end from public.questions q where q.id = p_q $$;
grant execute on all functions in schema t15 to authenticated, anon, service_role;

insert into auth.users (id, email, is_anonymous) values
  ('00000000-0000-0000-0000-00000000000a', 'kareem@example.com', false),
  ('00000000-0000-0000-0000-0000000000c1', null, true),
  ('00000000-0000-0000-0000-00000000000b', 'bob@example.com', false);

set role authenticated;
select t15.login('00000000-0000-0000-0000-00000000000a');
select create_family('Junaid', 'Kareem', 'en', 'v1', '[
  {"display_name":"Omar","kind":"child","grade":6},
  {"display_name":"Yassin","kind":"child","grade":3,"ui_locale":"ar"}]');
select t15.put('omar',   (select id::text from profiles where display_name = 'Omar'));
select t15.put('yassin', (select id::text from profiles where display_name = 'Yassin'));
select t15.put('kareem', (select id::text from profiles where display_name = 'Kareem'));
select t15.put('code', create_pairing_code(t15.v('yassin')::uuid) ->> 'code');

-- ---------------------------------------------------------------- tables are closed to the app
select t15.expect_error($$ select count(*) from public.ai_messages $$, 'permission');
select t15.expect_error($$ select count(*) from public.ai_conversations $$, 'permission');

-- ---------------------------------------------------------------- status & scenarios
select t15.ok((ai_status(t15.v('yassin')::uuid) ->> 'daily_limit')::int = 20
          and (ai_status(t15.v('kareem')::uuid) ->> 'daily_limit')::int = 60
          and (ai_status(t15.v('kareem')::uuid) ->> 'monthly_budget')::numeric = 5, 'defaults: 20/day child, 60/day adult, $5/month');
select t15.ok((select array_agg(x ->> 'code' order by x ->> 'code') from jsonb_array_elements(ai_scenarios_for(t15.v('yassin')::uuid)) x)
              = array['kid3_fr_bonjour', 'kid3_new_friend', 'kid3_toy_shop'], 'Yassin gets the grade-3 scenarios only');
select t15.ok(jsonb_array_length(ai_scenarios_for(t15.v('omar')::uuid)) = 5
          and not exists (select 1 from jsonb_array_elements(ai_scenarios_for(t15.v('omar')::uuid)) x where x ->> 'code' like 'kid3%' or x ->> 'code' = 'sales_report'),
              'Omar gets the grade-6 scenarios only');
select t15.ok(jsonb_array_length(ai_scenarios_for(t15.v('kareem')::uuid)) = 10, 'Kareem gets the 10 business scenarios');

-- ---------------------------------------------------------------- tutor with a question (before answering: no answer given)
reset role;
select t15.put('q', (select q.id from public.questions q join public.lessons l on l.id = q.lesson_id
                      where l.course_id = 'fr-g3' and q.type = 'multiple_choice' order by l.position, q.position limit 1));
set role authenticated;
select t15.put('p1', ai_prepare(t15.v('yassin')::uuid, 'tutor', null, jsonb_build_object('question_id', t15.v('q')), 'ساعدني')::text);
select t15.ok(t15.v('p1')::jsonb -> 'context' ->> 'question' is not null
          and (t15.v('p1')::jsonb -> 'context' ->> 'answered')::boolean = false
          and t15.v('p1')::jsonb -> 'context' ->> 'correct_answer' is null, 'tutor: question context without the answer before answering');
select t15.ok(t15.v('p1')::jsonb -> 'profile' ->> 'ui_locale' = 'ar' and (t15.v('p1')::jsonb -> 'profile' ->> 'grade')::int = 3, 'tutor: profile language and grade');
select t15.ok(jsonb_array_length(t15.v('p1')::jsonb -> 'history') = 1, 'tutor: the message is saved');
select t15.put('c1', t15.v('p1')::jsonb ->> 'conversation_id');
-- only service_role may save the reply
select t15.expect_error(format($$ select ai_finish(%L, 'assistant', 'hi', 1, 1, 0.1) $$, t15.v('c1')), 'permission');
-- after answering, the explanation is available
reset role;
select t15.put('ql', (select lesson_id from public.questions where id = t15.v('q')));
set role authenticated;
select t15.put('s1', start_lesson(t15.v('yassin')::uuid, t15.v('ql'))::text);
select submit_answer((t15.v('s1')::jsonb ->> 'attempt_id')::uuid, t15.v('q'), '"zzz-wrong"'::jsonb);
select t15.put('p2', ai_prepare(t15.v('yassin')::uuid, 'tutor', t15.v('c1')::uuid, '{}'::jsonb, 'لماذا أخطأت؟')::text);
select t15.ok((t15.v('p2')::jsonb -> 'context' ->> 'answered')::boolean
          and (t15.v('p2')::jsonb -> 'context' ->> 'learner_was_right')::boolean = false
          and t15.v('p2')::jsonb -> 'context' ->> 'correct_answer' is not null, 'tutor: after a wrong answer the right answer is given to the tutor');
-- another child's question / course is refused
select t15.expect_error(format($$ select ai_prepare(%L, 'tutor', null, '{"question_id":"fr-g6.u1.l1.q1"}', 'hi') $$, t15.v('yassin')), 'not_found');
select t15.expect_error(format($$ select ai_prepare(%L, 'tutor', %L, '{}', 'hi') $$, t15.v('omar'), t15.v('c1')), 'not_found');
select t15.expect_error(format($$ select ai_prepare(%L, 'tutor', null, '{}', '   ') $$, t15.v('omar')), 'empty_message');
select t15.expect_error(format($$ select ai_prepare(%L, 'tutor', null, '{}', %L) $$, t15.v('omar'), repeat('a', 601)), 'message_too_long');

-- ---------------------------------------------------------------- the reply (service_role)
reset role;
set role service_role;
select ai_finish(t15.v('c1')::uuid, 'assistant', 'Bonjour veut dire صباح الخير', 120, 40, 0.000032, true);
reset role;
set role authenticated;
select t15.login('00000000-0000-0000-0000-00000000000a');
select t15.ok((ai_status(t15.v('yassin')::uuid) ->> 'used_today')::int = 1, 'one model call counted for Yassin');
select t15.ok((ai_conversation(t15.v('c1')::uuid) ->> 'flagged')::boolean
          and jsonb_array_length(ai_conversation(t15.v('c1')::uuid) -> 'messages') = 3, 'parent sees the whole conversation and the safety flag');
select t15.ok((ai_history(t15.v('yassin')::uuid) -> 0 ->> 'messages')::int = 3 and ai_history(t15.v('omar')::uuid) = '[]'::jsonb,
              'history per child');

-- ---------------------------------------------------------------- role-play
select t15.expect_error(format($$ select ai_prepare(%L, 'roleplay', null, '{"scenario":"sales_report"}') $$, t15.v('yassin')), 'not_found');
select t15.put('r1', ai_prepare(t15.v('omar')::uuid, 'roleplay', null, '{"scenario":"kid6_fr_cafe"}')::text);
select t15.ok(t15.v('r1')::jsonb -> 'scenario' ->> 'lang' = 'fr' and jsonb_array_length(t15.v('r1')::jsonb -> 'history') = 0,
              'role-play opens without a message (the AI speaks first)');
select t15.put('rc', t15.v('r1')::jsonb ->> 'conversation_id');
select t15.expect_error(format($$ select ai_prepare(%L, 'feedback', %L) $$, t15.v('omar'), t15.v('rc')), 'too_short');
reset role; set role service_role;
select ai_finish(t15.v('rc')::uuid, 'assistant', 'Bonjour ! Qu''est-ce que vous désirez ?', 50, 20, 0.00001);
reset role; set role authenticated;
select t15.login('00000000-0000-0000-0000-00000000000a');
select t15.expect_error(format($$ select ai_prepare(%L, 'roleplay', %L, '{}', null) $$, t15.v('omar'), t15.v('rc')), 'empty_message');
select ai_prepare(t15.v('omar')::uuid, 'roleplay', t15.v('rc')::uuid, '{}', 'Un croissant, s''il vous plaît.');
select ai_prepare(t15.v('omar')::uuid, 'roleplay', t15.v('rc')::uuid, '{}', 'C''est combien ?');
select t15.ok(ai_prepare(t15.v('omar')::uuid, 'feedback', t15.v('rc')::uuid) ->> 'kind' = 'feedback', 'feedback allowed after 2 messages');
reset role; set role service_role;
select ai_finish(t15.v('rc')::uuid, 'feedback', '', 300, 200, 0.0001, false, '{"summary":"Très bien !"}');
reset role; set role authenticated;
select t15.login('00000000-0000-0000-0000-00000000000a');
select t15.ok(ai_prepare(t15.v('omar')::uuid, 'feedback', t15.v('rc')::uuid) -> 'cached_feedback' ->> 'summary' = 'Très bien !',
              'feedback is saved and returned again without a new model call');
select t15.ok(jsonb_array_length(ai_conversation(t15.v('rc')::uuid) -> 'messages') = 3, 'feedback is not shown as a chat message');

-- ---------------------------------------------------------------- child phone, other family
select t15.login('00000000-0000-0000-0000-0000000000c1', true);
select redeem_pairing_code(t15.v('code'), 'Yassin phone');
select t15.ok(jsonb_array_length(ai_history(t15.v('yassin')::uuid)) = 1, 'Yassin phone sees his own conversation');
select t15.expect_error(format($$ select ai_conversation(%L) $$, t15.v('rc')), 'not_found');
select t15.expect_error(format($$ select ai_history(%L) $$, t15.v('omar')), 'not_found');
select t15.expect_error(format($$ select ai_prepare(%L, 'roleplay', null, '{"scenario":"kid6_fr_cafe"}') $$, t15.v('omar')), 'not_found');
select t15.login('00000000-0000-0000-0000-00000000000b');
select t15.expect_error(format($$ select ai_conversation(%L) $$, t15.v('c1')), 'not_found');
select t15.expect_error(format($$ select ai_status(%L) $$, t15.v('yassin')), 'not_found');

-- ---------------------------------------------------------------- AI switched off by the parent
select t15.login('00000000-0000-0000-0000-00000000000a');
reset role;
update public.profiles set ai_enabled = false where id = t15.v('yassin')::uuid;
set role authenticated;
select t15.expect_error(format($$ select ai_prepare(%L, 'tutor', null, '{}', 'hi') $$, t15.v('yassin')), 'ai_disabled');
reset role;
update public.profiles set ai_enabled = true where id = t15.v('yassin')::uuid;

-- ---------------------------------------------------------------- daily limit
update public.ai_settings set child_daily_limit = 3 where family_id = (select family_id from public.profiles where id = t15.v('yassin')::uuid);
set role service_role;
select ai_finish(t15.v('c1')::uuid, 'assistant', 'second reply', 10, 10, 0.000001);
select ai_finish(t15.v('c1')::uuid, 'assistant', 'third reply', 10, 10, 0.000001);
reset role; set role authenticated;
select t15.expect_error(format($$ select ai_prepare(%L, 'tutor', %L, '{}', 'again') $$, t15.v('yassin'), t15.v('c1')), 'ai_daily_limit');
select t15.ok(ai_prepare(t15.v('omar')::uuid, 'tutor', null, '{}', 'hello') ->> 'conversation_id' is not null, 'Omar''s limit is separate');

-- ---------------------------------------------------------------- monthly budget (whole family)
reset role;
update public.ai_settings set child_daily_limit = 20, monthly_budget_usd = 0.0001
 where family_id = (select family_id from public.profiles where id = t15.v('yassin')::uuid);
set role authenticated;
select t15.expect_error(format($$ select ai_prepare(%L, 'tutor', null, '{}', 'hi') $$, t15.v('kareem')), 'ai_budget');
reset role;
update public.ai_settings set monthly_budget_usd = 5;

-- ---------------------------------------------------------------- grants
select t15.ok(not has_function_privilege('authenticated', 'public.ai_finish(uuid, text, text, int, int, numeric, boolean, jsonb)', 'execute'), 'ai_finish is not callable from the app');
select t15.ok(not has_function_privilege('anon', 'public.ai_prepare(uuid, text, uuid, jsonb, text)', 'execute'), 'anon cannot call ai_prepare');

\echo 'ALL AI DATABASE TESTS PASSED'
