-- LOCAL TESTING ONLY (plain PostgreSQL + supabase_stub.sql). Do NOT run on Supabase.
-- Speaking game: tracks, unlocking, per-child isolation, caps, re-run safety.
\set ON_ERROR_STOP 1
\set QUIET 1

create schema ts;
grant usage on schema ts to authenticated, anon;
create function ts.login(p_uid uuid, p_anon boolean default false) returns void
language sql as $$
  select set_config('request.jwt.claims',
                    json_build_object('sub', p_uid, 'role', 'authenticated', 'is_anonymous', p_anon)::text, false)
$$;
create function ts.expect_error(p_sql text, p_msg text) returns void
language plpgsql as $$
begin
  execute p_sql;
  raise exception 'EXPECTED ERROR "%" but statement succeeded: %', p_msg, p_sql;
exception
  when others then
    if sqlerrm like 'EXPECTED ERROR%' then raise; end if;
    if sqlerrm <> p_msg then raise exception 'expected error "%", got "%" for: %', p_msg, sqlerrm, p_sql; end if;
end $$;
create function ts.ok(p_cond boolean, p_what text) returns void
language plpgsql as $$
begin
  if p_cond is not true then raise exception 'FAILED: %', p_what; end if;
  raise notice 'ok - %', p_what;
end $$;
create table ts.vars (k text primary key, v text);
grant all on ts.vars to authenticated, anon;
grant execute on all functions in schema ts to authenticated, anon;
create function ts.v(p_k text) returns text language sql as $$ select v from ts.vars where k = p_k $$;
grant execute on function ts.v(text) to authenticated, anon;

insert into auth.users (id, email, is_anonymous) values
  ('00000000-0000-0000-0000-00000000000a', 'kareem@example.com', false),
  ('00000000-0000-0000-0000-0000000000c1', null, true),
  ('00000000-0000-0000-0000-0000000000c2', null, true),
  ('00000000-0000-0000-0000-00000000000b', 'bob@example.com', false);

set role authenticated;
select ts.login('00000000-0000-0000-0000-00000000000a');
select create_family('Junaid', 'Kareem', 'en', 'v1', '[
  {"display_name":"Omar","kind":"child","grade":6},
  {"display_name":"Yassin","kind":"child","grade":3,"ui_locale":"ar"}]');
insert into ts.vars select 'omar',   id::text from profiles where display_name = 'Omar';
insert into ts.vars select 'yassin', id::text from profiles where display_name = 'Yassin';
insert into ts.vars select 'kareem', id::text from profiles where display_name = 'Kareem';

-- tracks
select ts.ok(speak_game_state(ts.v('yassin')::uuid) ->> 'track' = 'young', 'Yassin gets the young (P3 book) levels');
select ts.ok(speak_game_state(ts.v('omar')::uuid) ->> 'track' = 'older', 'Omar gets the older (P6 book) levels');
select ts.ok(speak_game_state(ts.v('kareem')::uuid) ->> 'track' = 'adult', 'Kareem gets the adult levels');
select ts.ok(jsonb_array_length(speak_game_state(ts.v('yassin')::uuid) -> 'levels') = 34, 'Yassin has 34 stages');
select ts.ok((speak_game_state(ts.v('yassin')::uuid) -> 'levels' -> 0 ->> 'id') = 'y1-sounds', 'levels in order');
select ts.ok((speak_game_state(ts.v('yassin')::uuid) -> 'levels' -> 0 ->> 'unlocked')::boolean, 'first level open');
select ts.ok(not (speak_game_state(ts.v('yassin')::uuid) -> 'levels' -> 1 ->> 'unlocked')::boolean, 'second level locked');
select ts.ok(jsonb_array_length(speak_game_state(ts.v('yassin')::uuid) -> 'levels' -> 0 -> 'words') = 8, 'words come with the level');

-- tables are closed
select ts.expect_error($$ select * from public.speak_words $$, 'permission denied for table speak_words');
select ts.expect_error($$ select * from public.speak_plays $$, 'permission denied for table speak_plays');
select ts.expect_error($$ insert into public.speak_plays (profile_id, level_id, points, stars, words, first_try, attempts) values (ts.v('yassin')::uuid, 'y1-sounds', 5, 1, 1, 1, 1) $$,
                       'permission denied for table speak_plays');

-- link Yassin's phone and Omar's phone
insert into ts.vars select 'code_y', create_pairing_code(ts.v('yassin')::uuid) ->> 'code';
insert into ts.vars select 'code_o', create_pairing_code(ts.v('omar')::uuid) ->> 'code';
select ts.login('00000000-0000-0000-0000-0000000000c1', true);
select redeem_pairing_code(ts.v('code_y'), 'Yassin phone');
select ts.login('00000000-0000-0000-0000-0000000000c2', true);
select redeem_pairing_code(ts.v('code_o'), 'Omar phone');

-- Yassin plays on his phone
select ts.login('00000000-0000-0000-0000-0000000000c1', true);
select speak_record_attempt(ts.v('yassin')::uuid, 'y1-sounds', 'stop', 'stop', 1, 'correct', 1);
select speak_record_attempt(ts.v('yassin')::uuid, 'y1-sounds', 'star', 'stir', 0.6, 'close', 1);
select speak_record_attempt(ts.v('yassin')::uuid, 'y1-sounds', 'star', 'star', 1, 'correct', 2);
select speak_record_attempt(ts.v('yassin')::uuid, 'y1-sounds', 'step', '', 0, 'unclear', 1);
select ts.expect_error(format($$ select speak_record_attempt(%L, 'y1-sounds', 'giraffe', 'x', 1, 'correct', 1) $$, ts.v('yassin')), 'not_found');
select ts.expect_error(format($$ select speak_record_attempt(%L, 'y1-sounds', 'stop', 'x', 1, 'great', 1) $$, ts.v('yassin')), 'unknown');
select ts.expect_error(format($$ select speak_finish_level(%L, 'y2-safety', 50, 3, 8, 8, 8) $$, ts.v('yassin')), 'lesson_locked');
select ts.expect_error(format($$ select speak_finish_level(%L, 'o1-art', 50, 3, 8, 8, 8) $$, ts.v('yassin')), 'not_found');
-- Yassin's phone cannot touch Omar
select ts.expect_error(format($$ select speak_game_state(%L) $$, ts.v('omar')), 'not_found');
select ts.expect_error(format($$ select speak_record_attempt(%L, 'o1-art', 'canvas', 'canvas', 1, 'correct', 1) $$, ts.v('omar')), 'not_found');

insert into ts.vars select 'after', speak_finish_level(ts.v('yassin')::uuid, 'y1-sounds', 999999, 7, 8, 99, 12)::text;
select ts.ok((ts.v('after')::jsonb ->> 'points')::int = 8 * 30 + 50, 'points are capped');
select ts.ok((ts.v('after')::jsonb -> 'levels' -> 0 ->> 'best_stars')::int = 3, 'stars capped at 3');
select ts.ok((ts.v('after')::jsonb -> 'levels' -> 1 ->> 'unlocked')::boolean, 'next level unlocked after finishing');
select ts.ok((ts.v('after')::jsonb ->> 'words_mastered')::int = 2, 'words mastered counted (stop, star)');
select ts.ok((ts.v('after')::jsonb ->> 'day_streak')::int = 1, 'day streak = 1');
select ts.ok((ts.v('after')::jsonb -> 'tricky' -> 0 ->> 'word') = 'star', 'tricky words for the parent');
select speak_finish_level(ts.v('yassin')::uuid, 'y1-sounds', 100, 1, 8, 2, 12);
select ts.ok((speak_game_state(ts.v('yassin')::uuid) -> 'levels' -> 0 ->> 'best_stars')::int = 3, 'best stars kept after a weaker replay');
select ts.ok((speak_game_state(ts.v('yassin')::uuid) ->> 'points')::int = 290, 'points = best result of the stage (a weaker replay does not lower it)');

-- Omar's progress is separate
select ts.login('00000000-0000-0000-0000-0000000000c2', true);
select ts.ok((speak_game_state(ts.v('omar')::uuid) ->> 'points')::int = 0, 'Omar starts at 0 points');
select ts.ok(not (speak_game_state(ts.v('omar')::uuid) -> 'levels' -> 1 ->> 'unlocked')::boolean, 'Omar level 2 still locked');

-- parent sees both
select ts.login('00000000-0000-0000-0000-00000000000a');
select ts.ok((speak_game_state(ts.v('yassin')::uuid) ->> 'points')::int = 290, 'parent sees Yassin');
-- another family sees nothing
select ts.login('00000000-0000-0000-0000-00000000000b');
select create_family('Other', 'Bob', 'en', 'v1', '[]');
select ts.expect_error(format($$ select speak_game_state(%L) $$, ts.v('yassin')), 'not_found');
reset role;
set role anon;
select ts.expect_error(format($$ select speak_game_state(%L) $$, ts.v('yassin')), 'permission denied for function speak_game_state');
reset role;

-- re-running the migration keeps progress
\ir ../migrations/20261002000008_speak_stages.sql
select ts.ok((select count(*) from public.speak_plays) = 2, 'progress kept after re-run');
select ts.ok((select count(*) from public.speak_words) = 427, 'words replaced, not duplicated');
select 'ALL SPEAK GAME TESTS PASSED';
