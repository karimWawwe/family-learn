-- LOCAL TESTING ONLY (plain PostgreSQL + supabase_stub.sql). Do NOT run on Supabase.
-- Runs after phase3_accounts_test.sql's helpers are gone, so it sets up its own.
\set ON_ERROR_STOP 1
\set QUIET 1

create schema t4;
grant usage on schema t4 to authenticated, anon;

create function t4.login(p_uid uuid, p_anon boolean default false) returns void
language sql as $$
  select set_config('request.jwt.claims',
                    json_build_object('sub', p_uid, 'role', 'authenticated', 'is_anonymous', p_anon)::text, false)
$$;

create function t4.expect_error(p_sql text, p_msg text) returns void
language plpgsql as $$
begin
  execute p_sql;
  raise exception 'EXPECTED ERROR "%" but statement succeeded: %', p_msg, p_sql;
exception
  when others then
    if sqlerrm like 'EXPECTED ERROR%' then raise; end if;
    if sqlerrm <> p_msg then raise exception 'expected error "%", got "%" for: %', p_msg, sqlerrm, p_sql; end if;
end $$;

create function t4.ok(p_cond boolean, p_what text) returns void
language plpgsql as $$
begin
  if p_cond is not true then raise exception 'FAILED: %', p_what; end if;
  raise notice 'ok - %', p_what;
end $$;

create table t4.vars (k text primary key, v text);
grant all on t4.vars to authenticated;
grant execute on all functions in schema t4 to authenticated, anon;

-- ---------------------------------------------------------------- grader: every starter question
-- The correct answer built from the key must pass; a wrong one must fail.
create function t4.right_response(q public.questions) returns jsonb language sql as $$
  select case q.type
    when 'multiple_choice' then q.answer_key -> 'index'
    when 'reading'         then q.answer_key -> 'index'
    when 'true_false'      then q.answer_key -> 'value'
    when 'fill_blank'      then to_jsonb('  ' || upper(q.answer_key -> 'accepted' ->> 0) || '. ')
    when 'typing'          then to_jsonb(upper(q.answer_key -> 'accepted' ->> 0) || '!')
    when 'drag_drop'       then q.answer_key -> 'token'
    when 'word_problem'    then to_jsonb((q.answer_key ->> 'value') || ' ' || coalesce(q.payload ->> 'unit', ''))
    when 'matching'        then q.answer_key -> 'map'
    when 'ordering'        then q.answer_key -> 'order'
  end $$;

create function t4.wrong_response(q public.questions) returns jsonb language sql as $$
  select case q.type
    when 'multiple_choice' then to_jsonb(((q.answer_key ->> 'index')::int + 1) % jsonb_array_length(q.payload -> 'options'))
    when 'reading'         then to_jsonb(((q.answer_key ->> 'index')::int + 1) % jsonb_array_length(q.payload -> 'options'))
    when 'true_false'      then to_jsonb(not (q.answer_key ->> 'value')::boolean)
    when 'fill_blank'      then to_jsonb('zzz'::text)
    when 'typing'          then to_jsonb('zzz'::text)
    when 'drag_drop'       then to_jsonb('zzz'::text)
    when 'word_problem'    then to_jsonb(((q.answer_key ->> 'value')::numeric + 1)::text)
    when 'matching'        then (select jsonb_object_agg(i::text, (((q.answer_key -> 'map' ->> i::text)::int + 1) % (q.answer_key ->> 'pairs')::int))
                                   from generate_series(0, (q.answer_key ->> 'pairs')::int - 1) i)
    when 'ordering'        then (select jsonb_agg(x order by o desc) from jsonb_array_elements(q.answer_key -> 'order') with ordinality e(x, o))
  end $$;

select t4.ok((select count(*) from public.questions) = 110, '110 starter questions loaded');
select t4.ok(not exists (select 1 from public.questions q where not app.grade(q.type, q.answer_key, t4.right_response(q))),
             'every starter question accepts its right answer');
select t4.ok(not exists (select 1 from public.questions q where app.grade(q.type, q.answer_key, t4.wrong_response(q))),
             'every starter question rejects a wrong answer');
select t4.ok(app.parse_number('300 baisa') = 300 and app.parse_number('0,25') = 0.25
             and app.parse_number('20,000') = 20000 and app.parse_number('.5') = 0.5
             and app.parse_number('abc') is null, 'number reading from typed answers');
select t4.ok(not app.grade('multiple_choice', '{"index":1}', '"1"'), 'string is not an option index');
select t4.ok(not app.grade('matching', '{"pairs":2,"map":{"0":1,"1":0}}', '{"0":1}'), 'incomplete matching is wrong');
select t4.ok(not app.grade('matching', '{"pairs":2,"map":{"0":1,"1":0}}', '{"5":1,"6":0}'), 'matching keys out of range are wrong');
select t4.ok(app.norm(E'  Watched.\n') = 'watched', 'typed answers: spaces, tabs, new lines and final dot ignored');
select t4.ok(not exists (select 1 from public.questions where type = 'ordering' and payload -> 'items' = answer_key -> 'order'),
             'ordering items are never sent in the right order');
select t4.ok(not exists (select 1 from public.questions q where type = 'matching'
                          and (select bool_and((q.answer_key -> 'map' ->> i::text)::int = i) from generate_series(0, (q.answer_key ->> 'pairs')::int - 1) i)),
             'matching pairs are never sent in the right order');
select t4.ok(not app.grade('word_problem', '{"value":5}', 'null'), 'no answer is wrong');

-- ---------------------------------------------------------------- family for the flows
insert into auth.users (id, email, is_anonymous) values
  ('00000000-0000-0000-0000-00000000000a', 'kareem@example.com', false),
  ('00000000-0000-0000-0000-00000000000b', 'other@example.com',  false),
  ('00000000-0000-0000-0000-0000000000c1', null, true),
  ('00000000-0000-0000-0000-0000000000c3', null, true);

create function t4.status(p uuid, lesson text) returns text language sql as $$
  select l ->> 'status' from jsonb_array_elements(public.course_map(p)) c,
         jsonb_array_elements(c -> 'units') u, jsonb_array_elements(u -> 'lessons') l
   where l ->> 'id' = lesson $$;
grant execute on function t4.status(uuid, text) to authenticated;

set role authenticated;
select t4.login('00000000-0000-0000-0000-00000000000a');
select create_family('Junaid', 'Kareem', 'en', 'v1', '[
  {"display_name":"Omar","kind":"child","grade":6},
  {"display_name":"Yassin","kind":"child","grade":3,"ui_locale":"ar"}]');
insert into t4.vars select 'omar',   id::text from profiles where display_name = 'Omar';
insert into t4.vars select 'yassin', id::text from profiles where display_name = 'Yassin';
insert into t4.vars select 'kareem', id::text from profiles where display_name = 'Kareem';

-- ---------------------------------------------------------------- courses per profile
select t4.ok((select array_agg(c ->> 'id' order by c ->> 'id') from jsonb_array_elements(course_map((select v::uuid from t4.vars where k='omar'))) c)
             = array['eng-upper', 'math-upper'], 'Omar (grade 6) gets the grade 5+ courses');
select t4.ok((select array_agg(c ->> 'id' order by c ->> 'id') from jsonb_array_elements(course_map((select v::uuid from t4.vars where k='yassin'))) c)
             = array['eng-lower', 'math-lower'], 'Yassin (grade 3) gets the grade 1-4 courses');
select t4.ok((select array_agg(c ->> 'id') from jsonb_array_elements(course_map((select v::uuid from t4.vars where k='kareem'))) c)
             = array['business'], 'Kareem gets Business English');

-- first lesson open, second locked

select t4.ok(t4.status((select v::uuid from t4.vars where k='omar'), 'eng-upper.u1.l1') = 'available', 'first lesson available');
select t4.ok(t4.status((select v::uuid from t4.vars where k='omar'), 'eng-upper.u1.l2') = 'locked', 'second lesson locked');
select t4.expect_error(format($$ select start_lesson(%L, 'eng-upper.u1.l2') $$, (select v from t4.vars where k='omar')), 'lesson_locked');
select t4.expect_error(format($$ select start_lesson(%L, 'eng-lower.u1.l1') $$, (select v from t4.vars where k='omar')), 'not_found');

-- answer keys are private
select t4.expect_error($$ select answer_key from public.questions limit 1 $$, 'permission denied for table questions');
select t4.expect_error($$ select * from public.lesson_attempts $$, 'permission denied for table lesson_attempts');
select t4.ok((select count(*) from public.lessons) = 22, 'lesson outlines are readable');

-- ---------------------------------------------------------------- Omar's phone plays a lesson
select t4.login('00000000-0000-0000-0000-00000000000a');
insert into t4.vars select 'code', create_pairing_code((select v::uuid from t4.vars where k='omar')) ->> 'code';
select t4.login('00000000-0000-0000-0000-0000000000c1', true);
select redeem_pairing_code((select v from t4.vars where k='code'), 'Omar phone');

insert into t4.vars select 'start', start_lesson((select v::uuid from t4.vars where k='omar'), 'eng-upper.u1.l1')::text;
select t4.ok(jsonb_array_length((select v::jsonb from t4.vars where k='start') -> 'questions') = 5, 'lesson returns 5 questions');
select t4.ok(not ((select v from t4.vars where k='start') like '%answer_key%')
             and not ((select v from t4.vars where k='start') like '%"index"%'), 'no answer keys sent to the phone');
insert into t4.vars select 'att', (v::jsonb ->> 'attempt_id') from t4.vars where k = 'start';

-- phone cannot play Yassin's lessons or touch his attempts
select t4.expect_error(format($$ select start_lesson(%L, 'eng-lower.u1.l1') $$, (select v from t4.vars where k='yassin')), 'not_found');
select t4.expect_error(format($$ select profile_wallet(%L) $$, (select v from t4.vars where k='yassin')), 'not_found');
select t4.expect_error(format($$ select profile_report(%L) $$, (select v from t4.vars where k='omar')), 'parent_only');

-- answer: q1 right (played), q2 wrong, q3..q5 right  -> 4/5 = 80%
select t4.ok((submit_answer((select v::uuid from t4.vars where k='att'), 'eng-upper.u1.l1.q1', '1') ->> 'correct')::boolean, 'right answer marked right');
select t4.ok(not (submit_answer((select v::uuid from t4.vars where k='att'), 'eng-upper.u1.l1.q2', '"watch"') ->> 'correct')::boolean, 'wrong answer marked wrong');
select t4.ok((submit_answer((select v::uuid from t4.vars where k='att'), 'eng-upper.u1.l1.q2', '"watched"') ->> 'correct')::boolean is false,
             'second try on the same question does not change the mark');
select t4.ok((submit_answer((select v::uuid from t4.vars where k='att'), 'eng-upper.u1.l1.q2', '"x"') ->> 'correct_text') = 'watched', 'correct text returned');
select submit_answer((select v::uuid from t4.vars where k='att'), 'eng-upper.u1.l1.q3', '" Studied "');
select submit_answer((select v::uuid from t4.vars where k='att'), 'eng-upper.u1.l1.q4', 'false');
reset role;
insert into t4.vars select 'q5', (answer_key -> 'map')::text from public.questions where id = 'eng-upper.u1.l1.q5';
set role authenticated;
select t4.login('00000000-0000-0000-0000-0000000000c1', true);
select submit_answer((select v::uuid from t4.vars where k='att'), 'eng-upper.u1.l1.q5', (select v::jsonb from t4.vars where k='q5'));
select t4.expect_error(format($$ select submit_answer(%L, 'eng-upper.u2.l1.q1', '1') $$, (select v from t4.vars where k='att')), 'not_found');
select t4.ok(t4.status((select v::uuid from t4.vars where k='omar'), 'eng-upper.u1.l1') = 'in_progress', 'lesson in progress');

insert into t4.vars select 'fin', finish_lesson((select v::uuid from t4.vars where k='att'))::text;
select t4.ok((select (v::jsonb ->> 'correct')::int = 4 and (v::jsonb ->> 'total')::int = 5 from t4.vars where k='fin'), 'score 4/5');
select t4.ok((select (v::jsonb ->> 'xp')::int = 60 from t4.vars where k='fin'), 'xp = 4x10 + 20 bonus (80%)');
select t4.ok((select (v::jsonb ->> 'stars')::int = 2 and (v::jsonb ->> 'coins')::int = 9 from t4.vars where k='fin'), '2 stars, 9 coins');
select t4.ok((select (v::jsonb -> 'wallet' ->> 'streak_days')::int = 1 from t4.vars where k='fin'), 'streak starts at 1');
select t4.ok(finish_lesson((select v::uuid from t4.vars where k='att')) ->> 'xp' = '60', 'finishing twice gives the same result');
select t4.expect_error(format($$ select submit_answer(%L, 'eng-upper.u1.l1.q1', '1') $$, (select v from t4.vars where k='att')), 'lesson_finished');
select t4.ok(t4.status((select v::uuid from t4.vars where k='omar'), 'eng-upper.u1.l1') = 'done', 'lesson done');
select t4.ok(t4.status((select v::uuid from t4.vars where k='omar'), 'eng-upper.u1.l2') = 'available', 'next lesson unlocked');

-- ---------------------------------------------------------------- streak across days
reset role;
insert into public.lesson_attempts (profile_id, lesson_id, started_by, started_at, finished_at, total, correct, xp, coins, stars)
select (select v::uuid from t4.vars where k='omar'), 'eng-upper.u2.l1', '00000000-0000-0000-0000-0000000000c1',
       now() - interval '1 day' - interval '10 minutes', now() - interval '1 day', 5, 5, 70, 10, 3;
insert into public.lesson_attempts (profile_id, lesson_id, started_by, started_at, finished_at, total, correct, xp, coins, stars)
select (select v::uuid from t4.vars where k='omar'), 'eng-upper.u2.l1', '00000000-0000-0000-0000-0000000000c1',
       now() - interval '3 days' - interval '5 hours', now() - interval '3 days', 5, 5, 70, 10, 3;
set role authenticated;
select t4.login('00000000-0000-0000-0000-0000000000c1', true);
select t4.ok((profile_wallet((select v::uuid from t4.vars where k='omar')) ->> 'streak_days')::int = 2, 'streak counts today + yesterday, gap stops it');
select t4.ok((profile_wallet((select v::uuid from t4.vars where k='omar')) ->> 'xp')::int = 200, 'xp adds up');
select t4.ok((profile_wallet((select v::uuid from t4.vars where k='omar')) ->> 'stars')::int = 5, 'stars = best per lesson (2 + 3)');

-- ---------------------------------------------------------------- parent report
select t4.login('00000000-0000-0000-0000-00000000000a');
insert into t4.vars select 'rep', profile_report((select v::uuid from t4.vars where k='omar'))::text;
select t4.ok((select jsonb_array_length(v::jsonb -> 'minutes_by_day') = 7 from t4.vars where k='rep'), 'report has 7 days');
select t4.ok((select (v::jsonb -> 'minutes_by_day' ->> 5)::int = 10 from t4.vars where k='rep'), 'yesterday = 10 minutes');
select t4.ok((select (v::jsonb -> 'last_7' ->> 'questions')::int = 5 and (v::jsonb -> 'last_7' ->> 'accuracy')::numeric = 0.8 from t4.vars where k='rep'),
             '5 answers this week, 80% accuracy');
select t4.ok((select jsonb_array_length(v::jsonb -> 'history') = 3 from t4.vars where k='rep'), 'history lists finished lessons');
select t4.ok((select v::jsonb -> 'to_review' ? 'Past simple: regular verbs' from t4.vars where k='rep'), 'wrong answer shows in topics to review');
select t4.ok((select (v::jsonb -> 'skills' -> 0 ->> 'answers')::int = 5 from t4.vars where k='rep'), 'skill accuracy listed');

-- other family cannot see Omar
select t4.login('00000000-0000-0000-0000-00000000000b');
select create_family('Other', 'Bob', 'en', 'v1', '[]');
select t4.expect_error(format($$ select profile_report(%L) $$, (select v from t4.vars where k='omar')), 'not_found');
select t4.expect_error(format($$ select course_map(%L) $$, (select v from t4.vars where k='omar')), 'not_found');
select t4.expect_error(format($$ select finish_lesson(%L) $$, (select v from t4.vars where k='att')), 'not_found');

-- unlinked phone loses access to progress too
select t4.login('00000000-0000-0000-0000-00000000000a');
select unlink_device('00000000-0000-0000-0000-0000000000c1');
select t4.login('00000000-0000-0000-0000-0000000000c1', true);
select t4.expect_error(format($$ select profile_wallet(%L) $$, (select v from t4.vars where k='omar')), 'not_found');

reset role;
set role anon;
select t4.expect_error($$ select course_map('00000000-0000-0000-0000-000000000000') $$, 'permission denied for function course_map');
reset role;

\echo 'ALL PHASE 4 DATABASE TESTS PASSED'
