-- LOCAL TESTING ONLY. Math games, prophets stories, follow report with math, Yassin name.
\set ON_ERROR_STOP 1
\set QUIET 1

create schema tm;
grant usage on schema tm to authenticated, anon;
create function tm.login(p_uid uuid, p_anon boolean default false) returns void
language sql as $$
  select set_config('request.jwt.claims',
                    json_build_object('sub', p_uid, 'role', 'authenticated', 'is_anonymous', p_anon)::text, false)
$$;
create function tm.expect_error(p_sql text, p_msg text) returns void
language plpgsql as $$
begin
  execute p_sql;
  raise exception 'EXPECTED ERROR "%" but statement succeeded: %', p_msg, p_sql;
exception
  when others then
    if sqlerrm like 'EXPECTED ERROR%' then raise; end if;
    if sqlerrm <> p_msg then raise exception 'expected error "%", got "%" for: %', p_msg, sqlerrm, p_sql; end if;
end $$;
create function tm.ok(p_cond boolean, p_what text) returns void
language plpgsql as $$
begin
  if p_cond is not true then raise exception 'FAILED: %', p_what; end if;
  raise notice 'ok - %', p_what;
end $$;
create table tm.vars (k text primary key, v text);
grant all on tm.vars to authenticated, anon;
create function tm.v(p_k text) returns text language sql as $$ select v from tm.vars where k = p_k $$;
grant execute on all functions in schema tm to authenticated, anon;

insert into auth.users (id, email, is_anonymous) values
  ('00000000-0000-0000-0000-00000000000a', 'kareem@example.com', false),
  ('00000000-0000-0000-0000-0000000000c1', null, true),
  ('00000000-0000-0000-0000-0000000000c2', null, true);

set role authenticated;
select tm.login('00000000-0000-0000-0000-00000000000a');
select create_family('Junaid', 'Kareem', 'en', 'v1', '[
  {"display_name":"Omar","kind":"child","grade":6},
  {"display_name":"yasen","kind":"child","grade":3,"ui_locale":"ar"}]');
insert into tm.vars select 'omar',   id::text from profiles where display_name = 'Omar';
insert into tm.vars select 'yassin', id::text from profiles where display_name = 'yasen';
insert into tm.vars select 'code_y', create_pairing_code(tm.v('yassin')::uuid) ->> 'code';
insert into tm.vars select 'code_o', create_pairing_code(tm.v('omar')::uuid) ->> 'code';
select tm.login('00000000-0000-0000-0000-0000000000c1', true);
select redeem_pairing_code(tm.v('code_y'), 'Yassin phone');
select tm.login('00000000-0000-0000-0000-0000000000c2', true);
select redeem_pairing_code(tm.v('code_o'), 'Omar phone');
reset role;

-- run the new migration now (renames "yasen")
\ir ../migrations/20261003000009_math_games_prophets.sql
select tm.ok((select display_name from public.profiles where id = tm.v('yassin')::uuid) = 'Yassin', 'yasen is now shown as Yassin');
select tm.ok((select display_name from public.profiles where id = tm.v('omar')::uuid) = 'Omar', 'Omar unchanged');

set role authenticated;
-- Yassin's phone plays times tables and clock
select tm.login('00000000-0000-0000-0000-0000000000c1', true);
select tm.ok((math_state(tm.v('yassin')::uuid) ->> 'rounds')::int = 0, 'new: no rounds');
select math_finish(tm.v('yassin')::uuid, 'times', 't4-easy', 7, 10, 2, 90, 120);
insert into tm.vars select 'st', math_finish(tm.v('yassin')::uuid, 'times', 't4-easy', 10, 10, 3, 160, 100)::text;
select tm.ok((tm.v('st')::jsonb ->> 'points')::int = 160, 'best points per level');
select tm.ok((tm.v('st')::jsonb ->> 'stars')::int = 3, 'best stars per level');
select tm.ok((tm.v('st')::jsonb -> 'levels' -> 0 ->> 'plays')::int = 2, 'plays counted');
select math_finish(tm.v('yassin')::uuid, 'times', 'mixed-hard', 5, 10, 1, 999999, 60);
select tm.ok((math_state(tm.v('yassin')::uuid) ->> 'points')::int = 160 + 230, 'points capped (10*20+30)');
select tm.expect_error(format($$ select math_finish(%L, 'times', 't13-easy', 1, 10, 1, 10, 10) $$, tm.v('yassin')), 'not_found');
select tm.expect_error(format($$ select math_finish(%L, 'chess', 'x', 1, 10, 1, 10, 10) $$, tm.v('yassin')), 'not_found');
select tm.expect_error(format($$ select math_finish(%L, 'clock', 'clock-2', 5, 8, 1, 50, 60) $$, tm.v('yassin')), 'lesson_locked');
select math_finish(tm.v('yassin')::uuid, 'clock', 'clock-1', 6, 8, 2, 70, 90);
select math_finish(tm.v('yassin')::uuid, 'clock', 'clock-2', 4, 8, 1, 40, 90);
select tm.ok(exists (select 1 from jsonb_array_elements(math_state(tm.v('yassin')::uuid) -> 'levels') l
                      where l ->> 'level' = 'clock-2'), 'clock-2 open after clock-1');
-- separate from Omar
select tm.expect_error(format($$ select math_state(%L) $$, tm.v('omar')), 'not_found');
select tm.expect_error(format($$ select math_finish(%L, 'times', 't2-easy', 1, 10, 1, 10, 10) $$, tm.v('omar')), 'not_found');
select tm.login('00000000-0000-0000-0000-0000000000c2', true);
select tm.ok((math_state(tm.v('omar')::uuid) ->> 'rounds')::int = 0, 'Omar has his own math progress');
-- prophets stories visible to both children
select tm.ok((select count(*) from jsonb_array_elements(bedtime_state(tm.v('omar')::uuid) -> 'stories') s
               where s ->> 'kind' = 'prophet') = 3, 'Omar sees 3 prophets stories');
select tm.login('00000000-0000-0000-0000-0000000000c1', true);
select tm.ok((select count(*) from jsonb_array_elements(bedtime_state(tm.v('yassin')::uuid) -> 'stories') s
               where s ->> 'kind' = 'prophet') = 3, 'Yassin sees 3 prophets stories');
select tm.ok(jsonb_array_length(bedtime_state(tm.v('yassin')::uuid) -> 'stories') = 17, 'all 17 stories (14 + 3)');
select tm.expect_error($$ select * from public.math_plays $$, 'permission denied for table math_plays');

-- parent report includes math
select tm.login('00000000-0000-0000-0000-00000000000a');
insert into tm.vars select 'rep', parent_follow(tm.v('yassin')::uuid, 'week')::text;
select tm.ok((tm.v('rep')::jsonb -> 'current' ->> 'math_rounds')::int = 5, 'follow: 5 math rounds');
select tm.ok((tm.v('rep')::jsonb -> 'current' ->> 'minutes_math')::int = 8, 'follow: math minutes (460 s)');
select tm.ok((tm.v('rep')::jsonb -> 'current' ->> 'minutes_total')::int >= 8, 'follow: total includes math');
select tm.ok((tm.v('rep')::jsonb -> 'current' ->> 'days_used')::int = 1, 'follow: math day counted');
select tm.ok((tm.v('rep')::jsonb -> 'progress' ->> 'math_points')::int = 160 + 230 + 70 + 40, 'follow: math points (best per level)');
select tm.ok((tm.v('rep')::jsonb -> 'last_activity' ->> 'kind') = 'math', 'follow: last activity = math');
select tm.ok((parent_follow(tm.v('omar')::uuid, 'week') -> 'current' ->> 'math_rounds')::int = 0, 'follow: Omar separate');
reset role;
\ir ../migrations/20261003000009_math_games_prophets.sql
select tm.ok((select count(*) from public.math_plays) = 5, 'progress kept after re-run');
select 'ALL MATH + PROPHETS TESTS PASSED';
