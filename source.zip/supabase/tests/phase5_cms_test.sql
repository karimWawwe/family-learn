-- LOCAL TESTING ONLY (plain PostgreSQL + supabase_stub.sql). Do NOT run on Supabase.
\set ON_ERROR_STOP 1
\set QUIET 1

create schema t5;
grant usage on schema t5 to authenticated, anon;

create function t5.login(p_uid uuid, p_email text default null, p_anon boolean default false) returns void
language sql as $$
  select set_config('request.jwt.claims',
                    json_build_object('sub', p_uid, 'role', 'authenticated', 'email', p_email, 'is_anonymous', p_anon)::text, false)
$$;

create function t5.expect_error(p_sql text, p_msg text) returns void
language plpgsql as $$
begin
  execute p_sql;
  raise exception 'EXPECTED ERROR "%" but statement succeeded: %', p_msg, p_sql;
exception
  when others then
    if sqlerrm like 'EXPECTED ERROR%' then raise; end if;
    if sqlerrm <> p_msg then raise exception 'expected error "%", got "%" for: %', p_msg, sqlerrm, p_sql; end if;
end $$;

create function t5.ok(p_cond boolean, p_what text) returns void
language plpgsql as $$
begin
  if p_cond is not true then raise exception 'FAILED: %', p_what; end if;
  raise notice 'ok - %', p_what;
end $$;

create table t5.vars (k text primary key, v text);
grant all on t5.vars to authenticated;
grant execute on all functions in schema t5 to authenticated, anon;

create function t5.codes(p jsonb) returns text[] language sql as $$
  select coalesce(array_agg(e ->> 'code' order by e ->> 'path'), '{}') from jsonb_array_elements(p) e $$;
grant execute on function t5.codes(jsonb) to authenticated;

insert into auth.users (id, email, is_anonymous) values
  ('00000000-0000-0000-0000-00000000000e', 'junaidoman09@gmail.com', false),  -- editor (invited)
  ('00000000-0000-0000-0000-00000000000b', 'other@example.com', false),       -- not an editor
  ('00000000-0000-0000-0000-0000000000c1', null, true);                       -- a child's phone

-- ---------------------------------------------------------------- round trip: live -> author -> compile is identical
-- Matching / ordering are re-shuffled by the server (a different, still-wrong order); everything else is identical.
select t5.ok(not exists (
  select 1 from public.questions q
   where app.cms_question_problems(app.cms_question_to_author(q)) <> '{}'
      or (select c ->> 'correct_text' = q.correct_text
             and c ->> 'type' = q.type
             and c ->> 'prompt' = q.prompt
             and (q.type in ('matching', 'ordering') or (c -> 'answer_key' = q.answer_key and c -> 'payload' = q.payload))
             and (q.type <> 'matching' or (c -> 'payload' -> 'left' = q.payload -> 'left'
                                           and app.grade('matching', c -> 'answer_key', c -> 'answer_key' -> 'map')))
             and (q.type <> 'ordering' or (c -> 'answer_key' = q.answer_key
                                           and c -> 'payload' -> 'items' <> c -> 'answer_key' -> 'order'))
            from (select app.cms_compile_question(app.cms_question_to_author(q), q.id) c) x) is not true),
  'all 110 starter questions survive author format -> compile');
select t5.ok(not exists (
  select 1 from public.questions q, lateral (select app.cms_compile_question(app.cms_question_to_author(q), q.id) c) x
   where q.type = 'matching'
     and (select bool_and((c -> 'payload' -> 'right' ->> ((c -> 'answer_key' -> 'map' ->> i::text)::int))
                          = (q.payload -> 'right' ->> ((q.answer_key -> 'map' ->> i::text)::int)))
            from generate_series(0, (q.answer_key ->> 'pairs')::int - 1) i) is not true),
  'matching pairs keep the same partners after the round trip');
select t5.ok((select count(*) from jsonb_array_elements(app.cms_doc_from_live('eng-upper') -> 'units')) = 2, 'course document built from live content');
select t5.ok(jsonb_array_length(app.cms_validate(app.cms_doc_from_live('business'))) = 0, 'live courses validate cleanly');

-- shuffling never keeps the right order
select t5.ok(app.cms_shuffle('x', array['a','b']) <> array['a','b'] and app.cms_shuffle('seed', array['1','2','3','4']) <> array['1','2','3','4'],
             'shuffle never returns the original order');

-- ---------------------------------------------------------------- who may edit
set role authenticated;
select t5.login('00000000-0000-0000-0000-00000000000b', 'other@example.com');
select t5.ok(not (cms_claim_editor() ->> 'editor')::boolean, 'uninvited account is not an editor');
select t5.expect_error($$ select cms_list_courses() $$, 'editor_only');
select t5.expect_error($$ select cms_save_draft('x-course', '{"id":"x-course"}') $$, 'editor_only');
select t5.expect_error($$ select * from public.content_drafts $$, 'permission denied for table content_drafts');

select t5.login('00000000-0000-0000-0000-0000000000c1', 'junaidoman09@gmail.com', true);
select t5.ok(not (cms_claim_editor() ->> 'editor')::boolean, 'anonymous phone can never be an editor, even with the e-mail claim');

select t5.login('00000000-0000-0000-0000-00000000000e', 'JunaidOman09@gmail.com');
select t5.ok((cms_claim_editor() ->> 'editor')::boolean, 'invited e-mail becomes editor (case-insensitive)');
select t5.ok(jsonb_array_length(cms_list_courses()) = 5, 'editor sees the 5 courses');

-- the invitation is now bound to this account
select t5.login('00000000-0000-0000-0000-00000000000b', 'junaidoman09@gmail.com');
select t5.ok(not (cms_claim_editor() ->> 'editor')::boolean, 'a second account with the same e-mail claim cannot take the editor seat');

-- ---------------------------------------------------------------- draft edits do not reach learners
select t5.login('00000000-0000-0000-0000-00000000000e', 'junaidoman09@gmail.com');
insert into t5.vars select 'doc', (cms_get_course('eng-upper') -> 'doc')::text;
select t5.ok((select (cms_get_course('eng-upper') ->> 'source') = 'live'), 'no draft yet: editing starts from live');

-- change the first question's prompt, add a new lesson with 2 questions, remove the last lesson
reset role;
update t5.vars set v = (
  select jsonb_set(
           jsonb_set(d, '{units,0,lessons,0,questions,0,prompt}', '"Pick the past simple: Yesterday we ___ football."'),
           '{units,1,lessons}',
           jsonb_build_array(
             d -> 'units' -> 1 -> 'lessons' -> 0,
             jsonb_build_object('title', 'Holiday words', 'minutes', 6, 'questions', jsonb_build_array(
               jsonb_build_object('type', 'ordering', 'skill', 'eng.vocab.story', 'prompt', 'Order the day.',
                                  'items', jsonb_build_array('Wake up', 'Pack the bag', 'Drive to the beach')),
               jsonb_build_object('type', 'matching', 'skill', 'eng.vocab.story', 'prompt', 'Match.',
                                  'left', jsonb_build_array('hot', 'wet', 'windy'),
                                  'right', jsonb_build_array('sunny day', 'rain', 'kites fly'))))))::text
  from (select v::jsonb d from t5.vars where k = 'doc') x) where k = 'doc';
set role authenticated;
select t5.login('00000000-0000-0000-0000-00000000000e', 'junaidoman09@gmail.com');

select t5.ok(jsonb_array_length(cms_save_draft('eng-upper', (select v::jsonb from t5.vars where k='doc')) -> 'problems') = 0, 'draft saved without problems');
reset role;
select t5.ok((select prompt from public.questions where id = 'eng-upper.u1.l1.q1') = 'Choose the past simple: Yesterday we ___ football.',
             'learners still see the old question while it is a draft');
set role authenticated;
select t5.ok((cms_get_course('eng-upper') ->> 'source') = 'draft', 'editor reopens the draft');

-- ---------------------------------------------------------------- validation blocks bad content
insert into t5.vars values ('bad', jsonb_build_object(
  'id', 'bad-course', 'subject', 'english', 'title', '', 'audience', 'child', 'grade_min', 5, 'grade_max', 2,
  'units', jsonb_build_array(jsonb_build_object('title', 'U', 'lessons', jsonb_build_array(
    jsonb_build_object('title', 'L', 'minutes', 'ten', 'questions', jsonb_build_array(
      jsonb_build_object('type', 'multiple_choice', 'skill', 'eng.vocab.story', 'prompt', 'Q', 'options', jsonb_build_array('a', 'a'), 'answer', 5),
      jsonb_build_object('type', 'drag_drop', 'skill', 'nope', 'prompt', 'Q', 'before', 'x', 'tokens', jsonb_build_array('a', 'b'), 'answer', 'c'),
      jsonb_build_object('type', 'word_problem', 'skill', 'math.ratio.basic', 'prompt', '', 'answer', 'twelve'),
      jsonb_build_object('type', 'listening', 'skill', 'math.ratio.basic', 'prompt', 'Q'),
      jsonb_build_object('id', 'eng-lower.u1.l1.q1', 'type', 'true_false', 'skill', 'math.ratio.basic', 'prompt', 'Q', 'answer', 'yes')))))))::text);
select cms_save_draft('bad-course', (select v::jsonb from t5.vars where k='bad'));
insert into t5.vars select 'badpub', cms_publish('bad-course')::text;
select t5.ok((select not (v::jsonb ->> 'ok')::boolean from t5.vars where k='badpub'), 'publishing bad content is refused');
select t5.ok((select t5.codes(v::jsonb -> 'problems') @> array['no_title', 'bad_grades', 'bad_minutes', 'options_repeat', 'pick_answer',
                                                               'bad_skill', 'no_prompt', 'answer_number', 'bad_type', 'id_in_other_course']
                from t5.vars where k='badpub'), 'every kind of problem is reported');
reset role;
select t5.ok(not exists (select 1 from public.courses where id = 'bad-course'), 'nothing reached the live tables');
set role authenticated;
select cms_discard_draft('bad-course');
select t5.expect_error($$ select cms_publish('bad-course') $$, 'no_draft');
select t5.expect_error($$ select cms_save_draft('Bad Id', '{"id":"Bad Id"}') $$, 'bad_course_id');
select t5.expect_error($$ select cms_save_draft('a-b', '{"id":"other"}') $$, 'bad_document');

-- ---------------------------------------------------------------- learner progress before publishing
reset role;
insert into auth.users (id, email) values ('00000000-0000-0000-0000-00000000000a', 'parent@example.com');
set role authenticated;
select t5.login('00000000-0000-0000-0000-00000000000a', 'parent@example.com');
select create_family('Junaid', 'Kareem', 'en', 'v1', '[{"display_name":"Omar","kind":"child","grade":6}]');
insert into t5.vars select 'omar', id::text from profiles where display_name = 'Omar';
-- Omar finishes the last lesson of eng-upper? He must go in order: play all 4 lessons quickly
do $$
declare s jsonb; l text;
begin
  foreach l in array array['eng-upper.u1.l1','eng-upper.u1.l2','eng-upper.u2.l1','eng-upper.u2.l2'] loop
    s := public.start_lesson((select v::uuid from t5.vars where k='omar'), l);
    perform public.finish_lesson((s ->> 'attempt_id')::uuid);
  end loop;
end $$;
insert into t5.vars select 'xp_before', (profile_wallet((select v::uuid from t5.vars where k='omar')) ->> 'xp');

-- ---------------------------------------------------------------- publish
select t5.login('00000000-0000-0000-0000-00000000000e', 'junaidoman09@gmail.com');
insert into t5.vars select 'pub', cms_publish('eng-upper', 'First CMS edit')::text;
select t5.ok((select (v::jsonb ->> 'ok')::boolean and (v::jsonb ->> 'version')::int = 1 from t5.vars where k='pub'), 'publish ok, version 1');
reset role;
select t5.ok((select prompt from public.questions where id = 'eng-upper.u1.l1.q1') = 'Pick the past simple: Yesterday we ___ football.',
             'learners now see the edited question');
set role authenticated;
reset role;
select t5.ok(not exists (select 1 from public.content_drafts where course_id = 'eng-upper'), 'draft cleared after publish');
set role authenticated;
reset role;
select t5.ok((select archived from public.lessons where id = 'eng-upper.u2.l2'), 'removed lesson is archived, not deleted');
set role authenticated;
reset role;
select t5.ok((select count(*) from public.lessons where course_id = 'eng-upper' and not archived) = 4, 'course still has 4 active lessons');
set role authenticated;
reset role;
select t5.ok((select title from public.lessons where course_id = 'eng-upper' and position = 4 and not archived) = 'Holiday words', 'new lesson is 4th');
set role authenticated;
reset role;
select t5.ok((select count(*) from public.questions q join public.lessons l on l.id = q.lesson_id
               where l.title = 'Holiday words' and q.id like 'eng-upper.q-%') = 2, 'new questions got permanent ids');
set role authenticated;
reset role;
select t5.ok(not exists (select 1 from public.questions q join public.lessons l on l.id = q.lesson_id
                          where l.title = 'Holiday words' and q.type = 'ordering' and q.payload -> 'items' = q.answer_key -> 'order'),
             'new ordering question is shuffled on the server');
set role authenticated;
reset role;
select t5.ok(not exists (select 1 from public.questions q join public.lessons l on l.id = q.lesson_id
                          where l.title = 'Holiday words'
                            and not app.grade(q.type, q.answer_key, case q.type when 'ordering' then q.answer_key -> 'order'
                                                                              else q.answer_key -> 'map' end)),
             'new questions grade their right answers');
set role authenticated;

-- learners keep XP; archived lesson stays out of the course map; history keeps its title
select t5.login('00000000-0000-0000-0000-00000000000a', 'parent@example.com');
select t5.ok((profile_wallet((select v::uuid from t5.vars where k='omar')) ->> 'xp') = (select v from t5.vars where k='xp_before'),
             'XP unchanged after publishing');
select t5.ok(not exists (select 1 from jsonb_array_elements(course_map((select v::uuid from t5.vars where k='omar'))) c,
                           jsonb_array_elements(c -> 'units') u, jsonb_array_elements(u -> 'lessons') l
                          where l ->> 'id' = 'eng-upper.u2.l2'), 'archived lesson is gone from the course map');
select t5.ok((select l ->> 'status' from jsonb_array_elements(course_map((select v::uuid from t5.vars where k='omar'))) c,
                   jsonb_array_elements(c -> 'units') u, jsonb_array_elements(u -> 'lessons') l
               where l ->> 'title' = 'Holiday words') = 'available', 'new lesson opens after the finished ones');
select t5.expect_error(format($$ select start_lesson(%L, 'eng-upper.u2.l2') $$, (select v from t5.vars where k='omar')), 'not_found');
select t5.ok((profile_report((select v::uuid from t5.vars where k='omar')) -> 'history') @> '[{"lesson":"A trip to Nizwa"}]',
             'report history still shows the archived lesson');

-- ---------------------------------------------------------------- restore an old version
select t5.login('00000000-0000-0000-0000-00000000000e', 'junaidoman09@gmail.com');
reset role;
update t5.vars set v = jsonb_set(v::jsonb, '{title}', '"English 5+ (v2)"')::text where k = 'doc';
set role authenticated;
select t5.login('00000000-0000-0000-0000-00000000000e', 'junaidoman09@gmail.com');
select cms_save_draft('eng-upper', (cms_get_course('eng-upper') -> 'doc') || '{"title":"English 5+ (v2)"}');
select cms_publish('eng-upper', 'rename');
reset role;
select t5.ok((select title from public.courses where id = 'eng-upper') = 'English 5+ (v2)', 'version 2 live');
set role authenticated;
select cms_restore_version('eng-upper', 1);
select t5.ok((cms_publish('eng-upper', 'back to v1') ->> 'version')::int = 3, 'restoring v1 publishes as version 3');
reset role;
select t5.ok((select title from public.courses where id = 'eng-upper') = 'English - Grades 5+', 'old title is back');
set role authenticated;
select t5.ok(jsonb_array_length(cms_get_course('eng-upper') -> 'versions') = 3, 'three versions listed');

-- ---------------------------------------------------------------- a brand-new course
select cms_save_skill('eng.vocab.holidays', 'Holiday vocabulary', 'eng');
select t5.expect_error($$ select cms_save_skill('Bad Code', 'x', 'eng') $$, 'bad_skill_code');
select cms_save_draft('eng-extra', jsonb_build_object(
  'id', 'eng-extra', 'subject', 'english', 'title', 'Extra reading', 'level_label', 'Grade 6', 'audience', 'child',
  'grade_min', 6, 'grade_max', 6, 'position', 6, 'published', true,
  'units', jsonb_build_array(jsonb_build_object('title', 'Holidays', 'lessons', jsonb_build_array(
    jsonb_build_object('title', 'At the beach', 'minutes', 8, 'questions', jsonb_build_array(
      jsonb_build_object('type', 'multiple_choice', 'skill', 'eng.vocab.holidays', 'prompt', 'We swim in the ...',
                         'options', jsonb_build_array('sea', 'sky', 'sand'), 'answer', 0),
      jsonb_build_object('type', 'word_problem', 'skill', 'eng.vocab.holidays', 'prompt', 'How many days in a week?', 'answer', 7, 'unit', 'days'),
      jsonb_build_object('type', 'fill_blank', 'skill', 'eng.vocab.holidays', 'prompt', 'Complete.', 'before', 'I wear ', 'after', ' on my head.',
                         'accepted', jsonb_build_array('a hat', 'hat')))))))));
select t5.ok((cms_publish('eng-extra') ->> 'ok')::boolean, 'new course published');
reset role;
select t5.ok((select correct_text from public.questions q join public.lessons l on l.id = q.lesson_id
               where l.course_id = 'eng-extra' and q.type = 'word_problem') = '7 days', 'answer text built from number + unit');
set role authenticated;

select t5.login('00000000-0000-0000-0000-00000000000a', 'parent@example.com');
select t5.ok((select array_agg(c ->> 'id' order by c ->> 'id') from jsonb_array_elements(course_map((select v::uuid from t5.vars where k='omar'))) c)
             = array['eng-extra', 'eng-upper', 'math-upper'], 'Omar (grade 6) sees the new course');

-- hide a course
select t5.login('00000000-0000-0000-0000-00000000000e', 'junaidoman09@gmail.com');
select cms_save_draft('eng-extra', (cms_get_course('eng-extra') -> 'doc') || '{"published": false}');
select cms_publish('eng-extra', 'hide');
select t5.login('00000000-0000-0000-0000-00000000000a', 'parent@example.com');
select t5.ok(not exists (select 1 from jsonb_array_elements(course_map((select v::uuid from t5.vars where k='omar'))) c where c ->> 'id' = 'eng-extra'),
             'an unpublished course disappears for learners');

reset role;
set role anon;
select t5.expect_error($$ select cms_list_courses() $$, 'permission denied for function cms_list_courses');
reset role;

\echo 'ALL PHASE 5 DATABASE TESTS PASSED'
