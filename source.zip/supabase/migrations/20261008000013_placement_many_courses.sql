-- ============================================================================
--  Family Learn - placement test with many courses (after the Term-1 books, 0012).
--
--  With 5-8 courses per child the Phase 6 placement test grew to 40+ questions.
--  Now it stays short (at most 20 questions):
--    * only courses the child has not started yet (no finished lesson in them);
--      if every course is started, all courses are used as before
--    * 2 checkpoints per course (a third and two thirds of the way; one in the
--      middle for short courses), 2 questions each, in course order
--    * courses that do not fit in 20 questions are left out (they start at lesson 1;
--      the child can take the test again later)
--  Safe to run more than once. Nothing else changes.
-- ============================================================================

create or replace function public.start_placement(p_profile uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  ids      text[] := '{}';
  c_ids    text[];
  c        record;
  n        int;
  k        int;
  pos      int;
  lid      text;
  qs       text[];
  course_q text[];
  used     int[];
  sid      uuid;
begin
  perform app.require_profile(p_profile);

  delete from public.practice_sessions s
   where s.profile_id = p_profile and s.kind = 'placement' and s.finished_at is null;

  -- courses not started yet; all courses when every one is started
  select array_agg(x.id order by x.position, x.id) into c_ids
    from app.courses_for(p_profile) x
   where not exists (select 1 from public.lesson_attempts a join public.lessons l on l.id = a.lesson_id
                      where a.profile_id = p_profile and a.finished_at is not null and l.course_id = x.id);
  if c_ids is null then
    select array_agg(x.id order by x.position, x.id) into c_ids from app.courses_for(p_profile) x;
  end if;

  for c in select co.id from public.courses co join unnest(coalesce(c_ids, '{}')) with ordinality u(id, o) on u.id = co.id
           order by u.o loop
    select count(*) into n from public.lessons where course_id = c.id and not archived;
    if n < 2 then continue; end if;
    used := '{}';
    course_q := '{}';
    foreach k in array case when n >= 6 then array[1, 2] else array[0] end loop
      pos := case when k = 0 then greatest(1, round(n / 2.0)::int) else greatest(1, round(n * k / 3.0)::int) end;
      if pos = any(used) then continue; end if;
      used := used || pos;
      select l.id into lid from public.lessons l
       where l.course_id = c.id and not l.archived
       order by l.position offset pos - 1 limit 1;
      select array_agg(id order by position) into qs
        from (select q.id, q.position from public.questions q
               where q.lesson_id = lid and not q.archived and q.type not in ('speaking', 'listening')
               order by q.position limit 2) x;
      if qs is not null then course_q := course_q || qs; end if;
    end loop;
    if coalesce(array_length(ids, 1), 0) + coalesce(array_length(course_q, 1), 0) > 20 then
      exit when coalesce(array_length(ids, 1), 0) > 0;
    end if;
    ids := ids || course_q;
  end loop;

  if coalesce(array_length(ids, 1), 0) = 0 then perform app.fail('not_found'); end if;

  insert into public.practice_sessions (profile_id, kind, started_by, question_ids)
  values (p_profile, 'placement', auth.uid(), ids) returning id into sid;

  return jsonb_build_object('session_id', sid, 'kind', 'placement', 'questions', app.session_questions(ids));
end $$;

revoke all on function public.start_placement(uuid) from public, anon;
grant execute on function public.start_placement(uuid) to authenticated;

notify pgrst, 'reload schema';
