-- ============================================================================
--  Family Learn - Speaking game ("Say it!")
--   speak_levels -> speak_words      (content: words from the school books)
--   speak_attempts, speak_plays      (each child's own progress)
--
--  Needs Phases 3-4. Safe to run again: content is replaced, progress is kept.
--  Rules enforced here:
--   * a child's phone reads and writes only its own profile's game progress;
--   * the parent account can see every profile in the family;
--   * a level opens only after the previous level of the same track is finished;
--   * points per play are capped (the app cannot send huge numbers).
-- ============================================================================

create table if not exists public.speak_levels (
  id          text primary key,
  track       text not null check (track in ('young', 'older', 'adult')),
  sort        int  not null,
  title       text not null,
  title_ar    text not null default '',
  emoji       text not null default '⭐',
  strictness  numeric(3,2) not null default 0.75 check (strictness between 0.5 and 0.98),
  source      text not null default '',
  published   boolean not null default true
);

create table if not exists public.speak_words (
  id          bigint generated always as identity primary key,
  level_id    text not null references public.speak_levels (id) on delete cascade,
  sort        int  not null,
  text        text not null check (char_length(btrim(text)) between 1 and 80),
  emoji       text not null default '',
  meaning_ar  text not null default '',
  hint        text not null default '',
  accept      text[] not null default '{}'
);
create index if not exists speak_words_level on public.speak_words (level_id, sort);

create table if not exists public.speak_attempts (
  id          bigint generated always as identity primary key,
  profile_id  uuid not null references public.profiles (id) on delete cascade,
  level_id    text not null,
  word        text not null,
  heard       text not null default '',
  score       numeric(4,3) not null default 0,
  result      text not null check (result in ('correct', 'close', 'wrong', 'unclear')),
  try_no      int  not null default 1,
  created_at  timestamptz not null default now()
);
create index if not exists speak_attempts_profile on public.speak_attempts (profile_id, created_at desc);

create table if not exists public.speak_plays (
  id          bigint generated always as identity primary key,
  profile_id  uuid not null references public.profiles (id) on delete cascade,
  level_id    text not null references public.speak_levels (id) on delete cascade,
  points      int  not null check (points >= 0),
  stars       int  not null check (stars between 1 and 3),
  words       int  not null,
  first_try   int  not null,
  attempts    int  not null,
  created_at  timestamptz not null default now()
);
create index if not exists speak_plays_profile on public.speak_plays (profile_id, created_at desc);

-- Nothing is readable or writable directly; the app uses the functions below.
alter table public.speak_levels   enable row level security;
alter table public.speak_words    enable row level security;
alter table public.speak_attempts enable row level security;
alter table public.speak_plays    enable row level security;
revoke all on public.speak_levels, public.speak_words, public.speak_attempts, public.speak_plays from anon, authenticated;

-- ---------------------------------------------------------------- helpers
create or replace function app.speak_track(p_profile uuid) returns text
language sql stable security definer set search_path = '' as $$
  select case when p.kind <> 'child' then 'adult'
              when coalesce(p.grade, 3) <= 4 then 'young'
              else 'older' end
    from public.profiles p where p.id = p_profile
$$;

create or replace function app.speak_level_unlocked(p_profile uuid, p_level text) returns boolean
language sql stable security definer set search_path = '' as $$
  with me as (select * from public.speak_levels where id = p_level and published),
       prev as (
         select l.id from public.speak_levels l, me
          where l.track = me.track and l.published and l.sort < me.sort
          order by l.sort desc limit 1)
  select exists (select 1 from me)
     and (not exists (select 1 from prev)
          or exists (select 1 from public.speak_plays sp, prev
                      where sp.profile_id = p_profile and sp.level_id = prev.id))
$$;

revoke all on function app.speak_track(uuid) from public, anon;
revoke all on function app.speak_level_unlocked(uuid, text) from public, anon;
grant execute on function app.speak_track(uuid) to authenticated;
grant execute on function app.speak_level_unlocked(uuid, text) to authenticated;

-- ---------------------------------------------------------------- API (RPC)

-- Levels (with words) for the profile's track, its progress and totals.
create or replace function public.speak_game_state(p_profile uuid) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  v_track text;
  tz      text;
  today   date;
  v_levels jsonb;
  v_streak int := 0;
  d       date;
begin
  perform app.require_profile(p_profile);
  v_track := app.speak_track(p_profile);
  tz := app.profile_tz(p_profile);
  today := (now() at time zone tz)::date;

  select coalesce(jsonb_agg(x.j order by x.sort), '[]'::jsonb) into v_levels
    from (
      select l.sort, jsonb_build_object(
               'id', l.id, 'title', l.title, 'title_ar', l.title_ar, 'emoji', l.emoji,
               'strictness', l.strictness, 'source', l.source,
               'best_stars', coalesce((select max(stars) from public.speak_plays sp
                                        where sp.profile_id = p_profile and sp.level_id = l.id), 0),
               'plays', (select count(*) from public.speak_plays sp
                          where sp.profile_id = p_profile and sp.level_id = l.id),
               'unlocked', app.speak_level_unlocked(p_profile, l.id),
               'words', (select coalesce(jsonb_agg(jsonb_build_object(
                                  'text', w.text, 'emoji', w.emoji, 'meaning_ar', w.meaning_ar,
                                  'hint', w.hint, 'accept', to_jsonb(w.accept)) order by w.sort), '[]'::jsonb)
                           from public.speak_words w where w.level_id = l.id)) j
        from public.speak_levels l
       where l.track = v_track and l.published) x;

  -- days in a row with a finished level, ending today or yesterday
  select max((created_at at time zone tz)::date) into d from public.speak_plays where profile_id = p_profile;
  if d is not null and d >= today - 1 then
    while exists (select 1 from public.speak_plays where profile_id = p_profile
                   and (created_at at time zone tz)::date = d) loop
      v_streak := v_streak + 1;
      d := d - 1;
    end loop;
  end if;

  return jsonb_build_object(
    'track', v_track,
    'levels', v_levels,
    'points', (select coalesce(sum(points), 0) from public.speak_plays where profile_id = p_profile),
    'points_today', (select coalesce(sum(points), 0) from public.speak_plays
                      where profile_id = p_profile and (created_at at time zone tz)::date = today),
    'words_mastered', (select count(distinct lower(word)) from public.speak_attempts
                        where profile_id = p_profile and result = 'correct'),
    'day_streak', v_streak,
    'last_played', (select max(created_at) from public.speak_plays where profile_id = p_profile),
    'tricky', (select coalesce(jsonb_agg(jsonb_build_object('word', t.word, 'misses', t.n) order by t.n desc), '[]'::jsonb)
                 from (select word, count(*) n from public.speak_attempts
                        where profile_id = p_profile and result in ('close', 'wrong')
                          and created_at > now() - interval '14 days'
                        group by word order by count(*) desc limit 6) t));
end $$;

-- One try on one word (unclear tries are logged too, for the parent).
create or replace function public.speak_record_attempt(
  p_profile uuid, p_level text, p_word text, p_heard text, p_score numeric, p_result text, p_try int
) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform app.require_profile(p_profile);
  if not exists (select 1 from public.speak_words where level_id = p_level and text = p_word) then
    perform app.fail('not_found');
  end if;
  if p_result not in ('correct', 'close', 'wrong', 'unclear') then perform app.fail('unknown'); end if;
  -- simple flood guard: at most 40 tries a minute per profile
  if (select count(*) from public.speak_attempts
       where profile_id = p_profile and created_at > now() - interval '1 minute') >= 40 then
    perform app.fail('rate_limited');
  end if;
  insert into public.speak_attempts (profile_id, level_id, word, heard, score, result, try_no)
  values (p_profile, p_level, p_word, left(coalesce(p_heard, ''), 200),
          least(greatest(coalesce(p_score, 0), 0), 1), p_result, greatest(coalesce(p_try, 1), 1));
end $$;

-- A level played to the end. Returns the new state.
create or replace function public.speak_finish_level(
  p_profile uuid, p_level text, p_points int, p_stars int, p_words int, p_first_try int, p_attempts int
) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_words int;
begin
  perform app.require_profile(p_profile);
  if not exists (select 1 from public.speak_levels
                  where id = p_level and published and track = app.speak_track(p_profile)) then
    perform app.fail('not_found');
  end if;
  if not app.speak_level_unlocked(p_profile, p_level) then perform app.fail('lesson_locked'); end if;
  select count(*) into v_words from public.speak_words where level_id = p_level;
  insert into public.speak_plays (profile_id, level_id, points, stars, words, first_try, attempts)
  values (p_profile, p_level,
          least(greatest(coalesce(p_points, 0), 0), v_words * 30 + 50),
          least(greatest(coalesce(p_stars, 1), 1), 3),
          v_words,
          least(greatest(coalesce(p_first_try, 0), 0), v_words),
          greatest(coalesce(p_attempts, 0), 0));
  return public.speak_game_state(p_profile);
end $$;

revoke all on function public.speak_game_state(uuid) from public, anon;
revoke all on function public.speak_record_attempt(uuid, text, text, text, numeric, text, int) from public, anon;
revoke all on function public.speak_finish_level(uuid, text, int, int, int, int, int) from public, anon;
grant execute on function public.speak_game_state(uuid) to authenticated;
grant execute on function public.speak_record_attempt(uuid, text, text, text, numeric, text, int) to authenticated;
grant execute on function public.speak_finish_level(uuid, text, int, int, int, int, int) to authenticated;

-- ---------------------------------------------------------------- content
-- Replaced on every run (progress rows keep their level ids).
do $$
declare
  lv jsonb;
  wd jsonb;
  i  int;
  data jsonb := $json$[{"id":"y1-sounds","track":"young","sort":10,"title":"Sounds: st, sl, tr, gr","title_ar":"أصوات: st, sl, tr, gr","emoji":"🚂","strictness":0.8,"source":"English P3 - Unit 1: Sounds sl, st, gr, tr","words":[{"text":"stop","emoji":"🛑","meaning_ar":"قِف","hint":"","accept":[]},{"text":"star","emoji":"⭐","meaning_ar":"نجمة","hint":"","accept":[]},{"text":"step","emoji":"👣","meaning_ar":"خطوة","hint":"","accept":[]},{"text":"slow","emoji":"🐢","meaning_ar":"بطيء","hint":"","accept":[]},{"text":"sleep","emoji":"😴","meaning_ar":"ينام","hint":"","accept":[]},{"text":"train","emoji":"🚆","meaning_ar":"قطار","hint":"","accept":[]},{"text":"truck","emoji":"🚚","meaning_ar":"شاحنة","hint":"","accept":["trucks"]},{"text":"green","emoji":"🟢","meaning_ar":"أخضر","hint":"","accept":[]}]},
{"id":"y2-safety","track":"young","sort":20,"title":"Safety","title_ar":"السلامة","emoji":"⛑️","strictness":0.8,"source":"English P3 - Unit 1: Safety","words":[{"text":"helmet","emoji":"⛑️","meaning_ar":"خوذة","hint":"hel-met","accept":[]},{"text":"careful","emoji":"⚠️","meaning_ar":"حذِر","hint":"care-ful","accept":[]},{"text":"sign","emoji":"🪧","meaning_ar":"إشارة","hint":"","accept":["sine"]},{"text":"stranger","emoji":"🧍","meaning_ar":"شخص غريب","hint":"stran-ger","accept":[]},{"text":"ambulance","emoji":"🚑","meaning_ar":"سيارة إسعاف","hint":"am-bu-lance","accept":[]},{"text":"seat belt","emoji":"🚗","meaning_ar":"حزام الأمان","hint":"seat - belt","accept":["seatbelt"]},{"text":"dangerous","emoji":"⚡","meaning_ar":"خطير","hint":"dan-ger-ous","accept":[]},{"text":"emergency","emoji":"🚨","meaning_ar":"طوارئ","hint":"e-mer-gen-cy","accept":[]}]},
{"id":"y3-food","track":"young","sort":30,"title":"Food and health","title_ar":"الطعام والصحة","emoji":"🍎","strictness":0.8,"source":"English P3 - Unit 2: Food and Health","words":[{"text":"apple","emoji":"🍎","meaning_ar":"تفاحة","hint":"ap-ple","accept":[]},{"text":"milk","emoji":"🥛","meaning_ar":"حليب","hint":"","accept":[]},{"text":"rice","emoji":"🍚","meaning_ar":"أرز","hint":"","accept":[]},{"text":"water","emoji":"💧","meaning_ar":"ماء","hint":"wa-ter","accept":[]},{"text":"breakfast","emoji":"🍳","meaning_ar":"الفطور","hint":"break-fast","accept":[]},{"text":"lunch","emoji":"🥪","meaning_ar":"الغداء","hint":"","accept":[]},{"text":"dinner","emoji":"🍽️","meaning_ar":"العشاء","hint":"din-ner","accept":[]},{"text":"vegetables","emoji":"🥦","meaning_ar":"خضروات","hint":"veg-e-ta-bles","accept":["vegetable"]}]},
{"id":"y4-magic-e","track":"young","sort":40,"title":"Magic e: cap or cape?","title_ar":"حرف e السحري","emoji":"🪄","strictness":0.93,"source":"English P3 - Unit 3: Magic e","words":[{"text":"cap","emoji":"🧢","meaning_ar":"قبعة","hint":"","accept":[]},{"text":"cape","emoji":"🦸","meaning_ar":"عباءة","hint":"c-a-pe (a says its name)","accept":[]},{"text":"hop","emoji":"🐇","meaning_ar":"يقفز","hint":"","accept":[]},{"text":"hope","emoji":"🙏","meaning_ar":"أمل","hint":"h-o-pe (o says its name)","accept":[]},{"text":"kit","emoji":"🧰","meaning_ar":"عُدّة","hint":"","accept":[]},{"text":"kite","emoji":"🪁","meaning_ar":"طائرة ورقية","hint":"k-i-te (i says its name)","accept":[]},{"text":"cub","emoji":"🐻","meaning_ar":"شبل / صغير الدب","hint":"","accept":["cubs"]},{"text":"cube","emoji":"🧊","meaning_ar":"مكعب","hint":"c-u-be (u says its name)","accept":[]}]},
{"id":"y5-heroes","track":"young","sort":50,"title":"Heroes around us","title_ar":"أبطال حولنا","emoji":"🚒","strictness":0.8,"source":"English P3 - Unit 3: Heroes Around Us","words":[{"text":"firefighter","emoji":"👩‍🚒","meaning_ar":"رجل إطفاء","hint":"fire-fight-er","accept":["fire fighter","firefighters"]},{"text":"pilot","emoji":"👨‍✈️","meaning_ar":"طيار","hint":"pi-lot","accept":[]},{"text":"teacher","emoji":"👩‍🏫","meaning_ar":"معلم","hint":"tea-cher","accept":[]},{"text":"chef","emoji":"👨‍🍳","meaning_ar":"طاهٍ","hint":"","accept":["shef"]},{"text":"brave","emoji":"🦁","meaning_ar":"شجاع","hint":"","accept":[]},{"text":"ladder","emoji":"🪜","meaning_ar":"سلّم","hint":"lad-der","accept":[]},{"text":"medal","emoji":"🏅","meaning_ar":"ميدالية","hint":"med-al","accept":["metal"]},{"text":"uniform","emoji":"🦺","meaning_ar":"زي موحد","hint":"u-ni-form","accept":[]}]},
{"id":"y6-tech","track":"young","sort":60,"title":"Technology","title_ar":"التكنولوجيا","emoji":"🤖","strictness":0.8,"source":"English P3 - Unit 4: Living with Technology","words":[{"text":"phone","emoji":"📱","meaning_ar":"هاتف","hint":"","accept":[]},{"text":"robot","emoji":"🤖","meaning_ar":"روبوت","hint":"ro-bot","accept":[]},{"text":"camera","emoji":"📷","meaning_ar":"كاميرا","hint":"cam-er-a","accept":[]},{"text":"tablet","emoji":"📲","meaning_ar":"جهاز لوحي","hint":"tab-let","accept":[]},{"text":"screen","emoji":"🖥️","meaning_ar":"شاشة","hint":"","accept":[]},{"text":"keyboard","emoji":"⌨️","meaning_ar":"لوحة المفاتيح","hint":"key-board","accept":["key board"]},{"text":"button","emoji":"🔘","meaning_ar":"زر","hint":"but-ton","accept":[]},{"text":"password","emoji":"🔑","meaning_ar":"كلمة المرور","hint":"pass-word","accept":["pass word"]}]},
{"id":"y7-animals","track":"young","sort":70,"title":"Animals and habitats","title_ar":"الحيوانات وبيئاتها","emoji":"🐪","strictness":0.8,"source":"English P3 - Unit 5: Animals and Habitats","words":[{"text":"camel","emoji":"🐪","meaning_ar":"جمل","hint":"cam-el","accept":[]},{"text":"monkey","emoji":"🐒","meaning_ar":"قرد","hint":"mon-key","accept":[]},{"text":"fish","emoji":"🐟","meaning_ar":"سمكة","hint":"","accept":[]},{"text":"owl","emoji":"🦉","meaning_ar":"بومة","hint":"","accept":[]},{"text":"polar bear","emoji":"🐻‍❄️","meaning_ar":"دب قطبي","hint":"po-lar bear","accept":["polarbear"]},{"text":"feathers","emoji":"🪶","meaning_ar":"ريش","hint":"feath-ers","accept":["feather"]},{"text":"fur","emoji":"🧸","meaning_ar":"فرو","hint":"","accept":["fir"]},{"text":"claws","emoji":"🐾","meaning_ar":"مخالب","hint":"","accept":["claw","clause"]}]},
{"id":"y8-actions","track":"young","sort":80,"title":"I can... (action words)","title_ar":"أستطيع... (أفعال)","emoji":"🤸","strictness":0.8,"source":"English P3 - Unit 5: can / can't","words":[{"text":"fly","emoji":"🕊️","meaning_ar":"يطير","hint":"","accept":[]},{"text":"jump","emoji":"🦘","meaning_ar":"يقفز","hint":"","accept":[]},{"text":"crawl","emoji":"🐛","meaning_ar":"يزحف","hint":"","accept":[]},{"text":"swim","emoji":"🏊","meaning_ar":"يسبح","hint":"","accept":[]},{"text":"climb","emoji":"🧗","meaning_ar":"يتسلق","hint":"","accept":["clime"]},{"text":"run","emoji":"🏃","meaning_ar":"يجري","hint":"","accept":[]}]},
{"id":"y9-feelings","track":"young","sort":90,"title":"Feelings (story)","title_ar":"المشاعر (القصة)","emoji":"😊","strictness":0.8,"source":"English P3 - Unit 6: The Honest Choice","words":[{"text":"happy","emoji":"😀","meaning_ar":"سعيد","hint":"hap-py","accept":[]},{"text":"angry","emoji":"😠","meaning_ar":"غاضب","hint":"an-gry","accept":[]},{"text":"sleepy","emoji":"😴","meaning_ar":"نعسان","hint":"sleep-y","accept":[]},{"text":"nervous","emoji":"😬","meaning_ar":"متوتر","hint":"ner-vous","accept":[]},{"text":"honest","emoji":"🤝","meaning_ar":"صادق","hint":"hon-est (h is silent)","accept":[]},{"text":"whisper","emoji":"🤫","meaning_ar":"يهمس","hint":"whis-per","accept":[]}]},
{"id":"y10-math","track":"young","sort":100,"title":"Math words","title_ar":"كلمات الرياضيات","emoji":"➗","strictness":0.8,"source":"Math P3 - Chapters 1-10","words":[{"text":"multiply","emoji":"✖️","meaning_ar":"يضرب","hint":"mul-ti-ply","accept":[]},{"text":"divide","emoji":"➗","meaning_ar":"يقسم","hint":"di-vide","accept":[]},{"text":"hour","emoji":"⏰","meaning_ar":"ساعة","hint":"our (h is silent)","accept":["our"]},{"text":"minute","emoji":"⏱️","meaning_ar":"دقيقة","hint":"min-ute","accept":["minutes"]},{"text":"remainder","emoji":"🧮","meaning_ar":"الباقي","hint":"re-main-der","accept":[]},{"text":"kilometre","emoji":"🛣️","meaning_ar":"كيلومتر","hint":"ki-lo-me-tre","accept":["kilometer","kilometers","kilometres"]},{"text":"graph","emoji":"📊","meaning_ar":"رسم بياني","hint":"","accept":["graf"]},{"text":"ten thousand","emoji":"🔟","meaning_ar":"عشرة آلاف","hint":"","accept":["10000"]}]},
{"id":"y11-sentences","track":"young","sort":110,"title":"Short sentences","title_ar":"جمل قصيرة","emoji":"💬","strictness":0.8,"source":"English P3 - Units 1, 2, 6","words":[{"text":"Be careful","emoji":"⚠️","meaning_ar":"كن حذراً","hint":"","accept":[]},{"text":"Don't run","emoji":"🚫🏃","meaning_ar":"لا تجرِ","hint":"","accept":["do not run"]},{"text":"Wait here","emoji":"✋","meaning_ar":"انتظر هنا","hint":"","accept":[]},{"text":"I did it myself","emoji":"💪","meaning_ar":"فعلتها بنفسي","hint":"","accept":[]},{"text":"I can jump","emoji":"🦘","meaning_ar":"أستطيع أن أقفز","hint":"","accept":[]},{"text":"Always tell the truth","emoji":"🤝","meaning_ar":"قل الحقيقة دائماً","hint":"","accept":[]}]},
{"id":"o1-art","track":"older","sort":10,"title":"Celebrating creativity","title_ar":"الاحتفاء بالإبداع","emoji":"🎨","strictness":0.84,"source":"English P6 - Unit 1: Celebrating Creativity","words":[{"text":"canvas","emoji":"🖼️","meaning_ar":"قماش الرسم","hint":"can-vas","accept":["canvass"]},{"text":"gallery","emoji":"🏛️","meaning_ar":"معرض","hint":"gal-le-ry","accept":[]},{"text":"sketch","emoji":"✏️","meaning_ar":"رسم تخطيطي","hint":"","accept":[]},{"text":"mural","emoji":"🧱","meaning_ar":"لوحة جدارية","hint":"mu-ral","accept":[]},{"text":"palette","emoji":"🎨","meaning_ar":"لوحة الألوان","hint":"pal-ette","accept":["pallet"]},{"text":"sculpture","emoji":"🗿","meaning_ar":"منحوتة","hint":"sculp-ture","accept":[]},{"text":"sculptor","emoji":"🧑‍🎨","meaning_ar":"نحّات","hint":"sculp-tor","accept":[]},{"text":"masterpiece","emoji":"🌟","meaning_ar":"تحفة فنية","hint":"mas-ter-piece","accept":["master piece"]}]},
{"id":"o2-inventions","track":"older","sort":20,"title":"Wonderful inventions","title_ar":"اختراعات رائعة","emoji":"💡","strictness":0.84,"source":"English P6 - Unit 2: Wonderful Inventions","words":[{"text":"gadget","emoji":"📟","meaning_ar":"أداة / جهاز صغير","hint":"gad-get","accept":[]},{"text":"fabric","emoji":"🧵","meaning_ar":"قماش","hint":"fab-ric","accept":[]},{"text":"thread","emoji":"🪡","meaning_ar":"خيط","hint":"","accept":[]},{"text":"blueprint","emoji":"📐","meaning_ar":"مخطط","hint":"blue-print","accept":["blue print"]},{"text":"accurate","emoji":"🎯","meaning_ar":"دقيق","hint":"ac-cu-rate","accept":[]},{"text":"assemble","emoji":"🔧","meaning_ar":"يُجمِّع","hint":"as-sem-ble","accept":[]},{"text":"rebuild","emoji":"🏗️","meaning_ar":"يعيد البناء","hint":"re-build","accept":["re build"]},{"text":"unhappy","emoji":"🙁","meaning_ar":"غير سعيد","hint":"un-hap-py","accept":[]}]},
{"id":"o3-egypt","track":"older","sort":30,"title":"Hidden gems of Egypt","title_ar":"كنوز مصر الخفية","emoji":"🏺","strictness":0.84,"source":"English P6 - Unit 3: Hidden Gems of Egypt","words":[{"text":"mummy","emoji":"🧟","meaning_ar":"مومياء","hint":"mum-my","accept":[]},{"text":"monument","emoji":"🗿","meaning_ar":"أثر / نُصب","hint":"mon-u-ment","accept":[]},{"text":"chamber","emoji":"🚪","meaning_ar":"حجرة","hint":"cham-ber","accept":[]},{"text":"ruler","emoji":"👑","meaning_ar":"حاكم","hint":"rul-er","accept":[]},{"text":"discover","emoji":"🔍","meaning_ar":"يكتشف","hint":"dis-cov-er","accept":[]},{"text":"restore","emoji":"🛠️","meaning_ar":"يرمّم","hint":"re-store","accept":[]},{"text":"craftsman","emoji":"🔨","meaning_ar":"حِرفي","hint":"crafts-man","accept":["craftsmen"]},{"text":"archaeologist","emoji":"⛏️","meaning_ar":"عالم آثار","hint":"ar-chae-ol-o-gist","accept":["archeologist"]}]},
{"id":"o4-industry","track":"older","sort":40,"title":"Egypt on the move","title_ar":"مصر تتحرك","emoji":"🏭","strictness":0.84,"source":"English P6 - Unit 4: Egypt on the Move","words":[{"text":"steel","emoji":"🔩","meaning_ar":"فولاذ","hint":"","accept":["steal"]},{"text":"textile","emoji":"🧶","meaning_ar":"نسيج","hint":"tex-tile","accept":[]},{"text":"highway","emoji":"🛣️","meaning_ar":"طريق سريع","hint":"high-way","accept":["high way"]},{"text":"border","emoji":"🗺️","meaning_ar":"حدود","hint":"bor-der","accept":["boarder"]},{"text":"innovation","emoji":"🚀","meaning_ar":"ابتكار","hint":"in-no-va-tion","accept":[]},{"text":"manufacture","emoji":"🏭","meaning_ar":"يصنّع","hint":"man-u-fac-ture","accept":[]},{"text":"infrastructure","emoji":"🌉","meaning_ar":"البنية التحتية","hint":"in-fra-struc-ture","accept":[]},{"text":"self-reliant","emoji":"💪","meaning_ar":"معتمد على نفسه","hint":"self - re-li-ant","accept":["self reliant"]}]},
{"id":"o5-transport","track":"older","sort":50,"title":"Smart transportation","title_ar":"النقل الذكي","emoji":"🚝","strictness":0.84,"source":"English P6 - Unit 5: Smart Transportation","words":[{"text":"monorail","emoji":"🚝","meaning_ar":"قطار أحادي","hint":"mon-o-rail","accept":["mono rail"]},{"text":"escalator","emoji":"🛗","meaning_ar":"سلم متحرك","hint":"es-ca-la-tor","accept":[]},{"text":"ticket machine","emoji":"🎫","meaning_ar":"آلة التذاكر","hint":"tick-et ma-chine","accept":[]},{"text":"pollution","emoji":"🏭","meaning_ar":"تلوث","hint":"pol-lu-tion","accept":[]},{"text":"digital","emoji":"💻","meaning_ar":"رقمي","hint":"dig-i-tal","accept":[]},{"text":"renewable","emoji":"♻️","meaning_ar":"متجدد","hint":"re-new-a-ble","accept":[]},{"text":"eco-friendly","emoji":"🌱","meaning_ar":"صديق للبيئة","hint":"e-co friend-ly","accept":["eco friendly"]},{"text":"self-driving","emoji":"🚘","meaning_ar":"ذاتي القيادة","hint":"self driv-ing","accept":["self driving"]}]},
{"id":"o6-library","track":"older","sort":60,"title":"The library that time forgot","title_ar":"المكتبة المنسية","emoji":"📚","strictness":0.84,"source":"English P6 - Unit 6: The Library That Time Forgot","words":[{"text":"library","emoji":"📚","meaning_ar":"مكتبة","hint":"li-brar-y","accept":[]},{"text":"treasure","emoji":"💰","meaning_ar":"كنز","hint":"trea-sure","accept":[]},{"text":"fountain","emoji":"⛲","meaning_ar":"نافورة","hint":"foun-tain","accept":[]},{"text":"rusty","emoji":"🔧","meaning_ar":"صدئ","hint":"rust-y","accept":[]},{"text":"clogged","emoji":"🚱","meaning_ar":"مسدود","hint":"","accept":["clogs"]},{"text":"creaked","emoji":"🚪","meaning_ar":"صرّ / أصدر صريراً","hint":"","accept":["creeked"]},{"text":"stacks","emoji":"📚","meaning_ar":"أكوام","hint":"","accept":["stax"]},{"text":"mayor","emoji":"🎩","meaning_ar":"عمدة","hint":"","accept":["mare","mayer"]}]},
{"id":"o7-math","track":"older","sort":70,"title":"Math words","title_ar":"كلمات الرياضيات","emoji":"📐","strictness":0.84,"source":"Math P6 - Units 8-13","words":[{"text":"fraction","emoji":"½","meaning_ar":"كسر","hint":"frac-tion","accept":[]},{"text":"decimal","emoji":"🔢","meaning_ar":"عدد عشري","hint":"dec-i-mal","accept":[]},{"text":"ratio","emoji":"⚖️","meaning_ar":"نسبة","hint":"ra-ti-o","accept":[]},{"text":"percent","emoji":"💯","meaning_ar":"نسبة مئوية","hint":"per-cent","accept":["per cent"]},{"text":"unit rate","emoji":"🏷️","meaning_ar":"معدل الوحدة","hint":"u-nit rate","accept":[]},{"text":"coordinates","emoji":"📍","meaning_ar":"إحداثيات","hint":"co-or-di-nates","accept":["coordinate"]},{"text":"polygon","emoji":"🔷","meaning_ar":"مضلع","hint":"pol-y-gon","accept":[]},{"text":"volume","emoji":"🧊","meaning_ar":"الحجم","hint":"vol-ume","accept":[]}]},
{"id":"o8-sentences","track":"older","sort":80,"title":"Grammar sentences","title_ar":"جمل القواعد","emoji":"💬","strictness":0.8,"source":"English P6 - Units 1-6 (grammar)","words":[{"text":"Have you been to Aswan","emoji":"🏝️","meaning_ar":"هل زرت أسوان؟","hint":"","accept":[]},{"text":"We used to travel by train","emoji":"🚆","meaning_ar":"كنا نسافر بالقطار","hint":"","accept":[]},{"text":"If it rains we will stay at home","emoji":"🌧️","meaning_ar":"إذا أمطرت سنبقى في البيت","hint":"","accept":["if it rains we'll stay at home"]},{"text":"She was walking when it started to rain","emoji":"🚶‍♀️","meaning_ar":"كانت تمشي عندما بدأ المطر","hint":"","accept":[]},{"text":"The man who painted this is famous","emoji":"🧑‍🎨","meaning_ar":"الرجل الذي رسم هذه مشهور","hint":"","accept":[]},{"text":"Neither Ali nor Sara was late","emoji":"⏰","meaning_ar":"لا علي ولا سارة تأخرا","hint":"","accept":[]}]},
{"id":"a1-words","track":"adult","sort":10,"title":"Everyday English words","title_ar":"كلمات الإنجليزية اليومية","emoji":"💼","strictness":0.86,"source":"Everyday English 1","words":[{"text":"formal","emoji":"👔","meaning_ar":"رسمي","hint":"","accept":[]},{"text":"informal","emoji":"👕","meaning_ar":"غير رسمي","hint":"","accept":[]},{"text":"opinion","emoji":"💭","meaning_ar":"رأي","hint":"","accept":[]},{"text":"discussion","emoji":"🗣️","meaning_ar":"نقاش","hint":"","accept":[]},{"text":"paragraph","emoji":"📄","meaning_ar":"فقرة","hint":"","accept":[]},{"text":"punctuation","emoji":"❗","meaning_ar":"علامات الترقيم","hint":"","accept":[]},{"text":"spelling","emoji":"🔤","meaning_ar":"التهجئة","hint":"","accept":[]},{"text":"summary","emoji":"📝","meaning_ar":"ملخص","hint":"","accept":[]}]},
{"id":"a2-phrases","track":"adult","sort":20,"title":"Useful phrases","title_ar":"عبارات مفيدة","emoji":"🤝","strictness":0.82,"source":"Everyday English 1 - Speaking, Writing","words":[{"text":"Thank you for your email","emoji":"📧","meaning_ar":"شكراً على بريدك","hint":"","accept":[]},{"text":"Could you please send me the details","emoji":"📨","meaning_ar":"هل يمكنك إرسال التفاصيل من فضلك؟","hint":"","accept":[]},{"text":"In my opinion","emoji":"💭","meaning_ar":"في رأيي","hint":"","accept":[]},{"text":"I agree with you","emoji":"👍","meaning_ar":"أتفق معك","hint":"","accept":[]},{"text":"I would like to ask about the price","emoji":"💬","meaning_ar":"أود أن أسأل عن السعر","hint":"","accept":["i'd like to ask about the price"]},{"text":"Best regards","emoji":"✍️","meaning_ar":"مع أطيب التحيات","hint":"","accept":[]}]}]$json$;
begin
  update public.speak_levels set published = false;
  for lv in select * from jsonb_array_elements(data) loop
    insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published)
    values (lv->>'id', lv->>'track', (lv->>'sort')::int, lv->>'title', lv->>'title_ar', lv->>'emoji',
            (lv->>'strictness')::numeric, lv->>'source', true)
    on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title,
       title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness,
       source = excluded.source, published = true;
    delete from public.speak_words where level_id = lv->>'id';
    i := 0;
    for wd in select * from jsonb_array_elements(lv->'words') loop
      i := i + 1;
      insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept)
      values (lv->>'id', i, wd->>'text', wd->>'emoji', wd->>'meaning_ar', wd->>'hint',
              array(select jsonb_array_elements_text(wd->'accept')));
    end loop;
  end loop;
end $$;
