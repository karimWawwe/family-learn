-- ============================================================================
--  Family Learn - Speaking game ("Say it!")
--   speak_levels -> speak_words      (content: words from the school books)
--   speak_attempts, speak_plays      (each child's own progress)
--
--  Needs Phases 3-4. Safe to run again: content is replaced, progress is kept.
--  Rules enforced here:
--   * a child's phone reads and writes only its own profile's game progress;
--   * the parent account can see every profile in the family;
--   * a level opens only after the previous level of the same track is finished;
--   * points per play are capped (the app cannot send huge numbers).
-- ============================================================================

create table if not exists public.speak_levels (
  id          text primary key,
  track       text not null check (track in ('young', 'older', 'adult')),
  sort        int  not null,
  title       text not null,
  title_ar    text not null default '',
  emoji       text not null default '⭐',
  strictness  numeric(3,2) not null default 0.75 check (strictness between 0.5 and 0.98),
  source      text not null default '',
  published   boolean not null default true
);

create table if not exists public.speak_words (
  id          bigint generated always as identity primary key,
  level_id    text not null references public.speak_levels (id) on delete cascade,
  sort        int  not null,
  text        text not null check (char_length(btrim(text)) between 1 and 80),
  emoji       text not null default '',
  meaning_ar  text not null default '',
  hint        text not null default '',
  accept      text[] not null default '{}'
);
create index if not exists speak_words_level on public.speak_words (level_id, sort);

create table if not exists public.speak_attempts (
  id          bigint generated always as identity primary key,
  profile_id  uuid not null references public.profiles (id) on delete cascade,
  level_id    text not null,
  word        text not null,
  heard       text not null default '',
  score       numeric(4,3) not null default 0,
  result      text not null check (result in ('correct', 'close', 'wrong', 'unclear')),
  try_no      int  not null default 1,
  created_at  timestamptz not null default now()
);
create index if not exists speak_attempts_profile on public.speak_attempts (profile_id, created_at desc);

create table if not exists public.speak_plays (
  id          bigint generated always as identity primary key,
  profile_id  uuid not null references public.profiles (id) on delete cascade,
  level_id    text not null references public.speak_levels (id) on delete cascade,
  points      int  not null check (points >= 0),
  stars       int  not null check (stars between 1 and 3),
  words       int  not null,
  first_try   int  not null,
  attempts    int  not null,
  created_at  timestamptz not null default now()
);
create index if not exists speak_plays_profile on public.speak_plays (profile_id, created_at desc);

-- Nothing is readable or writable directly; the app uses the functions below.
alter table public.speak_levels   enable row level security;
alter table public.speak_words    enable row level security;
alter table public.speak_attempts enable row level security;
alter table public.speak_plays    enable row level security;
revoke all on public.speak_levels, public.speak_words, public.speak_attempts, public.speak_plays from anon, authenticated;

-- ---------------------------------------------------------------- helpers
create or replace function app.speak_track(p_profile uuid) returns text
language sql stable security definer set search_path = '' as $$
  select case when p.kind <> 'child' then 'adult'
              when coalesce(p.grade, 3) <= 4 then 'young'
              else 'older' end
    from public.profiles p where p.id = p_profile
$$;

create or replace function app.speak_level_unlocked(p_profile uuid, p_level text) returns boolean
language sql stable security definer set search_path = '' as $$
  with me as (select * from public.speak_levels where id = p_level and published),
       prev as (
         select l.id from public.speak_levels l, me
          where l.track = me.track and l.published and l.sort < me.sort
          order by l.sort desc limit 1)
  select exists (select 1 from me)
     and (not exists (select 1 from prev)
          or exists (select 1 from public.speak_plays sp, prev
                      where sp.profile_id = p_profile and sp.level_id = prev.id))
$$;

revoke all on function app.speak_track(uuid) from public, anon;
revoke all on function app.speak_level_unlocked(uuid, text) from public, anon;
grant execute on function app.speak_track(uuid) to authenticated;
grant execute on function app.speak_level_unlocked(uuid, text) to authenticated;

-- ---------------------------------------------------------------- API (RPC)

-- Levels (with words) for the profile's track, its progress and totals.
create or replace function public.speak_game_state(p_profile uuid) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  v_track text;
  tz      text;
  today   date;
  v_levels jsonb;
  v_streak int := 0;
  d       date;
begin
  perform app.require_profile(p_profile);
  v_track := app.speak_track(p_profile);
  tz := app.profile_tz(p_profile);
  today := (now() at time zone tz)::date;

  select coalesce(jsonb_agg(x.j order by x.sort), '[]'::jsonb) into v_levels
    from (
      select l.sort, jsonb_build_object(
               'id', l.id, 'title', l.title, 'title_ar', l.title_ar, 'emoji', l.emoji,
               'strictness', l.strictness, 'source', l.source,
               'best_stars', coalesce((select max(stars) from public.speak_plays sp
                                        where sp.profile_id = p_profile and sp.level_id = l.id), 0),
               'plays', (select count(*) from public.speak_plays sp
                          where sp.profile_id = p_profile and sp.level_id = l.id),
               'unlocked', app.speak_level_unlocked(p_profile, l.id),
               'words', (select coalesce(jsonb_agg(jsonb_build_object(
                                  'text', w.text, 'emoji', w.emoji, 'meaning_ar', w.meaning_ar,
                                  'hint', w.hint, 'accept', to_jsonb(w.accept)) order by w.sort), '[]'::jsonb)
                           from public.speak_words w where w.level_id = l.id)) j
        from public.speak_levels l
       where l.track = v_track and l.published) x;

  -- days in a row with a finished level, ending today or yesterday
  select max((created_at at time zone tz)::date) into d from public.speak_plays where profile_id = p_profile;
  if d is not null and d >= today - 1 then
    while exists (select 1 from public.speak_plays where profile_id = p_profile
                   and (created_at at time zone tz)::date = d) loop
      v_streak := v_streak + 1;
      d := d - 1;
    end loop;
  end if;

  return jsonb_build_object(
    'track', v_track,
    'levels', v_levels,
    'points', (select coalesce(sum(points), 0) from public.speak_plays where profile_id = p_profile),
    'points_today', (select coalesce(sum(points), 0) from public.speak_plays
                      where profile_id = p_profile and (created_at at time zone tz)::date = today),
    'words_mastered', (select count(distinct lower(word)) from public.speak_attempts
                        where profile_id = p_profile and result = 'correct'),
    'day_streak', v_streak,
    'last_played', (select max(created_at) from public.speak_plays where profile_id = p_profile),
    'tricky', (select coalesce(jsonb_agg(jsonb_build_object('word', t.word, 'misses', t.n) order by t.n desc), '[]'::jsonb)
                 from (select word, count(*) n from public.speak_attempts
                        where profile_id = p_profile and result in ('close', 'wrong')
                          and created_at > now() - interval '14 days'
                        group by word order by count(*) desc limit 6) t));
end $$;

-- One try on one word (unclear tries are logged too, for the parent).
create or replace function public.speak_record_attempt(
  p_profile uuid, p_level text, p_word text, p_heard text, p_score numeric, p_result text, p_try int
) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform app.require_profile(p_profile);
  if not exists (select 1 from public.speak_words where level_id = p_level and text = p_word) then
    perform app.fail('not_found');
  end if;
  if p_result not in ('correct', 'close', 'wrong', 'unclear') then perform app.fail('unknown'); end if;
  -- simple flood guard: at most 40 tries a minute per profile
  if (select count(*) from public.speak_attempts
       where profile_id = p_profile and created_at > now() - interval '1 minute') >= 40 then
    perform app.fail('rate_limited');
  end if;
  insert into public.speak_attempts (profile_id, level_id, word, heard, score, result, try_no)
  values (p_profile, p_level, p_word, left(coalesce(p_heard, ''), 200),
          least(greatest(coalesce(p_score, 0), 0), 1), p_result, greatest(coalesce(p_try, 1), 1));
end $$;

-- A level played to the end. Returns the new state.
create or replace function public.speak_finish_level(
  p_profile uuid, p_level text, p_points int, p_stars int, p_words int, p_first_try int, p_attempts int
) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_words int;
begin
  perform app.require_profile(p_profile);
  if not exists (select 1 from public.speak_levels
                  where id = p_level and published and track = app.speak_track(p_profile)) then
    perform app.fail('not_found');
  end if;
  if not app.speak_level_unlocked(p_profile, p_level) then perform app.fail('lesson_locked'); end if;
  select count(*) into v_words from public.speak_words where level_id = p_level;
  insert into public.speak_plays (profile_id, level_id, points, stars, words, first_try, attempts)
  values (p_profile, p_level,
          least(greatest(coalesce(p_points, 0), 0), v_words * 30 + 50),
          least(greatest(coalesce(p_stars, 1), 1), 3),
          v_words,
          least(greatest(coalesce(p_first_try, 0), 0), v_words),
          greatest(coalesce(p_attempts, 0), 0));
  return public.speak_game_state(p_profile);
end $$;

revoke all on function public.speak_game_state(uuid) from public, anon;
revoke all on function public.speak_record_attempt(uuid, text, text, text, numeric, text, int) from public, anon;
revoke all on function public.speak_finish_level(uuid, text, int, int, int, int, int) from public, anon;
grant execute on function public.speak_game_state(uuid) to authenticated;
grant execute on function public.speak_record_attempt(uuid, text, text, text, numeric, text, int) to authenticated;
grant execute on function public.speak_finish_level(uuid, text, int, int, int, int, int) to authenticated;

-- ---------------------------------------------------------------- content
-- Replaced on every run (progress rows keep their level ids).

update public.speak_levels set published = false;
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('y1-sounds', 'young', 10, 'Sounds: st, sl, tr, gr', 'أصوات: st, sl, tr, gr', '🚂', 0.8, 'English P3 - Unit 1: Sounds sl, st, gr, tr', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'y1-sounds';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('y1-sounds', 1, 'stop', '🛑', 'قِف', '', '{}'::text[]),
  ('y1-sounds', 2, 'star', '⭐', 'نجمة', '', '{}'::text[]),
  ('y1-sounds', 3, 'step', '👣', 'خطوة', '', '{}'::text[]),
  ('y1-sounds', 4, 'slow', '🐢', 'بطيء', '', '{}'::text[]),
  ('y1-sounds', 5, 'sleep', '😴', 'ينام', '', '{}'::text[]),
  ('y1-sounds', 6, 'train', '🚆', 'قطار', '', '{}'::text[]),
  ('y1-sounds', 7, 'truck', '🚚', 'شاحنة', '', array['trucks']::text[]),
  ('y1-sounds', 8, 'green', '🟢', 'أخضر', '', '{}'::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('y2-safety', 'young', 20, 'Safety', 'السلامة', '⛑️', 0.8, 'English P3 - Unit 1: Safety', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'y2-safety';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('y2-safety', 1, 'helmet', '⛑️', 'خوذة', 'hel-met', '{}'::text[]),
  ('y2-safety', 2, 'careful', '⚠️', 'حذِر', 'care-ful', '{}'::text[]),
  ('y2-safety', 3, 'sign', '🪧', 'إشارة', '', array['sine']::text[]),
  ('y2-safety', 4, 'stranger', '🧍', 'شخص غريب', 'stran-ger', '{}'::text[]),
  ('y2-safety', 5, 'ambulance', '🚑', 'سيارة إسعاف', 'am-bu-lance', '{}'::text[]),
  ('y2-safety', 6, 'seat belt', '🚗', 'حزام الأمان', 'seat - belt', array['seatbelt']::text[]),
  ('y2-safety', 7, 'dangerous', '⚡', 'خطير', 'dan-ger-ous', '{}'::text[]),
  ('y2-safety', 8, 'emergency', '🚨', 'طوارئ', 'e-mer-gen-cy', '{}'::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('y3-food', 'young', 30, 'Food and health', 'الطعام والصحة', '🍎', 0.8, 'English P3 - Unit 2: Food and Health', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'y3-food';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('y3-food', 1, 'apple', '🍎', 'تفاحة', 'ap-ple', '{}'::text[]),
  ('y3-food', 2, 'milk', '🥛', 'حليب', '', '{}'::text[]),
  ('y3-food', 3, 'rice', '🍚', 'أرز', '', '{}'::text[]),
  ('y3-food', 4, 'water', '💧', 'ماء', 'wa-ter', '{}'::text[]),
  ('y3-food', 5, 'breakfast', '🍳', 'الفطور', 'break-fast', '{}'::text[]),
  ('y3-food', 6, 'lunch', '🥪', 'الغداء', '', '{}'::text[]),
  ('y3-food', 7, 'dinner', '🍽️', 'العشاء', 'din-ner', '{}'::text[]),
  ('y3-food', 8, 'vegetables', '🥦', 'خضروات', 'veg-e-ta-bles', array['vegetable']::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('y4-magic-e', 'young', 40, 'Magic e: cap or cape?', 'حرف e السحري', '🪄', 0.93, 'English P3 - Unit 3: Magic e', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'y4-magic-e';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('y4-magic-e', 1, 'cap', '🧢', 'قبعة', '', '{}'::text[]),
  ('y4-magic-e', 2, 'cape', '🦸', 'عباءة', 'c-a-pe (a says its name)', '{}'::text[]),
  ('y4-magic-e', 3, 'hop', '🐇', 'يقفز', '', '{}'::text[]),
  ('y4-magic-e', 4, 'hope', '🙏', 'أمل', 'h-o-pe (o says its name)', '{}'::text[]),
  ('y4-magic-e', 5, 'kit', '🧰', 'عُدّة', '', '{}'::text[]),
  ('y4-magic-e', 6, 'kite', '🪁', 'طائرة ورقية', 'k-i-te (i says its name)', '{}'::text[]),
  ('y4-magic-e', 7, 'cub', '🐻', 'شبل / صغير الدب', '', array['cubs']::text[]),
  ('y4-magic-e', 8, 'cube', '🧊', 'مكعب', 'c-u-be (u says its name)', '{}'::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('y5-heroes', 'young', 50, 'Heroes around us', 'أبطال حولنا', '🚒', 0.8, 'English P3 - Unit 3: Heroes Around Us', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'y5-heroes';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('y5-heroes', 1, 'firefighter', '👩‍🚒', 'رجل إطفاء', 'fire-fight-er', array['fire fighter', 'firefighters']::text[]),
  ('y5-heroes', 2, 'pilot', '👨‍✈️', 'طيار', 'pi-lot', '{}'::text[]),
  ('y5-heroes', 3, 'teacher', '👩‍🏫', 'معلم', 'tea-cher', '{}'::text[]),
  ('y5-heroes', 4, 'chef', '👨‍🍳', 'طاهٍ', '', array['shef']::text[]),
  ('y5-heroes', 5, 'brave', '🦁', 'شجاع', '', '{}'::text[]),
  ('y5-heroes', 6, 'ladder', '🪜', 'سلّم', 'lad-der', '{}'::text[]),
  ('y5-heroes', 7, 'medal', '🏅', 'ميدالية', 'med-al', array['metal']::text[]),
  ('y5-heroes', 8, 'uniform', '🦺', 'زي موحد', 'u-ni-form', '{}'::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('y6-tech', 'young', 60, 'Technology', 'التكنولوجيا', '🤖', 0.8, 'English P3 - Unit 4: Living with Technology', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'y6-tech';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('y6-tech', 1, 'phone', '📱', 'هاتف', '', '{}'::text[]),
  ('y6-tech', 2, 'robot', '🤖', 'روبوت', 'ro-bot', '{}'::text[]),
  ('y6-tech', 3, 'camera', '📷', 'كاميرا', 'cam-er-a', '{}'::text[]),
  ('y6-tech', 4, 'tablet', '📲', 'جهاز لوحي', 'tab-let', '{}'::text[]),
  ('y6-tech', 5, 'screen', '🖥️', 'شاشة', '', '{}'::text[]),
  ('y6-tech', 6, 'keyboard', '⌨️', 'لوحة المفاتيح', 'key-board', array['key board']::text[]),
  ('y6-tech', 7, 'button', '🔘', 'زر', 'but-ton', '{}'::text[]),
  ('y6-tech', 8, 'password', '🔑', 'كلمة المرور', 'pass-word', array['pass word']::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('y7-animals', 'young', 70, 'Animals and habitats', 'الحيوانات وبيئاتها', '🐪', 0.8, 'English P3 - Unit 5: Animals and Habitats', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'y7-animals';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('y7-animals', 1, 'camel', '🐪', 'جمل', 'cam-el', '{}'::text[]),
  ('y7-animals', 2, 'monkey', '🐒', 'قرد', 'mon-key', '{}'::text[]),
  ('y7-animals', 3, 'fish', '🐟', 'سمكة', '', '{}'::text[]),
  ('y7-animals', 4, 'owl', '🦉', 'بومة', '', '{}'::text[]),
  ('y7-animals', 5, 'polar bear', '🐻‍❄️', 'دب قطبي', 'po-lar bear', array['polarbear']::text[]),
  ('y7-animals', 6, 'feathers', '🪶', 'ريش', 'feath-ers', array['feather']::text[]),
  ('y7-animals', 7, 'fur', '🧸', 'فرو', '', array['fir']::text[]),
  ('y7-animals', 8, 'claws', '🐾', 'مخالب', '', array['claw', 'clause']::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('y8-actions', 'young', 80, 'I can... (action words)', 'أستطيع... (أفعال)', '🤸', 0.8, 'English P3 - Unit 5: can / can''t', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'y8-actions';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('y8-actions', 1, 'fly', '🕊️', 'يطير', '', '{}'::text[]),
  ('y8-actions', 2, 'jump', '🦘', 'يقفز', '', '{}'::text[]),
  ('y8-actions', 3, 'crawl', '🐛', 'يزحف', '', '{}'::text[]),
  ('y8-actions', 4, 'swim', '🏊', 'يسبح', '', '{}'::text[]),
  ('y8-actions', 5, 'climb', '🧗', 'يتسلق', '', array['clime']::text[]),
  ('y8-actions', 6, 'run', '🏃', 'يجري', '', '{}'::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('y9-feelings', 'young', 90, 'Feelings (story)', 'المشاعر (القصة)', '😊', 0.8, 'English P3 - Unit 6: The Honest Choice', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'y9-feelings';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('y9-feelings', 1, 'happy', '😀', 'سعيد', 'hap-py', '{}'::text[]),
  ('y9-feelings', 2, 'angry', '😠', 'غاضب', 'an-gry', '{}'::text[]),
  ('y9-feelings', 3, 'sleepy', '😴', 'نعسان', 'sleep-y', '{}'::text[]),
  ('y9-feelings', 4, 'nervous', '😬', 'متوتر', 'ner-vous', '{}'::text[]),
  ('y9-feelings', 5, 'honest', '🤝', 'صادق', 'hon-est (h is silent)', '{}'::text[]),
  ('y9-feelings', 6, 'whisper', '🤫', 'يهمس', 'whis-per', '{}'::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('y10-math', 'young', 100, 'Math words', 'كلمات الرياضيات', '➗', 0.8, 'Math P3 - Chapters 1-10', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'y10-math';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('y10-math', 1, 'multiply', '✖️', 'يضرب', 'mul-ti-ply', '{}'::text[]),
  ('y10-math', 2, 'divide', '➗', 'يقسم', 'di-vide', '{}'::text[]),
  ('y10-math', 3, 'hour', '⏰', 'ساعة', 'our (h is silent)', array['our']::text[]),
  ('y10-math', 4, 'minute', '⏱️', 'دقيقة', 'min-ute', array['minutes']::text[]),
  ('y10-math', 5, 'remainder', '🧮', 'الباقي', 're-main-der', '{}'::text[]),
  ('y10-math', 6, 'kilometre', '🛣️', 'كيلومتر', 'ki-lo-me-tre', array['kilometer', 'kilometers', 'kilometres']::text[]),
  ('y10-math', 7, 'graph', '📊', 'رسم بياني', '', array['graf']::text[]),
  ('y10-math', 8, 'ten thousand', '🔟', 'عشرة آلاف', '', array['10000']::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('y11-sentences', 'young', 110, 'Short sentences', 'جمل قصيرة', '💬', 0.8, 'English P3 - Units 1, 2, 6', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'y11-sentences';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('y11-sentences', 1, 'Be careful', '⚠️', 'كن حذراً', '', '{}'::text[]),
  ('y11-sentences', 2, 'Don''t run', '🚫🏃', 'لا تجرِ', '', array['do not run']::text[]),
  ('y11-sentences', 3, 'Wait here', '✋', 'انتظر هنا', '', '{}'::text[]),
  ('y11-sentences', 4, 'I did it myself', '💪', 'فعلتها بنفسي', '', '{}'::text[]),
  ('y11-sentences', 5, 'I can jump', '🦘', 'أستطيع أن أقفز', '', '{}'::text[]),
  ('y11-sentences', 6, 'Always tell the truth', '🤝', 'قل الحقيقة دائماً', '', '{}'::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('o1-art', 'older', 10, 'Celebrating creativity', 'الاحتفاء بالإبداع', '🎨', 0.84, 'English P6 - Unit 1: Celebrating Creativity', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'o1-art';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('o1-art', 1, 'canvas', '🖼️', 'قماش الرسم', 'can-vas', array['canvass']::text[]),
  ('o1-art', 2, 'gallery', '🏛️', 'معرض', 'gal-le-ry', '{}'::text[]),
  ('o1-art', 3, 'sketch', '✏️', 'رسم تخطيطي', '', '{}'::text[]),
  ('o1-art', 4, 'mural', '🧱', 'لوحة جدارية', 'mu-ral', '{}'::text[]),
  ('o1-art', 5, 'palette', '🎨', 'لوحة الألوان', 'pal-ette', array['pallet']::text[]),
  ('o1-art', 6, 'sculpture', '🗿', 'منحوتة', 'sculp-ture', '{}'::text[]),
  ('o1-art', 7, 'sculptor', '🧑‍🎨', 'نحّات', 'sculp-tor', '{}'::text[]),
  ('o1-art', 8, 'masterpiece', '🌟', 'تحفة فنية', 'mas-ter-piece', array['master piece']::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('o2-inventions', 'older', 20, 'Wonderful inventions', 'اختراعات رائعة', '💡', 0.84, 'English P6 - Unit 2: Wonderful Inventions', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'o2-inventions';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('o2-inventions', 1, 'gadget', '📟', 'أداة / جهاز صغير', 'gad-get', '{}'::text[]),
  ('o2-inventions', 2, 'fabric', '🧵', 'قماش', 'fab-ric', '{}'::text[]),
  ('o2-inventions', 3, 'thread', '🪡', 'خيط', '', '{}'::text[]),
  ('o2-inventions', 4, 'blueprint', '📐', 'مخطط', 'blue-print', array['blue print']::text[]),
  ('o2-inventions', 5, 'accurate', '🎯', 'دقيق', 'ac-cu-rate', '{}'::text[]),
  ('o2-inventions', 6, 'assemble', '🔧', 'يُجمِّع', 'as-sem-ble', '{}'::text[]),
  ('o2-inventions', 7, 'rebuild', '🏗️', 'يعيد البناء', 're-build', array['re build']::text[]),
  ('o2-inventions', 8, 'unhappy', '🙁', 'غير سعيد', 'un-hap-py', '{}'::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('o3-egypt', 'older', 30, 'Hidden gems of Egypt', 'كنوز مصر الخفية', '🏺', 0.84, 'English P6 - Unit 3: Hidden Gems of Egypt', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'o3-egypt';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('o3-egypt', 1, 'mummy', '🧟', 'مومياء', 'mum-my', '{}'::text[]),
  ('o3-egypt', 2, 'monument', '🗿', 'أثر / نُصب', 'mon-u-ment', '{}'::text[]),
  ('o3-egypt', 3, 'chamber', '🚪', 'حجرة', 'cham-ber', '{}'::text[]),
  ('o3-egypt', 4, 'ruler', '👑', 'حاكم', 'rul-er', '{}'::text[]),
  ('o3-egypt', 5, 'discover', '🔍', 'يكتشف', 'dis-cov-er', '{}'::text[]),
  ('o3-egypt', 6, 'restore', '🛠️', 'يرمّم', 're-store', '{}'::text[]),
  ('o3-egypt', 7, 'craftsman', '🔨', 'حِرفي', 'crafts-man', array['craftsmen']::text[]),
  ('o3-egypt', 8, 'archaeologist', '⛏️', 'عالم آثار', 'ar-chae-ol-o-gist', array['archeologist']::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('o4-industry', 'older', 40, 'Egypt on the move', 'مصر تتحرك', '🏭', 0.84, 'English P6 - Unit 4: Egypt on the Move', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'o4-industry';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('o4-industry', 1, 'steel', '🔩', 'فولاذ', '', array['steal']::text[]),
  ('o4-industry', 2, 'textile', '🧶', 'نسيج', 'tex-tile', '{}'::text[]),
  ('o4-industry', 3, 'highway', '🛣️', 'طريق سريع', 'high-way', array['high way']::text[]),
  ('o4-industry', 4, 'border', '🗺️', 'حدود', 'bor-der', array['boarder']::text[]),
  ('o4-industry', 5, 'innovation', '🚀', 'ابتكار', 'in-no-va-tion', '{}'::text[]),
  ('o4-industry', 6, 'manufacture', '🏭', 'يصنّع', 'man-u-fac-ture', '{}'::text[]),
  ('o4-industry', 7, 'infrastructure', '🌉', 'البنية التحتية', 'in-fra-struc-ture', '{}'::text[]),
  ('o4-industry', 8, 'self-reliant', '💪', 'معتمد على نفسه', 'self - re-li-ant', array['self reliant']::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('o5-transport', 'older', 50, 'Smart transportation', 'النقل الذكي', '🚝', 0.84, 'English P6 - Unit 5: Smart Transportation', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'o5-transport';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('o5-transport', 1, 'monorail', '🚝', 'قطار أحادي', 'mon-o-rail', array['mono rail']::text[]),
  ('o5-transport', 2, 'escalator', '🛗', 'سلم متحرك', 'es-ca-la-tor', '{}'::text[]),
  ('o5-transport', 3, 'ticket machine', '🎫', 'آلة التذاكر', 'tick-et ma-chine', '{}'::text[]),
  ('o5-transport', 4, 'pollution', '🏭', 'تلوث', 'pol-lu-tion', '{}'::text[]),
  ('o5-transport', 5, 'digital', '💻', 'رقمي', 'dig-i-tal', '{}'::text[]),
  ('o5-transport', 6, 'renewable', '♻️', 'متجدد', 're-new-a-ble', '{}'::text[]),
  ('o5-transport', 7, 'eco-friendly', '🌱', 'صديق للبيئة', 'e-co friend-ly', array['eco friendly']::text[]),
  ('o5-transport', 8, 'self-driving', '🚘', 'ذاتي القيادة', 'self driv-ing', array['self driving']::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('o6-library', 'older', 60, 'The library that time forgot', 'المكتبة المنسية', '📚', 0.84, 'English P6 - Unit 6: The Library That Time Forgot', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'o6-library';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('o6-library', 1, 'library', '📚', 'مكتبة', 'li-brar-y', '{}'::text[]),
  ('o6-library', 2, 'treasure', '💰', 'كنز', 'trea-sure', '{}'::text[]),
  ('o6-library', 3, 'fountain', '⛲', 'نافورة', 'foun-tain', '{}'::text[]),
  ('o6-library', 4, 'rusty', '🔧', 'صدئ', 'rust-y', '{}'::text[]),
  ('o6-library', 5, 'clogged', '🚱', 'مسدود', '', array['clogs']::text[]),
  ('o6-library', 6, 'creaked', '🚪', 'صرّ / أصدر صريراً', '', array['creeked']::text[]),
  ('o6-library', 7, 'stacks', '📚', 'أكوام', '', array['stax']::text[]),
  ('o6-library', 8, 'mayor', '🎩', 'عمدة', '', array['mare', 'mayer']::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('o7-math', 'older', 70, 'Math words', 'كلمات الرياضيات', '📐', 0.84, 'Math P6 - Units 8-13', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'o7-math';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('o7-math', 1, 'fraction', '½', 'كسر', 'frac-tion', '{}'::text[]),
  ('o7-math', 2, 'decimal', '🔢', 'عدد عشري', 'dec-i-mal', '{}'::text[]),
  ('o7-math', 3, 'ratio', '⚖️', 'نسبة', 'ra-ti-o', '{}'::text[]),
  ('o7-math', 4, 'percent', '💯', 'نسبة مئوية', 'per-cent', array['per cent']::text[]),
  ('o7-math', 5, 'unit rate', '🏷️', 'معدل الوحدة', 'u-nit rate', '{}'::text[]),
  ('o7-math', 6, 'coordinates', '📍', 'إحداثيات', 'co-or-di-nates', array['coordinate']::text[]),
  ('o7-math', 7, 'polygon', '🔷', 'مضلع', 'pol-y-gon', '{}'::text[]),
  ('o7-math', 8, 'volume', '🧊', 'الحجم', 'vol-ume', '{}'::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('o8-sentences', 'older', 80, 'Grammar sentences', 'جمل القواعد', '💬', 0.8, 'English P6 - Units 1-6 (grammar)', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'o8-sentences';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('o8-sentences', 1, 'Have you been to Aswan', '🏝️', 'هل زرت أسوان؟', '', '{}'::text[]),
  ('o8-sentences', 2, 'We used to travel by train', '🚆', 'كنا نسافر بالقطار', '', '{}'::text[]),
  ('o8-sentences', 3, 'If it rains we will stay at home', '🌧️', 'إذا أمطرت سنبقى في البيت', '', array['if it rains we''ll stay at home']::text[]),
  ('o8-sentences', 4, 'She was walking when it started to rain', '🚶‍♀️', 'كانت تمشي عندما بدأ المطر', '', '{}'::text[]),
  ('o8-sentences', 5, 'The man who painted this is famous', '🧑‍🎨', 'الرجل الذي رسم هذه مشهور', '', '{}'::text[]),
  ('o8-sentences', 6, 'Neither Ali nor Sara was late', '⏰', 'لا علي ولا سارة تأخرا', '', '{}'::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('a1-words', 'adult', 10, 'Everyday English words', 'كلمات الإنجليزية اليومية', '💼', 0.86, 'Everyday English 1', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'a1-words';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('a1-words', 1, 'formal', '👔', 'رسمي', '', '{}'::text[]),
  ('a1-words', 2, 'informal', '👕', 'غير رسمي', '', '{}'::text[]),
  ('a1-words', 3, 'opinion', '💭', 'رأي', '', '{}'::text[]),
  ('a1-words', 4, 'discussion', '🗣️', 'نقاش', '', '{}'::text[]),
  ('a1-words', 5, 'paragraph', '📄', 'فقرة', '', '{}'::text[]),
  ('a1-words', 6, 'punctuation', '❗', 'علامات الترقيم', '', '{}'::text[]),
  ('a1-words', 7, 'spelling', '🔤', 'التهجئة', '', '{}'::text[]),
  ('a1-words', 8, 'summary', '📝', 'ملخص', '', '{}'::text[]);
insert into public.speak_levels (id, track, sort, title, title_ar, emoji, strictness, source, published) values ('a2-phrases', 'adult', 20, 'Useful phrases', 'عبارات مفيدة', '🤝', 0.82, 'Everyday English 1 - Speaking, Writing', true)
  on conflict (id) do update set track = excluded.track, sort = excluded.sort, title = excluded.title, title_ar = excluded.title_ar, emoji = excluded.emoji, strictness = excluded.strictness, source = excluded.source, published = true;
delete from public.speak_words where level_id = 'a2-phrases';
insert into public.speak_words (level_id, sort, text, emoji, meaning_ar, hint, accept) values
  ('a2-phrases', 1, 'Thank you for your email', '📧', 'شكراً على بريدك', '', '{}'::text[]),
  ('a2-phrases', 2, 'Could you please send me the details', '📨', 'هل يمكنك إرسال التفاصيل من فضلك؟', '', '{}'::text[]),
  ('a2-phrases', 3, 'In my opinion', '💭', 'في رأيي', '', '{}'::text[]),
  ('a2-phrases', 4, 'I agree with you', '👍', 'أتفق معك', '', '{}'::text[]),
  ('a2-phrases', 5, 'I would like to ask about the price', '💬', 'أود أن أسأل عن السعر', '', array['i''d like to ask about the price']::text[]),
  ('a2-phrases', 6, 'Best regards', '✍️', 'مع أطيب التحيات', '', '{}'::text[]);
