-- ============================================================================
--  Family Learn - Phase 4: learning database
--   courses -> units -> lessons -> questions   (content, read-only for the app)
--   lesson_attempts + answers                   (progress, written only by the functions below)
--
--  Needs Phase 3 first. Run once: Supabase -> SQL Editor -> paste -> Run.
--  Then run 20260926000003_phase4_starter_content.sql for the lessons.
--
--  Rules enforced here (not in the app):
--   * answer keys are never sent to the phone before an answer is submitted;
--   * the server marks every answer (the app cannot report its own score);
--   * a child's phone can only read and write its own profile's progress;
--   * the parent account can use every profile in the family;
--   * a lesson opens only after the previous lesson in the course is finished.
-- ============================================================================

alter table public.families
  add column if not exists timezone text not null default 'Asia/Muscat';

-- ---------------------------------------------------------------- content

create table public.skills (
  code     text primary key,
  name     text not null,
  subject  text not null
);

create table public.courses (
  id           text primary key,
  subject      text not null check (subject in ('english', 'math', 'business')),
  title        text not null,
  level_label  text not null,
  audience     text not null check (audience in ('child', 'adult')),
  grade_min    smallint,
  grade_max    smallint,
  position     smallint not null default 0,
  published    boolean not null default true
);

create table public.units (
  id         text primary key,
  course_id  text not null references public.courses (id) on delete cascade,
  position   smallint not null,
  title      text not null
);
create index units_course_idx on public.units (course_id, position);

create table public.lessons (
  id         text primary key,
  unit_id    text not null references public.units (id) on delete cascade,
  course_id  text not null references public.courses (id) on delete cascade,
  position   smallint not null,          -- order inside the whole course (1, 2, 3...)
  title      text not null,
  minutes    smallint not null default 10,
  unique (course_id, position)
);
create index lessons_unit_idx on public.lessons (unit_id);

create table public.questions (
  id           text primary key,
  lesson_id    text not null references public.lessons (id) on delete cascade,
  position     smallint not null,
  type         text not null check (type in ('multiple_choice', 'true_false', 'fill_blank', 'matching', 'ordering',
                                             'drag_drop', 'typing', 'listening', 'speaking', 'reading', 'word_problem')),
  skill        text not null references public.skills (code),
  prompt       text not null,
  hint         text,
  payload      jsonb not null default '{}'::jsonb,   -- what the phone may see
  answer_key   jsonb not null,                       -- PRIVATE: used only by app.grade()
  correct_text text not null,                        -- shown after the answer is submitted
  explanation  text,
  unique (lesson_id, position)
);

-- ---------------------------------------------------------------- progress

create table public.lesson_attempts (
  id           uuid primary key default gen_random_uuid(),
  profile_id   uuid not null references public.profiles (id) on delete cascade,
  lesson_id    text not null references public.lessons (id) on delete cascade,
  started_by   uuid not null,                        -- auth user (parent account or child phone)
  started_at   timestamptz not null default now(),
  finished_at  timestamptz,
  total        smallint,
  correct      smallint,
  xp           integer not null default 0,
  coins        integer not null default 0,
  stars        smallint not null default 0
);
create index lesson_attempts_profile_idx on public.lesson_attempts (profile_id, finished_at);
create index lesson_attempts_lesson_idx on public.lesson_attempts (profile_id, lesson_id);

create table public.answers (
  attempt_id   uuid not null references public.lesson_attempts (id) on delete cascade,
  question_id  text not null references public.questions (id) on delete cascade,
  response     jsonb,
  is_correct   boolean not null,
  answered_at  timestamptz not null default now(),
  primary key (attempt_id, question_id)
);
create index answers_question_idx on public.answers (question_id);

-- ---------------------------------------------------------------- access

alter table public.skills           enable row level security;
alter table public.courses          enable row level security;
alter table public.units            enable row level security;
alter table public.lessons          enable row level security;
alter table public.questions        enable row level security;
alter table public.lesson_attempts  enable row level security;
alter table public.answers          enable row level security;

revoke all on public.skills, public.courses, public.units, public.lessons, public.questions,
              public.lesson_attempts, public.answers
  from anon, authenticated;

-- Course outlines are readable by any signed-in member; questions and progress
-- only through the functions below.
grant select on public.skills, public.courses, public.units, public.lessons to authenticated;
create policy skills_read  on public.skills  for select to authenticated using (true);
create policy courses_read on public.courses for select to authenticated using (published);
create policy units_read   on public.units   for select to authenticated using (true);
create policy lessons_read on public.lessons for select to authenticated using (true);

-- ---------------------------------------------------------------- helpers

create or replace function app.can_use_profile(p_profile uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.profiles p
     where p.id = p_profile
       and p.family_id = app.my_family_id()
       and (app.i_am_parent() or p.id = app.my_device_profile_id()))
$$;

create or replace function app.require_profile(p_profile uuid) returns void
language plpgsql stable security definer set search_path = '' as $$
begin
  if p_profile is null or not app.can_use_profile(p_profile) then perform app.fail('not_found'); end if;
end $$;

create or replace function app.profile_tz(p_profile uuid) returns text
language sql stable security definer set search_path = '' as $$
  select coalesce(f.timezone, 'Asia/Muscat')
    from public.profiles p join public.families f on f.id = p.family_id
   where p.id = p_profile
$$;

-- Courses that fit a profile: adults get adult courses, children the ones for their grade.
create or replace function app.courses_for(p_profile uuid) returns setof public.courses
language sql stable security definer set search_path = '' as $$
  select c.* from public.courses c, public.profiles p
   where p.id = p_profile and c.published
     and ((p.kind = 'adult' and c.audience = 'adult')
       or (p.kind = 'child' and c.audience = 'child'
           and coalesce(p.grade, 1) between coalesce(c.grade_min, 1) and coalesce(c.grade_max, 12)))
   order by c.position, c.id
$$;

create or replace function app.lesson_done(p_profile uuid, p_lesson text) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.lesson_attempts
                  where profile_id = p_profile and lesson_id = p_lesson and finished_at is not null)
$$;

-- First lesson of a course is open; every other one opens when the previous is finished.
create or replace function app.lesson_unlocked(p_profile uuid, p_lesson text) returns boolean
language sql stable security definer set search_path = '' as $$
  select l.position = 1 or exists (
           select 1 from public.lessons prev
            where prev.course_id = l.course_id and prev.position = l.position - 1
              and app.lesson_done(p_profile, prev.id))
    from public.lessons l where l.id = p_lesson
$$;

create or replace function app.norm(t text) returns text
language sql immutable set search_path = '' as $$
  select regexp_replace(regexp_replace(lower(regexp_replace(coalesce(t, ''), '^\s+|\s+$', '', 'g')), '\s+', ' ', 'g'), '[.!?]+$', '')
$$;

-- First number in a typed answer: "300 baisa" -> 300, "0,25" -> 0.25, "20,000" -> 20000.
create or replace function app.parse_number(t text) returns numeric
language plpgsql immutable set search_path = '' as $$
declare s text;
begin
  s := regexp_replace(coalesce(t, ''), '(\d),(\d{3})(?!\d)', '\1\2', 'g');
  s := replace(s, ',', '.');
  s := substring(s from '-?\d+(?:\.\d+)?|-?\.\d+');
  if s is null then return null; end if;
  return s::numeric;
exception when others then
  return null;
end $$;

-- The answer checker. Same rules as lib/data/learning/grader.dart in the app.
create or replace function app.grade(p_type text, p_key jsonb, p_response jsonb) returns boolean
language plpgsql immutable set search_path = '' as $$
declare
  n int;
  v numeric;
begin
  if p_response is null or jsonb_typeof(p_response) = 'null' then return false; end if;
  case p_type
    when 'multiple_choice', 'reading', 'listening' then
      return jsonb_typeof(p_response) = 'number' and (p_response #>> '{}')::numeric = (p_key ->> 'index')::numeric;
    when 'true_false' then
      return jsonb_typeof(p_response) = 'boolean' and p_response = p_key -> 'value';
    when 'fill_blank', 'typing' then
      return jsonb_typeof(p_response) = 'string'
         and app.norm(p_response #>> '{}') in (select app.norm(x) from jsonb_array_elements_text(p_key -> 'accepted') x);
    when 'drag_drop' then
      return jsonb_typeof(p_response) = 'string' and (p_response #>> '{}') = (p_key ->> 'token');
    when 'word_problem' then
      if jsonb_typeof(p_response) = 'number' then v := (p_response #>> '{}')::numeric;
      elsif jsonb_typeof(p_response) = 'string' then v := app.parse_number(p_response #>> '{}');
      end if;
      return v is not null and abs(v - (p_key ->> 'value')::numeric) < 0.0001;
    when 'matching' then
      -- response: {"0": 2, "1": 0, ...} = left index -> index in the right list as shown;
      -- key.map holds the right pairs.
      if jsonb_typeof(p_response) <> 'object' then return false; end if;
      n := (p_key ->> 'pairs')::int;
      return (select count(*) from jsonb_object_keys(p_response)) = n
         and not exists (select 1 from jsonb_each(p_response) e
                          where jsonb_typeof(e.value) <> 'number'
                             or (p_key -> 'map' -> e.key) is null
                             or (e.value #>> '{}')::numeric <> (p_key -> 'map' ->> e.key)::numeric);
    when 'ordering' then
      return jsonb_typeof(p_response) = 'array' and p_response = p_key -> 'order';
    when 'speaking' then
      return true;   -- pronunciation scoring arrives in Phase 9
    else
      return false;
  end case;
exception when others then
  return false;
end $$;

-- Minutes of one attempt (capped at 30 so a lesson left open overnight doesn't count as hours).
create or replace function app.attempt_minutes(a public.lesson_attempts) returns numeric
language sql immutable set search_path = '' as $$
  select case when a.finished_at is null then 0
              else least(extract(epoch from (a.finished_at - a.started_at)) / 60.0, 30) end
$$;

-- Days in a row (family time zone) with at least one finished lesson, ending today or yesterday.
create or replace function app.streak(p_profile uuid) returns int
language plpgsql stable security definer set search_path = '' as $$
declare
  tz    text := app.profile_tz(p_profile);
  today date := (now() at time zone tz)::date;
  d     date;
  n     int := 0;
begin
  select max((finished_at at time zone tz)::date) into d
    from public.lesson_attempts where profile_id = p_profile and finished_at is not null;
  if d is null or d < today - 1 then return 0; end if;
  while exists (select 1 from public.lesson_attempts
                 where profile_id = p_profile and finished_at is not null
                   and (finished_at at time zone tz)::date = d) loop
    n := n + 1;
    d := d - 1;
  end loop;
  return n;
end $$;

revoke all on all functions in schema app from public, anon;
grant execute on all functions in schema app to authenticated;

-- ---------------------------------------------------------------- API (RPC)

-- XP, coins, stars, level, streak and today's minutes for one profile.
create or replace function public.profile_wallet(p_profile uuid) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  tz    text;
  today date;
  v_xp  int;
  v_coins int;
  v_stars int;
  v_done int;
  v_min numeric;
begin
  perform app.require_profile(p_profile);
  tz := app.profile_tz(p_profile);
  today := (now() at time zone tz)::date;

  select coalesce(sum(xp), 0), coalesce(sum(coins), 0) into v_xp, v_coins
    from public.lesson_attempts where profile_id = p_profile and finished_at is not null;
  select coalesce(sum(best), 0), count(*) into v_stars, v_done
    from (select max(stars) best from public.lesson_attempts
           where profile_id = p_profile and finished_at is not null group by lesson_id) b;
  select coalesce(sum(app.attempt_minutes(a)), 0) into v_min
    from public.lesson_attempts a
   where a.profile_id = p_profile and a.finished_at is not null
     and (a.finished_at at time zone tz)::date = today;

  return jsonb_build_object(
    'xp', v_xp, 'coins', v_coins, 'stars', v_stars,
    'level', 1 + v_xp / 500,
    'streak_days', app.streak(p_profile),
    'minutes_today', ceil(v_min)::int,
    'lessons_done', v_done);
end $$;

-- The profile's courses with units, lessons and each lesson's status.
-- status: done | in_progress | available | locked
create or replace function public.course_map(p_profile uuid) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
begin
  perform app.require_profile(p_profile);
  return coalesce((
    select jsonb_agg(jsonb_build_object(
             'id', c.id, 'subject', c.subject, 'title', c.title, 'level_label', c.level_label,
             'units', (
               select coalesce(jsonb_agg(jsonb_build_object(
                        'id', u.id, 'title', u.title,
                        'lessons', (
                          select coalesce(jsonb_agg(jsonb_build_object(
                                   'id', l.id, 'title', l.title, 'minutes', l.minutes,
                                   'status', case
                                     when app.lesson_done(p_profile, l.id) then 'done'
                                     when not app.lesson_unlocked(p_profile, l.id) then 'locked'
                                     when exists (select 1 from public.lesson_attempts a
                                                   join public.answers an on an.attempt_id = a.id
                                                  where a.profile_id = p_profile and a.lesson_id = l.id
                                                    and a.finished_at is null) then 'in_progress'
                                     else 'available' end)
                                 order by l.position), '[]'::jsonb)
                            from public.lessons l where l.unit_id = u.id)
                      ) order by u.position), '[]'::jsonb)
                 from public.units u where u.course_id = c.id)
           ) order by c.position, c.id)
      from app.courses_for(p_profile) c), '[]'::jsonb);
end $$;

-- Opens a lesson: creates an attempt and returns the questions WITHOUT answers.
create or replace function public.start_lesson(p_profile uuid, p_lesson text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_attempt uuid;
  v_title   text;
begin
  perform app.require_profile(p_profile);
  select l.title into v_title from public.lessons l
   where l.id = p_lesson and l.course_id in (select c.id from app.courses_for(p_profile) c);
  if v_title is null then perform app.fail('not_found'); end if;
  if not app.lesson_unlocked(p_profile, p_lesson) then perform app.fail('lesson_locked'); end if;

  -- tidy: earlier attempts of this lesson that were opened but never answered
  delete from public.lesson_attempts a
   where a.profile_id = p_profile and a.lesson_id = p_lesson and a.finished_at is null
     and not exists (select 1 from public.answers an where an.attempt_id = a.id);

  insert into public.lesson_attempts (profile_id, lesson_id, started_by)
  values (p_profile, p_lesson, auth.uid())
  returning id into v_attempt;

  return jsonb_build_object(
    'attempt_id', v_attempt,
    'lesson_id', p_lesson,
    'title', v_title,
    'questions', (select coalesce(jsonb_agg(jsonb_build_object(
                           'id', q.id, 'type', q.type, 'skill', q.skill,
                           'prompt', q.prompt, 'hint', q.hint, 'payload', q.payload)
                         order by q.position), '[]'::jsonb)
                    from public.questions q where q.lesson_id = p_lesson));
end $$;

-- Marks one answer on the server. Only the first answer to a question counts.
-- Returns {"correct": bool, "correct_text": "...", "explanation": "..."}
create or replace function public.submit_answer(p_attempt uuid, p_question text, p_response jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  a public.lesson_attempts%rowtype;
  q public.questions%rowtype;
  v_ok boolean;
begin
  select * into a from public.lesson_attempts where id = p_attempt;
  if not found or not app.can_use_profile(a.profile_id) then perform app.fail('not_found'); end if;
  if a.finished_at is not null then perform app.fail('lesson_finished'); end if;

  select * into q from public.questions where id = p_question and lesson_id = a.lesson_id;
  if not found then perform app.fail('not_found'); end if;

  select is_correct into v_ok from public.answers where attempt_id = p_attempt and question_id = p_question;
  if not found then
    v_ok := app.grade(q.type, q.answer_key, p_response);
    insert into public.answers (attempt_id, question_id, response, is_correct)
    values (p_attempt, p_question, p_response, v_ok);
  end if;

  return jsonb_build_object('correct', v_ok, 'correct_text', q.correct_text, 'explanation', q.explanation);
end $$;

-- Closes the attempt, awards XP / coins / stars. Unanswered questions count as wrong.
-- Calling it twice returns the same result.
create or replace function public.finish_lesson(p_attempt uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  a       public.lesson_attempts%rowtype;
  v_total int;
  v_right int;
  v_pct   numeric;
begin
  select * into a from public.lesson_attempts where id = p_attempt for update;
  if not found or not app.can_use_profile(a.profile_id) then perform app.fail('not_found'); end if;

  if a.finished_at is null then
    select count(*) into v_total from public.questions where lesson_id = a.lesson_id;
    select count(*) into v_right from public.answers where attempt_id = p_attempt and is_correct;
    v_pct := case when v_total = 0 then 0 else v_right::numeric / v_total end;
    update public.lesson_attempts
       set finished_at = now(), total = v_total, correct = v_right,
           xp = 10 * v_right + case when v_pct >= 0.8 then 20 else 0 end,
           coins = v_right + 5,
           stars = case when v_pct >= 0.9 then 3 when v_pct >= 0.7 then 2 else 1 end
     where id = p_attempt
     returning * into a;
  end if;

  return jsonb_build_object(
    'correct', a.correct, 'total', a.total, 'xp', a.xp, 'coins', a.coins, 'stars', a.stars,
    'wallet', public.profile_wallet(a.profile_id));
end $$;

-- Parent only: a child's (or any family profile's) real study report.
create or replace function public.profile_report(p_profile uuid) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  tz    text;
  today date;
  v_goal int;
  r     jsonb := '{}'::jsonb;
  days  int;
begin
  if not app.i_am_parent() then perform app.fail('parent_only'); end if;
  perform app.require_profile(p_profile);
  tz := app.profile_tz(p_profile);
  today := (now() at time zone tz)::date;
  select daily_minutes_goal into v_goal from public.profiles where id = p_profile;

  -- minutes per day, last 7 days, oldest first
  r := r || jsonb_build_object('minutes_by_day', (
    select jsonb_agg(ceil(coalesce((
             select sum(app.attempt_minutes(a)) from public.lesson_attempts a
              where a.profile_id = p_profile and a.finished_at is not null
                and (a.finished_at at time zone tz)::date = d), 0))::int order by d)
      from generate_series(today - 6, today, interval '1 day') g(dd), lateral (select g.dd::date d) x));

  -- totals for today / 7 days / 30 days
  foreach days in array array[1, 7, 30] loop
    r := r || jsonb_build_object('last_' || days, (
      select jsonb_build_object(
               'minutes', ceil(coalesce((select sum(app.attempt_minutes(a)) from public.lesson_attempts a
                                          where a.profile_id = p_profile and a.finished_at is not null
                                            and (a.finished_at at time zone tz)::date > today - days), 0))::int,
               'questions', count(*),
               'correct', count(*) filter (where an.is_correct),
               'accuracy', case when count(*) = 0 then null
                                else round(count(*) filter (where an.is_correct)::numeric / count(*), 3) end)
        from public.answers an join public.lesson_attempts a on a.id = an.attempt_id
       where a.profile_id = p_profile and (an.answered_at at time zone tz)::date > today - days));
  end loop;

  r := r || jsonb_build_object(
    'daily_goal', v_goal,
    'streak_days', app.streak(p_profile),
    'history', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'lesson', h.title, 'correct', h.correct, 'total', h.total, 'finished_at', h.finished_at)
             order by h.finished_at desc), '[]'::jsonb)
        from (select l.title, a.correct, a.total, a.finished_at
                from public.lesson_attempts a join public.lessons l on l.id = a.lesson_id
               where a.profile_id = p_profile and a.finished_at is not null
               order by a.finished_at desc limit 8) h),
    'skills', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'code', s.skill, 'name', sk.name, 'answers', s.n, 'accuracy', round(s.ok::numeric / s.n, 3))
             order by s.ok::numeric / s.n), '[]'::jsonb)
        from (select q.skill, count(*) n, count(*) filter (where an.is_correct) ok
                from public.answers an
                join public.lesson_attempts a on a.id = an.attempt_id
                join public.questions q on q.id = an.question_id
               where a.profile_id = p_profile and an.answered_at > now() - interval '30 days'
               group by q.skill) s
        join public.skills sk on sk.code = s.skill),
    'to_review', (
      select coalesce(jsonb_agg(distinct sk.name), '[]'::jsonb)
        from public.answers an
        join public.lesson_attempts a on a.id = an.attempt_id
        join public.questions q on q.id = an.question_id
        join public.skills sk on sk.code = q.skill
       where a.profile_id = p_profile and not an.is_correct and an.answered_at > now() - interval '7 days'));
  return r;
end $$;

revoke all on function public.profile_wallet(uuid)              from public, anon;
revoke all on function public.course_map(uuid)                  from public, anon;
revoke all on function public.start_lesson(uuid, text)          from public, anon;
revoke all on function public.submit_answer(uuid, text, jsonb)  from public, anon;
revoke all on function public.finish_lesson(uuid)               from public, anon;
revoke all on function public.profile_report(uuid)              from public, anon;

grant execute on function public.profile_wallet(uuid)              to authenticated;
grant execute on function public.course_map(uuid)                  to authenticated;
grant execute on function public.start_lesson(uuid, text)          to authenticated;
grant execute on function public.submit_answer(uuid, text, jsonb)  to authenticated;
grant execute on function public.finish_lesson(uuid)               to authenticated;
grant execute on function public.profile_report(uuid)              to authenticated;
