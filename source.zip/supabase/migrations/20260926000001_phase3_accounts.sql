-- ============================================================================
--  Family Learn - Phase 3: accounts, families, profiles, PINs, device linking
--
--  Run once in Supabase: Dashboard -> SQL Editor -> New query -> paste -> Run.
--  Safe to run on a new project. Everything is protected by Row Level Security:
--   * a parent account sees and manages only its own family;
--   * a child's device (anonymous sign-in + link code) sees only its own profile;
--   * PIN hashes and link codes are never readable from the app.
-- ============================================================================

create extension if not exists pgcrypto with schema extensions;

create schema if not exists app;          -- private helpers, not exposed by the API
grant usage on schema app to authenticated;

-- ---------------------------------------------------------------- tables

create table public.families (
  id               uuid primary key default gen_random_uuid(),
  name             text not null check (char_length(btrim(name)) between 1 and 60),
  created_by       uuid not null references auth.users (id) on delete cascade,
  consent_version  text not null,
  consent_at       timestamptz not null default now(),
  created_at       timestamptz not null default now()
);

create table public.profiles (
  id                  uuid primary key default gen_random_uuid(),
  family_id           uuid not null references public.families (id) on delete cascade,
  display_name        text not null check (char_length(btrim(display_name)) between 1 and 40),
  kind                text not null check (kind in ('adult', 'child')),
  role                text not null default 'learner' check (role in ('parent', 'learner')),
  ui_locale           text not null default 'en' check (ui_locale in ('en', 'ar')),
  avatar_emoji        text not null default '🙂' check (char_length(avatar_emoji) between 1 and 16),
  daily_minutes_goal  smallint not null default 20 check (daily_minutes_goal between 5 and 180),
  grade               smallint check (grade between 1 and 12),
  birth_year          smallint check (birth_year between 1900 and 2100),
  ai_enabled          boolean not null default true,
  has_pin             boolean not null default false,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  constraint child_has_grade check (kind <> 'child' or grade is not null),
  constraint parent_is_adult check (role <> 'parent' or kind = 'adult')
);
create index profiles_family_idx on public.profiles (family_id);

-- Who (which auth user) belongs to which family.
--  role 'parent'       = the parent's email account
--  role 'child_device' = an anonymous sign-in on a child's phone, bound to ONE profile
create table public.family_members (
  user_id       uuid primary key references auth.users (id) on delete cascade,
  family_id     uuid not null references public.families (id) on delete cascade,
  role          text not null check (role in ('parent', 'child_device')),
  profile_id    uuid references public.profiles (id) on delete cascade,
  device_name   text check (char_length(device_name) <= 60),
  created_at    timestamptz not null default now(),
  last_seen_at  timestamptz not null default now(),
  constraint device_has_profile check (role <> 'child_device' or profile_id is not null)
);
create index family_members_family_idx on public.family_members (family_id);

-- Private: PIN hashes and lockout counters. No policies = unreachable from the app.
create table public.profile_secrets (
  profile_id       uuid primary key references public.profiles (id) on delete cascade,
  pin_hash         text,
  failed_attempts  smallint not null default 0,
  locked_until     timestamptz
);

-- Private: one-time link codes (stored hashed, valid 10 minutes).
create table public.pairing_codes (
  id          uuid primary key default gen_random_uuid(),
  family_id   uuid not null references public.families (id) on delete cascade,
  profile_id  uuid not null references public.profiles (id) on delete cascade,
  code_hash   text not null,
  created_by  uuid not null references auth.users (id) on delete cascade,
  created_at  timestamptz not null default now(),
  expires_at  timestamptz not null,
  used_at     timestamptz,
  used_by     uuid
);
create index pairing_codes_lookup_idx on public.pairing_codes (code_hash) where used_at is null;

-- Private: link-code attempts, for rate limiting.
create table public.pairing_attempts (
  id            bigint generated always as identity primary key,
  user_id       uuid not null,
  success       boolean not null,
  attempted_at  timestamptz not null default now()
);
create index pairing_attempts_user_idx on public.pairing_attempts (user_id, attempted_at);
create index pairing_attempts_time_idx on public.pairing_attempts (attempted_at);

-- ---------------------------------------------------------------- access rules

alter table public.families         enable row level security;
alter table public.profiles         enable row level security;
alter table public.family_members   enable row level security;
alter table public.profile_secrets  enable row level security;
alter table public.pairing_codes    enable row level security;
alter table public.pairing_attempts enable row level security;

-- Start from nothing, then grant only what the app needs.
revoke all on public.families, public.profiles, public.family_members,
              public.profile_secrets, public.pairing_codes, public.pairing_attempts
  from anon, authenticated;

grant select on public.families, public.profiles, public.family_members to authenticated;
grant update (name) on public.families to authenticated;
grant update (display_name, ui_locale, avatar_emoji, daily_minutes_goal, grade, birth_year, ai_enabled)
  on public.profiles to authenticated;

-- helpers (security definer so policies don't recurse through RLS)
create or replace function app.my_family_id() returns uuid
language sql stable security definer set search_path = '' as $$
  select family_id from public.family_members where user_id = auth.uid()
$$;

create or replace function app.i_am_parent() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.family_members where user_id = auth.uid() and role = 'parent')
$$;

create or replace function app.my_device_profile_id() returns uuid
language sql stable security definer set search_path = '' as $$
  select profile_id from public.family_members where user_id = auth.uid() and role = 'child_device'
$$;

create or replace function app.is_anonymous() returns boolean
language sql stable set search_path = '' as $$
  select coalesce((auth.jwt() ->> 'is_anonymous')::boolean, false)
$$;

create or replace function app.fail(code text) returns void
language plpgsql set search_path = '' as $$
begin
  raise exception using errcode = 'P0001', message = code;
end $$;

revoke all on all functions in schema app from public, anon;
grant execute on all functions in schema app to authenticated;

create policy families_read on public.families for select to authenticated
  using (id = app.my_family_id());
create policy families_parent_update on public.families for update to authenticated
  using (id = app.my_family_id() and app.i_am_parent())
  with check (id = app.my_family_id());

create policy profiles_read on public.profiles for select to authenticated
  using (family_id = app.my_family_id()
         and (app.i_am_parent() or id = app.my_device_profile_id()));
create policy profiles_parent_update on public.profiles for update to authenticated
  using (family_id = app.my_family_id() and app.i_am_parent())
  with check (family_id = app.my_family_id());

create policy members_read on public.family_members for select to authenticated
  using (user_id = auth.uid() or (family_id = app.my_family_id() and app.i_am_parent()));

create or replace function app.touch_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin new.updated_at := now(); return new; end $$;
create trigger profiles_updated_at before update on public.profiles
  for each row execute function app.touch_updated_at();

-- ---------------------------------------------------------------- internal

-- Validates a learner JSON object and inserts it. Used by create_family and add_profile.
create or replace function app.insert_learner(p_family uuid, p jsonb) returns uuid
language plpgsql security definer set search_path = '' as $$
declare
  v_kind  text := coalesce(p ->> 'kind', 'child');
  v_grade smallint := nullif(p ->> 'grade', '')::smallint;
  v_id    uuid;
begin
  if v_kind not in ('adult', 'child') then perform app.fail('invalid_profile'); end if;
  if v_kind = 'child' and v_grade is null then perform app.fail('grade_required'); end if;
  if (select count(*) from public.profiles where family_id = p_family) >= 10 then
    perform app.fail('too_many_profiles');
  end if;
  insert into public.profiles (family_id, display_name, kind, role, ui_locale, avatar_emoji,
                               daily_minutes_goal, grade, birth_year)
  values (p_family,
          btrim(p ->> 'display_name'),
          v_kind,
          'learner',
          coalesce(p ->> 'ui_locale', 'en'),
          coalesce(nullif(p ->> 'avatar_emoji', ''), case when v_kind = 'child' then '🦁' else '🙂' end),
          coalesce(nullif(p ->> 'daily_minutes_goal', '')::smallint, case when v_kind = 'child' then 20 else 30 end),
          case when v_kind = 'child' then v_grade end,
          nullif(p ->> 'birth_year', '')::smallint)
  returning id into v_id;
  insert into public.profile_secrets (profile_id) values (v_id);
  return v_id;
exception
  when check_violation or not_null_violation or invalid_text_representation then
    perform app.fail('invalid_profile');
end $$;

create or replace function app.require_parent() returns uuid
language plpgsql stable security definer set search_path = '' as $$
declare v_family uuid;
begin
  select family_id into v_family from public.family_members
   where user_id = auth.uid() and role = 'parent';
  if v_family is null then perform app.fail('parent_only'); end if;
  return v_family;
end $$;

revoke all on function app.insert_learner(uuid, jsonb) from public, anon, authenticated;
revoke all on function app.require_parent() from public, anon, authenticated;

-- ---------------------------------------------------------------- API (RPC)

-- Where does the signed-in user belong?  Returns
--  {"role": "parent"|"child_device"|null, "family_id", "family_name", "profile_id", "is_anonymous"}
create or replace function public.my_context() returns jsonb
language sql stable security definer set search_path = '' as $$
  select jsonb_build_object(
    'role',         m.role,
    'family_id',    m.family_id,
    'family_name',  f.name,
    'profile_id',   m.profile_id,
    'is_anonymous', app.is_anonymous())
  from (select 1) one
  left join public.family_members m on m.user_id = auth.uid()
  left join public.families f on f.id = m.family_id
$$;

-- Parent, after confirming their email: create the family, their own profile
-- and the first learners.  p_learners: [{"display_name","kind","grade","ui_locale","avatar_emoji"}]
create or replace function public.create_family(
  p_family_name     text,
  p_parent_name     text,
  p_parent_locale   text,
  p_consent_version text,
  p_learners        jsonb default '[]'::jsonb
) returns uuid
language plpgsql security definer set search_path = '' as $$
declare
  v_uid     uuid := auth.uid();
  v_family  uuid;
  v_parent  uuid;
  v_learner jsonb;
begin
  if v_uid is null then perform app.fail('not_signed_in'); end if;
  if app.is_anonymous() then perform app.fail('parent_account_required'); end if;
  if exists (select 1 from public.family_members where user_id = v_uid) then
    perform app.fail('already_in_family');
  end if;
  if coalesce(btrim(p_consent_version), '') = '' then perform app.fail('consent_required'); end if;
  if jsonb_typeof(coalesce(p_learners, '[]'::jsonb)) <> 'array'
     or jsonb_array_length(coalesce(p_learners, '[]'::jsonb)) > 9 then
    perform app.fail('invalid_profile');
  end if;

  begin
    insert into public.families (name, created_by, consent_version)
    values (btrim(p_family_name), v_uid, p_consent_version)
    returning id into v_family;

    insert into public.profiles (family_id, display_name, kind, role, ui_locale, avatar_emoji, daily_minutes_goal)
    values (v_family, btrim(p_parent_name), 'adult', 'parent', coalesce(p_parent_locale, 'en'), '🧑‍💼', 30)
    returning id into v_parent;
  exception when check_violation or not_null_violation then
    perform app.fail('invalid_family');
  end;
  insert into public.profile_secrets (profile_id) values (v_parent);

  insert into public.family_members (user_id, family_id, role, profile_id)
  values (v_uid, v_family, 'parent', v_parent);

  for v_learner in select * from jsonb_array_elements(coalesce(p_learners, '[]'::jsonb)) loop
    perform app.insert_learner(v_family, v_learner);
  end loop;

  return v_family;
end $$;

create or replace function public.add_profile(p_profile jsonb) returns uuid
language plpgsql security definer set search_path = '' as $$
begin
  return app.insert_learner(app.require_parent(), p_profile);
end $$;

create or replace function public.delete_profile(p_profile_id uuid) returns void
language plpgsql security definer set search_path = '' as $$
declare v_family uuid := app.require_parent();
begin
  if not exists (select 1 from public.profiles
                  where id = p_profile_id and family_id = v_family and role <> 'parent') then
    perform app.fail('not_found');
  end if;
  delete from public.profiles where id = p_profile_id;   -- linked devices are removed by cascade
end $$;

-- Parent sets (or removes, with null) a 4-digit PIN for any profile in the family.
create or replace function public.set_profile_pin(p_profile_id uuid, p_pin text) returns void
language plpgsql security definer set search_path = '' as $$
declare v_family uuid := app.require_parent();
begin
  if not exists (select 1 from public.profiles where id = p_profile_id and family_id = v_family) then
    perform app.fail('not_found');
  end if;
  if p_pin is not null and p_pin !~ '^[0-9]{4}$' then perform app.fail('invalid_pin'); end if;

  insert into public.profile_secrets (profile_id, pin_hash, failed_attempts, locked_until)
  values (p_profile_id,
          case when p_pin is null then null else extensions.crypt(p_pin, extensions.gen_salt('bf', 8)) end,
          0, null)
  on conflict (profile_id) do update
    set pin_hash = excluded.pin_hash, failed_attempts = 0, locked_until = null;

  update public.profiles set has_pin = (p_pin is not null) where id = p_profile_id;
end $$;

-- Checks a PIN. 5 wrong tries lock the profile for 15 minutes.
-- Returns {"ok": bool, "attempts_left": int, "locked_until": timestamptz|null}.
-- (Returns instead of raising so the failed-attempt counter is saved.)
create or replace function public.verify_profile_pin(p_profile_id uuid, p_pin text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_family uuid := app.my_family_id();
  s        public.profile_secrets%rowtype;
  v_max    constant int := 5;
begin
  if v_family is null
     or not exists (select 1 from public.profiles where id = p_profile_id and family_id = v_family)
     or not (app.i_am_parent() or p_profile_id = app.my_device_profile_id()) then
    perform app.fail('not_found');
  end if;

  select * into s from public.profile_secrets where profile_id = p_profile_id for update;
  if not found or s.pin_hash is null then
    return jsonb_build_object('ok', true, 'attempts_left', v_max, 'locked_until', null);
  end if;

  if s.locked_until is not null and s.locked_until > now() then
    return jsonb_build_object('ok', false, 'attempts_left', 0, 'locked_until', s.locked_until);
  end if;

  if p_pin is not null and extensions.crypt(p_pin, s.pin_hash) = s.pin_hash then
    update public.profile_secrets set failed_attempts = 0, locked_until = null where profile_id = p_profile_id;
    return jsonb_build_object('ok', true, 'attempts_left', v_max, 'locked_until', null);
  end if;

  s.failed_attempts := coalesce(s.failed_attempts, 0) + 1;
  if s.failed_attempts >= v_max then
    update public.profile_secrets
       set failed_attempts = 0, locked_until = now() + interval '15 minutes'
     where profile_id = p_profile_id;
    return jsonb_build_object('ok', false, 'attempts_left', 0,
                              'locked_until', now() + interval '15 minutes');
  end if;
  update public.profile_secrets set failed_attempts = s.failed_attempts, locked_until = null
   where profile_id = p_profile_id;
  return jsonb_build_object('ok', false, 'attempts_left', v_max - s.failed_attempts, 'locked_until', null);
end $$;

-- Parent: make a one-time 6-digit code to link a child's phone. Valid 10 minutes.
-- Returns {"code": "123456", "expires_at": ...}
create or replace function public.create_pairing_code(p_profile_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_family  uuid := app.require_parent();
  v_code    text;
  v_hash    text;
  v_expires timestamptz := now() + interval '10 minutes';
  v_tries   int := 0;
begin
  if not exists (select 1 from public.profiles
                  where id = p_profile_id and family_id = v_family and kind = 'child') then
    perform app.fail('not_found');
  end if;

  -- old codes for this child stop working; tidy up long-expired ones
  delete from public.pairing_codes
   where (profile_id = p_profile_id and used_at is null) or expires_at < now() - interval '1 day';

  loop
    v_tries := v_tries + 1;
    v_code := lpad(((('x' || encode(extensions.gen_random_bytes(4), 'hex'))::bit(32)::bigint) % 1000000)::text, 6, '0');
    v_hash := encode(extensions.digest(v_code, 'sha256'), 'hex');
    exit when not exists (select 1 from public.pairing_codes
                           where code_hash = v_hash and used_at is null and expires_at > now());
    if v_tries > 20 then perform app.fail('try_later'); end if;
  end loop;

  insert into public.pairing_codes (family_id, profile_id, code_hash, created_by, expires_at)
  values (v_family, p_profile_id, v_hash, auth.uid(), v_expires);

  return jsonb_build_object('code', v_code, 'expires_at', v_expires);
end $$;

-- Child's phone (signed in anonymously): enter the code to join the family.
-- Returns {"ok": true, "profile_id", "family_id"} or {"ok": false, "error": "..."}.
-- Limits: 5 tries per device per 15 minutes, 100 failed tries per 10 minutes overall.
create or replace function public.redeem_pairing_code(p_code text, p_device_name text default null) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  c     public.pairing_codes%rowtype;
begin
  if v_uid is null then perform app.fail('not_signed_in'); end if;
  if not app.is_anonymous() then perform app.fail('child_device_only'); end if;
  if exists (select 1 from public.family_members where user_id = v_uid) then
    perform app.fail('already_linked');
  end if;

  if (select count(*) from public.pairing_attempts
       where user_id = v_uid and attempted_at > now() - interval '15 minutes') >= 5
     or (select count(*) from public.pairing_attempts
          where not success and attempted_at > now() - interval '10 minutes') >= 100 then
    return jsonb_build_object('ok', false, 'error', 'too_many_attempts');
  end if;

  select * into c from public.pairing_codes
   where code_hash = encode(extensions.digest(coalesce(btrim(p_code), ''), 'sha256'), 'hex')
     and used_at is null and expires_at > now()
   for update;

  if not found then
    insert into public.pairing_attempts (user_id, success) values (v_uid, false);
    return jsonb_build_object('ok', false, 'error', 'invalid_code');
  end if;

  update public.pairing_codes set used_at = now(), used_by = v_uid where id = c.id;
  insert into public.pairing_attempts (user_id, success) values (v_uid, true);
  insert into public.family_members (user_id, family_id, role, profile_id, device_name)
  values (v_uid, c.family_id, 'child_device', c.profile_id, left(nullif(btrim(p_device_name), ''), 60));

  return jsonb_build_object('ok', true, 'profile_id', c.profile_id, 'family_id', c.family_id);
end $$;

-- Parent: remove a child's phone from the family. That phone loses access at once.
create or replace function public.unlink_device(p_user_id uuid) returns void
language plpgsql security definer set search_path = '' as $$
declare v_family uuid := app.require_parent();
begin
  delete from public.family_members
   where user_id = p_user_id and family_id = v_family and role = 'child_device';
  if not found then perform app.fail('not_found'); end if;
end $$;

-- Any member: "I'm still here" (shown to the parent as last seen).
create or replace function public.touch_device() returns void
language sql security definer set search_path = '' as $$
  update public.family_members set last_seen_at = now() where user_id = auth.uid()
$$;

-- Only signed-in users may call the API functions.
revoke all on function public.my_context()                               from public, anon;
revoke all on function public.create_family(text, text, text, text, jsonb) from public, anon;
revoke all on function public.add_profile(jsonb)                         from public, anon;
revoke all on function public.delete_profile(uuid)                       from public, anon;
revoke all on function public.set_profile_pin(uuid, text)                from public, anon;
revoke all on function public.verify_profile_pin(uuid, text)             from public, anon;
revoke all on function public.create_pairing_code(uuid)                  from public, anon;
revoke all on function public.redeem_pairing_code(text, text)            from public, anon;
revoke all on function public.unlink_device(uuid)                        from public, anon;
revoke all on function public.touch_device()                             from public, anon;

grant execute on function public.my_context()                               to authenticated;
grant execute on function public.create_family(text, text, text, text, jsonb) to authenticated;
grant execute on function public.add_profile(jsonb)                         to authenticated;
grant execute on function public.delete_profile(uuid)                       to authenticated;
grant execute on function public.set_profile_pin(uuid, text)                to authenticated;
grant execute on function public.verify_profile_pin(uuid, text)             to authenticated;
grant execute on function public.create_pairing_code(uuid)                  to authenticated;
grant execute on function public.redeem_pairing_code(text, text)            to authenticated;
grant execute on function public.unlink_device(uuid)                        to authenticated;
grant execute on function public.touch_device()                             to authenticated;
