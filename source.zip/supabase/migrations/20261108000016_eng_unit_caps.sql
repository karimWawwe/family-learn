-- ============================================================================
--  Family Learn - English unit "English Grammar – Capitalization and Financial
--  Literacy": progress of the lesson, exercises, quiz and videos.
--
--  Needs migrations 0001-0015. Safe to run again: progress is kept.
--   * a child's phone reads and writes only its own progress (app.require_profile);
--   * the parent reads every child of the family (parent dashboard);
--   * item codes are checked, stars capped, rate limited.
-- ============================================================================

do $$
begin
  if to_regclass('public.eng_unit_events') is null then
    create table public.eng_unit_events (
      id          bigint generated always as identity primary key,
      profile_id  uuid not null references public.profiles (id) on delete cascade,
      unit        text not null check (unit = 'caps_finance'),
      item        text not null check (item ~ '^(rules|ex([1-9]|10)|card_q1|vid_(11|22|33))$'),
      kind        text not null check (kind in ('answer', 'video', 'read')),
      correct     boolean not null default true,
      stars       int not null default 0 check (stars between 0 and 3),
      created_at  timestamptz not null default now()
    );
    create index eng_unit_events_profile on public.eng_unit_events (profile_id, unit, created_at desc);
    alter table public.eng_unit_events enable row level security;
    revoke all on public.eng_unit_events from anon, authenticated;
  end if;
end $$;

-- Progress of one profile in one unit.
create or replace function public.eng_unit_state(p_profile uuid, p_unit text) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
begin
  perform app.require_profile(p_profile);
  if p_unit is distinct from 'caps_finance' then perform app.fail('not_found'); end if;
  return jsonb_build_object(
    'items', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'item', a.item, 'attempts', a.attempts, 'wrong', a.wrong,
               'solved', a.solved, 'best_stars', a.best_stars, 'last_at', a.last_at) order by a.item), '[]'::jsonb)
        from (select item, count(*) attempts, count(*) filter (where not correct) wrong,
                     bool_or(correct) solved, coalesce(max(stars) filter (where correct), 0) best_stars,
                     max(created_at) last_at
                from public.eng_unit_events
               where profile_id = p_profile and unit = p_unit and kind = 'answer'
               group by item) a),
    'videos', (
      select coalesce(jsonb_agg(distinct item), '[]'::jsonb)
        from public.eng_unit_events where profile_id = p_profile and unit = p_unit and kind = 'video'),
    'read', exists (select 1 from public.eng_unit_events
                     where profile_id = p_profile and unit = p_unit and kind = 'read'));
end $$;

-- One event: an answer (correct / wrong + stars), a video watched, or the rules read.
create or replace function public.eng_unit_log(
  p_profile uuid, p_unit text, p_item text, p_kind text, p_correct boolean, p_stars int
) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform app.require_profile(p_profile);
  if p_unit is distinct from 'caps_finance'
     or coalesce(p_item, '') !~ '^(rules|ex([1-9]|10)|card_q1|vid_(11|22|33))$'
     or coalesce(p_kind, '') not in ('answer', 'video', 'read')
     or (p_kind = 'answer' and p_item !~ '^(ex([1-9]|10)|card_q1)$')
     or (p_kind = 'video' and p_item !~ '^vid_')
     or (p_kind = 'read' and p_item <> 'rules') then
    perform app.fail('not_found');
  end if;
  if (select count(*) from public.eng_unit_events
       where profile_id = p_profile and created_at > now() - interval '1 minute') >= 40 then
    perform app.fail('rate_limited');
  end if;
  insert into public.eng_unit_events (profile_id, unit, item, kind, correct, stars)
  values (p_profile, p_unit, p_item, p_kind,
          case when p_kind = 'answer' then coalesce(p_correct, false) else true end,
          case when p_kind = 'answer' and coalesce(p_correct, false)
               then least(greatest(coalesce(p_stars, 1), 1), 3) else 0 end);
  return public.eng_unit_state(p_profile, p_unit);
end $$;

revoke all on function public.eng_unit_state(uuid, text) from public, anon;
revoke all on function public.eng_unit_log(uuid, text, text, text, boolean, int) from public, anon;
grant execute on function public.eng_unit_state(uuid, text) to authenticated;
grant execute on function public.eng_unit_log(uuid, text, text, text, boolean, int) to authenticated;

notify pgrst, 'reload schema';
