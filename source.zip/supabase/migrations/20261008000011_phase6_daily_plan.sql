-- ============================================================================
--  Family Learn - Phase 6: today's plan, spaced review, mastery, placement test
--
--  Needs migrations 0001-0010. Safe to run more than once (Supabase -> SQL Editor
--  -> paste -> Run). It never deletes progress.
--
--  * Every answered lesson question goes into the profile's REVIEW BOX:
--      wrong            -> box 1, comes back tomorrow
--      right (lesson)   -> box 3, comes back in 7 days
--    In a review: right moves it up one box (1, 3, 7, 14, 30 days), wrong sends
--    it back to box 1. After box 5 it is MASTERED and stops coming back.
--  * Existing answers are copied into the review box once (backfill).
--  * review_overview(): what is due + mastery per skill (from the review box).
--  * start_review / submit_practice_answer / finish_practice: a review session
--    of up to 10 due questions, marked on the server like lessons.
--  * start_placement / finish_practice: a short placement test per course; the
--    lessons the child already knows open at once (status "placed") and never
--    lock again. Taking it again can only move the start further on.
--  * daily_plan(): today's tasks (review, next lesson, speaking game), done or
--    not, and today's minutes against the daily goal.
--  * Streak and wallet now also count finished reviews / placement tests.
-- ============================================================================

-- ---------------------------------------------------------------- tables

create table if not exists public.review_items (
  profile_id   uuid not null references public.profiles (id) on delete cascade,
  question_id  text not null references public.questions (id) on delete cascade,
  box          smallint not null default 1 check (box between 1 and 6),   -- 6 = mastered
  due_on       date,                                                       -- null when mastered
  seen         int not null default 0,
  right_count  int not null default 0,
  lapses       int not null default 0,
  last_result  boolean,
  last_seen    timestamptz not null default now(),
  primary key (profile_id, question_id)
);
create index if not exists review_items_due on public.review_items (profile_id, due_on);

create table if not exists public.practice_sessions (
  id            uuid primary key default gen_random_uuid(),
  profile_id    uuid not null references public.profiles (id) on delete cascade,
  kind          text not null check (kind in ('review', 'placement')),
  started_by    uuid not null,
  started_at    timestamptz not null default now(),
  finished_at   timestamptz,
  question_ids  text[] not null,
  total         smallint,
  correct       smallint,
  xp            integer not null default 0,
  coins         integer not null default 0,
  result        jsonb
);
create index if not exists practice_sessions_profile on public.practice_sessions (profile_id, finished_at);

create table if not exists public.practice_answers (
  session_id   uuid not null references public.practice_sessions (id) on delete cascade,
  question_id  text not null references public.questions (id) on delete cascade,
  response     jsonb,
  is_correct   boolean not null,
  answered_at  timestamptz not null default now(),
  primary key (session_id, question_id)
);

create table if not exists public.placements (
  profile_id       uuid not null references public.profiles (id) on delete cascade,
  course_id        text not null references public.courses (id) on delete cascade,
  placed_position  smallint not null default 0,   -- lessons up to here are known
  correct          smallint,
  total            smallint,
  taken_at         timestamptz not null default now(),
  primary key (profile_id, course_id)
);

alter table public.review_items      enable row level security;
alter table public.practice_sessions enable row level security;
alter table public.practice_answers  enable row level security;
alter table public.placements        enable row level security;
revoke all on public.review_items, public.practice_sessions, public.practice_answers, public.placements
  from anon, authenticated;

-- ---------------------------------------------------------------- review box

create or replace function app.review_days(p_box int) returns int
language sql immutable set search_path = '' as $$
  select case p_box when 1 then 1 when 2 then 3 when 3 then 7 when 4 then 14 when 5 then 30 else null end
$$;

-- Records one answer in the profile's review box.
-- p_review = true when the answer comes from a review session.
create or replace function app.review_record(p_profile uuid, p_question text, p_ok boolean, p_review boolean)
returns void language plpgsql security definer set search_path = '' as $$
declare
  tz    text := app.profile_tz(p_profile);
  today date := (now() at time zone tz)::date;
  r     public.review_items%rowtype;
  nb    int;
begin
  select * into r from public.review_items where profile_id = p_profile and question_id = p_question for update;
  if not found then
    nb := case when p_ok then 3 else 1 end;
    insert into public.review_items (profile_id, question_id, box, due_on, seen, right_count, lapses, last_result)
    values (p_profile, p_question, nb, today + app.review_days(nb), 1, case when p_ok then 1 else 0 end,
            case when p_ok then 0 else 1 end, p_ok);
    return;
  end if;

  if not p_ok then
    nb := 1;
  elsif p_review or r.due_on is null or r.due_on <= today then
    nb := least(r.box + 1, 6);           -- answered right when it was due: one box up
  else
    nb := r.box;                          -- right again before it was due: keep the box
  end if;

  update public.review_items
     set box = nb,
         due_on = case when nb >= 6 then null else today + app.review_days(nb) end,
         seen = seen + 1,
         right_count = right_count + case when p_ok then 1 else 0 end,
         lapses = lapses + case when p_ok then 0 else 1 end,
         last_result = p_ok,
         last_seen = now()
   where profile_id = p_profile and question_id = p_question;
end $$;

-- Every lesson answer feeds the review box.
create or replace function app.on_lesson_answer() returns trigger
language plpgsql security definer set search_path = '' as $$
declare v_profile uuid;
begin
  select profile_id into v_profile from public.lesson_attempts where id = new.attempt_id;
  if v_profile is not null then
    perform app.review_record(v_profile, new.question_id, new.is_correct, false);
  end if;
  return new;
end $$;

drop trigger if exists answers_to_review on public.answers;
create trigger answers_to_review after insert on public.answers
  for each row execute function app.on_lesson_answer();

-- Backfill once from past answers (latest answer per question decides the box).
insert into public.review_items (profile_id, question_id, box, due_on, seen, right_count, lapses, last_result, last_seen)
select x.profile_id, x.question_id,
       case when x.last_ok then 3 else 1 end,
       case when x.last_ok then greatest((x.last_at at time zone app.profile_tz(x.profile_id))::date + 7,
                                         (now() at time zone app.profile_tz(x.profile_id))::date)
            else (now() at time zone app.profile_tz(x.profile_id))::date end,
       x.seen, x.rights, x.seen - x.rights, x.last_ok, x.last_at
  from (select a.profile_id, an.question_id,
               count(*) seen,
               count(*) filter (where an.is_correct) rights,
               (array_agg(an.is_correct order by an.answered_at desc))[1] last_ok,
               max(an.answered_at) last_at
          from public.answers an join public.lesson_attempts a on a.id = an.attempt_id
         group by a.profile_id, an.question_id) x
on conflict (profile_id, question_id) do nothing;

-- Questions that may be shown to a profile now (active content of its own courses).
create or replace function app.question_visible(p_profile uuid, p_question text) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.questions q
      join public.lessons l on l.id = q.lesson_id
     where q.id = p_question and not q.archived and not l.archived
       and l.course_id in (select c.id from app.courses_for(p_profile) c))
$$;

-- ---------------------------------------------------------------- placement opens lessons

create or replace function app.placed_position(p_profile uuid, p_course text) returns int
language sql stable security definer set search_path = '' as $$
  select coalesce((select placed_position from public.placements
                    where profile_id = p_profile and course_id = p_course), 0)
$$;

create or replace function app.lesson_unlocked(p_profile uuid, p_lesson text) returns boolean
language sql stable security definer set search_path = '' as $$
  select l.position = 1
      or l.position <= app.placed_position(p_profile, l.course_id) + 1
      or exists (
           select 1 from public.lessons prev
            where prev.course_id = l.course_id and prev.position = l.position - 1 and not prev.archived
              and app.lesson_done(p_profile, prev.id))
    from public.lessons l where l.id = p_lesson and not l.archived
$$;

-- status: done | placed | in_progress | available | locked
create or replace function public.course_map(p_profile uuid) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
begin
  perform app.require_profile(p_profile);
  return coalesce((
    select jsonb_agg(jsonb_build_object(
             'id', c.id, 'subject', c.subject, 'title', c.title, 'level_label', c.level_label,
             'units', (
               select coalesce(jsonb_agg(jsonb_build_object(
                        'id', u.id, 'title', u.title,
                        'lessons', (
                          select coalesce(jsonb_agg(jsonb_build_object(
                                   'id', l.id, 'title', l.title, 'minutes', l.minutes,
                                   'status', case
                                     when app.lesson_done(p_profile, l.id) then 'done'
                                     when exists (select 1 from public.lesson_attempts a
                                                   join public.answers an on an.attempt_id = a.id
                                                  where a.profile_id = p_profile and a.lesson_id = l.id
                                                    and a.finished_at is null) then 'in_progress'
                                     when l.position <= app.placed_position(p_profile, c.id) then 'placed'
                                     when not app.lesson_unlocked(p_profile, l.id) then 'locked'
                                     else 'available' end)
                                 order by l.position), '[]'::jsonb)
                            from public.lessons l where l.unit_id = u.id and not l.archived)
                      ) order by u.position), '[]'::jsonb)
                 from public.units u where u.course_id = c.id and not u.archived)
           ) order by c.position, c.id)
      from app.courses_for(p_profile) c), '[]'::jsonb);
end $$;

-- ---------------------------------------------------------------- streak & wallet include practice

create or replace function app.study_days(p_profile uuid, tz text) returns setof date
language sql stable security definer set search_path = '' as $$
  select distinct (finished_at at time zone tz)::date from public.lesson_attempts
   where profile_id = p_profile and finished_at is not null
  union
  select distinct (finished_at at time zone tz)::date from public.practice_sessions
   where profile_id = p_profile and finished_at is not null
$$;

create or replace function app.streak(p_profile uuid) returns int
language plpgsql stable security definer set search_path = '' as $$
declare
  tz    text := app.profile_tz(p_profile);
  today date := (now() at time zone tz)::date;
  days  date[];
  d     date;
  n     int := 0;
begin
  select array_agg(x) into days from app.study_days(p_profile, tz) x;
  if days is null then return 0; end if;
  select max(x) into d from unnest(days) x;
  if d < today - 1 then return 0; end if;
  while d = any(days) loop
    n := n + 1;
    d := d - 1;
  end loop;
  return n;
end $$;

create or replace function app.practice_minutes(p_profile uuid, d1 date, d2 date, tz text) returns numeric
language sql stable security definer set search_path = '' as $$
  select coalesce(sum(least(extract(epoch from (finished_at - started_at)) / 60.0, 30)), 0)
    from public.practice_sessions
   where profile_id = p_profile and finished_at is not null
     and (finished_at at time zone tz)::date between d1 and d2
$$;

create or replace function public.profile_wallet(p_profile uuid) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  tz    text;
  today date;
  v_xp  int;
  v_coins int;
  v_pxp int;
  v_pcoins int;
  v_stars int;
  v_done int;
  v_min numeric;
begin
  perform app.require_profile(p_profile);
  tz := app.profile_tz(p_profile);
  today := (now() at time zone tz)::date;

  select coalesce(sum(xp), 0), coalesce(sum(coins), 0) into v_xp, v_coins
    from public.lesson_attempts where profile_id = p_profile and finished_at is not null;
  select coalesce(sum(xp), 0), coalesce(sum(coins), 0) into v_pxp, v_pcoins
    from public.practice_sessions where profile_id = p_profile and finished_at is not null;
  v_xp := v_xp + v_pxp;
  v_coins := v_coins + v_pcoins;
  select coalesce(sum(best), 0), count(*) into v_stars, v_done
    from (select max(stars) best from public.lesson_attempts
           where profile_id = p_profile and finished_at is not null group by lesson_id) b;
  select coalesce(sum(app.attempt_minutes(a)), 0) into v_min
    from public.lesson_attempts a
   where a.profile_id = p_profile and a.finished_at is not null
     and (a.finished_at at time zone tz)::date = today;
  v_min := v_min + app.practice_minutes(p_profile, today, today, tz);

  return jsonb_build_object(
    'xp', v_xp, 'coins', v_coins, 'stars', v_stars,
    'level', 1 + v_xp / 500,
    'streak_days', app.streak(p_profile),
    'minutes_today', ceil(v_min)::int,
    'lessons_done', v_done);
end $$;

-- ---------------------------------------------------------------- sessions (review + placement)

create or replace function app.session_questions(p_ids text[]) returns jsonb
language sql stable security definer set search_path = '' as $$
  select coalesce(jsonb_agg(jsonb_build_object(
           'id', q.id, 'type', q.type, 'skill', q.skill,
           'prompt', q.prompt, 'hint', q.hint, 'payload', q.payload)
         order by array_position(p_ids, q.id)), '[]'::jsonb)
    from public.questions q where q.id = any(p_ids)
$$;

-- Up to p_limit due questions, weakest first. Empty list = nothing due (no session made).
create or replace function public.start_review(p_profile uuid, p_limit int default 10) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  tz    text;
  today date;
  ids   text[];
  sid   uuid;
begin
  perform app.require_profile(p_profile);
  tz := app.profile_tz(p_profile);
  today := (now() at time zone tz)::date;

  -- tidy: earlier review sessions opened but never answered
  delete from public.practice_sessions s
   where s.profile_id = p_profile and s.kind = 'review' and s.finished_at is null
     and not exists (select 1 from public.practice_answers pa where pa.session_id = s.id);

  select array_agg(question_id order by box, due_on, last_seen) into ids
    from (select r.question_id, r.box, r.due_on, r.last_seen
            from public.review_items r
           where r.profile_id = p_profile and r.due_on is not null and r.due_on <= today
             and app.question_visible(p_profile, r.question_id)
           order by r.box, r.due_on, r.last_seen
           limit greatest(1, least(coalesce(p_limit, 10), 20))) x;

  if ids is null then
    return jsonb_build_object('session_id', null, 'kind', 'review', 'questions', '[]'::jsonb);
  end if;

  insert into public.practice_sessions (profile_id, kind, started_by, question_ids)
  values (p_profile, 'review', auth.uid(), ids) returning id into sid;

  return jsonb_build_object('session_id', sid, 'kind', 'review', 'questions', app.session_questions(ids));
end $$;

-- Placement: per course, checkpoints a quarter / half / three quarters of the way
-- (one in the middle for short courses), 2 questions each, easiest course first. Speaking / listening questions are left out.
create or replace function public.start_placement(p_profile uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  ids  text[] := '{}';
  c    record;
  n    int;
  k    int;
  pos  int;
  lid  text;
  qs   text[];
  used int[];
  sid  uuid;
begin
  perform app.require_profile(p_profile);

  delete from public.practice_sessions s
   where s.profile_id = p_profile and s.kind = 'placement' and s.finished_at is null;

  for c in select * from app.courses_for(p_profile) loop
    select count(*) into n from public.lessons where course_id = c.id and not archived;
    if n < 2 then continue; end if;
    used := '{}';
    -- long courses: 3 checkpoints; short ones (under 8 lessons): 1 in the middle
    foreach k in array case when n >= 8 then array[1, 2, 3] else array[2] end loop
      pos := greatest(1, round(n * k / 4.0)::int);
      if pos = any(used) then continue; end if;
      used := used || pos;
      select l.id into lid from public.lessons l
       where l.course_id = c.id and not l.archived
       order by l.position offset pos - 1 limit 1;
      select array_agg(id order by position) into qs
        from (select q.id, q.position from public.questions q
               where q.lesson_id = lid and not q.archived and q.type not in ('speaking', 'listening')
               order by q.position limit 2) x;
      if qs is not null then ids := ids || qs; end if;
    end loop;
  end loop;

  if coalesce(array_length(ids, 1), 0) = 0 then perform app.fail('not_found'); end if;

  insert into public.practice_sessions (profile_id, kind, started_by, question_ids)
  values (p_profile, 'placement', auth.uid(), ids) returning id into sid;

  return jsonb_build_object('session_id', sid, 'kind', 'placement', 'questions', app.session_questions(ids));
end $$;

-- Marks one answer of a review / placement session. First answer counts.
create or replace function public.submit_practice_answer(p_session uuid, p_question text, p_response jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  s    public.practice_sessions%rowtype;
  q    public.questions%rowtype;
  v_ok boolean;
begin
  select * into s from public.practice_sessions where id = p_session;
  if not found or not app.can_use_profile(s.profile_id) then perform app.fail('not_found'); end if;
  if s.finished_at is not null then perform app.fail('lesson_finished'); end if;
  if not (p_question = any(s.question_ids)) then perform app.fail('not_found'); end if;

  select * into q from public.questions where id = p_question;
  if not found then perform app.fail('not_found'); end if;

  select is_correct into v_ok from public.practice_answers where session_id = p_session and question_id = p_question;
  if not found then
    v_ok := app.grade(q.type, q.answer_key, p_response);
    insert into public.practice_answers (session_id, question_id, response, is_correct)
    values (p_session, p_question, p_response, v_ok);
    if s.kind = 'review' then
      perform app.review_record(s.profile_id, p_question, v_ok, true);
    end if;
  end if;

  return jsonb_build_object('correct', v_ok, 'correct_text', q.correct_text, 'explanation', q.explanation);
end $$;

-- Closes a review / placement session. Calling it twice returns the same result.
--   review    : 5 XP per right answer (+10 when all right), 1 coin per right answer + 2
--   placement : 5 XP per right answer; opens the lessons the profile already knows
create or replace function public.finish_practice(p_session uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  s        public.practice_sessions%rowtype;
  v_total  int;
  v_right  int;
  v_res    jsonb := '[]'::jsonb;
  c        record;
  cp       record;
  placed   int;
  ok_all   boolean;
  n_less   int;
  start_t  text;
begin
  select * into s from public.practice_sessions where id = p_session for update;
  if not found or not app.can_use_profile(s.profile_id) then perform app.fail('not_found'); end if;

  if s.finished_at is null then
    v_total := coalesce(array_length(s.question_ids, 1), 0);
    select count(*) into v_right from public.practice_answers where session_id = p_session and is_correct;

    if s.kind = 'placement' then
      for c in
        select distinct l.course_id, co.title, co.position
          from unnest(s.question_ids) qid
          join public.questions q on q.id = qid
          join public.lessons l on l.id = q.lesson_id
          join public.courses co on co.id = l.course_id
         order by co.position, l.course_id
      loop
        placed := 0;
        ok_all := true;
        -- checkpoints in order; stop at the first one not fully right
        for cp in
          select l.position,
                 count(*) n,
                 count(*) filter (where coalesce(pa.is_correct, false)) ok
            from unnest(s.question_ids) qid
            join public.questions q on q.id = qid
            join public.lessons l on l.id = q.lesson_id
            left join public.practice_answers pa on pa.session_id = p_session and pa.question_id = qid
           where l.course_id = c.course_id
           group by l.position order by l.position
        loop
          if ok_all and cp.ok = cp.n then placed := cp.position; else ok_all := false; end if;
        end loop;

        insert into public.placements (profile_id, course_id, placed_position, correct, total, taken_at)
        select s.profile_id, c.course_id, placed,
               count(*) filter (where coalesce(pa.is_correct, false)), count(*), now()
          from unnest(s.question_ids) qid
          join public.questions q on q.id = qid
          join public.lessons l on l.id = q.lesson_id
          left join public.practice_answers pa on pa.session_id = p_session and pa.question_id = qid
         where l.course_id = c.course_id
        on conflict (profile_id, course_id) do update
          set placed_position = greatest(public.placements.placed_position, excluded.placed_position),
              correct = excluded.correct, total = excluded.total, taken_at = now();

        select count(*) into n_less from public.lessons where course_id = c.course_id and not archived;
        select l.title into start_t from public.lessons l
         where l.course_id = c.course_id and not l.archived
           and l.position > app.placed_position(s.profile_id, c.course_id)
         order by l.position limit 1;
        v_res := v_res || jsonb_build_array(jsonb_build_object(
                   'course_id', c.course_id, 'title', c.title,
                   'placed_position', app.placed_position(s.profile_id, c.course_id),
                   'lessons', n_less, 'start_lesson', start_t));
      end loop;
    end if;

    update public.practice_sessions
       set finished_at = now(), total = v_total, correct = v_right,
           xp = 5 * v_right + case when s.kind = 'review' and v_total > 0 and v_right = v_total then 10 else 0 end,
           coins = case when s.kind = 'review' then v_right + 2 else v_right end,
           result = v_res
     where id = p_session
     returning * into s;
  end if;

  return jsonb_build_object(
    'kind', s.kind, 'correct', s.correct, 'total', s.total, 'xp', s.xp, 'coins', s.coins,
    'stars', case when s.total = 0 then 1
                  when s.correct::numeric / s.total >= 0.9 then 3
                  when s.correct::numeric / s.total >= 0.7 then 2 else 1 end,
    'placements', coalesce(s.result, '[]'::jsonb),
    'wallet', public.profile_wallet(s.profile_id));
end $$;

-- ---------------------------------------------------------------- overview & plan

-- What is due, and mastery per skill (share of the skill's questions in the top boxes).
create or replace function public.review_overview(p_profile uuid) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  tz    text;
  today date;
begin
  perform app.require_profile(p_profile);
  tz := app.profile_tz(p_profile);
  today := (now() at time zone tz)::date;
  return jsonb_build_object(
    'due_today', (select count(*) from public.review_items r
                   where r.profile_id = p_profile and r.due_on <= today and app.question_visible(p_profile, r.question_id)),
    'due_tomorrow', (select count(*) from public.review_items r
                      where r.profile_id = p_profile and r.due_on = today + 1 and app.question_visible(p_profile, r.question_id)),
    'tracked', (select count(*) from public.review_items where profile_id = p_profile),
    'mastered', (select count(*) from public.review_items where profile_id = p_profile and box >= 6),
    'reviewed_today', exists (select 1 from public.practice_sessions
                               where profile_id = p_profile and kind = 'review' and finished_at is not null
                                 and (finished_at at time zone tz)::date = today),
    'items', (select coalesce(jsonb_agg(jsonb_build_object(
                       'question_id', x.question_id, 'prompt', x.prompt, 'skill', x.name,
                       'box', x.box, 'due_on', x.due_on, 'last_result', x.last_result, 'lapses', x.lapses)
                     order by x.box, x.due_on), '[]'::jsonb)
                from (select r.question_id, q.prompt, sk.name, r.box, r.due_on, r.last_result, r.lapses
                        from public.review_items r
                        join public.questions q on q.id = r.question_id
                        join public.skills sk on sk.code = q.skill
                       where r.profile_id = p_profile and r.due_on <= today
                         and app.question_visible(p_profile, r.question_id)
                       order by r.box, r.due_on limit 30) x),
    'skills', (select coalesce(jsonb_agg(jsonb_build_object(
                        'code', y.skill, 'name', y.name, 'questions', y.n,
                        'mastery', round(y.score, 3))
                      order by y.score), '[]'::jsonb)
                 from (select q.skill, sk.name, count(*) n,
                              avg(case when r.box >= 6 then 1.0 else (r.box - 1) / 5.0 end) score
                         from public.review_items r
                         join public.questions q on q.id = r.question_id
                         join public.skills sk on sk.code = q.skill
                        where r.profile_id = p_profile and app.question_visible(p_profile, r.question_id)
                        group by q.skill, sk.name) y));
end $$;

-- Today's plan for one profile.
create or replace function public.daily_plan(p_profile uuid) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  tz        text;
  today     date;
  v_due     int;
  v_rev     boolean;
  v_lid     text;
  v_ltitle  text;
  v_lmin    int;
  v_lcourse text;
  v_less_today boolean;
  v_speak   boolean;
  v_has_speak boolean;
  v_goal    int;
  v_min     numeric;
  v_place   boolean;
  tasks     jsonb := '[]'::jsonb;
  n_done    int := 0;
  n_tasks   int := 0;
begin
  perform app.require_profile(p_profile);
  tz := app.profile_tz(p_profile);
  today := (now() at time zone tz)::date;

  select count(*) into v_due from public.review_items r
   where r.profile_id = p_profile and r.due_on <= today and app.question_visible(p_profile, r.question_id);
  v_rev := exists (select 1 from public.practice_sessions where profile_id = p_profile and kind = 'review'
                    and finished_at is not null and (finished_at at time zone tz)::date = today);

  select l.id, l.title, l.minutes, c.title into v_lid, v_ltitle, v_lmin, v_lcourse
    from app.courses_for(p_profile) c
    join public.lessons l on l.course_id = c.id and not l.archived
   where not app.lesson_done(p_profile, l.id)
     and l.position > app.placed_position(p_profile, c.id)
     and app.lesson_unlocked(p_profile, l.id)
   order by (exists (select 1 from public.lesson_attempts a join public.answers an on an.attempt_id = a.id
                      where a.profile_id = p_profile and a.lesson_id = l.id and a.finished_at is null)) desc,
            c.position, c.id, l.position
   limit 1;
  v_less_today := exists (select 1 from public.lesson_attempts where profile_id = p_profile
                           and finished_at is not null and (finished_at at time zone tz)::date = today);

  v_has_speak := exists (select 1 from public.speak_levels where track = app.speak_track(p_profile));
  v_speak := exists (select 1 from public.speak_plays where profile_id = p_profile
                      and (created_at at time zone tz)::date = today);

  select daily_minutes_goal into v_goal from public.profiles where id = p_profile;
  select coalesce(sum(app.attempt_minutes(a)), 0) into v_min from public.lesson_attempts a
   where a.profile_id = p_profile and a.finished_at is not null and (a.finished_at at time zone tz)::date = today;
  v_min := v_min + app.practice_minutes(p_profile, today, today, tz)
                 + app.speak_minutes(p_profile, today, today, tz)
                 + app.math_minutes(p_profile, today, today, tz);

  v_place := not exists (select 1 from public.placements where profile_id = p_profile)
         and not exists (select 1 from public.lesson_attempts where profile_id = p_profile and finished_at is not null)
         and exists (select 1 from app.courses_for(p_profile));

  if v_due > 0 or v_rev then
    tasks := tasks || jsonb_build_array(jsonb_build_object(
      'kind', 'review', 'done', v_rev, 'count', least(v_due, 10), 'minutes', greatest(3, least(v_due, 10))));
    n_tasks := n_tasks + 1; if v_rev then n_done := n_done + 1; end if;
  end if;
  if v_lid is not null or v_less_today then
    tasks := tasks || jsonb_build_array(jsonb_build_object(
      'kind', 'lesson', 'done', v_less_today, 'lesson_id', v_lid, 'title', v_ltitle,
      'course', v_lcourse, 'minutes', coalesce(v_lmin, 10)));
    n_tasks := n_tasks + 1; if v_less_today then n_done := n_done + 1; end if;
  end if;
  if v_has_speak then
    tasks := tasks || jsonb_build_array(jsonb_build_object('kind', 'speak', 'done', v_speak, 'minutes', 5));
    n_tasks := n_tasks + 1; if v_speak then n_done := n_done + 1; end if;
  end if;

  return jsonb_build_object(
    'date', today,
    'tasks', tasks,
    'done', n_done,
    'total', n_tasks,
    'all_done', n_tasks > 0 and n_done = n_tasks,
    'minutes_today', ceil(v_min)::int,
    'goal_minutes', v_goal,
    'streak_days', app.streak(p_profile),
    'due_review', v_due,
    'suggest_placement', v_place);
end $$;

-- ---------------------------------------------------------------- grants

revoke all on all functions in schema app from public, anon;
grant execute on all functions in schema app to authenticated;

revoke all on function public.start_review(uuid, int)                       from public, anon;
revoke all on function public.start_placement(uuid)                         from public, anon;
revoke all on function public.submit_practice_answer(uuid, text, jsonb)     from public, anon;
revoke all on function public.finish_practice(uuid)                         from public, anon;
revoke all on function public.review_overview(uuid)                         from public, anon;
revoke all on function public.daily_plan(uuid)                              from public, anon;

grant execute on function public.start_review(uuid, int)                    to authenticated;
grant execute on function public.start_placement(uuid)                      to authenticated;
grant execute on function public.submit_practice_answer(uuid, text, jsonb)  to authenticated;
grant execute on function public.finish_practice(uuid)                      to authenticated;
grant execute on function public.review_overview(uuid)                      to authenticated;
grant execute on function public.daily_plan(uuid)                           to authenticated;

notify pgrst, 'reload schema';
