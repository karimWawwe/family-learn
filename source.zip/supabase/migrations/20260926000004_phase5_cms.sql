-- ============================================================================
--  Family Learn - Phase 5: content management (CMS)
--
--  Needs Phases 3 and 4. Run once: Supabase -> SQL Editor -> paste -> Run.
--
--  * Only invited editors (content_editors) can change content.
--  * Editors work on a DRAFT per course; learners see nothing until "Publish".
--  * Every publish is checked, saved as a numbered version, and can be restored.
--  * Removed lessons / questions are ARCHIVED (hidden), never deleted, so
--    children keep their XP, stars and history.
--
--  After this, do NOT run 20260926000003_phase4_starter_content.sql again:
--  it would overwrite changes made in the CMS.
-- ============================================================================

-- ---------------------------------------------------------------- archive instead of delete

alter table public.units     add column if not exists archived boolean not null default false;
alter table public.lessons   add column if not exists archived boolean not null default false;
alter table public.questions add column if not exists archived boolean not null default false;

-- positions only need to be unique among ACTIVE rows
alter table public.lessons   drop constraint if exists lessons_course_id_position_key;
alter table public.questions drop constraint if exists questions_lesson_id_position_key;
create unique index if not exists lessons_active_position   on public.lessons (course_id, position) where not archived;
create unique index if not exists questions_active_position on public.questions (lesson_id, position) where not archived;

-- the app's lesson functions now skip archived content

create or replace function app.lesson_unlocked(p_profile uuid, p_lesson text) returns boolean
language sql stable security definer set search_path = '' as $$
  select l.position = 1 or exists (
           select 1 from public.lessons prev
            where prev.course_id = l.course_id and prev.position = l.position - 1 and not prev.archived
              and app.lesson_done(p_profile, prev.id))
    from public.lessons l where l.id = p_lesson and not l.archived
$$;

create or replace function public.course_map(p_profile uuid) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
begin
  perform app.require_profile(p_profile);
  return coalesce((
    select jsonb_agg(jsonb_build_object(
             'id', c.id, 'subject', c.subject, 'title', c.title, 'level_label', c.level_label,
             'units', (
               select coalesce(jsonb_agg(jsonb_build_object(
                        'id', u.id, 'title', u.title,
                        'lessons', (
                          select coalesce(jsonb_agg(jsonb_build_object(
                                   'id', l.id, 'title', l.title, 'minutes', l.minutes,
                                   'status', case
                                     when app.lesson_done(p_profile, l.id) then 'done'
                                     when not app.lesson_unlocked(p_profile, l.id) then 'locked'
                                     when exists (select 1 from public.lesson_attempts a
                                                   join public.answers an on an.attempt_id = a.id
                                                  where a.profile_id = p_profile and a.lesson_id = l.id
                                                    and a.finished_at is null) then 'in_progress'
                                     else 'available' end)
                                 order by l.position), '[]'::jsonb)
                            from public.lessons l where l.unit_id = u.id and not l.archived)
                      ) order by u.position), '[]'::jsonb)
                 from public.units u where u.course_id = c.id and not u.archived)
           ) order by c.position, c.id)
      from app.courses_for(p_profile) c), '[]'::jsonb);
end $$;

create or replace function public.start_lesson(p_profile uuid, p_lesson text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_attempt uuid;
  v_title   text;
begin
  perform app.require_profile(p_profile);
  select l.title into v_title from public.lessons l
   where l.id = p_lesson and not l.archived and l.course_id in (select c.id from app.courses_for(p_profile) c);
  if v_title is null then perform app.fail('not_found'); end if;
  if not app.lesson_unlocked(p_profile, p_lesson) then perform app.fail('lesson_locked'); end if;

  -- tidy: earlier attempts of this lesson that were opened but never answered
  delete from public.lesson_attempts a
   where a.profile_id = p_profile and a.lesson_id = p_lesson and a.finished_at is null
     and not exists (select 1 from public.answers an where an.attempt_id = a.id);

  insert into public.lesson_attempts (profile_id, lesson_id, started_by)
  values (p_profile, p_lesson, auth.uid())
  returning id into v_attempt;

  return jsonb_build_object(
    'attempt_id', v_attempt,
    'lesson_id', p_lesson,
    'title', v_title,
    'questions', (select coalesce(jsonb_agg(jsonb_build_object(
                           'id', q.id, 'type', q.type, 'skill', q.skill,
                           'prompt', q.prompt, 'hint', q.hint, 'payload', q.payload)
                         order by q.position), '[]'::jsonb)
                    from public.questions q where q.lesson_id = p_lesson and not q.archived));
end $$;

create or replace function public.submit_answer(p_attempt uuid, p_question text, p_response jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  a public.lesson_attempts%rowtype;
  q public.questions%rowtype;
  v_ok boolean;
begin
  select * into a from public.lesson_attempts where id = p_attempt;
  if not found or not app.can_use_profile(a.profile_id) then perform app.fail('not_found'); end if;
  if a.finished_at is not null then perform app.fail('lesson_finished'); end if;

  select * into q from public.questions where id = p_question and lesson_id = a.lesson_id and not archived;
  if not found then perform app.fail('not_found'); end if;

  select is_correct into v_ok from public.answers where attempt_id = p_attempt and question_id = p_question;
  if not found then
    v_ok := app.grade(q.type, q.answer_key, p_response);
    insert into public.answers (attempt_id, question_id, response, is_correct)
    values (p_attempt, p_question, p_response, v_ok);
  end if;

  return jsonb_build_object('correct', v_ok, 'correct_text', q.correct_text, 'explanation', q.explanation);
end $$;

create or replace function public.finish_lesson(p_attempt uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  a       public.lesson_attempts%rowtype;
  v_total int;
  v_right int;
  v_pct   numeric;
begin
  select * into a from public.lesson_attempts where id = p_attempt for update;
  if not found or not app.can_use_profile(a.profile_id) then perform app.fail('not_found'); end if;

  if a.finished_at is null then
    select count(*) into v_total from public.questions where lesson_id = a.lesson_id and not archived;
    select count(*) into v_right from public.answers where attempt_id = p_attempt and is_correct;
    v_pct := case when v_total = 0 then 0 else v_right::numeric / v_total end;
    update public.lesson_attempts
       set finished_at = now(), total = v_total, correct = v_right,
           xp = 10 * v_right + case when v_pct >= 0.8 then 20 else 0 end,
           coins = v_right + 5,
           stars = case when v_pct >= 0.9 then 3 when v_pct >= 0.7 then 2 else 1 end
     where id = p_attempt
     returning * into a;
  end if;

  return jsonb_build_object(
    'correct', a.correct, 'total', a.total, 'xp', a.xp, 'coins', a.coins, 'stars', a.stars,
    'wallet', public.profile_wallet(a.profile_id));
end $$;

-- ---------------------------------------------------------------- editors, drafts, versions

create table public.content_editors (
  email     text primary key check (email = lower(email)),
  user_id   uuid unique references auth.users (id) on delete set null,
  added_at  timestamptz not null default now()
);

create table public.content_drafts (
  course_id   text primary key,
  doc         jsonb not null,
  updated_at  timestamptz not null default now(),
  updated_by  uuid
);

create table public.content_versions (
  id            bigint generated always as identity primary key,
  course_id     text not null,
  version       int not null,
  doc           jsonb not null,
  note          text,
  published_at  timestamptz not null default now(),
  published_by  uuid,
  unique (course_id, version)
);

alter table public.content_editors  enable row level security;
alter table public.content_drafts   enable row level security;
alter table public.content_versions enable row level security;
revoke all on public.content_editors, public.content_drafts, public.content_versions from anon, authenticated;

-- The first editor. More can be added in the SQL editor:
--   insert into public.content_editors (email) values ('someone@example.com');
insert into public.content_editors (email) values ('junaidoman09@gmail.com') on conflict do nothing;

create or replace function app.is_editor() returns boolean
language sql stable security definer set search_path = '' as $$
  select not app.is_anonymous()
     and exists (select 1 from public.content_editors where user_id = auth.uid())
$$;

create or replace function app.require_editor() returns void
language plpgsql stable security definer set search_path = '' as $$
begin
  if auth.uid() is null or not app.is_editor() then perform app.fail('editor_only'); end if;
end $$;

-- ---------------------------------------------------------------- author format <-> stored format
--
-- Author format of one question (what the CMS edits):
--   common: id, type, skill, prompt, hint, explanation
--   multiple_choice: options[], answer (index)      reading: passage, options[], answer (index)
--   true_false: answer (bool)                        typing: accepted[]
--   fill_blank: before, after, accepted[]            drag_drop: before, after, tokens[], answer (token)
--   word_problem: answer (number), unit              matching: left[], right[] (left[i] <-> right[i])
--   ordering: items[] (in the right order)
-- Stored format: payload (what the phone sees), answer_key (private), correct_text.

create or replace function app.cms_text(v jsonb) returns text
language sql immutable set search_path = '' as $$
  select case when v is null or jsonb_typeof(v) = 'null' then null else nullif(btrim(v #>> '{}'), '') end
$$;

-- Array of non-empty strings, or null if it is not one.
create or replace function app.cms_strings(v jsonb) returns text[]
language sql immutable set search_path = '' as $$
  select case when jsonb_typeof(v) = 'array'
               and not exists (select 1 from jsonb_array_elements(v) e
                                where jsonb_typeof(e) <> 'string' or btrim(e #>> '{}') = '')
              then array(select btrim(e) from jsonb_array_elements_text(v) e) end
$$;

-- Fixed shuffle (never the original order) so the phone cannot read the answer from the order.
create or replace function app.cms_shuffle(p_seed text, p_items text[]) returns text[]
language plpgsql immutable set search_path = '' as $$
declare r text[];
begin
  select array_agg(x order by md5(p_seed || '|' || x), x) into r from unnest(p_items) x;
  if r = p_items then r := r[2:] || r[1:1]; end if;
  return r;
end $$;

create or replace function app.cms_num_text(v numeric) returns text
language sql immutable set search_path = '' as $$
  select case when v = trunc(v) then trunc(v)::text else trim(trailing '0' from v::text) end
$$;

-- Problems with one question, as codes (the CMS translates them).
create or replace function app.cms_question_problems(q jsonb) returns text[]
language plpgsql stable security definer set search_path = '' as $$
declare
  t    text := q ->> 'type';
  p    text[] := '{}';
  opts text[];
  a    text[];
  b    text[];
  bad  boolean;
begin
  if jsonb_typeof(q) is distinct from 'object' then return array['bad_question']; end if;
  if t is null or t not in ('multiple_choice', 'reading', 'true_false', 'fill_blank', 'typing',
                            'drag_drop', 'word_problem', 'matching', 'ordering') then
    return array['bad_type'];
  end if;
  if app.cms_text(q -> 'prompt') is null then p := p || 'no_prompt'::text; end if;
  if app.cms_text(q -> 'skill') is null
     or not exists (select 1 from public.skills where code = q ->> 'skill') then p := p || 'bad_skill'::text; end if;

  case t
    when 'multiple_choice', 'reading' then
      opts := app.cms_strings(q -> 'options');
      if opts is null or cardinality(opts) < 2 or cardinality(opts) > 6 then p := p || 'options_2_6'::text;
      elsif (select count(distinct x) from unnest(opts) x) <> cardinality(opts) then p := p || 'options_repeat'::text;
      end if;
      bad := case when jsonb_typeof(q -> 'answer') is distinct from 'number' or opts is null then true
                  when (q ->> 'answer')::numeric <> trunc((q ->> 'answer')::numeric) then true
                  else (q ->> 'answer')::numeric < 0 or (q ->> 'answer')::numeric >= cardinality(opts) end;
      if bad then p := p || 'pick_answer'::text; end if;
      if t = 'reading' and app.cms_text(q -> 'passage') is null then p := p || 'no_passage'::text; end if;
    when 'true_false' then
      if jsonb_typeof(q -> 'answer') is distinct from 'boolean' then p := p || 'pick_answer'::text; end if;
    when 'fill_blank', 'typing' then
      a := app.cms_strings(q -> 'accepted');
      if a is null or cardinality(a) = 0 then p := p || 'no_accepted'::text; end if;
      if t = 'fill_blank' and app.cms_text(q -> 'before') is null and app.cms_text(q -> 'after') is null then
        p := p || 'no_sentence'::text;
      end if;
    when 'drag_drop' then
      a := app.cms_strings(q -> 'tokens');
      if a is null or cardinality(a) < 2 then p := p || 'tokens_2'::text;
      elsif (select count(distinct x) from unnest(a) x) <> cardinality(a) then p := p || 'options_repeat'::text;
      elsif app.cms_text(q -> 'answer') is null or not (btrim(q ->> 'answer') = any (a)) then p := p || 'pick_answer'::text;
      end if;
      if app.cms_text(q -> 'before') is null and app.cms_text(q -> 'after') is null then p := p || 'no_sentence'::text; end if;
    when 'word_problem' then
      if jsonb_typeof(q -> 'answer') is distinct from 'number' then p := p || 'answer_number'::text; end if;
    when 'matching' then
      a := app.cms_strings(q -> 'left');
      b := app.cms_strings(q -> 'right');
      if a is null or b is null or cardinality(a) < 2 or cardinality(a) > 6 or cardinality(a) <> cardinality(b) then
        p := p || 'pairs_2_6'::text;
      elsif (select count(distinct x) from unnest(b) x) <> cardinality(b)
         or (select count(distinct x) from unnest(a) x) <> cardinality(a) then p := p || 'options_repeat'::text;
      end if;
    when 'ordering' then
      a := app.cms_strings(q -> 'items');
      if a is null or cardinality(a) < 2 or cardinality(a) > 8 then p := p || 'items_2_8'::text;
      elsif (select count(distinct x) from unnest(a) x) <> cardinality(a) then p := p || 'options_repeat'::text;
      end if;
  end case;
  return p;
end $$;

-- Author question -> {type, skill, prompt, hint, explanation, payload, answer_key, correct_text}.
-- Only called on questions without problems.
create or replace function app.cms_compile_question(q jsonb, p_qid text) returns jsonb
language plpgsql immutable set search_path = '' as $$
declare
  t      text := q ->> 'type';
  opts   text[];
  a      text[];
  b      text[];
  shown  text[];
  pay    jsonb;
  k      jsonb;
  ct     text;
  v      numeric;
  i      int;
  m      jsonb := '{}'::jsonb;
begin
  case t
    when 'multiple_choice', 'reading' then
      opts := app.cms_strings(q -> 'options');
      i := (q ->> 'answer')::int;
      pay := jsonb_build_object('options', to_jsonb(opts));
      if t = 'reading' then pay := pay || jsonb_build_object('passage', app.cms_text(q -> 'passage')); end if;
      k := jsonb_build_object('index', i);
      ct := opts[i + 1];
    when 'true_false' then
      pay := '{}'::jsonb;
      k := jsonb_build_object('value', q -> 'answer');
      ct := case when (q ->> 'answer')::boolean then 'True' else 'False' end;
    when 'fill_blank', 'typing' then
      a := app.cms_strings(q -> 'accepted');
      pay := case when t = 'fill_blank'
                  then jsonb_build_object('before', coalesce(q ->> 'before', ''), 'after', coalesce(q ->> 'after', ''))
                  else '{}'::jsonb end;
      k := jsonb_build_object('accepted', to_jsonb(a));
      ct := a[1];
    when 'drag_drop' then
      a := app.cms_strings(q -> 'tokens');
      pay := jsonb_build_object('before', coalesce(q ->> 'before', ''), 'after', coalesce(q ->> 'after', ''),
                                'tokens', to_jsonb(a));
      k := jsonb_build_object('token', btrim(q ->> 'answer'));
      ct := btrim(q ->> 'answer');
    when 'word_problem' then
      v := (q ->> 'answer')::numeric;
      pay := jsonb_build_object('unit', app.cms_text(q -> 'unit'));
      k := jsonb_build_object('value', v);
      ct := btrim(app.cms_num_text(v) || coalesce(' ' || app.cms_text(q -> 'unit'), ''));
    when 'matching' then
      a := app.cms_strings(q -> 'left');
      b := app.cms_strings(q -> 'right');
      shown := app.cms_shuffle(p_qid, b);
      for i in 1 .. cardinality(b) loop
        m := m || jsonb_build_object((i - 1)::text, array_position(shown, b[i]) - 1);
      end loop;
      pay := jsonb_build_object('left', to_jsonb(a), 'right', to_jsonb(shown));
      k := jsonb_build_object('pairs', cardinality(a), 'map', m);
      ct := (select string_agg(a[j] || ' = ' || b[j], ', ' order by j) from generate_subscripts(a, 1) j);
    when 'ordering' then
      a := app.cms_strings(q -> 'items');
      pay := jsonb_build_object('items', to_jsonb(app.cms_shuffle(p_qid, a)));
      k := jsonb_build_object('order', to_jsonb(a));
      ct := array_to_string(a, ' > ');
  end case;
  return jsonb_build_object(
    'type', t, 'skill', q ->> 'skill', 'prompt', btrim(q ->> 'prompt'),
    'hint', app.cms_text(q -> 'hint'), 'explanation', app.cms_text(q -> 'explanation'),
    'payload', pay, 'answer_key', k, 'correct_text', ct);
end $$;

-- Stored question -> author format.
create or replace function app.cms_question_to_author(q public.questions) returns jsonb
language plpgsql immutable set search_path = '' as $$
declare
  r   jsonb := jsonb_build_object('id', q.id, 'type', q.type, 'skill', q.skill, 'prompt', q.prompt);
  n   int;
begin
  if q.hint is not null then r := r || jsonb_build_object('hint', q.hint); end if;
  if q.explanation is not null then r := r || jsonb_build_object('explanation', q.explanation); end if;
  case q.type
    when 'multiple_choice', 'reading', 'listening' then
      r := r || jsonb_build_object('options', q.payload -> 'options', 'answer', q.answer_key -> 'index');
      if q.type = 'reading' then r := r || jsonb_build_object('passage', q.payload -> 'passage'); end if;
    when 'true_false' then
      r := r || jsonb_build_object('answer', q.answer_key -> 'value');
    when 'fill_blank' then
      r := r || jsonb_build_object('before', q.payload -> 'before', 'after', q.payload -> 'after',
                                   'accepted', q.answer_key -> 'accepted');
    when 'typing' then
      r := r || jsonb_build_object('accepted', q.answer_key -> 'accepted');
    when 'drag_drop' then
      r := r || jsonb_build_object('before', q.payload -> 'before', 'after', q.payload -> 'after',
                                   'tokens', q.payload -> 'tokens', 'answer', q.answer_key -> 'token');
    when 'word_problem' then
      r := r || jsonb_build_object('answer', q.answer_key -> 'value', 'unit', q.payload -> 'unit');
    when 'matching' then
      n := (q.answer_key ->> 'pairs')::int;
      r := r || jsonb_build_object(
        'left', q.payload -> 'left',
        'right', (select jsonb_agg(q.payload -> 'right' -> ((q.answer_key -> 'map' ->> i::text)::int) order by i)
                    from generate_series(0, n - 1) i));
    when 'ordering' then
      r := r || jsonb_build_object('items', q.answer_key -> 'order');
    else
      r := r || jsonb_build_object('payload', q.payload, 'answer_key', q.answer_key);
  end case;
  return r;
end $$;

-- A published course as an author document.
create or replace function app.cms_doc_from_live(p_course text) returns jsonb
language sql stable security definer set search_path = '' as $$
  select jsonb_build_object(
    'id', c.id, 'subject', c.subject, 'title', c.title, 'level_label', c.level_label,
    'audience', c.audience, 'grade_min', c.grade_min, 'grade_max', c.grade_max,
    'position', c.position, 'published', c.published,
    'units', coalesce((
      select jsonb_agg(jsonb_build_object(
               'id', u.id, 'title', u.title,
               'lessons', coalesce((
                 select jsonb_agg(jsonb_build_object(
                          'id', l.id, 'title', l.title, 'minutes', l.minutes,
                          'questions', coalesce((
                            select jsonb_agg(app.cms_question_to_author(q) order by q.position)
                              from public.questions q where q.lesson_id = l.id and not q.archived), '[]'::jsonb))
                        order by l.position)
                   from public.lessons l where l.unit_id = u.id and not l.archived), '[]'::jsonb))
             order by u.position)
        from public.units u where u.course_id = c.id and not u.archived), '[]'::jsonb))
  from public.courses c where c.id = p_course
$$;

-- All problems in a course document: [{"path": "U1 L2 Q3", "code": "..."}].
create or replace function app.cms_validate(doc jsonb) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  errs  jsonb := '[]'::jsonb;
  cid   text := doc ->> 'id';
  u     jsonb;
  l     jsonb;
  q     jsonb;
  ui    int := 0;
  li    int;
  qi    int;
  code  text;
  ids   text[] := '{}';
  path  text;
  gmin  int;
  gmax  int;
  nlessons int := 0;
  bad   boolean;
begin
  if jsonb_typeof(doc) is distinct from 'object' then return '[{"path":"","code":"bad_document"}]'::jsonb; end if;
  if cid is null or cid !~ '^[a-z0-9][a-z0-9-]{1,39}$' then
    errs := errs || jsonb_build_object('path', 'course', 'code', 'bad_course_id');
  end if;
  if coalesce(doc ->> 'subject', '') not in ('english', 'math', 'business') then
    errs := errs || jsonb_build_object('path', 'course', 'code', 'bad_subject');
  end if;
  if app.cms_text(doc -> 'title') is null then errs := errs || jsonb_build_object('path', 'course', 'code', 'no_title'); end if;
  if coalesce(doc ->> 'audience', '') not in ('child', 'adult') then
    errs := errs || jsonb_build_object('path', 'course', 'code', 'bad_audience');
  elsif doc ->> 'audience' = 'child' then
    begin
      gmin := (doc ->> 'grade_min')::int;
      gmax := (doc ->> 'grade_max')::int;
    exception when others then gmin := null;
    end;
    if gmin is null or gmax is null or gmin < 1 or gmax > 12 or gmin > gmax then
      errs := errs || jsonb_build_object('path', 'course', 'code', 'bad_grades');
    end if;
  end if;
  if jsonb_typeof(doc -> 'units') is distinct from 'array' then
    return errs || jsonb_build_object('path', 'course', 'code', 'no_units');
  end if;

  for u in select * from jsonb_array_elements(doc -> 'units') loop
    ui := ui + 1;
    if app.cms_text(u -> 'title') is null then errs := errs || jsonb_build_object('path', 'U' || ui, 'code', 'no_title'); end if;
    if u ->> 'id' is not null then
      if u ->> 'id' = any (ids) then errs := errs || jsonb_build_object('path', 'U' || ui, 'code', 'duplicate_id'); end if;
      ids := ids || (u ->> 'id');
      if exists (select 1 from public.units x where x.id = u ->> 'id' and x.course_id <> cid) then
        errs := errs || jsonb_build_object('path', 'U' || ui, 'code', 'id_in_other_course');
      end if;
    end if;
    li := 0;
    for l in select * from jsonb_array_elements(coalesce(u -> 'lessons', '[]'::jsonb)) loop
      li := li + 1;
      nlessons := nlessons + 1;
      path := 'U' || ui || ' L' || li;
      if app.cms_text(l -> 'title') is null then errs := errs || jsonb_build_object('path', path, 'code', 'no_title'); end if;
      bad := case when jsonb_typeof(l -> 'minutes') is distinct from 'number' then true
                  else (l ->> 'minutes')::numeric not between 1 and 60
                       or (l ->> 'minutes')::numeric <> trunc((l ->> 'minutes')::numeric) end;
      if bad then
        errs := errs || jsonb_build_object('path', path, 'code', 'bad_minutes');
      end if;
      if l ->> 'id' is not null then
        if l ->> 'id' = any (ids) then errs := errs || jsonb_build_object('path', path, 'code', 'duplicate_id'); end if;
        ids := ids || (l ->> 'id');
        if exists (select 1 from public.lessons x where x.id = l ->> 'id' and x.course_id <> cid) then
          errs := errs || jsonb_build_object('path', path, 'code', 'id_in_other_course');
        end if;
      end if;
      if jsonb_array_length(coalesce(l -> 'questions', '[]'::jsonb)) = 0 then
        errs := errs || jsonb_build_object('path', path, 'code', 'no_questions');
      end if;
      qi := 0;
      for q in select * from jsonb_array_elements(coalesce(l -> 'questions', '[]'::jsonb)) loop
        qi := qi + 1;
        foreach code in array app.cms_question_problems(q) loop
          errs := errs || jsonb_build_object('path', path || ' Q' || qi, 'code', code);
        end loop;
        if q ->> 'id' is not null then
          if q ->> 'id' = any (ids) then errs := errs || jsonb_build_object('path', path || ' Q' || qi, 'code', 'duplicate_id'); end if;
          ids := ids || (q ->> 'id');
          if exists (select 1 from public.questions x join public.lessons xl on xl.id = x.lesson_id
                      where x.id = q ->> 'id' and xl.course_id <> cid) then
            errs := errs || jsonb_build_object('path', path || ' Q' || qi, 'code', 'id_in_other_course');
          end if;
        end if;
      end loop;
    end loop;
  end loop;
  if jsonb_typeof(doc -> 'published') not in ('boolean', 'null') then
    errs := errs || jsonb_build_object('path', 'course', 'code', 'bad_document');
  elsif nlessons = 0 and coalesce((doc ->> 'published')::boolean, true) then
    errs := errs || jsonb_build_object('path', 'course', 'code', 'no_lessons');
  end if;
  return errs;
end $$;

create or replace function app.cms_new_id(p_prefix text) returns text
language sql volatile set search_path = '' as $$
  select p_prefix || substr(md5(random()::text || clock_timestamp()::text), 1, 8)
$$;

revoke all on all functions in schema app from public, anon;
grant execute on all functions in schema app to authenticated;

-- ---------------------------------------------------------------- CMS API (editors only)

-- Links the signed-in account to its editor invitation (by e-mail). Returns {"editor": bool}.
create or replace function public.cms_claim_editor() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_email text := lower(auth.jwt() ->> 'email');
begin
  if auth.uid() is null or app.is_anonymous() then return jsonb_build_object('editor', false); end if;
  update public.content_editors set user_id = auth.uid()
   where email = v_email and user_id is null;
  return jsonb_build_object('editor', app.is_editor(), 'email', v_email);
end $$;

create or replace function public.cms_list_courses() returns jsonb
language plpgsql stable security definer set search_path = '' as $$
begin
  perform app.require_editor();
  return coalesce((
    select jsonb_agg(x order by x ->> 'position', x ->> 'id') from (
      select jsonb_build_object(
               'id', coalesce(c.id, d.course_id),
               'title', coalesce(d.doc ->> 'title', c.title),
               'subject', coalesce(d.doc ->> 'subject', c.subject),
               'audience', coalesce(d.doc ->> 'audience', c.audience),
               'position', lpad(coalesce(d.doc ->> 'position', c.position::text, '99'), 4, '0'),
               'live', c.id is not null,
               'published', coalesce(c.published, false),
               'has_draft', d.course_id is not null,
               'draft_updated_at', d.updated_at,
               'version', (select max(v.version) from public.content_versions v where v.course_id = coalesce(c.id, d.course_id)),
               'lessons', (select count(*) from public.lessons l where l.course_id = c.id and not l.archived),
               'questions', (select count(*) from public.questions q join public.lessons l on l.id = q.lesson_id
                              where l.course_id = c.id and not l.archived and not q.archived)) x
        from public.courses c full join public.content_drafts d on d.course_id = c.id) s), '[]'::jsonb);
end $$;

-- The course to edit: the draft if there is one, else the published course.
create or replace function public.cms_get_course(p_course text) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  d   public.content_drafts%rowtype;
  doc jsonb;
begin
  perform app.require_editor();
  select * into d from public.content_drafts where course_id = p_course;
  doc := coalesce(d.doc, app.cms_doc_from_live(p_course));
  if doc is null then perform app.fail('not_found'); end if;
  return jsonb_build_object(
    'doc', doc,
    'source', case when d.course_id is null then 'live' else 'draft' end,
    'draft_updated_at', d.updated_at,
    'problems', app.cms_validate(doc),
    'versions', coalesce((select jsonb_agg(jsonb_build_object('version', v.version, 'note', v.note,
                                                               'published_at', v.published_at) order by v.version desc)
                            from public.content_versions v where v.course_id = p_course), '[]'::jsonb));
end $$;

-- Saves a draft (nothing changes for learners). Returns the problems found (saving is still allowed).
create or replace function public.cms_save_draft(p_course text, p_doc jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform app.require_editor();
  if jsonb_typeof(p_doc) is distinct from 'object' or p_doc ->> 'id' is distinct from p_course then perform app.fail('bad_document'); end if;
  if p_course !~ '^[a-z0-9][a-z0-9-]{1,39}$' then perform app.fail('bad_course_id'); end if;
  if octet_length(p_doc::text) > 2000000 then perform app.fail('too_large'); end if;
  insert into public.content_drafts (course_id, doc, updated_at, updated_by)
  values (p_course, p_doc, now(), auth.uid())
  on conflict (course_id) do update set doc = excluded.doc, updated_at = now(), updated_by = auth.uid();
  return jsonb_build_object('saved_at', now(), 'problems', app.cms_validate(p_doc));
end $$;

create or replace function public.cms_discard_draft(p_course text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform app.require_editor();
  delete from public.content_drafts where course_id = p_course;
end $$;

-- Publishes the draft: checks everything, then updates the live course in one step.
-- Lessons and questions removed from the course are archived (hidden), not deleted,
-- so learners keep their XP and history. Returns {"ok": true, "version": n} or {"ok": false, "problems": [...]}.
create or replace function public.cms_publish(p_course text, p_note text default null) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  doc     jsonb;
  errs    jsonb;
  u       jsonb;
  l       jsonb;
  q       jsonb;
  c       jsonb;
  ui      int := 0;
  lpos    int := 0;
  qi      int;
  uid     text;
  lid     text;
  qid     text;
  keep_u  text[] := '{}';
  keep_l  text[] := '{}';
  keep_q  text[] := '{}';
  v_ver   int;
begin
  perform app.require_editor();
  select d.doc into doc from public.content_drafts d where d.course_id = p_course for update;
  if doc is null then perform app.fail('no_draft'); end if;

  -- give every unit / lesson / question a permanent id first
  doc := jsonb_set(doc, '{units}', coalesce((
    select jsonb_agg(
             jsonb_set(uu || jsonb_build_object('id', coalesce(uu ->> 'id', app.cms_new_id(p_course || '.u-'))),
                       '{lessons}', coalesce((
                         select jsonb_agg(
                                  jsonb_set(ll || jsonb_build_object('id', coalesce(ll ->> 'id', app.cms_new_id(p_course || '.l-'))),
                                            '{questions}', coalesce((
                                              select jsonb_agg(qq || jsonb_build_object('id', coalesce(qq ->> 'id', app.cms_new_id(p_course || '.q-')))
                                                               order by qo)
                                                from jsonb_array_elements(ll -> 'questions') with ordinality qx(qq, qo)), '[]'::jsonb))
                                  order by lo)
                           from jsonb_array_elements(uu -> 'lessons') with ordinality lx(ll, lo)), '[]'::jsonb))
             order by uo)
      from jsonb_array_elements(doc -> 'units') with ordinality ux(uu, uo)), '[]'::jsonb));

  errs := app.cms_validate(doc);
  if jsonb_array_length(errs) > 0 then
    return jsonb_build_object('ok', false, 'problems', errs);
  end if;

  insert into public.courses (id, subject, title, level_label, audience, grade_min, grade_max, position, published)
  values (p_course, doc ->> 'subject', btrim(doc ->> 'title'), coalesce(app.cms_text(doc -> 'level_label'), ''),
          doc ->> 'audience',
          case when doc ->> 'audience' = 'child' then (doc ->> 'grade_min')::smallint end,
          case when doc ->> 'audience' = 'child' then (doc ->> 'grade_max')::smallint end,
          case when jsonb_typeof(doc -> 'position') = 'number' then least(greatest((doc ->> 'position')::numeric, 0), 999)::smallint else 50 end,
          coalesce((doc ->> 'published')::boolean, true))
  on conflict (id) do update set subject = excluded.subject, title = excluded.title, level_label = excluded.level_label,
     audience = excluded.audience, grade_min = excluded.grade_min, grade_max = excluded.grade_max,
     position = excluded.position, published = excluded.published;

  -- move active positions out of the way (positions are unique among active rows)
  update public.lessons set position = position + 10000 where course_id = p_course and not archived;
  update public.questions set position = position + 10000
   where not archived and lesson_id in (select id from public.lessons where course_id = p_course);

  for u in select * from jsonb_array_elements(doc -> 'units') loop
    ui := ui + 1;
    uid := u ->> 'id';
    keep_u := keep_u || uid;
    insert into public.units (id, course_id, position, title, archived)
    values (uid, p_course, ui, btrim(u ->> 'title'), false)
    on conflict (id) do update set course_id = excluded.course_id, position = excluded.position,
       title = excluded.title, archived = false;

    for l in select * from jsonb_array_elements(coalesce(u -> 'lessons', '[]'::jsonb)) loop
      lpos := lpos + 1;
      lid := l ->> 'id';
      keep_l := keep_l || lid;
      insert into public.lessons (id, unit_id, course_id, position, title, minutes, archived)
      values (lid, uid, p_course, lpos, btrim(l ->> 'title'), (l ->> 'minutes')::smallint, false)
      on conflict (id) do update set unit_id = excluded.unit_id, course_id = excluded.course_id,
         position = excluded.position, title = excluded.title, minutes = excluded.minutes, archived = false;

      qi := 0;
      for q in select * from jsonb_array_elements(coalesce(l -> 'questions', '[]'::jsonb)) loop
        qi := qi + 1;
        qid := q ->> 'id';
        keep_q := keep_q || qid;
        c := app.cms_compile_question(q, qid);
        insert into public.questions (id, lesson_id, position, type, skill, prompt, hint, payload, answer_key,
                                      correct_text, explanation, archived)
        values (qid, lid, qi, c ->> 'type', c ->> 'skill', c ->> 'prompt', c ->> 'hint', c -> 'payload',
                c -> 'answer_key', c ->> 'correct_text', c ->> 'explanation', false)
        on conflict (id) do update set lesson_id = excluded.lesson_id, position = excluded.position,
           type = excluded.type, skill = excluded.skill, prompt = excluded.prompt, hint = excluded.hint,
           payload = excluded.payload, answer_key = excluded.answer_key, correct_text = excluded.correct_text,
           explanation = excluded.explanation, archived = false;
      end loop;
    end loop;
  end loop;

  -- anything left out of the document is hidden (history is kept)
  update public.questions set archived = true
   where not archived and not (id = any (keep_q))
     and lesson_id in (select id from public.lessons where course_id = p_course);
  update public.lessons set archived = true where course_id = p_course and not archived and not (id = any (keep_l));
  update public.units set archived = true where course_id = p_course and not archived and not (id = any (keep_u));

  select coalesce(max(version), 0) + 1 into v_ver from public.content_versions where course_id = p_course;
  insert into public.content_versions (course_id, version, doc, note, published_by)
  values (p_course, v_ver, app.cms_doc_from_live(p_course), nullif(btrim(p_note), ''), auth.uid());
  delete from public.content_drafts where course_id = p_course;

  return jsonb_build_object('ok', true, 'version', v_ver);
end $$;

-- Puts an older published version back into the draft (publish it to make it live again).
create or replace function public.cms_restore_version(p_course text, p_version int) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_doc jsonb;
begin
  perform app.require_editor();
  select doc into v_doc from public.content_versions where course_id = p_course and version = p_version;
  if v_doc is null then perform app.fail('not_found'); end if;
  return public.cms_save_draft(p_course, v_doc);
end $$;

create or replace function public.cms_skills() returns jsonb
language plpgsql stable security definer set search_path = '' as $$
begin
  perform app.require_editor();
  return coalesce((select jsonb_agg(jsonb_build_object('code', code, 'name', name, 'subject', subject) order by code)
                     from public.skills), '[]'::jsonb);
end $$;

create or replace function public.cms_save_skill(p_code text, p_name text, p_subject text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform app.require_editor();
  if p_code !~ '^[a-z][a-z0-9_]*(\.[a-z0-9_]+){1,3}$' then perform app.fail('bad_skill_code'); end if;
  if coalesce(btrim(p_name), '') = '' then perform app.fail('no_title'); end if;
  insert into public.skills (code, name, subject) values (p_code, btrim(p_name), coalesce(nullif(btrim(p_subject), ''), split_part(p_code, '.', 1)))
  on conflict (code) do update set name = excluded.name, subject = excluded.subject;
end $$;

revoke all on function public.cms_claim_editor()                  from public, anon;
revoke all on function public.cms_list_courses()                  from public, anon;
revoke all on function public.cms_get_course(text)                from public, anon;
revoke all on function public.cms_save_draft(text, jsonb)         from public, anon;
revoke all on function public.cms_discard_draft(text)             from public, anon;
revoke all on function public.cms_publish(text, text)             from public, anon;
revoke all on function public.cms_restore_version(text, int)      from public, anon;
revoke all on function public.cms_skills()                        from public, anon;
revoke all on function public.cms_save_skill(text, text, text)    from public, anon;

grant execute on function public.cms_claim_editor()                  to authenticated;
grant execute on function public.cms_list_courses()                  to authenticated;
grant execute on function public.cms_get_course(text)                to authenticated;
grant execute on function public.cms_save_draft(text, jsonb)         to authenticated;
grant execute on function public.cms_discard_draft(text)             to authenticated;
grant execute on function public.cms_publish(text, text)             to authenticated;
grant execute on function public.cms_restore_version(text, int)      to authenticated;
grant execute on function public.cms_skills()                        to authenticated;
grant execute on function public.cms_save_skill(text, text, text)    to authenticated;
