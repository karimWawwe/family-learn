// Family Learn - speech bridge for the speaking game.
// Speech recognition (Web Speech API), text-to-speech and small sound
// effects made with Web Audio (no sound files needed).
// Used from Dart: lib/core/speech/speech_engine_web.dart
(function () {
  'use strict';
  var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  var rec = null;          // current recognition
  var ctx = null;          // AudioContext for effects
  var voice = null;
  var wakeWanted = false, wakePending = false;

  function emit(cb, type, data) {
    try { cb(type, data == null ? '' : String(data)); } catch (e) { /* ignore */ }
  }

  function pickVoice(lang) {
    if (!('speechSynthesis' in window)) return null;
    var list = window.speechSynthesis.getVoices() || [];
    if (!list.length) return null;
    var want = (lang || 'en-US').toLowerCase();
    var prefix = want.split('-')[0];
    var same = list.filter(function (v) { return (v.lang || '').toLowerCase().replace('_', '-') === want; });
    var en = same.length ? same : list.filter(function (v) { return (v.lang || '').toLowerCase().indexOf(prefix) === 0; });
    if (!en.length) return null;
    var nice = prefix === 'ar'
      ? ['Majed', 'Maged', 'Tarik', 'Laila', 'Google العربية', 'Microsoft Hamed', 'Microsoft Zariyah', 'Microsoft Naayf']
      : ['Samantha', 'Google US English', 'Microsoft Aria', 'Microsoft Jenny', 'Alex', 'Karen', 'Daniel'];
    for (var i = 0; i < nice.length; i++) {
      for (var j = 0; j < en.length; j++) if (en[j].name.indexOf(nice[i]) === 0) return en[j];
    }
    var local = en.filter(function (v) { return v.localService; });
    return (local[0] || en[0] || null);
  }
  if ('speechSynthesis' in window) {
    try { window.speechSynthesis.onvoiceschanged = function () { voice = pickVoice('en-US'); }; } catch (e) {}
    voice = pickVoice('en-US');
  }

  function audio() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      try { ctx = new AC(); } catch (e) { return null; }
    }
    if (ctx.state === 'suspended') { try { ctx.resume(); } catch (e) {} }
    return ctx;
  }

  function tone(freq, start, dur, type, gain) {
    var a = audio(); if (!a) return;
    var t0 = a.currentTime + start;
    var o = a.createOscillator();
    var g = a.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, t0);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain || 0.18, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(a.destination);
    o.start(t0); o.stop(t0 + dur + 0.05);
  }

  var SFX = {
    success: function () { [523.25, 659.25, 783.99, 1046.5].forEach(function (f, i) { tone(f, i * 0.09, 0.28, 'triangle', 0.2); }); },
    star: function () { [1318.5, 1760, 2093].forEach(function (f, i) { tone(f, i * 0.06, 0.22, 'sine', 0.12); }); },
    tryAgain: function () { tone(440, 0, 0.18, 'sine', 0.14); tone(392, 0.16, 0.3, 'sine', 0.12); },
    levelUp: function () {
      [523.25, 659.25, 783.99, 1046.5, 783.99, 1046.5, 1318.5].forEach(function (f, i) { tone(f, i * 0.11, 0.3, 'triangle', 0.2); });
    },
    tap: function () { tone(880, 0, 0.06, 'sine', 0.08); },
    start: function () { tone(660, 0, 0.09, 'sine', 0.12); tone(990, 0.08, 0.12, 'sine', 0.12); }
  };

  window.flSpeech = {
    recognitionSupported: function () { return !!SR; },
    ttsSupported: function () { return 'speechSynthesis' in window; },

    // One listening attempt. cb(type, data):
    //  start | sound | result (JSON {final, alts:[{t,c}]}) | error (code) | end
    // continuous=true keeps listening through short pauses ("I can ... jump");
    // the app decides when to stop (after a short silence).
    start: function (lang, cb, continuous) {
      if (!SR) { emit(cb, 'error', 'not-supported'); emit(cb, 'end'); return; }
      if (rec) { try { rec.onend = null; rec.abort(); } catch (e) {} rec = null; }
      try { if ('speechSynthesis' in window) window.speechSynthesis.cancel(); } catch (e) {}
      var r = new SR();
      rec = r;
      r.lang = lang || 'en-US';
      r.continuous = !!continuous;
      r.interimResults = true;
      r.maxAlternatives = 5;
      var ended = false;
      function finish() {
        if (ended) return; ended = true;
        if (rec === r) rec = null;
        emit(cb, 'end');
      }
      r.onstart = function () { emit(cb, 'start'); };
      r.onsoundstart = function () { emit(cb, 'sound'); };
      r.onspeechstart = function () { emit(cb, 'sound'); };
      r.onresult = function (ev) {
        // Join all result segments; alternatives come from the last segment.
        var isFinal = true, prefix = '';
        for (var i = 0; i < ev.results.length; i++) {
          if (!ev.results[i].isFinal) isFinal = false;
          if (i < ev.results.length - 1) prefix += ev.results[i][0].transcript + ' ';
        }
        var last = ev.results[ev.results.length - 1];
        var alts = [];
        for (var k = 0; k < last.length; k++) {
          alts.push({ t: (prefix + last[k].transcript).trim(), c: last[k].confidence || 0 });
        }
        emit(cb, 'result', JSON.stringify({ final: isFinal, alts: alts }));
      };
      r.onnomatch = function () { emit(cb, 'error', 'no-match'); };
      r.onerror = function (ev) { emit(cb, 'error', (ev && ev.error) || 'unknown'); };
      r.onend = finish;
      try { r.start(); } catch (e) { emit(cb, 'error', 'start-failed'); finish(); }
    },
    stop: function () { if (rec) { try { rec.stop(); } catch (e) {} } },
    abort: function () {
      if (rec) { var r = rec; rec = null; try { r.onend = null; r.abort(); } catch (e) {} }
    },

    speak: function (text, lang, rate, pitch, onEnd) {
      var done = false;
      function end() { if (!done) { done = true; try { onEnd(); } catch (e) {} } }
      if (!('speechSynthesis' in window)) { end(); return; }
      try {
        var s = window.speechSynthesis;
        s.cancel();
        var u = new SpeechSynthesisUtterance(text);
        u.lang = lang || 'en-US';
        u.rate = rate || 0.85;
        u.pitch = pitch || 1.05;
        var v = /^en/i.test(u.lang) ? (voice || pickVoice(u.lang)) : pickVoice(u.lang);
        if (v) u.voice = v;
        u.onend = end;
        u.onerror = end;
        s.speak(u);
      } catch (e) { end(); }
    },
    cancelSpeak: function () { try { window.speechSynthesis.cancel(); } catch (e) {} },

    sfx: function (kind) { try { (SFX[kind] || SFX.tap)(); } catch (e) {} },

    hasVoice: function (lang) { return !!pickVoice(lang); },

    // Keeps the screen on while a story plays (Screen Wake Lock API, where supported).
    keepAwake: function (on) {
      wakeWanted = !!on;
      try {
        if (on) {
          if (!navigator.wakeLock || window.__flWake || wakePending) return;
          wakePending = true;
          navigator.wakeLock.request('screen').then(function (l) {
            wakePending = false;
            if (!wakeWanted) { l.release(); return; }
            window.__flWake = l;
            l.addEventListener('release', function () { window.__flWake = null; });
          }).catch(function () { wakePending = false; });
        } else if (window.__flWake) {
          window.__flWake.release(); window.__flWake = null;
        }
      } catch (e) {}
    },

    // Call inside a tap so iOS allows sound later on.
    unlock: function () {
      var a = audio();
      if (a) { try { var b = a.createBuffer(1, 1, 22050); var src = a.createBufferSource(); src.buffer = b; src.connect(a.destination); src.start(0); } catch (e) {} }
    }
  };
})();
