import 'package:family_learn/app.dart';
import 'package:family_learn/data/auth/demo_auth_repository.dart';
import 'package:family_learn/data/learning/demo_learning_repository.dart';
import 'package:family_learn/state/account.dart';
import 'package:family_learn/state/learning.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

// The app runs against DemoAuthRepository: same rules as the Supabase SQL,
// but in memory. Seeded family: parent kareem@demo.app / password123,
// Omar (PIN 1234, grade 6), Yassin (no PIN, Arabic UI, grade 3).

Future<void> _pumpApp(WidgetTester tester, DemoAuthRepository repo) async {
  tester.view.physicalSize = const Size(1170, 2532);
  tester.view.devicePixelRatio = 3.0;
  addTearDown(tester.view.reset);
  await tester.pumpWidget(ProviderScope(
    overrides: [
      authRepositoryProvider.overrideWithValue(repo),
      learningRepositoryProvider.overrideWithValue(DemoLearningRepository(repo)),
    ],
    child: const FamilyLearnApp(),
  ));
  await tester.pumpAndSettle();
}

Future<void> _signInAsParent(WidgetTester tester) async {
  await tester.tap(find.text('I already have an account'));
  await tester.pumpAndSettle();
  final fields = find.byType(TextFormField);
  await tester.enterText(fields.at(0), 'kareem@demo.app');
  await tester.enterText(fields.at(1), 'password123');
  await tester.tap(find.widgetWithText(FilledButton, 'Sign in'));
  await tester.pumpAndSettle();
  expect(find.text("Who's learning?"), findsOneWidget);
}

Future<void> _typePin(WidgetTester tester, String pin) async {
  for (final d in pin.split('')) {
    await tester.tap(find.text(d).last);
    await tester.pump();
  }
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('starts on the welcome screen with the demo banner', (tester) async {
    await _pumpApp(tester, DemoAuthRepository.seeded());
    expect(find.text('Learning for the whole family'), findsOneWidget);
    expect(find.text("This is my child's phone"), findsOneWidget);
    expect(find.bySemanticsLabel(RegExp('mock data banner')), findsWidgets);
  });

  testWidgets('wrong password is refused', (tester) async {
    await _pumpApp(tester, DemoAuthRepository.seeded());
    await tester.tap(find.text('I already have an account'));
    await tester.pumpAndSettle();
    final fields = find.byType(TextFormField);
    await tester.enterText(fields.at(0), 'kareem@demo.app');
    await tester.enterText(fields.at(1), 'wrong-password');
    await tester.tap(find.widgetWithText(FilledButton, 'Sign in'));
    await tester.pumpAndSettle();
    expect(find.text('Wrong e-mail or password'), findsOneWidget);
    expect(find.text("Who's learning?"), findsNothing);
  });

  testWidgets('new parent: sign up, e-mail code, consent, create family', (tester) async {
    await _pumpApp(tester, DemoAuthRepository());
    await tester.tap(find.text('Get started'));
    await tester.pumpAndSettle();
    var fields = find.byType(TextFormField);
    await tester.enterText(fields.at(0), 'new.parent@example.com');
    await tester.enterText(fields.at(1), 'secret-pass');
    await tester.enterText(fields.at(2), 'secret-pass');
    await tester.tap(find.widgetWithText(FilledButton, 'Continue'));
    await tester.pumpAndSettle();

    expect(find.text('Confirm your e-mail'), findsOneWidget);
    await tester.enterText(find.byType(TextFormField), '000000');
    await tester.tap(find.widgetWithText(FilledButton, 'Confirm'));
    await tester.pumpAndSettle();
    expect(find.text('That code is wrong or has expired'), findsOneWidget);

    await tester.enterText(find.byType(TextFormField), DemoAuthRepository.demoEmailCode);
    await tester.tap(find.widgetWithText(FilledButton, 'Confirm'));
    await tester.pumpAndSettle();

    expect(find.text('Parental consent'), findsOneWidget);
    await tester.tap(find.byType(CheckboxListTile));
    await tester.pump();
    await tester.tap(find.widgetWithText(FilledButton, 'Continue'));
    await tester.pumpAndSettle();

    fields = find.byType(TextFormField);
    await tester.enterText(fields.at(0), 'Junaid');
    await tester.enterText(fields.at(1), 'Kareem');
    await tester.enterText(fields.at(2), 'Omar');
    // Text fields contain their own Scrollable, so name the page's list.
    await tester.scrollUntilVisible(
      find.widgetWithText(FilledButton, 'Create family'),
      200,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.tap(find.widgetWithText(FilledButton, 'Create family'));
    await tester.pumpAndSettle();

    expect(find.text("Who's learning?"), findsOneWidget);
    expect(find.text('Kareem'), findsOneWidget);
    expect(find.text('Omar'), findsOneWidget);
  });

  testWidgets('a PIN-protected child profile needs the right PIN', (tester) async {
    await _pumpApp(tester, DemoAuthRepository.seeded());
    await _signInAsParent(tester);
    await tester.tap(find.text('Omar'));
    await tester.pumpAndSettle();
    await _typePin(tester, '0000');
    expect(find.text('Wrong PIN. 4 tries left.'), findsOneWidget);
    await _typePin(tester, '1234');
    expect(find.text("Today's mission"), findsOneWidget);
    expect(find.byType(NavigationBar), findsOneWidget);
  });

  testWidgets('the parent profile sees the family dashboard', (tester) async {
    await _pumpApp(tester, DemoAuthRepository.seeded());
    await _signInAsParent(tester);
    await tester.tap(find.text('Kareem'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('More'));
    await tester.pumpAndSettle();
    expect(find.text('Family dashboard'), findsOneWidget);
    await tester.tap(find.text('Family dashboard'));
    await tester.pumpAndSettle();
    expect(find.text('Omar'), findsOneWidget);
    expect(find.text('Yassin'), findsOneWidget);
  });

  testWidgets('a child profile on the parent phone has no family dashboard', (tester) async {
    await _pumpApp(tester, DemoAuthRepository.seeded());
    await _signInAsParent(tester);
    await tester.tap(find.text('Omar'));
    await tester.pumpAndSettle();
    await _typePin(tester, '1234');
    await tester.tap(find.text('More'));
    await tester.pumpAndSettle();
    expect(find.text('Family dashboard'), findsNothing);
    expect(find.text('Shop'), findsOneWidget);
  });

  testWidgets('a profile with Arabic UI switches to right-to-left', (tester) async {
    await _pumpApp(tester, DemoAuthRepository.seeded());
    await _signInAsParent(tester);
    await tester.tap(find.text('Yassin'));
    await tester.pumpAndSettle();
    final dir = Directionality.of(tester.element(find.byType(NavigationBar)));
    expect(dir, TextDirection.rtl);
    expect(find.text('مهمة اليوم'), findsOneWidget);
  });

  testWidgets("child's phone: link with the parent's code, then locked to that child", (tester) async {
    final repo = DemoAuthRepository.seeded();
    await repo.debugSignInParent();
    final code = await repo.createPairingCode(repo.debugProfileId('Omar'));
    await repo.signOut();

    await _pumpApp(tester, repo);
    await tester.tap(find.text("This is my child's phone"));
    await tester.pumpAndSettle();

    await tester.enterText(find.byType(TextFormField), '000000' == code.code ? '111111' : '000000');
    await tester.tap(find.widgetWithText(FilledButton, 'Link phone'));
    await tester.pumpAndSettle();
    expect(find.text('That code is wrong or has expired'), findsOneWidget);

    await tester.enterText(find.byType(TextFormField), code.code);
    await tester.tap(find.widgetWithText(FilledButton, 'Link phone'));
    await tester.pumpAndSettle();

    // Straight to Omar's PIN - no profile picker on a child's phone.
    expect(find.text('Enter PIN'), findsOneWidget);
    await _typePin(tester, '1234');
    expect(find.text("Today's mission"), findsOneWidget);

    await tester.tap(find.text('More'));
    await tester.pumpAndSettle();
    expect(find.text('Family dashboard'), findsNothing);
    expect(find.text('Switch profile'), findsNothing);
  });

  testWidgets("the Learn tab shows the child's real courses with the next lessons locked", (tester) async {
    await _pumpApp(tester, DemoAuthRepository.seeded());
    await _signInAsParent(tester);
    await tester.tap(find.text('Yassin'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('تعلّم')); // Yassin's app is in Arabic
    await tester.pumpAndSettle();
    expect(find.text('English - Grades 1-4'), findsOneWidget);
    expect(find.text('Long a: ai and ay'), findsOneWidget);
    expect(find.text('مقفل'), findsWidgets); // "Locked"
  });
}
