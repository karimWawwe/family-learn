import 'package:family_learn/domain/questions.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('checkAnswer (Phase 2 UI check)', () {
    test('multiple choice', () {
      const q = MultipleChoiceQuestion(id: 'a', skill: 's', prompt: 'p', options: ['x', 'y'], correctIndex: 1);
      expect(checkAnswer(q, 1), isTrue);
      expect(checkAnswer(q, 0), isFalse);
    });

    test('true / false', () {
      const q = TrueFalseQuestion(id: 'a', skill: 's', prompt: 'p', answer: true);
      expect(checkAnswer(q, true), isTrue);
      expect(checkAnswer(q, false), isFalse);
    });

    test('fill blank ignores case, spaces and final dot', () {
      const q = FillBlankQuestion(id: 'a', skill: 's', prompt: 'p', before: 'b', after: 'a', accepted: ['increased', 'rose']);
      expect(checkAnswer(q, '  Rose. '), isTrue);
      expect(checkAnswer(q, 'fell'), isFalse);
    });

    test('matching needs every pair right', () {
      const q = MatchingQuestion(id: 'a', skill: 's', prompt: 'p', left: ['1', '2'], right: ['one', 'two']);
      expect(checkAnswer(q, <int, int>{0: 0, 1: 1}), isTrue);
      expect(checkAnswer(q, <int, int>{0: 1, 1: 0}), isFalse);
      expect(checkAnswer(q, <int, int>{0: 0}), isFalse);
    });

    test('ordering', () {
      const q = OrderingQuestion(id: 'a', skill: 's', prompt: 'p', correctOrder: ['a', 'b', 'c']);
      expect(checkAnswer(q, ['a', 'b', 'c']), isTrue);
      expect(checkAnswer(q, ['b', 'a', 'c']), isFalse);
    });

    test('drag and drop', () {
      const q = DragDropQuestion(id: 'a', skill: 's', prompt: 'p', before: 'b', after: 'a', tokens: ['go', 'went'], correctToken: 'went');
      expect(checkAnswer(q, 'went'), isTrue);
      expect(checkAnswer(q, 'go'), isFalse);
    });

    test('word problem accepts decimal comma', () {
      const q = WordProblemQuestion(id: 'a', skill: 's', prompt: 'p', answer: 0.75);
      expect(checkAnswer(q, '0,75'), isTrue);
      expect(checkAnswer(q, '0.7'), isFalse);
      expect(checkAnswer(q, 'abc'), isFalse);
    });

    test('speaking is not auto-checked in Phase 2', () {
      const q = SpeakingQuestion(id: 'a', skill: 's', prompt: 'p', targetText: 'hello');
      expect(checkAnswer(q, 'recorded'), isNull);
    });
  });
}
