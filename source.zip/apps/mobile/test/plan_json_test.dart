import 'package:family_learn/data/plan/plan_repository.dart';
import 'package:family_learn/domain/plan.dart';
import 'package:flutter_test/flutter_test.dart';

// Phase 6: the JSON shapes returned by daily_plan / review_overview / finish_practice.
void main() {
  test('daily plan', () {
    final p = dailyPlanFromJson({
      'tasks': [
        {'kind': 'review', 'done': false, 'count': 4, 'minutes': 4},
        {'kind': 'lesson', 'done': true, 'lesson_id': 'eng.l1', 'title': 'Past simple', 'course': 'English', 'minutes': 10},
        {'kind': 'speak', 'done': false, 'minutes': 5},
        {'kind': 'something_new', 'done': false},
      ],
      'done': 1,
      'total': 3,
      'minutes_today': 12,
      'goal_minutes': 20,
      'streak_days': 2,
      'due_review': 4,
      'suggest_placement': false,
    });
    expect(p.tasks.length, 3, reason: 'unknown task kinds are skipped');
    expect(p.tasks.first.kind, PlanTaskKind.review);
    expect(p.tasks.first.count, 4);
    expect(p.nextTask!.kind, PlanTaskKind.review);
    expect(p.allDone, isFalse);
    expect(p.progress, closeTo(1 / 3, 0.001));
    expect(p.tasks[1].lessonId, 'eng.l1');
  });

  test('all done', () {
    final p = dailyPlanFromJson({
      'tasks': [
        {'kind': 'lesson', 'done': true},
      ],
      'done': 1,
      'total': 1,
    });
    expect(p.allDone, isTrue);
    expect(p.nextTask, isNull);
  });

  test('review overview', () {
    final o = reviewOverviewFromJson({
      'due_today': 3,
      'due_tomorrow': 1,
      'tracked': 20,
      'mastered': 2,
      'reviewed_today': false,
      'items': [
        {'question_id': 'q1', 'prompt': 'went / goed?', 'skill': 'Past simple', 'box': 1, 'last_result': false, 'lapses': 2},
      ],
      'skills': [
        {'code': 'past', 'name': 'Past simple', 'questions': 6, 'mastery': 0.2},
        {'code': 'num', 'name': 'Numbers', 'questions': 2, 'mastery': 0.1},
      ],
    });
    expect(o.dueToday, 3);
    expect(o.items.single.strength, 0);
    expect(o.weakSkills.map((s) => s.code), ['past'], reason: 'needs at least 3 questions to be called weak');
  });

  test('placement outcome', () {
    final o = practiceOutcomeFromJson({
      'kind': 'placement',
      'correct': 5,
      'total': 6,
      'xp': 25,
      'coins': 5,
      'stars': 2,
      'placements': [
        {'course_id': 'eng-g6', 'title': 'English', 'placed_position': 7, 'lessons': 13, 'start_lesson': 'Unit 3'},
      ],
      'wallet': {'xp': 25, 'streak_days': 1},
    });
    expect(o.kind, PracticeKind.placement);
    expect(o.placements.single.placedPosition, 7);
    expect(o.wallet.xp, 25);
    expect(o.percent, 83);
  });

  test('empty review session', () {
    final s = practiceSessionFromJson({'session_id': null, 'kind': 'review', 'questions': []});
    expect(s.sessionId, isNull);
    expect(s.questions, isEmpty);
  });
}
