import 'package:family_learn/data/auth/demo_auth_repository.dart';
import 'package:family_learn/domain/account.dart';
import 'package:flutter_test/flutter_test.dart';

// The demo repository follows the same rules as the Supabase SQL
// (supabase/tests/phase3_accounts_test.sql checks the real database).

void main() {
  late DateTime now;
  late DemoAuthRepository repo;

  setUp(() {
    now = DateTime(2026, 9, 26, 10);
    repo = DemoAuthRepository.seeded(clock: () => now);
  });

  Matcher failsWith(String code) => throwsA(isA<AuthFailure>().having((e) => e.code, 'code', code));

  test('signed out until sign in; parent sees the whole family', () async {
    expect((await repo.load()).stage, AccountStage.signedOut);
    await repo.debugSignInParent();
    final a = await repo.load();
    expect(a.isParentAccount, isTrue);
    expect(a.profiles.map((p) => p.displayName), ['Kareem', 'Omar', 'Yassin']);
  });

  test('5 wrong PINs lock the profile for 15 minutes', () async {
    await repo.debugSignInParent();
    final omar = repo.debugProfileId('Omar');
    for (var i = 4; i >= 1; i--) {
      expect((await repo.verifyPin(omar, '0000')).attemptsLeft, i);
    }
    final locked = await repo.verifyPin(omar, '0000');
    expect(locked.ok, isFalse);
    expect(locked.lockedUntil, now.add(const Duration(minutes: 15)));
    expect((await repo.verifyPin(omar, '1234')).ok, isFalse, reason: 'locked even with the right PIN');
    now = now.add(const Duration(minutes: 16));
    expect((await repo.verifyPin(omar, '1234')).ok, isTrue);
  });

  test('PIN must be 4 digits and only the parent can set it', () async {
    await repo.debugSignInParent();
    final yassin = repo.debugProfileId('Yassin');
    await expectLater(repo.setPin(yassin, '12a4'), failsWith('invalid_pin'));
    await repo.setPin(yassin, '9999');
    expect((await repo.load()).profileById(yassin)!.hasPin, isTrue);
    await repo.signOut();
    await expectLater(repo.setPin(yassin, '1111'), failsWith('parent_only'));
  });

  test("link code: works once, links the phone to one child only", () async {
    await repo.debugSignInParent();
    final omar = repo.debugProfileId('Omar');
    final code = await repo.createPairingCode(omar);
    expect(code.code, matches(RegExp(r'^\d{6}$')));
    expect(code.expiresAt, now.add(const Duration(minutes: 10)));
    await repo.signOut();

    await repo.linkThisDevice(code: code.code);
    final phone = await repo.load();
    expect(phone.isChildDevice, isTrue);
    expect(phone.deviceProfileId, omar);
    expect(phone.profiles.map((p) => p.displayName), ['Omar']);
    await expectLater(repo.createPairingCode(omar), failsWith('parent_only'));
    await expectLater(repo.verifyPin(repo.debugProfileId('Yassin'), '0000'), failsWith('not_found'));

    // another phone cannot reuse it
    await repo.signOut();
    await expectLater(repo.linkThisDevice(code: code.code), failsWith('invalid_code'));
  });

  test('link code expires after 10 minutes and a new code replaces the old one', () async {
    await repo.debugSignInParent();
    final yassin = repo.debugProfileId('Yassin');
    final first = await repo.createPairingCode(yassin);
    final second = await repo.createPairingCode(yassin);
    await repo.signOut();
    if (first.code != second.code) {
      await expectLater(repo.linkThisDevice(code: first.code), failsWith('invalid_code'));
    }
    now = now.add(const Duration(minutes: 11));
    await expectLater(repo.linkThisDevice(code: second.code), failsWith('invalid_code'));
  });

  test('a phone gets 5 code tries per 15 minutes', () async {
    for (var i = 0; i < 5; i++) {
      await expectLater(repo.linkThisDevice(code: '00000$i'), failsWith('invalid_code'));
    }
    await expectLater(repo.linkThisDevice(code: '000009'), failsWith('too_many_attempts'));
  });

  test('parent can unlink a phone; it loses access at once', () async {
    await repo.debugSignInParent();
    final code = await repo.createPairingCode(repo.debugProfileId('Omar'));
    await repo.signOut();
    await repo.linkThisDevice(code: code.code, deviceName: 'Omar phone');
    final phoneState = await repo.load();
    expect(phoneState.isChildDevice, isTrue);

    // (the demo has one "device", so switch to the parent to unlink)
    await repo.debugSignInParent();
    final devices = await repo.linkedDevices();
    expect(devices.single.deviceName, 'Omar phone');
    await repo.unlinkDevice(devices.single.userId);
    expect(await repo.linkedDevices(), isEmpty);
  });

  test('create family needs a confirmed parent and happens once', () async {
    final r = DemoAuthRepository(clock: () => now);
    await r.signUp(email: 'mum@example.com', password: 'longenough');
    expect((await r.load()).stage, AccountStage.signedOut, reason: 'not confirmed yet');
    await expectLater(r.verifySignUpCode(email: 'mum@example.com', code: '999999'), failsWith('invalid_code'));
    await r.verifySignUpCode(email: 'mum@example.com', code: DemoAuthRepository.demoEmailCode);
    expect((await r.load()).stage, AccountStage.needsFamily);
    const fam = NewFamily(familyName: 'Home', parentName: 'Mum', parentLocale: 'ar', learners: []);
    await r.createFamily(fam);
    expect((await r.load()).isParentAccount, isTrue);
    await expectLater(r.createFamily(fam), failsWith('already_in_family'));
  });
}
