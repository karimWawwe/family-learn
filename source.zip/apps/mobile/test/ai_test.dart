import 'package:family_learn/data/ai/ai_repository.dart';
import 'package:family_learn/domain/account.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('AI gateway JSON', () {
    test('tutor reply', () {
      final r = replyFromJson({'conversation_id': 'c1', 'reply': 'Bonjour = صباح الخير', 'flagged': false, 'remaining_today': 17});
      expect(r.conversationId, 'c1');
      expect(r.text, contains('Bonjour'));
      expect(r.remainingToday, 17);
      expect(r.feedback, isNull);
    });

    test('role-play feedback', () {
      final r = replyFromJson({
        'conversation_id': 'c2',
        'feedback': {
          'summary': 'Très bien !',
          'goal_reached': true,
          'grammar': [
            ['je suis 12 ans', "j'ai 12 ans"],
            ['bad'],
          ],
          'phrases': ['Je voudrais un croissant.'],
          'new_words': ['serveur — نادل'],
        },
      });
      final f = r.feedback!;
      expect(f.goalReached, isTrue);
      expect(f.grammar.single.$2, "j'ai 12 ans");
      expect(f.betterWords, isEmpty);
      expect(f.newWords.single, contains('نادل'));
    });

    test('status, scenarios, history, conversation', () {
      final st = statusFromJson({'enabled': true, 'used_today': 25, 'daily_limit': 20, 'month_cost': 0.0123, 'monthly_budget': 5});
      expect(st.remainingToday, 0);
      expect(st.monthlyBudget, 5);
      final sc = scenariosFromJson([
        {'code': 'kid6_fr_cafe', 'lang': 'fr', 'title': 'Au café', 'title_ar': 'في المقهى', 'persona': 'p', 'goal': 'g', 'emoji': '🥐'},
      ]);
      expect(sc.single.lang, 'fr');
      expect(sc.single.titleAr, 'في المقهى');
      final h = historyFromJson([
        {'id': 'c', 'kind': 'tutor', 'title': 't', 'started_at': '2026-10-14T05:00:00Z', 'last_at': '2026-10-14T05:01:00Z', 'messages': 4, 'flagged': true},
      ]);
      expect(h.single.flagged, isTrue);
      expect(h.single.messages, 4);
      final c = conversationFromJson({
        'id': 'c', 'profile_id': 'p', 'kind': 'roleplay', 'title': 'x', 'scenario': 'kid6_fr_cafe',
        'messages': [
          {'role': 'assistant', 'content': 'Bonjour !'},
          {'role': 'user', 'content': 'Un croissant', 'flagged': true},
        ],
        'feedback': {'summary': 'ok'},
      });
      expect(c.messages.first.fromLearner, isFalse);
      expect(c.messages.last.flagged, isTrue);
      expect(c.feedback!.summary, 'ok');
    });

    test('demo mode explains that AI needs the connection', () async {
      final demo = DemoAiRepository();
      expect(() => demo.askTutor('p', 'hi'), throwsA(isA<AuthFailure>().having((e) => e.code, 'code', 'ai_needs_connection')));
      expect(await demo.scenarios('p'), isEmpty);
    });

    test('AI error codes have their own messages', () {
      for (final code in ['ai_daily_limit', 'ai_budget', 'ai_not_configured', 'ai_disabled', 'too_short']) {
        expect(AuthFailure(code).messageKey, 'err_$code');
      }
    });
  });
}
