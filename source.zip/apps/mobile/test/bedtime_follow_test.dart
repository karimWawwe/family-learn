import 'package:family_learn/data/bedtime/bedtime_repository.dart';
import 'package:family_learn/data/follow/follow_repository.dart';
import 'package:family_learn/domain/bedtime.dart';
import 'package:family_learn/domain/follow.dart';
import 'package:family_learn/domain/models.dart';
import 'package:family_learn/features/follow/recommendations.dart';
import 'package:flutter_test/flutter_test.dart';

LearnerProfile _kid(String id, int grade) => LearnerProfile(
      id: id,
      displayName: id,
      kind: ProfileKind.child,
      role: FamilyRole.member,
      uiMode: UiMode.kid,
      uiLocale: 'ar',
      avatarEmoji: '🙂',
      dailyMinutesGoal: 15,
      grade: grade,
    );

void main() {
  group('stories content', () {
    test('17 calm stories (14 values + 3 prophets), each with pages, a question and an activity', () async {
      final st = await DemoBedtimeRepository().load(_kid('y', 3));
      expect(st.stories.length, 17);
      final prophets = st.stories.where((s) => s.isProphet).toList();
      expect(prophets.map((s) => s.id), containsAll(['p01-saleh', 'p02-nuh', 'p03-ibrahim']));
      for (final s in prophets) {
        expect(s.showsSource, isTrue, reason: s.id);
        expect(s.source, contains('القرآن الكريم'), reason: s.id);
      }
      for (final s in st.stories) {
        expect(s.pages.length, greaterThanOrEqualTo(4), reason: s.id);
        expect(s.question.options.length, 3, reason: s.id);
        expect(s.question.answer, inInclusiveRange(0, 2));
        expect(s.activity, isNotEmpty);
        expect(s.minutes, inInclusiveRange(3, 5), reason: s.id);
        if (s.isHadith || s.isProphet) expect(s.source, isNotEmpty, reason: '${s.id} must cite its source');
        for (final p in s.pages) {
          expect(p.sentences, isNotEmpty);
          expect(p.sentences.join(' ').replaceAll(' ', ''), p.text.replaceAll(' ', ''), reason: s.id);
        }
      }
      // the ten values asked for
      final values = st.stories.map((s) => s.valueCode).toSet();
      expect(values, containsAll(['sidq', 'amana', 'birr', 'rahma', 'help', 'afw', 'respect', 'manners', 'shukr', 'sabr']));
    });
  });

  group('demo stories progress', () {
    test('separate per child, resume, completion, favourites, last story', () async {
      final repo = DemoBedtimeRepository();
      final y = _kid('yassin', 3);
      final o = _kid('omar', 6);
      final a = await repo.start(y, 's01-honest-rabbit');
      await repo.progress(a.listenId, 3, 100);
      final again = await repo.start(y, 's01-honest-rabbit');
      expect(again.listenId, a.listenId);
      expect(again.page, 3);
      await repo.progress(a.listenId, 4, 50); // seconds never go down
      expect(repo.listens.first.seconds, 100);
      await repo.complete(a.listenId, 230, true);
      await repo.setFavorite(y, 's01-honest-rabbit', true);

      final sy = await repo.load(y);
      expect(sy.byId('s01-honest-rabbit')!.completed, 1);
      expect(sy.byId('s01-honest-rabbit')!.favorite, isTrue);
      expect(sy.last!.storyId, 's01-honest-rabbit');
      expect(sy.completedCount, 1);

      final so = await repo.load(o);
      expect(so.completedCount, 0);
      expect(so.favorites, isEmpty);
      expect(so.last, isNull);

      // after completion a new listen starts fresh
      final b = await repo.start(y, 's01-honest-rabbit');
      expect(b.listenId, isNot(a.listenId));
    });
  });

  group('follow report (demo) and suggestions', () {
    test('numbers come from the child\'s own saved stories', () async {
      final bedtime = DemoBedtimeRepository();
      final follow = DemoFollowRepository(bedtime);
      final y = _kid('yassin', 3);
      final o = _kid('omar', 6);
      final l = await bedtime.start(y, 's01-honest-rabbit');
      await bedtime.complete(l.listenId, 240, true);
      final l2 = await bedtime.start(y, 's04-kitten-rain');
      await bedtime.progress(l2.listenId, 2, 60);

      final r = await follow.report(y, FollowPeriod.week);
      expect(r.current.storiesListened, 2);
      expect(r.current.storiesCompleted, 1);
      expect(r.current.minutesStories, 5);
      expect(r.current.daysUsed, 1);
      expect(r.current.values, ['الصدق']);
      expect(r.lastStory!.id, 's04-kitten-rain');
      expect(r.topValue, 'الصدق');
      expect(r.suggestion, isNotNull);
      expect(r.suggestion!.id, isNot('s01-honest-rabbit'));
      expect(r.byDay.length, 7);
      expect(r.storyPoints, 20);

      final ro = await follow.report(o, FollowPeriod.week);
      expect(ro.current.storiesListened, 0);
      expect(ro.neverUsed, isTrue);
    });

    test('tips follow the data', () {
      const none = FollowReport(suggestion: StoryRef(id: 's01', title: 'الأرنب الصادق', value: 'الصدق'));
      final t0 = buildTips(none, 'ياسين', ar: true);
      expect(t0.single.text, contains('لم يبدأ'));

      const noStory = FollowReport(
        totalDays: 3,
        current: RangeFigures(daysUsed: 2, minutesTotal: 20),
        previous: RangeFigures(daysUsed: 4),
        suggestion: StoryRef(id: 's02', title: 'الحقيبة الزرقاء', value: 'الأمانة'),
      );
      final t1 = buildTips(noStory, 'عمر', ar: true).map((t) => t.text).join('\n');
      expect(t1, contains('عمر لم يكمل قصة'));
      expect(t1, contains('الحقيبة الزرقاء'));
      expect(t1, contains('أقل من'));

      const enjoys = FollowReport(
        totalDays: 5,
        totalStoriesCompleted: 4,
        current: RangeFigures(daysUsed: 5, storiesCompleted: 3, minutesTotal: 40),
        previous: RangeFigures(daysUsed: 2),
        topValue: 'الصدق',
        suggestion: StoryRef(id: 's02', title: 'الحقيبة الزرقاء', value: 'الأمانة'),
      );
      final t2 = buildTips(enjoys, 'ياسين', ar: true).map((t) => t.text).join('\n');
      expect(t2, contains('ياسين يستمتع بالقصص الأخلاقية'));
      expect(t2, contains('الأمانة'));
      expect(t2, contains('تقدّم جميل'));
    });
  });

  test('page sentences are split for gentle reading', () {
    const p = StoryPage(text: 'كان رنّوش يلعبُ بالكرةِ قربَ الشرفة. ركلَ الكرةَ بقوّةٍ فارتفعتْ عاليًا، ثم نزلتْ على الأصيص.');
    expect(p.sentences.length, greaterThanOrEqualTo(2));
  });
}
