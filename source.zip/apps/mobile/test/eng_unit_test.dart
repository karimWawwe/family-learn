import 'package:family_learn/domain/eng_unit.dart';
import 'package:family_learn/data/eng_unit/eng_unit_repository.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('every exercise finds exactly its wrong words', () {
    for (final e in capsExercises) {
      expect(e.wrongIndexes.length, e.fixes.length, reason: e.id);
    }
    expect(capsExercises.length, 10);
  });

  test('corrected sentence keeps punctuation', () {
    final ex6 = capsExercises.firstWhere((e) => e.id == 'ex6');
    expect(ex6.correctedSentence, 'On our tour of Coit Tower in San Francisco, we met some Brazilian tourists who spoke Portuguese.');
  });

  test('stages open in order and progress is counted', () {
    final st = engUnitStateFromJson({
      'read': true,
      'videos': ['vid_22'],
      'items': [
        for (final id in ['ex1', 'ex2', 'ex3', 'ex4', 'ex5']) {'item': id, 'attempts': 1, 'wrong': 0, 'solved': true, 'best_stars': 3},
      ],
    });
    expect(st.stageOpen(2), isTrue);
    expect(st.stageOpen(3), isTrue);
    expect(st.stageOpen(4), isFalse);
    expect(st.currentStage, 3);
    expect(st.stars, 15);
    expect(st.videosWatched, 1);
    expect((st.completion * 15).round(), 7);
  });

  test('stars by attempt', () {
    expect(starsForAttempt(1), 3);
    expect(starsForAttempt(2), 2);
    expect(starsForAttempt(5), 1);
  });
}
