import 'package:family_learn/data/speak_game/speak_game_repository.dart';
import 'package:family_learn/domain/models.dart';
import 'package:family_learn/domain/speak_game.dart';
import 'package:family_learn/features/speak_game/game_session.dart';
import 'package:family_learn/features/speak_game/pronunciation.dart';
import 'package:flutter_test/flutter_test.dart';

const _c = PronunciationChecker();

PronunciationVerdict _check(String target, List<String> heard, {List<String> accepted = const [], double strict = 0.82}) =>
    _c.check(target: target, accepted: accepted, alternatives: [for (final h in heard) SpeechAlt(h)], strictness: strict);

LearnerProfile _kid(String id, int grade) => LearnerProfile(
      id: id,
      displayName: id,
      kind: ProfileKind.child,
      role: FamilyRole.member,
      uiMode: UiMode.kid,
      uiLocale: 'ar',
      avatarEmoji: '🙂',
      dailyMinutesGoal: 15,
      grade: grade,
    );

void main() {
  group('pronunciation checker', () {
    test('exact, case and punctuation', () {
      expect(_check('Cat', ['cat.']).result, SpeakResult.correct);
      expect(_check('thank you', ['Thank you!']).result, SpeakResult.correct);
    });

    test('recogniser sound-alikes of children are accepted', () {
      expect(_check('cat', ['Kat']).result, SpeakResult.correct);
      expect(_check('cat', ['cats']).result, SpeakResult.correct);
      expect(_check('cat', ['the cat']).result, SpeakResult.correct);
      expect(_check('cat', ['cat cat']).result, SpeakResult.correct);
      expect(_check('banana', ['bananas']).result, SpeakResult.correct);
      expect(_check('beautiful', ['beautifull']).result, SpeakResult.correct);
    });

    test('listed sound-alikes and digits', () {
      expect(_check('two', ['to'], accepted: ['to', 'too']).result, SpeakResult.correct);
      expect(_check('two', ['2']).result, SpeakResult.correct);
      expect(_check('eight', ['8']).result, SpeakResult.correct);
      expect(_check('seventeen', ['17']).result, SpeakResult.correct);
    });

    test('best of several alternatives counts', () {
      expect(_check('horse', ['house', 'horse']).result, SpeakResult.correct);
    });

    test('a different word is not accepted', () {
      expect(_check('cat', ['dog']).result, SpeakResult.wrong);
      expect(_check('apple', ['bubble']).result, SpeakResult.wrong);
      expect(_check('fish', ['fist']).result, isNot(SpeakResult.correct));
      expect(_check('book', ['look']).result, isNot(SpeakResult.correct));
      expect(_check('chair', ['share']).result, isNot(SpeakResult.correct));
    });

    test('near misses are "close" (encouraging, not wrong)', () {
      expect(_check('elephant', ['element']).result, SpeakResult.close);
    });

    test('sentences: extra words ok, missing words lower the score', () {
      expect(_check('I went to the market', ['I want to the market'], strict: 0.8).result, SpeakResult.correct);
      expect(_check('I went to the market', ['the weather is nice today'], strict: 0.8).result, isNot(SpeakResult.correct));
    });

    test('silence and noise are unclear, never wrong', () {
      expect(_check('cat', []).result, SpeakResult.unclear);
      expect(_check('cat', ['   ']).result, SpeakResult.unclear);
      final noisy = _check('cat', ['and then we went to the shops with my mum yesterday']);
      expect(noisy.result, SpeakResult.unclear);
      expect(noisy.reason, 'noise');
      final unsure = _c.check(target: 'cat', alternatives: const [SpeechAlt('mop', 0.1)], strictness: 0.82);
      expect(unsure.result, SpeakResult.unclear);
    });

    test('number words and sound keys', () {
      expect(PronunciationChecker.normalize('I have 21 cars & 3rd'), 'i have twenty one cars and third');
      expect(PronunciationChecker.soundKey('phone'), 'fn');
      expect(PronunciationChecker.soundKey('knife'), 'nf');
    });
  });

  group('game session', () {
    const level = SpeakLevel(id: 'L1', title: 'T', strictness: 0.82, unlocked: true, words: [
      SpeakWord(text: 'cat'),
      SpeakWord(text: 'dog'),
      SpeakWord(text: 'sun'),
    ]);
    PronunciationVerdict ok(String w) => _check(w, [w]);
    PronunciationVerdict bad() => _check('cat', ['table']);
    const quiet = PronunciationVerdict(SpeakResult.unclear, 0, '', reason: 'silence');

    test('a word stays until it is said correctly; unclear is not a try', () {
      final s = SpeakSession(level);
      expect(s.register(bad()).result, SpeakResult.wrong);
      s.advance(); // not done: stays
      expect(s.current!.text, 'cat');
      expect(s.register(quiet).triesOnWord, 1);
      expect(s.totalTries, 1);
      final fb = s.register(ok('cat'));
      expect(fb.result, SpeakResult.correct);
      expect(fb.wordStars, 2);
      expect(fb.pointsGained, 10);
      s.advance();
      expect(s.current!.text, 'dog');
    });

    test('points, combo, stars and level bonus', () {
      final s = SpeakSession(level);
      for (final w in ['cat', 'dog', 'sun']) {
        final fb = s.register(ok(w));
        expect(fb.wordStars, 3);
        s.advance();
      }
      expect(s.finished, isTrue);
      // 15 + 17 + 19 (first-try bonus + combo)
      expect(s.points, 51);
      expect(s.levelStars, 3);
      final r = s.result();
      expect(r.points, 51 + 30);
      expect(r.firstTry, 3);
    });

    test('skip after 5 tries puts the word at the end', () {
      final s = SpeakSession(level);
      for (var i = 0; i < 4; i++) {
        s.register(bad());
      }
      expect(s.canSkip, isFalse);
      s.register(bad());
      expect(s.canSkip, isTrue);
      s.skip();
      expect(s.current!.text, 'dog');
      s.register(ok('dog'));
      s.advance();
      s.register(ok('sun'));
      s.advance();
      expect(s.current!.text, 'cat'); // back again
      expect(s.finished, isFalse);
    });
  });

  group('demo repository', () {
    test('progress is separate per child and levels unlock in order', () async {
      final repo = DemoSpeakGameRepository();
      final yassin = _kid('yassin', 3);
      final omar = _kid('omar', 6);
      final y0 = await repo.load(yassin);
      final o0 = await repo.load(omar);
      expect(y0.track, 'young');
      expect(o0.track, 'older');
      expect(y0.levels, isNotEmpty);
      expect(y0.levels.first.unlocked, isTrue);
      if (y0.levels.length > 1) expect(y0.levels[1].unlocked, isFalse);

      final l1 = y0.levels.first;
      final after = await repo.finishLevel(
        yassin,
        SpeakPlayResult(levelId: l1.id, points: 99999, stars: 3, words: l1.words.length, firstTry: 3, attempts: 5),
      );
      expect(after.points, l1.words.length * 30 + 50); // capped
      expect(after.levels.first.bestStars, 3);
      if (after.levels.length > 1) expect(after.levels[1].unlocked, isTrue);
      expect(after.stickers, [l1.emoji]);

      final o1 = await repo.load(omar);
      expect(o1.points, 0);
      expect(o1.levelsDone, 0);
    });

    test('locked level cannot be finished', () async {
      final repo = DemoSpeakGameRepository();
      final y = _kid('y', 3);
      final st = await repo.load(y);
      if (st.levels.length < 2) return;
      expect(
        () => repo.finishLevel(y, SpeakPlayResult(levelId: st.levels[1].id, points: 10, stars: 1, words: 1, firstTry: 0, attempts: 1)),
        throwsA(anything),
      );
    });
  });
}
