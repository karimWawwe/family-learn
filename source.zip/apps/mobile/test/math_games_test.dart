import 'dart:math' as math;

import 'package:family_learn/data/math/math_repository.dart';
import 'package:family_learn/domain/account.dart';
import 'package:family_learn/domain/math_games.dart';
import 'package:family_learn/domain/models.dart';
import 'package:family_learn/features/math/math_logic.dart';
import 'package:family_learn/features/speak_game/pronunciation.dart';
import 'package:flutter_test/flutter_test.dart';

LearnerProfile _kid(String id, int grade) => LearnerProfile(
      id: id,
      displayName: id,
      kind: ProfileKind.child,
      role: FamilyRole.member,
      uiMode: UiMode.kid,
      uiLocale: 'ar',
      avatarEmoji: '🙂',
      dailyMinutesGoal: 15,
      grade: grade,
    );

MathRoundResult _r(MathGame g, String level, {int correct = 8, int total = 10}) => MathRoundResult(
      game: g,
      level: level,
      correct: correct,
      total: total,
      stars: MathRoundResult.starsFor(correct, total),
      points: correct * 10,
      seconds: 60,
    );

void main() {
  group('digits', () {
    test('Arabic-Indic or Western digits', () {
      expect(nd(24, true), '٢٤');
      expect(nd(24, false), '24');
      expect(nd('7:05', true), '٧:٠٥');
    });
  });

  group('times tables', () {
    test('a round of one table: 10 questions, answer always in the options, options unique', () {
      for (final level in TimesLevel.values) {
        for (var seed = 0; seed < 30; seed++) {
          final r = TimesRound(table: 4, level: level, random: math.Random(seed));
          expect(r.questions.length, 10);
          expect(r.levelId, 't4-${level.name}');
          for (final q in r.questions) {
            expect(q.a, 4);
            expect(q.options, contains(q.answer));
            expect(q.options.toSet().length, q.options.length);
            expect(q.options.every((o) => o > 0), isTrue);
            expect(q.options.length, level == TimesLevel.easy ? 3 : 4);
            if (q.missing) expect(level, TimesLevel.hard);
          }
        }
      }
    });

    test('mixed tables use the level ranges', () {
      final r = TimesRound(level: TimesLevel.easy, random: math.Random(3));
      expect(r.levelId, 'mixed-easy');
      for (final q in r.questions) {
        expect(q.a, inInclusiveRange(2, 5));
        expect(q.b, inInclusiveRange(1, 5));
      }
    });

    test('scoring: first try, streak, second try, reveal', () {
      final r = TimesRound(table: 3, level: TimesLevel.medium, random: math.Random(1));
      var f = r.answer(r.current.answer);
      expect(f.outcome, AnswerOutcome.correct);
      expect(f.points, 10);
      r.next();
      f = r.answer(r.current.answer);
      expect(f.points, 11); // streak bonus
      r.next();
      final wrong = r.current.options.firstWhere((o) => o != r.current.answer);
      expect(r.answer(wrong).outcome, AnswerOutcome.tryAgain);
      f = r.answer(r.current.answer);
      expect(f.outcome, AnswerOutcome.correct);
      expect(f.points, 5);
      r.next();
      expect(r.answer(-1).outcome, AnswerOutcome.tryAgain);
      expect(r.answer(-2).outcome, AnswerOutcome.revealed);
      expect(r.correct, 3);
      expect(r.points, 26);
    });

    test('hints', () {
      expect(TimesRound.repeatedAddition(3, 6, false), '6 + 6 + 6');
      expect(TimesRound.skipCount(3, 6, false), '6, 12, 18');
    });

    test('stars', () {
      expect(MathRoundResult.starsFor(10, 10), 3);
      expect(MathRoundResult.starsFor(9, 10), 3);
      expect(MathRoundResult.starsFor(7, 10), 2);
      expect(MathRoundResult.starsFor(3, 10), 1);
    });
  });

  group('clock', () {
    test('levels: o\'clock, half, quarters, fives, any minute', () {
      expect(ClockRound.stepFor(1), 60);
      expect(ClockRound.stepFor(2), 30);
      expect(ClockRound.stepFor(3), 15);
      expect(ClockRound.stepFor(4), 5);
      expect(ClockRound.stepFor(5), 1);
      final allowed = {
        1: [0],
        2: [0, 30],
        3: [0, 15, 30, 45],
      };
      for (final level in [1, 2, 3, 4, 5]) {
        for (var seed = 0; seed < 20; seed++) {
          final r = ClockRound(level: level, random: math.Random(seed));
          expect(r.questions.length, 8);
          expect(r.levelId, 'clock-$level');
          expect(r.questions.map((q) => q.task).toSet(), containsAll(ClockTask.values));
          for (final q in r.questions) {
            expect(q.time.hour, inInclusiveRange(1, 12));
            if (allowed[level] != null) expect(allowed[level], contains(q.time.minute));
            if (level == 4) expect(q.time.minute % 5, 0);
            if (q.task == ClockTask.setHands) {
              expect(q.options, isEmpty);
            } else {
              expect(q.options.where((o) => o.same(q.time)).length, 1);
              expect(q.options.toSet().length, q.options.length);
            }
          }
        }
      }
    });

    test('same time, digital text, angles', () {
      expect(const ClockTime(12, 0).same(const ClockTime(12, 0)), isTrue);
      expect(const ClockTime(3, 15).same(const ClockTime(3, 45)), isFalse);
      expect(const ClockTime(7, 5).digital(false), '7:05');
      expect(ClockRound.minuteAngle(15), closeTo(math.pi / 2, 1e-9));
      expect(ClockRound.hourAngle(3, 0), closeTo(math.pi / 2, 1e-9));
      expect(ClockRound.hourAngle(6, 30), closeTo(6.5 / 12 * 2 * math.pi, 1e-9));
    });

    test('answers', () {
      final r = ClockRound(level: 1, random: math.Random(2));
      final t = r.current.time;
      final wrong = ClockTime(t.hour % 12 + 1, 0);
      expect(r.answer(wrong).outcome, AnswerOutcome.tryAgain);
      expect(r.answer(t).outcome, AnswerOutcome.correct);
      expect(r.points, 5);
    });
  });

  group('demo math progress', () {
    test('each child has its own progress; clock levels open in order', () async {
      final repo = DemoMathRepository();
      final omar = _kid('omar', 6);
      final yassin = _kid('yassin', 3);
      await repo.finish(omar, _r(MathGame.times, 't6-medium', correct: 10));
      await repo.finish(omar, _r(MathGame.times, 't6-medium', correct: 7));
      var so = await repo.load(omar);
      expect(so.best(MathGame.times, 't6-medium').bestStars, 3);
      expect(so.best(MathGame.times, 't6-medium').plays, 2);
      expect(so.points, 100);
      final sy = await repo.load(yassin);
      expect(sy.rounds, 0);

      expect(sy.clockOpen(1), isTrue);
      expect(sy.clockOpen(2), isFalse);
      await expectLater(repo.finish(yassin, _r(MathGame.clock, 'clock-2', total: 8)),
          throwsA(isA<AuthFailure>().having((e) => e.code, 'code', 'lesson_locked')));
      await repo.finish(yassin, _r(MathGame.clock, 'clock-1', correct: 5, total: 8));
      expect((await repo.load(yassin)).clockOpen(2), isTrue);
      so = await repo.load(omar);
      expect(so.clockOpen(2), isFalse);
      await expectLater(repo.finish(omar, _r(MathGame.times, 'bad')), throwsA(isA<AuthFailure>()));
    });
  });

  group('pronunciation: kinder matching', () {
    const c = PronunciationChecker();
    PronunciationVerdict check(String target, List<String> heard, {double strict = 0.82}) =>
        c.check(target: target, alternatives: [for (final h in heard) SpeechAlt(h)], strictness: strict);

    test('words that sound the same are accepted without an accept list', () {
      expect(check('four', ['for']).result, SpeakResult.correct);
      expect(check('eight', ['ate']).result, SpeakResult.correct);
    });

    test('fillers and pauses do not hurt', () {
      expect(check('apple', ['um apple']).result, SpeakResult.correct);
    });

    test('a different word is still not accepted', () {
      expect(check('cap', ['capes']).result, isNot(SpeakResult.correct));
      expect(check('four', ['i want to go to the shop and buy some bread for my mum']).result, isNot(SpeakResult.correct));
      expect(check('dog', ['cat']).result, isNot(SpeakResult.correct));
    });

    test('nothing heard is "unclear", not wrong', () {
      expect(check('cat', []).result, SpeakResult.unclear);
      expect(check('cat', ['  ']).result, SpeakResult.unclear);
    });

    test('Arabic text is normalised (diacritics, alef forms)', () {
      expect(PronunciationChecker.normalize('أَحْمَد'), PronunciationChecker.normalize('احمد'));
    });
  });
}
