import 'dart:convert';

import 'package:family_learn/data/auth/demo_auth_repository.dart';
import 'package:family_learn/data/learning/demo_learning_repository.dart';
import 'package:family_learn/data/learning/grader.dart';
import 'package:family_learn/data/learning/question_codec.dart';
import 'package:family_learn/data/learning/starter_content.g.dart';
import 'package:family_learn/domain/account.dart';
import 'package:family_learn/domain/learning.dart';
import 'package:family_learn/domain/models.dart';
import 'package:flutter_test/flutter_test.dart';

// Same checks as supabase/tests/phase4_learning_test.sql, on the demo copy.

final _data = jsonDecode(starterContentJson) as Map<String, dynamic>;
final _questions = (_data['questions'] as List).cast<Map<String, dynamic>>();

Object? _right(Map<String, dynamic> q) {
  final k = (q['answer_key'] as Map).cast<String, dynamic>();
  return switch (q['type']) {
    'multiple_choice' || 'reading' => k['index'],
    'true_false' => k['value'],
    'fill_blank' => '  ${(k['accepted'] as List).first.toString().toUpperCase()}. ',
    'typing' => '${(k['accepted'] as List).first.toString().toUpperCase()}!',
    'drag_drop' => k['token'],
    'word_problem' => '${k['value']} ${(q['payload'] as Map)['unit'] ?? ''}',
    'matching' => k['map'],
    'ordering' => k['order'],
    _ => null,
  };
}

Object? _wrong(Map<String, dynamic> q) {
  final k = (q['answer_key'] as Map).cast<String, dynamic>();
  final p = (q['payload'] as Map).cast<String, dynamic>();
  return switch (q['type']) {
    'multiple_choice' || 'reading' => ((k['index'] as int) + 1) % (p['options'] as List).length,
    'true_false' => !(k['value'] as bool),
    'fill_blank' || 'typing' || 'drag_drop' => 'zzz',
    'word_problem' => '${(k['value'] as num) + 1}',
    'matching' => {
        for (final e in (k['map'] as Map).entries) '${e.key}': ((e.value as int) + 1) % (k['pairs'] as int),
      },
    'ordering' => (k['order'] as List).reversed.toList(),
    _ => 'zzz',
  };
}

void main() {
  test('110 starter questions, all readable by the app', () {
    expect(_questions, hasLength(110));
    for (final q in _questions) {
      expect(questionFromJson(q), isNotNull, reason: q['id'] as String);
    }
  });

  test('every starter question accepts its right answer and rejects a wrong one', () {
    for (final q in _questions) {
      final key = (q['answer_key'] as Map).cast<String, dynamic>();
      expect(gradeAnswer(q['type'] as String, key, _right(q)), isTrue, reason: 'right: ${q['id']}');
      expect(gradeAnswer(q['type'] as String, key, _wrong(q)), isFalse, reason: 'wrong: ${q['id']}');
    }
  });

  test('numbers in typed answers', () {
    expect(parseNumber('300 baisa'), 300);
    expect(parseNumber('0,25'), 0.25);
    expect(parseNumber('20,000'), 20000);
    expect(parseNumber('.5'), 0.5);
    expect(parseNumber('abc'), isNull);
  });

  test('matching and ordering are never sent in the right order', () {
    for (final q in _questions) {
      final k = (q['answer_key'] as Map).cast<String, dynamic>();
      final p = (q['payload'] as Map).cast<String, dynamic>();
      if (q['type'] == 'ordering') expect(p['items'], isNot(equals(k['order'])), reason: q['id'] as String);
      if (q['type'] == 'matching') {
        final identity = {for (var i = 0; i < (k['pairs'] as int); i++) '$i': i};
        expect(k['map'], isNot(equals(identity)), reason: q['id'] as String);
      }
    }
  });

  test('the app sends matching answers with text keys', () {
    expect(encodeResponse({0: 0, 1: 1}), {'0': 0, '1': 1});
  });

  group('lessons', () {
    late DateTime now;
    late DemoAuthRepository auth;
    late DemoLearningRepository repo;
    late String omar;

    setUp(() async {
      now = DateTime(2026, 9, 26, 16);
      auth = DemoAuthRepository.seeded(clock: () => now);
      repo = DemoLearningRepository(auth, clock: () => now);
      await auth.debugSignInParent();
      omar = auth.debugProfileId('Omar');
    });

    Matcher failsWith(String code) => throwsA(isA<AuthFailure>().having((e) => e.code, 'code', code));

    test('Omar (grade 6) gets the grade 5+ courses, first lesson open', () async {
      final courses = await repo.courseMap(omar);
      expect(courses.map((c) => c.id), ['eng-upper', 'math-upper']);
      final lessons = courses.first.units.expand((u) => u.lessons).toList();
      expect(lessons.first.status, LessonStatus.available);
      expect(lessons[1].status, LessonStatus.locked);
      await expectLater(repo.startLesson(omar, lessons[1].id), failsWith('lesson_locked'));
      await expectLater(repo.startLesson(omar, 'eng-lower.u1.l1'), failsWith('not_found'));
    });

    test('play a lesson: server marks, 4/5 -> 60 XP, 2 stars, next lesson opens', () async {
      final session = await repo.startLesson(omar, 'eng-upper.u1.l1');
      expect(session.questions, hasLength(5));
      now = now.add(const Duration(minutes: 1));
      expect((await repo.submitAnswer(session.attemptId, 'eng-upper.u1.l1.q1', 1)).correct, isTrue);
      final wrong = await repo.submitAnswer(session.attemptId, 'eng-upper.u1.l1.q2', 'watch');
      expect(wrong.correct, isFalse);
      expect(wrong.correctText, 'watched');
      expect((await repo.submitAnswer(session.attemptId, 'eng-upper.u1.l1.q2', 'watched')).correct, isFalse,
          reason: 'only the first answer counts');
      await repo.submitAnswer(session.attemptId, 'eng-upper.u1.l1.q3', ' Studied ');
      await repo.submitAnswer(session.attemptId, 'eng-upper.u1.l1.q4', false);
      final q5 = _questions.firstWhere((q) => q['id'] == 'eng-upper.u1.l1.q5');
      await repo.submitAnswer(session.attemptId, 'eng-upper.u1.l1.q5', (q5['answer_key'] as Map)['map']);
      now = now.add(const Duration(minutes: 9));

      final out = await repo.finishLesson(session.attemptId);
      expect([out.correct, out.total, out.xp, out.coins, out.stars], [4, 5, 60, 9, 2]);
      expect(out.wallet.streakDays, 1);
      expect(out.wallet.minutesToday, 10);
      await expectLater(repo.submitAnswer(session.attemptId, 'eng-upper.u1.l1.q1', 1), failsWith('lesson_finished'));

      final lessons = (await repo.courseMap(omar)).first.units.expand((u) => u.lessons).toList();
      expect(lessons[0].status, LessonStatus.done);
      expect(lessons[1].status, LessonStatus.available);
      expect(nextLesson(await repo.courseMap(omar))!.id, lessons[1].id);

      final report = await repo.report(omar);
      expect(report.minutesByDay.last, 10);
      expect(report.week.questions, 5);
      expect(report.week.accuracy, 0.8);
      expect(report.history.single.lesson, 'Regular verbs (-ed)');
      expect(report.toReview, contains('Past simple: regular verbs'));
    });

    test("a child's phone cannot touch another child or see reports", () async {
      final code = await auth.createPairingCode(omar);
      await auth.signOut();
      await auth.linkThisDevice(code: code.code);
      final yassin = auth.debugProfileId('Yassin');
      await expectLater(repo.courseMap(yassin), failsWith('not_found'));
      await expectLater(repo.wallet(yassin), failsWith('not_found'));
      await expectLater(repo.report(omar), failsWith('parent_only'));
      expect(await repo.courseMap(omar), isNotEmpty);
    });

    test('streak: today and yesterday count, a gap resets', () async {
      Future<void> play(String lesson) async {
        final s = await repo.startLesson(omar, lesson);
        await repo.finishLesson(s.attemptId);
      }

      now = DateTime(2026, 9, 22, 16);
      await play('eng-upper.u1.l1');
      now = DateTime(2026, 9, 25, 16);
      await play('eng-upper.u1.l2');
      now = DateTime(2026, 9, 26, 16);
      await play('eng-upper.u2.l1');
      expect((await repo.wallet(omar)).streakDays, 2);
      now = DateTime(2026, 9, 28, 16);
      expect((await repo.wallet(omar)).streakDays, 0);
    });
  });
}
