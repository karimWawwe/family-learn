import 'package:family_learn/core/router/app_router.dart';
import 'package:family_learn/domain/account.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

const _parent = AccountState.ready(
  role: DeviceRole.parent,
  familyId: 'f',
  familyName: 'Junaid',
  profiles: [],
);
const _childPhone = AccountState.ready(
  role: DeviceRole.childDevice,
  familyId: 'f',
  familyName: 'Junaid',
  profiles: [],
  deviceProfileId: 'omar',
);

String? _go(String path, AccountState a, {String? open, bool parentProfile = false}) => redirectFor(
      path: path,
      account: AsyncValue.data(a),
      openProfileId: open,
      openProfileExists: open != null,
      openProfileIsParent: parentProfile,
    );

void main() {
  test('loading shows the splash, errors show the retry screen', () {
    expect(redirectFor(path: '/welcome', account: const AsyncValue.loading(), openProfileId: null, openProfileExists: false, openProfileIsParent: false), Routes.splash);
    expect(redirectFor(path: '/home', account: AsyncValue.error('x', StackTrace.empty), openProfileId: null, openProfileExists: false, openProfileIsParent: false), Routes.startupError);
  });

  test('signed out: only public screens', () {
    const out = AccountState.signedOut();
    expect(_go(Routes.home, out), Routes.welcome);
    expect(_go(Routes.parent, out), Routes.welcome);
    expect(_go(Routes.childDeviceLink, out), isNull);
    expect(_go(Routes.forgotPassword, out), isNull);
  });

  test('confirmed parent without family goes to consent', () {
    const a = AccountState.needsFamily(email: 'a@b.c');
    expect(_go(Routes.home, a), Routes.consent);
    expect(_go(Routes.createFamily, a), isNull);
  });

  test('parent: picker first, dashboard only from the parent profile', () {
    expect(_go(Routes.welcome, _parent), Routes.profiles);
    expect(_go(Routes.home, _parent), Routes.profiles);
    expect(_go(Routes.pin('omar'), _parent), isNull);
    expect(_go(Routes.parent, _parent, open: 'omar'), Routes.home);
    expect(_go(Routes.linkDevice('omar'), _parent, open: 'omar'), Routes.home);
    expect(_go(Routes.parent, _parent, open: 'kareem', parentProfile: true), isNull);
  });

  test("child's phone: only its own profile, never the parent screens", () {
    expect(_go(Routes.home, _childPhone), Routes.pin('omar'));
    expect(_go(Routes.pin('omar'), _childPhone), isNull);
    expect(_go(Routes.pin('yassin'), _childPhone), Routes.pin('omar'));
    expect(_go(Routes.home, _childPhone, open: 'yassin'), Routes.pin('omar'));
    expect(_go(Routes.home, _childPhone, open: 'omar'), isNull);
    expect(_go(Routes.profiles, _childPhone, open: 'omar'), Routes.home);
    expect(_go(Routes.parent, _childPhone, open: 'omar', parentProfile: true), Routes.home);
    expect(_go(Routes.setPin('omar'), _childPhone, open: 'omar'), Routes.home);
    expect(_go(Routes.welcome, _childPhone, open: 'omar'), Routes.home);
  });
}
