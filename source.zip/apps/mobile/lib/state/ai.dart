import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/ai/ai_repository.dart';
import '../domain/ai.dart';

/// Overridden in main.dart with the Supabase repository.
final aiRepositoryProvider = Provider<AiRepository>((ref) => DemoAiRepository());

final aiStatusProvider = FutureProvider.autoDispose.family<AiStatus, String>(
    (ref, profileId) => ref.watch(aiRepositoryProvider).status(profileId));

final aiScenariosProvider = FutureProvider.autoDispose.family<List<AiScenario>, String>(
    (ref, profileId) => ref.watch(aiRepositoryProvider).scenarios(profileId));

final aiHistoryProvider = FutureProvider.autoDispose.family<List<AiConversationSummary>, String>(
    (ref, profileId) => ref.watch(aiRepositoryProvider).history(profileId));

final aiConversationProvider = FutureProvider.autoDispose.family<AiConversation, String>(
    (ref, id) => ref.watch(aiRepositoryProvider).conversation(id));
