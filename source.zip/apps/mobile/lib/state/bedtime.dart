import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/bedtime/bedtime_repository.dart';
import '../data/follow/follow_repository.dart';
import '../data/math/math_repository.dart';
import '../domain/bedtime.dart';
import '../domain/follow.dart';
import '../domain/math_games.dart';
import 'account.dart';
import 'session.dart';

/// Set in main.dart (Supabase or demo) and in tests.
final bedtimeRepositoryProvider = Provider<BedtimeRepository>((ref) => DemoBedtimeRepository());

final followRepositoryProvider = Provider<FollowRepository>((ref) {
  final b = ref.watch(bedtimeRepositoryProvider);
  return DemoFollowRepository(b is DemoBedtimeRepository ? b : DemoBedtimeRepository());
});

/// Stories + progress of the open profile.
final bedtimeProvider = FutureProvider.autoDispose<BedtimeState>((ref) {
  final p = ref.watch(currentProfileProvider);
  if (p == null) return const BedtimeState();
  return ref.watch(bedtimeRepositoryProvider).load(p);
});

/// Parent report for one child and one period.
final followProvider = FutureProvider.autoDispose.family<FollowReport, (String, FollowPeriod)>((ref, key) {
  final child = ref.watch(accountProvider).valueOrNull?.profileById(key.$1);
  if (child == null) return const FollowReport();
  return ref.watch(followRepositoryProvider).report(child, key.$2);
});

/// Night look for the bedtime section (on by default; per device while the app is open).
final bedtimeNightProvider = StateProvider<bool>((ref) => true);

// ---------------------------------------------------------------- math games
/// Set in main.dart (Supabase or demo) and in tests.
final mathRepositoryProvider = Provider<MathRepository>((ref) => DemoMathRepository());

/// Math games progress of the open profile.
final mathProvider = FutureProvider.autoDispose<MathState>((ref) {
  final p = ref.watch(currentProfileProvider);
  if (p == null) return const MathState();
  return ref.watch(mathRepositoryProvider).load(p);
});
