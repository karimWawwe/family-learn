import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/eng_unit/eng_unit_repository.dart';
import '../domain/eng_unit.dart';
import 'account.dart';
import 'session.dart';

/// Set in main.dart (Supabase or demo) and in tests.
final engUnitRepositoryProvider = Provider<EngUnitRepository>((ref) => DemoEngUnitRepository());

/// Progress of the open profile.
final engUnitProvider = FutureProvider.autoDispose<EngUnitState>((ref) {
  final p = ref.watch(currentProfileProvider);
  if (p == null) return const EngUnitState();
  return ref.watch(engUnitRepositoryProvider).load(p);
});

/// Progress of one profile (parent dashboard).
final engUnitForProvider = FutureProvider.autoDispose.family<EngUnitState, String>((ref, profileId) {
  final p = ref.watch(accountProvider).valueOrNull?.profileById(profileId);
  if (p == null) return const EngUnitState();
  return ref.watch(engUnitRepositoryProvider).load(p);
});
