import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/learning/learning_repository.dart';
import '../domain/learning.dart';
import '../domain/models.dart';

/// Set in main.dart (Supabase or demo) and in tests (demo).
final learningRepositoryProvider = Provider<LearningRepository>(
  (ref) => throw UnimplementedError('learningRepositoryProvider must be overridden'),
);

/// Courses with lesson status for a profile.
final courseMapProvider = FutureProvider.autoDispose.family<List<Course>, String>(
  (ref, profileId) => ref.watch(learningRepositoryProvider).courseMap(profileId),
);

/// XP, coins, stars, streak and today's minutes for a profile.
final walletProvider = FutureProvider.autoDispose.family<ProfileWallet, String>(
  (ref, profileId) => ref.watch(learningRepositoryProvider).wallet(profileId),
);

/// Parent report for a profile.
final reportProvider = FutureProvider.autoDispose.family<ProfileReport, String>(
  (ref, profileId) => ref.watch(learningRepositoryProvider).report(profileId),
);

/// Call after a lesson ends so every screen shows the new numbers.
void refreshProgress(WidgetRef ref, String profileId) {
  ref.invalidate(courseMapProvider(profileId));
  ref.invalidate(walletProvider(profileId));
  ref.invalidate(reportProvider(profileId));
}
