import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/auth/auth_repository.dart';
import '../domain/account.dart';

/// Set in main.dart (Supabase or demo) and in tests (demo).
final authRepositoryProvider = Provider<AuthRepository>(
  (ref) => throw UnimplementedError('authRepositoryProvider must be overridden'),
);

/// Who is signed in on this device and which profiles they may see.
class AccountController extends AsyncNotifier<AccountState> {
  AuthRepository get _repo => ref.read(authRepositoryProvider);

  @override
  Future<AccountState> build() async {
    final repo = ref.watch(authRepositoryProvider);
    final sub = repo.changes.listen((_) => refresh());
    ref.onDispose(sub.cancel);
    final first = await repo.load();
    if (first.isReady) unawaited(repo.touch());
    return first;
  }

  /// Reloads without showing a loading screen. If the reload fails (for
  /// example no internet) the last known state is kept.
  Future<void> refresh() async {
    final next = await AsyncValue.guard(_repo.load);
    if (next.hasError && state.hasValue) return;
    state = next;
  }

  /// Runs a backend action, then reloads the account.
  /// Throws [AuthFailure] so screens can show the message.
  Future<T> run<T>(Future<T> Function(AuthRepository repo) action) async {
    final result = await action(_repo);
    await refresh();
    return result;
  }
}

final accountProvider = AsyncNotifierProvider<AccountController, AccountState>(AccountController.new);

/// Parent ticked the consent box in this sign-up (checked before creating the family).
final consentGivenProvider = StateProvider<bool>((ref) => false);
