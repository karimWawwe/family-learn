import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/speech/speech_engine.dart';
import '../data/speak_game/speak_game_repository.dart';
import '../domain/speak_game.dart';
import 'account.dart';
import 'session.dart';

/// Set in main.dart (Supabase or demo) and in tests.
final speakGameRepositoryProvider = Provider<SpeakGameRepository>((ref) => DemoSpeakGameRepository());

/// Microphone / speech. Web Speech API in the browser; overridable in tests.
final speechEngineProvider = Provider<SpeechEngine>((ref) => createSpeechEngine());

/// Game state of the open profile.
final speakGameProvider = FutureProvider.autoDispose<SpeakGameState>((ref) {
  final p = ref.watch(currentProfileProvider);
  if (p == null) return const SpeakGameState();
  return ref.watch(speakGameRepositoryProvider).load(p);
});

/// Game state of any family profile (parent report).
final speakGameForProvider = FutureProvider.autoDispose.family<SpeakGameState, String>((ref, profileId) {
  final p = ref.watch(accountProvider).valueOrNull?.profileById(profileId);
  if (p == null) return const SpeakGameState();
  return ref.watch(speakGameRepositoryProvider).load(p);
});
