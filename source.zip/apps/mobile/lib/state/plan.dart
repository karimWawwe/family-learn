import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/plan/plan_repository.dart';
import '../domain/plan.dart';
import 'learning.dart';

/// Set in main.dart to the Supabase one; defaults to the demo plan (DEMO mode and tests).
final planRepositoryProvider = Provider<PlanRepository>(
  (ref) => DemoPlanRepository(ref.watch(learningRepositoryProvider)),
);

/// Today's plan for a profile.
final dailyPlanProvider = FutureProvider.autoDispose.family<DailyPlan, String>(
  (ref, profileId) => ref.watch(planRepositoryProvider).dailyPlan(profileId),
);

/// What is due in the review box + mastery per skill.
final reviewOverviewProvider = FutureProvider.autoDispose.family<ReviewOverview, String>(
  (ref, profileId) => ref.watch(planRepositoryProvider).reviewOverview(profileId),
);
