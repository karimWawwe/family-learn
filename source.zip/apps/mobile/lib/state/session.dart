import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/models.dart';
import 'account.dart';

/// Local, per-device UI state: which profile is open, language and theme.
/// The account itself (who is signed in) lives in [accountProvider].
class SessionState {
  const SessionState({
    this.profileId,
    this.localeOverride,
    this.themeMode = ThemeMode.light,
  });

  final String? profileId;
  final Locale? localeOverride;
  final ThemeMode themeMode;

  SessionState copyWith({
    String? profileId,
    bool clearProfile = false,
    Locale? localeOverride,
    ThemeMode? themeMode,
  }) =>
      SessionState(
        profileId: clearProfile ? null : (profileId ?? this.profileId),
        localeOverride: localeOverride ?? this.localeOverride,
        themeMode: themeMode ?? this.themeMode,
      );
}

class SessionController extends Notifier<SessionState> {
  @override
  SessionState build() => const SessionState();

  /// Called when the signed-in account changes: close the open profile
  /// (the language picked on the welcome screen is kept).
  void reset() => state = SessionState(themeMode: state.themeMode, localeOverride: state.localeOverride);

  /// Opening a profile (after its PIN) also resets any manual language
  /// choice, so each profile opens in its own UI language.
  void selectProfile(String id) => state = SessionState(profileId: id, themeMode: state.themeMode);

  void clearProfile() => state = state.copyWith(clearProfile: true);

  void setLocale(Locale locale) => state = state.copyWith(localeOverride: locale);

  void setThemeMode(ThemeMode mode) => state = state.copyWith(themeMode: mode);
}

final sessionProvider = NotifierProvider<SessionController, SessionState>(SessionController.new);

/// The open learner profile, taken from the real account. Null when no
/// profile is open, or when the open one no longer exists / is not visible.
final currentProfileProvider = Provider<LearnerProfile?>((ref) {
  final id = ref.watch(sessionProvider.select((s) => s.profileId));
  final account = ref.watch(accountProvider).valueOrNull;
  if (id == null || account == null || !account.isReady) return null;
  return account.profileById(id);
});

/// UI locale: manual override, else the open profile's language, else English.
final localeProvider = Provider<Locale>((ref) {
  final override = ref.watch(sessionProvider.select((s) => s.localeOverride));
  final profile = ref.watch(currentProfileProvider);
  return override ?? Locale(profile?.uiLocale ?? 'en');
});
