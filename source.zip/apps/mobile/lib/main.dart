import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'app.dart';
import 'core/config/env.dart';
import 'data/auth/auth_repository.dart';
import 'data/auth/demo_auth_repository.dart';
import 'data/auth/supabase_auth_repository.dart';
import 'data/learning/demo_learning_repository.dart';
import 'data/learning/learning_repository.dart';
import 'data/learning/supabase_learning_repository.dart';
import 'state/account.dart';
import 'state/learning.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final AuthRepository auth;
  final LearningRepository learning;
  if (Env.hasSupabase) {
    // Keeps the session on the phone, so parents and linked children's
    // phones stay signed in between launches.
    await Supabase.initialize(url: Env.supabaseUrl, anonKey: Env.supabaseAnonKey);
    auth = SupabaseAuthRepository(Supabase.instance.client);
    learning = SupabaseLearningRepository(Supabase.instance.client);
  } else {
    // No keys given: in-memory DEMO mode (see README).
    final demo = DemoAuthRepository();
    auth = demo;
    learning = DemoLearningRepository(demo);
  }

  runApp(ProviderScope(
    overrides: [
      authRepositoryProvider.overrideWithValue(auth),
      learningRepositoryProvider.overrideWithValue(learning),
    ],
    child: const FamilyLearnApp(),
  ));
}
