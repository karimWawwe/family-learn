// Question models for the Question Engine (11 types).
// Content comes from the content packs (Phase 5); in Phase 2 it is MOCK DATA.
//
// NOTE (Phase 2): `checkAnswer` below is a temporary, UI-only check so the
// screens can show right/wrong feedback. The real graders, partial scores,
// error codes and mastery evidence live in packages/learning_core (Phase 6).

sealed class Question {
  const Question({
    required this.id,
    required this.skill,
    required this.prompt,
    this.hint,
    this.explanation,
  });

  final String id;
  final String skill;
  final String prompt;
  final String? hint;
  final String? explanation;

  String get typeCode;
}

class MultipleChoiceQuestion extends Question {
  const MultipleChoiceQuestion({
    required super.id,
    required super.skill,
    required super.prompt,
    required this.options,
    required this.correctIndex,
    super.hint,
    super.explanation,
  });
  final List<String> options;
  final int correctIndex;
  @override
  String get typeCode => 'multiple_choice';
}

class TrueFalseQuestion extends Question {
  const TrueFalseQuestion({
    required super.id,
    required super.skill,
    required super.prompt,
    required this.answer,
    super.hint,
    super.explanation,
  });
  final bool answer;
  @override
  String get typeCode => 'true_false';
}

class FillBlankQuestion extends Question {
  const FillBlankQuestion({
    required super.id,
    required super.skill,
    required super.prompt,
    required this.before,
    required this.after,
    required this.accepted,
    super.hint,
    super.explanation,
  });
  final String before;
  final String after;
  final List<String> accepted;
  @override
  String get typeCode => 'fill_blank';
}

class MatchingQuestion extends Question {
  const MatchingQuestion({
    required super.id,
    required super.skill,
    required super.prompt,
    required this.left,
    required this.right,
    super.hint,
    super.explanation,
  });
  // left[i] matches right[i]; the UI shuffles the right column.
  final List<String> left;
  final List<String> right;
  @override
  String get typeCode => 'matching';
}

class OrderingQuestion extends Question {
  const OrderingQuestion({
    required super.id,
    required super.skill,
    required super.prompt,
    required this.correctOrder,
    super.hint,
    super.explanation,
  });
  final List<String> correctOrder;
  @override
  String get typeCode => 'ordering';
}

class DragDropQuestion extends Question {
  const DragDropQuestion({
    required super.id,
    required super.skill,
    required super.prompt,
    required this.before,
    required this.after,
    required this.tokens,
    required this.correctToken,
    super.hint,
    super.explanation,
  });
  final String before;
  final String after;
  final List<String> tokens;
  final String correctToken;
  @override
  String get typeCode => 'drag_drop';
}

class TypingQuestion extends Question {
  const TypingQuestion({
    required super.id,
    required super.skill,
    required super.prompt,
    required this.accepted,
    super.hint,
    super.explanation,
  });
  final List<String> accepted;
  @override
  String get typeCode => 'typing';
}

class ListeningQuestion extends Question {
  const ListeningQuestion({
    required super.id,
    required super.skill,
    required super.prompt,
    required this.audioText,
    required this.options,
    required this.correctIndex,
    super.hint,
    super.explanation,
  });
  // Phase 2: text that the audio will say. Phase 9: an audio file / TTS.
  final String audioText;
  final List<String> options;
  final int correctIndex;
  @override
  String get typeCode => 'listening';
}

class SpeakingQuestion extends Question {
  const SpeakingQuestion({
    required super.id,
    required super.skill,
    required super.prompt,
    required this.targetText,
    super.hint,
    super.explanation,
  });
  final String targetText;
  @override
  String get typeCode => 'speaking';
}

class ReadingQuestion extends Question {
  const ReadingQuestion({
    required super.id,
    required super.skill,
    required super.prompt,
    required this.passage,
    required this.options,
    required this.correctIndex,
    super.hint,
    super.explanation,
  });
  final String passage;
  final List<String> options;
  final int correctIndex;
  @override
  String get typeCode => 'reading';
}

class WordProblemQuestion extends Question {
  const WordProblemQuestion({
    required super.id,
    required super.skill,
    required super.prompt,
    required this.answer,
    this.unit,
    super.hint,
    super.explanation,
  });
  final num answer;
  final String? unit;
  @override
  String get typeCode => 'word_problem';
}

String _norm(String s) =>
    s.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ').replaceAll(RegExp(r'[.!?]$'), '');

bool _matchesAny(List<String> accepted, String given) {
  final g = _norm(given);
  return accepted.any((a) => _norm(a) == g);
}

/// Temporary UI-only check (see note at the top of this file).
/// Returns null when the answer cannot be auto-checked yet (speaking).
bool? checkAnswer(Question q, Object? answer) {
  switch (q) {
    case final MultipleChoiceQuestion m:
      return answer == m.correctIndex;
    case final TrueFalseQuestion t:
      return answer == t.answer;
    case final FillBlankQuestion f:
      return answer is String && _matchesAny(f.accepted, answer);
    case final MatchingQuestion m:
      // answer: Map<int leftIndex, int rightIndex in the ORIGINAL right list>
      if (answer is! Map<int, int> || answer.length != m.left.length) return false;
      return answer.entries.every((e) => e.key == e.value);
    case final OrderingQuestion o:
      if (answer is! List<String> || answer.length != o.correctOrder.length) return false;
      for (var i = 0; i < answer.length; i++) {
        if (answer[i] != o.correctOrder[i]) return false;
      }
      return true;
    case final DragDropQuestion d:
      return answer == d.correctToken;
    case final TypingQuestion t:
      return answer is String && _matchesAny(t.accepted, answer);
    case final ListeningQuestion l:
      return answer == l.correctIndex;
    case SpeakingQuestion():
      return null;
    case final ReadingQuestion r:
      return answer == r.correctIndex;
    case final WordProblemQuestion w:
      if (answer is! String) return false;
      final v = num.tryParse(answer.trim().replaceAll(',', '.'));
      return v != null && (v - w.answer).abs() < 0.0001;
  }
}
