/// Math games: "جدول الضرب" (times tables) and "تعلّم الوقت" (reading the clock).

enum MathGame { times, clock }

/// Best result of one game level (e.g. times 't4-easy', clock 'clock-2').
class MathBest {
  const MathBest({this.bestStars = 0, this.bestPoints = 0, this.bestCorrect = 0, this.total = 0, this.plays = 0});

  final int bestStars;
  final int bestPoints;
  final int bestCorrect;
  final int total;
  final int plays;
}

class MathState {
  const MathState({this.levels = const {}, this.points = 0, this.stars = 0, this.rounds = 0});

  /// key: '<game>|<level>'
  final Map<String, MathBest> levels;
  final int points;
  final int stars;
  final int rounds;

  MathBest best(MathGame g, String level) => levels['${g.name}|$level'] ?? const MathBest();

  /// Clock level n (1..5) opens when level n-1 was finished once.
  bool clockOpen(int n) => n <= 1 || best(MathGame.clock, 'clock-${n - 1}').plays > 0;

  /// Best stars over the three difficulties of one times table (or 'mixed').
  int tableStars(String table) => [
        for (final d in const ['easy', 'medium', 'hard']) best(MathGame.times, '$table-$d').bestStars,
      ].fold(0, (a, b) => a > b ? a : b);
}

/// One round played to the end.
class MathRoundResult {
  const MathRoundResult({
    required this.game,
    required this.level,
    required this.correct,
    required this.total,
    required this.stars,
    required this.points,
    required this.seconds,
  });

  final MathGame game;
  final String level;
  final int correct;
  final int total;
  final int stars;
  final int points;
  final int seconds;

  /// ⭐ finished, ⭐⭐ good (70%+), ⭐⭐⭐ excellent (90%+).
  static int starsFor(int correct, int total) {
    if (total == 0) return 1;
    final r = correct / total;
    return r >= 0.9 ? 3 : (r >= 0.7 ? 2 : 1);
  }
}
