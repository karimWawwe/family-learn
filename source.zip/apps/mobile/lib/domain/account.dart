// Account & family types (Phase 3). Plain Dart: no Flutter, no network.

import 'models.dart';

/// Which kind of sign-in this device has.
///  parent      = the parent's email account (can manage the family)
///  childDevice = a child's own phone, linked with a one-time code, bound to one profile
enum DeviceRole { parent, childDevice }

enum AccountStage {
  /// No session (or a child's phone that is not linked yet).
  signedOut,

  /// Parent confirmed their email but has not created the family yet.
  needsFamily,

  /// Signed in and part of a family.
  ready,
}

/// Bump when the consent text changes; stored with the family.
const kConsentVersion = 'family-consent-v1';

class AccountState {
  const AccountState._({
    required this.stage,
    this.email,
    this.role,
    this.familyId,
    this.familyName,
    this.deviceProfileId,
    this.profiles = const [],
  });

  const AccountState.signedOut() : this._(stage: AccountStage.signedOut);

  const AccountState.needsFamily({required String? email})
      : this._(stage: AccountStage.needsFamily, email: email);

  const AccountState.ready({
    required DeviceRole role,
    required String familyId,
    required String familyName,
    required List<LearnerProfile> profiles,
    String? email,
    String? deviceProfileId,
  }) : this._(
          stage: AccountStage.ready,
          role: role,
          familyId: familyId,
          familyName: familyName,
          profiles: profiles,
          email: email,
          deviceProfileId: deviceProfileId,
        );

  final AccountStage stage;
  final String? email;
  final DeviceRole? role;
  final String? familyId;
  final String? familyName;

  /// On a child's phone: the one profile this phone may use.
  final String? deviceProfileId;

  /// Profiles this device may see: all of them for a parent, one for a child's phone.
  final List<LearnerProfile> profiles;

  bool get isReady => stage == AccountStage.ready;
  bool get isParentAccount => isReady && role == DeviceRole.parent;
  bool get isChildDevice => isReady && role == DeviceRole.childDevice;

  LearnerProfile? profileById(String id) {
    for (final p in profiles) {
      if (p.id == id) return p;
    }
    return null;
  }

  List<LearnerProfile> get children => profiles.where((p) => p.isChild).toList();
  List<LearnerProfile> get adults => profiles.where((p) => !p.isChild).toList();
}

/// A learner typed in by the parent (family creation or "Add learner").
class NewLearner {
  const NewLearner({
    required this.displayName,
    required this.kind,
    this.grade,
    this.uiLocale = 'en',
    this.avatarEmoji,
  });

  final String displayName;
  final ProfileKind kind;
  final int? grade;
  final String uiLocale;
  final String? avatarEmoji;

  Map<String, Object?> toJson() => {
        'display_name': displayName.trim(),
        'kind': kind == ProfileKind.child ? 'child' : 'adult',
        if (kind == ProfileKind.child) 'grade': grade,
        'ui_locale': uiLocale,
        if (avatarEmoji != null) 'avatar_emoji': avatarEmoji,
      };
}

class NewFamily {
  const NewFamily({
    required this.familyName,
    required this.parentName,
    required this.parentLocale,
    required this.learners,
    this.consentVersion = kConsentVersion,
  });

  final String familyName;
  final String parentName;
  final String parentLocale;
  final List<NewLearner> learners;
  final String consentVersion;
}

class PinCheck {
  const PinCheck({required this.ok, required this.attemptsLeft, this.lockedUntil});

  final bool ok;
  final int attemptsLeft;
  final DateTime? lockedUntil;

  bool get isLocked => lockedUntil != null && lockedUntil!.isAfter(DateTime.now());
}

class PairingCode {
  const PairingCode({required this.code, required this.expiresAt});
  final String code;
  final DateTime expiresAt;
}

class LinkedDevice {
  const LinkedDevice({
    required this.userId,
    required this.profileId,
    required this.linkedAt,
    required this.lastSeenAt,
    this.deviceName,
  });

  final String userId;
  final String profileId;
  final String? deviceName;
  final DateTime linkedAt;
  final DateTime lastSeenAt;
}

/// Error with a short machine code. The UI shows the text for 'err_<code>'.
class AuthFailure implements Exception {
  const AuthFailure(this.code, [this.detail]);

  final String code;
  final String? detail;

  static const known = {
    'invalid_credentials',
    'email_not_confirmed',
    'user_exists',
    'weak_password',
    'invalid_email',
    'invalid_code',
    'code_expired',
    'too_many_attempts',
    'rate_limited',
    'network',
    'already_in_family',
    'parent_only',
    'not_found',
    'invalid_pin',
    'grade_required',
    'invalid_profile',
    'invalid_family',
    'too_many_profiles',
    'anonymous_disabled',
    'already_linked',
    'lesson_locked',
    'lesson_finished',
    'plan_not_installed',
  };

  /// Text key for AppStrings. Unknown codes fall back to a generic message.
  String get messageKey => known.contains(code) ? 'err_$code' : 'err_unknown';

  @override
  String toString() => 'AuthFailure($code${detail == null ? '' : ': $detail'})';
}
