// Phase 6: today's plan, spaced review, mastery and the placement test. Plain Dart.

import 'learning.dart';
import 'questions.dart';

enum PlanTaskKind { review, lesson, speak }

class PlanTask {
  const PlanTask({
    required this.kind,
    required this.done,
    this.minutes = 5,
    this.count = 0,
    this.lessonId,
    this.title,
    this.course,
  });

  final PlanTaskKind kind;
  final bool done;
  final int minutes;

  /// Review: how many questions are waiting (max 10 per session).
  final int count;

  /// Lesson: the next lesson to play.
  final String? lessonId;
  final String? title;
  final String? course;
}

/// What the learner should do today, worked out on the server.
class DailyPlan {
  const DailyPlan({
    this.tasks = const [],
    this.done = 0,
    this.total = 0,
    this.minutesToday = 0,
    this.goalMinutes = 20,
    this.streakDays = 0,
    this.dueReview = 0,
    this.suggestPlacement = false,
  });

  final List<PlanTask> tasks;
  final int done;
  final int total;
  final int minutesToday;
  final int goalMinutes;
  final int streakDays;
  final int dueReview;

  /// True for a new learner who has not taken the placement test or any lesson yet.
  final bool suggestPlacement;

  bool get allDone => total > 0 && done >= total;
  double get progress => total == 0 ? 0 : (done / total).clamp(0.0, 1.0).toDouble();

  /// The first task still to do (null when everything is done).
  PlanTask? get nextTask {
    for (final t in tasks) {
      if (!t.done) return t;
    }
    return null;
  }
}

class ReviewItemInfo {
  const ReviewItemInfo({
    required this.questionId,
    required this.prompt,
    required this.skill,
    required this.box,
    this.lastResult,
    this.lapses = 0,
  });

  final String questionId;
  final String prompt;
  final String skill;

  /// 1..5 (6 = mastered). Higher = remembered longer.
  final int box;
  final bool? lastResult;
  final int lapses;

  /// 0..1 for a mastery bar.
  double get strength => box >= 6 ? 1.0 : (box - 1) / 5.0;
}

class SkillMasteryInfo {
  const SkillMasteryInfo({required this.code, required this.name, required this.questions, required this.mastery});

  final String code;
  final String name;
  final int questions;

  /// 0..1 from the review box (questions answered right over time).
  final double mastery;

  bool get isWeak => questions >= 3 && mastery < 0.4;
}

class ReviewOverview {
  const ReviewOverview({
    this.dueToday = 0,
    this.dueTomorrow = 0,
    this.tracked = 0,
    this.mastered = 0,
    this.reviewedToday = false,
    this.items = const [],
    this.skills = const [],
  });

  final int dueToday;
  final int dueTomorrow;
  final int tracked;
  final int mastered;
  final bool reviewedToday;
  final List<ReviewItemInfo> items;
  final List<SkillMasteryInfo> skills;

  List<SkillMasteryInfo> get weakSkills => skills.where((s) => s.isWeak).toList();
}

enum PracticeKind { review, placement }

/// A review or placement session opened on the server. Questions come
/// WITHOUT answers. [sessionId] is null when there is nothing to review.
class PracticeSession {
  const PracticeSession({required this.sessionId, required this.kind, required this.questions});

  final String? sessionId;
  final PracticeKind kind;
  final List<Question> questions;
}

class PlacementCourse {
  const PlacementCourse({
    required this.courseId,
    required this.title,
    required this.placedPosition,
    required this.lessons,
    this.startLesson,
  });

  final String courseId;
  final String title;

  /// Lessons 1..placedPosition are already known (0 = start from the beginning).
  final int placedPosition;
  final int lessons;
  final String? startLesson;
}

class PracticeOutcome {
  const PracticeOutcome({
    required this.kind,
    required this.correct,
    required this.total,
    required this.xp,
    required this.coins,
    required this.stars,
    required this.wallet,
    this.placements = const [],
  });

  final PracticeKind kind;
  final int correct;
  final int total;
  final int xp;
  final int coins;
  final int stars;
  final ProfileWallet wallet;
  final List<PlacementCourse> placements;

  int get percent => total == 0 ? 0 : (correct * 100 / total).round();
}
