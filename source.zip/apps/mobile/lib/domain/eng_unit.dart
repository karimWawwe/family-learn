// English unit "English Grammar – Capitalization and Financial Literacy".
// Content, stages and progress rules. Progress is saved per profile
// (eng_unit_state / eng_unit_log in Supabase, in memory in DEMO mode).

const engUnitCode = 'caps_finance';

/// One capitalization exercise: the student taps the words that are wrong.
class CapsExercise {
  const CapsExercise({
    required this.id,
    required this.sentence,
    required this.fixes,
    required this.whyEn,
    required this.whyAr,
  });

  final String id;

  /// The original sentence, exactly as given (with its mistakes).
  final String sentence;

  /// Wrong word (as written, without punctuation) -> corrected word.
  final Map<String, String> fixes;
  final String whyEn;
  final String whyAr;

  /// The sentence split into words (punctuation stays on the word).
  List<String> get tokens => sentence.split(' ');

  /// Index of every word that has to be corrected.
  Set<int> get wrongIndexes {
    final t = tokens;
    final out = <int>{};
    for (var i = 0; i < t.length; i++) {
      if (fixes.containsKey(bareWord(t[i]))) out.add(i);
    }
    return out;
  }

  /// The word at [i] after correction (punctuation kept).
  String corrected(int i) {
    final w = tokens[i];
    final b = bareWord(w);
    final f = fixes[b];
    return f == null ? w : w.replaceFirst(b, f);
  }

  String get correctedSentence => [for (var i = 0; i < tokens.length; i++) corrected(i)].join(' ');
}

/// The word without leading / trailing punctuation ("renaissance," -> "renaissance").
String bareWord(String w) => w.replaceAll(RegExp(r"^[^A-Za-z']+|[^A-Za-z']+$"), '');

class CapsRule {
  const CapsRule(this.n, this.en, this.ar, this.example);
  final int n;
  final String en;
  final String ar;
  final String example;
}

const capsRules = <CapsRule>[
  CapsRule(1, "Capitalize people's names.", 'نبدأ أسماء الأشخاص بحرف كبير.', 'Thomas Jefferson, Aunt Nellie, General Sherman'),
  CapsRule(2, 'Capitalize countries and nationalities.', 'نبدأ أسماء الدول والجنسيات واللغات بحرف كبير.', 'the United States, English, Italian, Brazilian'),
  CapsRule(3, 'Capitalize cities and geographical landmarks.', 'نبدأ أسماء المدن والمعالم الجغرافية (أنهار، جبال، غابات) بحرف كبير.', 'San Francisco, the Colorado River, the Grand Canyon'),
  CapsRule(4, 'Capitalize historical events and important documents.', 'نبدأ أسماء الأحداث التاريخية والوثائق المهمة بحرف كبير.', 'the Renaissance, the Battle of the Bulge, the Constitution'),
  CapsRule(5, 'Capitalize official names of places and institutions.', 'نبدأ الأسماء الرسمية للأماكن والمؤسسات بحرف كبير.', 'the Sistine Chapel, Coit Tower, the Statue of Liberty'),
  CapsRule(6, 'Do not capitalize ordinary nouns unless they are part of a proper name.',
      'لا نكتب الأسماء العادية بحرف كبير إلا إذا كانت جزءاً من اسم علم.', 'an artist, a river → but: the Colorado River'),
  CapsRule(7, 'Capitalize the first word of every sentence.', 'نبدأ أول كلمة في كل جملة بحرف كبير.', 'My aunt went rafting.'),
];

const capsExercises = <CapsExercise>[
  CapsExercise(
    id: 'ex1',
    sentence: 'Michelangelo, perhaps the greatest Artist of the renaissance, is famous for the religious scenes he painted on the Ceiling of the Sistine Chapel.',
    fixes: {'Artist': 'artist', 'renaissance': 'Renaissance', 'Ceiling': 'ceiling'},
    whyEn: '"artist" and "ceiling" are ordinary nouns (rule 6). "Renaissance" is the name of a historical period (rule 4).',
    whyAr: '«artist» و«ceiling» أسماء عادية فتُكتب بحرف صغير (القاعدة 6). أما «Renaissance» فهي اسم فترة تاريخية فتبدأ بحرف كبير (القاعدة 4).',
  ),
  CapsExercise(
    id: 'ex2',
    sentence: "Lasting from 1337 until 1453, the Hundred Years' War was a series of ongoing Battles and Disputes between the english and the French.",
    fixes: {'Battles': 'battles', 'Disputes': 'disputes', 'english': 'English'},
    whyEn: '"battles" and "disputes" are ordinary nouns (rule 6). "English" is a nationality (rule 2), just like "French".',
    whyAr: '«battles» و«disputes» أسماء عادية (القاعدة 6). أما «English» فهي جنسية فتبدأ بحرف كبير مثل «French» (القاعدة 2).',
  ),
  CapsExercise(
    id: 'ex3',
    sentence: 'If you visit Sequoia National forest, you can see the tree known as General Sherman, which is nearly as tall as the Statue of liberty.',
    fixes: {'forest': 'Forest', 'liberty': 'Liberty'},
    whyEn: '"Sequoia National Forest" and "the Statue of Liberty" are official names, so every main word is capitalized (rules 3 and 5).',
    whyAr: '«Sequoia National Forest» و«the Statue of Liberty» أسماء رسمية لأماكن، فكل كلمة أساسية فيها تبدأ بحرف كبير (القاعدتان 3 و5).',
  ),
  CapsExercise(
    id: 'ex4',
    sentence: 'According to the constitution, a Person must be at least thirty years old to serve as a Senator.',
    fixes: {'constitution': 'Constitution', 'Person': 'person', 'Senator': 'senator'},
    whyEn: '"the Constitution" is an important document (rule 4). "person" and "senator" are ordinary nouns here (rule 6).',
    whyAr: '«the Constitution» وثيقة مهمة فتبدأ بحرف كبير (القاعدة 4). أما «person» و«senator» فأسماء عادية هنا (القاعدة 6).',
  ),
  CapsExercise(
    id: 'ex5',
    sentence: 'Thomas Jefferson, the third President of the United states, was an important Contributor to the Declaration of independence.',
    fixes: {'President': 'president', 'states': 'States', 'Contributor': 'contributor', 'independence': 'Independence'},
    whyEn: '"president" (after "the third") and "contributor" are ordinary nouns (rule 6). "the United States" is a country (rule 2) and "the Declaration of Independence" is a document (rule 4).',
    whyAr: '«president» و«contributor» أسماء عادية هنا (القاعدة 6). «the United States» اسم دولة (القاعدة 2)، و«the Declaration of Independence» وثيقة مهمة (القاعدة 4).',
  ),
  CapsExercise(
    id: 'ex6',
    sentence: 'On our tour of coit tower in san francisco, we met some brazilian Tourists who spoke Portuguese.',
    fixes: {'coit': 'Coit', 'tower': 'Tower', 'san': 'San', 'francisco': 'Francisco', 'brazilian': 'Brazilian', 'Tourists': 'tourists'},
    whyEn: '"Coit Tower" is the name of a place (rule 5), "San Francisco" is a city (rule 3) and "Brazilian" is a nationality (rule 2). "tourists" is an ordinary noun (rule 6).',
    whyAr: '«Coit Tower» اسم مكان (القاعدة 5)، و«San Francisco» مدينة (القاعدة 3)، و«Brazilian» جنسية (القاعدة 2). أما «tourists» فاسم عادي (القاعدة 6).',
  ),
  CapsExercise(
    id: 'ex7',
    sentence: 'After a Blizzard dumped twelve inches of snow across the Northeast, the Brooklyn Bridge was closed to bike riders for three days.',
    fixes: {'Blizzard': 'blizzard'},
    whyEn: '"blizzard" (a snowstorm) is an ordinary noun (rule 6). "the Northeast" and "the Brooklyn Bridge" are names, so they stay capitalized.',
    whyAr: '«blizzard» (عاصفة ثلجية) اسم عادي (القاعدة 6). أما «the Northeast» و«the Brooklyn Bridge» فأسماء أماكن وتبقى بحرف كبير.',
  ),
  CapsExercise(
    id: 'ex8',
    sentence: 'Aunt Nellie makes the best Spaghetti carbonara, which is an italian pasta Dish made with bacon, eggs, and cheese.',
    fixes: {'Spaghetti': 'spaghetti', 'italian': 'Italian', 'Dish': 'dish'},
    whyEn: 'Food names like "spaghetti" and the word "dish" are ordinary nouns (rule 6). "Italian" is a nationality (rule 2).',
    whyAr: 'أسماء الأكلات مثل «spaghetti» وكلمة «dish» أسماء عادية (القاعدة 6). أما «Italian» فجنسية تبدأ بحرف كبير (القاعدة 2).',
  ),
  CapsExercise(
    id: 'ex9',
    sentence: "Many historians agree that a major factor contributing to the Germans' defeat in the Battle of the bulge was their lack of Fuel.",
    fixes: {'bulge': 'Bulge', 'Fuel': 'fuel'},
    whyEn: '"the Battle of the Bulge" is a historical event, so "Bulge" is capitalized (rule 4). "fuel" is an ordinary noun (rule 6).',
    whyAr: '«the Battle of the Bulge» حدث تاريخي فتبدأ «Bulge» بحرف كبير (القاعدة 4). أما «fuel» (الوقود) فاسم عادي (القاعدة 6).',
  ),
  CapsExercise(
    id: 'ex10',
    sentence: 'My Aunt went white-water Rafting on the Colorado river in the Grand Canyon.',
    fixes: {'Aunt': 'aunt', 'Rafting': 'rafting', 'river': 'River'},
    whyEn: '"aunt" without a name after it and "rafting" are ordinary words (rule 6). "the Colorado River" is a geographical name (rule 3).',
    whyAr: '«aunt» بدون اسم بعدها و«rafting» كلمات عادية (القاعدة 6). أما «the Colorado River» فاسم نهر فتبدأ «River» بحرف كبير (القاعدة 3).',
  ),
];

/// The three uploaded videos, titled from what they actually show.
class UnitVideo {
  const UnitVideo(this.id, this.file, this.titleEn, this.titleAr, this.descEn, this.descAr, this.seconds);
  final String id;
  final String file;
  final String titleEn;
  final String titleAr;
  final String descEn;
  final String descAr;
  final int seconds;
  String get src => 'videos/$file';
  String get poster => 'videos/${file.replaceAll('.mp4', '.jpg')}';
}

const unitVideos = <UnitVideo>[
  UnitVideo(
    'vid_22',
    '22.mp4',
    'Correct the five capitalization errors',
    'صحّح أخطاء الحروف الكبيرة الخمسة',
    'Watch how the mistakes are clicked one by one in: "When I asked Dad whether the mountains and craters on Venus have names, he told me that one of the craters is named Billie Holiday."',
    'شاهد كيف يتم الضغط على الأخطاء واحداً واحداً في جملة عن الجبال والفوهات على كوكب الزهرة (Venus) واسم Billie Holiday.',
    10,
  ),
  UnitVideo(
    'vid_33',
    '33.mp4',
    'Find the four capitalization errors',
    'اكتشف الأخطاء الأربعة في الحروف الكبيرة',
    'A short example: "Of the many different kinds of food available in southern california, mexican Food is my favorite." Can you spot the four mistakes?',
    'مثال قصير: جملة عن الأكل في southern california و mexican Food — هل تقدر تكتشف الأخطاء الأربعة؟',
    4,
  ),
  UnitVideo(
    'vid_11',
    '11.mp4',
    'Math practice: division facts for 2, 3, 4, 5 and 10',
    'تدريب رياضيات: حقائق القسمة على 2 و3 و4 و5 و10',
    'Solving division questions on a tablet (for example 40 ÷ 5), typing the answer and pressing Submit.',
    'حل أسئلة القسمة على التابلت (مثل 40 ÷ 5)، وكتابة الإجابة ثم الضغط على Submit.',
    47,
  ),
];

/// Every item that counts towards completion.
const engUnitReadItem = 'rules';
const engUnitQuizItem = 'card_q1';
List<String> get engUnitAnswerItems => [for (final e in capsExercises) e.id, engUnitQuizItem];
int get engUnitTotalItems => 1 + engUnitAnswerItems.length + unitVideos.length;

/// Stages that open one after another.
class UnitStage {
  const UnitStage(this.n, this.emoji, this.titleEn, this.titleAr, this.items);
  final int n;
  final String emoji;
  final String titleEn;
  final String titleAr;
  final List<String> items;
}

const unitStages = <UnitStage>[
  UnitStage(1, '📖', 'Learn the capitalization rules', 'تعلّم قواعد الحروف الكبيرة', ['rules']),
  UnitStage(2, '✏️', 'Practice 1 – sentences 1 to 5', 'تدريب 1 – الجمل من 1 إلى 5', ['ex1', 'ex2', 'ex3', 'ex4', 'ex5']),
  UnitStage(3, '✏️', 'Practice 2 – sentences 6 to 10', 'تدريب 2 – الجمل من 6 إلى 10', ['ex6', 'ex7', 'ex8', 'ex9', 'ex10']),
  UnitStage(4, '💳', 'Money skills – debit vs credit cards', 'مهارات مالية – بطاقة الخصم وبطاقة الائتمان', ['card_q1']),
];

/// Saved result of one item.
class UnitItemStat {
  const UnitItemStat({this.attempts = 0, this.wrong = 0, this.solved = false, this.bestStars = 0});
  final int attempts;
  final int wrong;
  final bool solved;
  final int bestStars;
}

class EngUnitState {
  const EngUnitState({this.items = const {}, this.videos = const {}, this.read = false});

  final Map<String, UnitItemStat> items;
  final Set<String> videos;
  final bool read;

  UnitItemStat item(String id) => items[id] ?? const UnitItemStat();
  bool done(String id) => id == engUnitReadItem ? read : item(id).solved;

  bool stageDone(int n) => unitStages[n - 1].items.every(done);

  /// Stage 1 is always open; every next stage opens when the one before is done.
  /// Once opened (because the earlier stage is done) it stays open.
  bool stageOpen(int n) => n <= 1 || stageDone(n - 1);

  int get currentStage {
    for (final s in unitStages) {
      if (!stageDone(s.n)) return s.n;
    }
    return unitStages.length + 1; // all done
  }

  int get stars => items.values.fold(0, (s, i) => s + i.bestStars);
  int get maxStars => engUnitAnswerItems.length * 3;
  int get attempts => items.values.fold(0, (s, i) => s + i.attempts);
  int get wrong => items.values.fold(0, (s, i) => s + i.wrong);
  int get correct => items.values.where((i) => i.solved).length;
  int get videosWatched => unitVideos.where((v) => videos.contains(v.id)).length;

  double get completion {
    final done = (read ? 1 : 0) + engUnitAnswerItems.where((id) => item(id).solved).length + videosWatched;
    return done / engUnitTotalItems;
  }
}

/// Stars for a correct answer: first try 3, second try 2, later 1.
int starsForAttempt(int attemptNumber) => attemptNumber <= 1 ? 3 : (attemptNumber == 2 ? 2 : 1);

/// Allowed item codes (same list as the database check).
final engUnitItemRe = RegExp(r'^(rules|ex([1-9]|10)|card_q1|vid_(11|22|33))$');
