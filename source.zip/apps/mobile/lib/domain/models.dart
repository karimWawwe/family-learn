// Domain models shared by the UI. Plain Dart: no Flutter, no network.
// Phase 3: LearnerProfile comes from the real family account (Supabase).
// Learning data (courses, plans, mastery...) is still MOCK DATA until Phases 4-6.

enum ProfileKind { adult, child }

enum UiMode { kid, pro }

/// parent = the account holder's own profile; member = any other learner.
enum FamilyRole { parent, member }

class LearnerProfile {
  const LearnerProfile({
    required this.id,
    required this.displayName,
    required this.kind,
    required this.role,
    required this.uiMode,
    required this.uiLocale,
    required this.avatarEmoji,
    required this.dailyMinutesGoal,
    this.grade,
    this.birthYear,
    this.trackIds = const [],
    this.hasPin = false,
    this.aiEnabled = true,
  });

  final String id;
  final String displayName;
  final ProfileKind kind;
  final FamilyRole role;
  final UiMode uiMode;
  final String uiLocale; // 'en' | 'ar'
  final String avatarEmoji;
  final int dailyMinutesGoal;
  final int? grade;
  final int? birthYear;
  final List<String> trackIds;
  final bool hasPin;
  final bool aiEnabled;

  bool get isChild => kind == ProfileKind.child;
  bool get isParent => role == FamilyRole.parent;

  LearnerProfile copyWith({
    String? displayName,
    String? uiLocale,
    String? avatarEmoji,
    int? dailyMinutesGoal,
    bool? hasPin,
    bool? aiEnabled,
  }) =>
      LearnerProfile(
        id: id,
        displayName: displayName ?? this.displayName,
        kind: kind,
        role: role,
        uiMode: uiMode,
        uiLocale: uiLocale ?? this.uiLocale,
        avatarEmoji: avatarEmoji ?? this.avatarEmoji,
        dailyMinutesGoal: dailyMinutesGoal ?? this.dailyMinutesGoal,
        grade: grade,
        birthYear: birthYear,
        trackIds: trackIds,
        hasPin: hasPin ?? this.hasPin,
        aiEnabled: aiEnabled ?? this.aiEnabled,
      );
}

class Course {
  const Course({
    required this.id,
    required this.subject,
    required this.title,
    required this.levelLabel,
    required this.units,
  });

  final String id;
  final String subject; // 'english' | 'math' | 'business'
  final String title;
  final String levelLabel;
  final List<Unit> units;
}

class Unit {
  const Unit({required this.id, required this.title, required this.lessons});
  final String id;
  final String title;
  final List<LessonSummary> lessons;
}

enum LessonStatus { locked, available, inProgress, done }

class LessonSummary {
  const LessonSummary({
    required this.id,
    required this.title,
    required this.minutes,
    required this.status,
  });
  final String id;
  final String title;
  final int minutes;
  final LessonStatus status;
}

class SkillMastery {
  const SkillMastery({
    required this.skillCode,
    required this.name,
    required this.subject,
    required this.mastery,
  });
  final String skillCode;
  final String name;
  final String subject;
  final double mastery; // 0..1

  bool get isWeak => mastery < 0.5;
  bool get isMastered => mastery >= 0.8;
}

enum PlanItemType { review, lesson, practice, game, speaking, vocabulary }

class DailyPlanItem {
  const DailyPlanItem({
    required this.type,
    required this.title,
    required this.subtitle,
    required this.minutes,
    required this.done,
    this.lessonId,
  });
  final PlanItemType type;
  final String title;
  final String subtitle;
  final int minutes;
  final bool done;
  final String? lessonId;
}

class VocabItem {
  const VocabItem({
    required this.word,
    required this.meaningEn,
    required this.meaningAr,
    required this.example,
    required this.ipa,
    required this.difficulty,
    required this.mastery,
    required this.errors,
    required this.lastReview,
    required this.nextReview,
    required this.domain,
  });
  final String word;
  final String meaningEn;
  final String meaningAr;
  final String example;
  final String ipa;
  final int difficulty; // 1..5
  final double mastery; // 0..1
  final int errors;
  final DateTime? lastReview;
  final DateTime nextReview;
  final String domain;
}

enum ReviewReason { due, weak, recentError }

class ReviewItem {
  const ReviewItem({
    required this.title,
    required this.kind,
    required this.reason,
    required this.mastery,
  });
  final String title;
  final String kind; // 'word' | 'skill'
  final ReviewReason reason;
  final double mastery;
}

class Achievement {
  const Achievement({
    required this.code,
    required this.title,
    required this.emoji,
    required this.earned,
  });
  final String code;
  final String title;
  final String emoji;
  final bool earned;
}

class Wallet {
  const Wallet({
    required this.xp,
    required this.coins,
    required this.stars,
    required this.level,
    required this.streakDays,
  });
  final int xp;
  final int coins;
  final int stars;
  final int level;
  final int streakDays;
}

class RoleplayScenario {
  const RoleplayScenario({
    required this.code,
    required this.title,
    required this.persona,
    required this.goal,
    required this.emoji,
  });
  final String code;
  final String title;
  final String persona;
  final String goal;
  final String emoji;
}

class ChatMessage {
  const ChatMessage({required this.fromLearner, required this.text});
  final bool fromLearner;
  final String text;
}

class ChildReport {
  const ChildReport({
    required this.profileId,
    required this.minutesToday,
    required this.minutesWeek,
    required this.questionsWeek,
    required this.accuracyWeek,
    required this.dailyGoalMinutes,
    required this.streakDays,
    required this.minutesByDay,
    required this.weakAreas,
    required this.toReview,
    required this.history,
  });
  final String profileId;
  final int minutesToday;
  final int minutesWeek;
  final int questionsWeek;
  final double accuracyWeek;
  final int dailyGoalMinutes;
  final int streakDays;
  final List<int> minutesByDay; // last 7 days, oldest first
  final List<String> weakAreas;
  final List<String> toReview;
  final List<String> history;
}
