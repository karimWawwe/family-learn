/// Speaking game ("Say it!"): levels of words the child reads aloud.

class SpeakWord {
  const SpeakWord({
    required this.text,
    this.emoji = '',
    this.meaningAr = '',
    this.accepted = const [],
    this.hint = '',
  });

  /// What the child must say (a word or a short sentence).
  final String text;
  final String emoji;
  final String meaningAr;

  /// Sound-alikes that also count (e.g. "two": ["to", "too", "2"]).
  final List<String> accepted;

  /// Optional help, e.g. syllables "ba-na-na".
  final String hint;

  bool get isPhrase => text.trim().contains(' ');
}

class SpeakLevel {
  const SpeakLevel({
    required this.id,
    required this.title,
    this.titleAr = '',
    this.emoji = '⭐',
    this.strictness = 0.75,
    this.source = '',
    this.words = const [],
    this.bestStars = 0,
    this.plays = 0,
    this.unlocked = false,
  });

  final String id;
  final String title;
  final String titleAr;
  final String emoji;

  /// Minimum pronunciation score counted as correct (higher = stricter).
  final double strictness;

  /// Where the words come from (school book unit / lesson).
  final String source;
  final List<SpeakWord> words;
  final int bestStars;
  final int plays;
  final bool unlocked;

  bool get completed => bestStars > 0;
}

class TrickyWord {
  const TrickyWord(this.word, this.misses);

  final String word;
  final int misses;
}

class SpeakGameState {
  const SpeakGameState({
    this.track = 'young',
    this.levels = const [],
    this.points = 0,
    this.pointsToday = 0,
    this.wordsMastered = 0,
    this.dayStreak = 0,
    this.lastPlayed,
    this.tricky = const [],
  });

  /// young (grades 1-4) | older (grade 5+) | adult
  final String track;
  final List<SpeakLevel> levels;
  final int points;
  final int pointsToday;
  final int wordsMastered;
  final int dayStreak;
  final DateTime? lastPlayed;

  /// Words with the most unsuccessful tries lately (for the parent).
  final List<TrickyWord> tricky;

  int get stars => levels.fold(0, (s, l) => s + l.bestStars);
  int get levelsDone => levels.where((l) => l.completed).length;

  /// Stickers: one per finished level (its emoji).
  List<String> get stickers => [for (final l in levels) if (l.completed) l.emoji];

  SpeakLevel? levelById(String id) {
    for (final l in levels) {
      if (l.id == id) return l;
    }
    return null;
  }

  SpeakLevel? get nextLevel {
    for (final l in levels) {
      if (l.unlocked && !l.completed) return l;
    }
    return levels.isEmpty ? null : levels.last;
  }

  /// Simple badges from the totals.
  List<SpeakBadge> get badges => [
        SpeakBadge('first', '🎤', 'First word', 'أول كلمة', wordsMastered >= 1),
        SpeakBadge('w25', '🗣️', '25 words', '25 كلمة', wordsMastered >= 25),
        SpeakBadge('w100', '🏅', '100 words', '100 كلمة', wordsMastered >= 100),
        SpeakBadge('perfect', '🌟', '3-star level', 'مستوى بـ 3 نجوم', levels.any((l) => l.bestStars >= 3)),
        SpeakBadge('streak3', '🔥', '3 days in a row', '3 أيام متتالية', dayStreak >= 3),
        SpeakBadge('p1000', '💎', '1000 points', '1000 نقطة', points >= 1000),
      ];
}

class SpeakBadge {
  const SpeakBadge(this.code, this.emoji, this.name, this.nameAr, this.earned);

  final String code;
  final String emoji;
  final String name;
  final String nameAr;
  final bool earned;
}

/// One level played to the end (sent to the server).
class SpeakPlayResult {
  const SpeakPlayResult({
    required this.levelId,
    required this.points,
    required this.stars,
    required this.words,
    required this.firstTry,
    required this.attempts,
  });

  final String levelId;
  final int points;
  final int stars;
  final int words;
  final int firstTry;
  final int attempts;
}
