/// "حكاية قبل النوم": calm stories with one value each.

class StoryPage {
  const StoryPage({required this.text, this.scene = const [], this.bg = 'night'});

  final String text;

  /// 1-4 emojis drawn as a calm picture.
  final List<String> scene;

  /// night | dusk | garden | home | forest | desert | sea | mountain | river | city
  final String bg;

  /// Sentences to read one by one (short utterances are more reliable in browsers).
  List<String> get sentences {
    final out = <String>[];
    final buf = StringBuffer();
    for (final ch in text.split('')) {
      buf.write(ch);
      if ('.!؟?:،'.contains(ch) && buf.toString().trim().length > 25) {
        out.add(buf.toString().trim());
        buf.clear();
      }
    }
    final rest = buf.toString().trim();
    if (rest.isNotEmpty) {
      if (out.isNotEmpty && rest.length < 12) {
        out[out.length - 1] = '${out.last} $rest';
      } else {
        out.add(rest);
      }
    }
    return out;
  }
}

class StoryQuestion {
  const StoryQuestion({required this.question, required this.options, required this.answer});

  final String question;
  final List<String> options;
  final int answer;
}

class BedtimeStory {
  const BedtimeStory({
    required this.id,
    required this.title,
    this.emoji = '🌙',
    required this.valueCode,
    required this.valueName,
    this.kind = 'value',
    this.minutes = 4,
    this.source = '',
    this.pages = const [],
    required this.question,
    this.activity = '',
    this.favorite = false,
    this.completed = 0,
    this.listened = 0,
  });

  final String id;
  final String title;
  final String emoji;
  final String valueCode;
  final String valueName;

  /// value (original story) | hadith (retold from an authentic narration)
  final String kind;
  final int minutes;

  /// For hadith stories: the book and number.
  final String source;
  final List<StoryPage> pages;
  final StoryQuestion question;
  final String activity;
  final bool favorite;
  final int completed;
  final int listened;

  bool get isHadith => kind == 'hadith';
  bool get isProphet => kind == 'prophet';

  static final _prophetRe = RegExp(r'سيدنا\s+(.+?)\s+(?:عليه|ﷺ|صلى)');

  /// For prophets stories: the prophet's name from the title
  /// ("سيدنا يونس عليه السلام والحوت" -> "يونس").
  String get prophetName {
    final m = _prophetRe.firstMatch(title);
    return m == null ? title : m.group(1)!.trim();
  }

  /// ﷺ for our Prophet Muhammad, «عليه السلام» for the other prophets.
  String get prophetHonorific => title.contains('ﷺ') ? 'ﷺ' : 'عليه السلام';

  /// Hadith and prophets stories always show where they come from.
  bool get showsSource => (isHadith || isProphet) && source.isNotEmpty;
  bool get isDone => completed > 0;

  BedtimeStory copyWith({bool? favorite, int? completed}) => BedtimeStory(
        id: id,
        title: title,
        emoji: emoji,
        valueCode: valueCode,
        valueName: valueName,
        kind: kind,
        minutes: minutes,
        source: source,
        pages: pages,
        question: question,
        activity: activity,
        favorite: favorite ?? this.favorite,
        completed: completed ?? this.completed,
        listened: listened,
      );
}

class LastStory {
  const LastStory({required this.storyId, this.page = 0, this.completed = false, this.at});

  final String storyId;
  final int page;
  final bool completed;
  final DateTime? at;
}

class BedtimeState {
  const BedtimeState({this.stories = const [], this.last});

  final List<BedtimeStory> stories;
  final LastStory? last;

  BedtimeStory? byId(String id) {
    for (final s in stories) {
      if (s.id == id) return s;
    }
    return null;
  }

  List<BedtimeStory> get favorites => stories.where((s) => s.favorite).toList();
  int get completedCount => stories.where((s) => s.isDone).length;
}

/// A listen opened on the server.
class ListenSession {
  const ListenSession({required this.listenId, this.page = 0});

  final String listenId;
  final int page;
}
