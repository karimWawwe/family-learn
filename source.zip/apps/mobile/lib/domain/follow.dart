/// "لوحة متابعة الوالدين": a child's real progress, compared with its own past.

enum FollowPeriod { day, week, month }

class RangeFigures {
  const RangeFigures({
    this.minutesLessons = 0,
    this.minutesStories = 0,
    this.minutesSpeaking = 0,
    this.minutesTotal = 0,
    this.daysUsed = 0,
    this.storiesListened = 0,
    this.storiesCompleted = 0,
    this.values = const [],
    this.lessonsDone = 0,
    this.questions = 0,
    this.correct = 0,
    this.speakWords = 0,
    this.speakLevels = 0,
    this.speakPoints = 0,
  });

  final int minutesLessons;
  final int minutesStories;
  final int minutesSpeaking;
  final int minutesTotal;
  final int daysUsed;
  final int storiesListened;
  final int storiesCompleted;
  final List<String> values;
  final int lessonsDone;
  final int questions;
  final int correct;
  final int speakWords;
  final int speakLevels;
  final int speakPoints;

  double? get accuracy => questions == 0 ? null : correct / questions;
  bool get isEmpty => daysUsed == 0 && minutesTotal == 0;
}

class DayMinutes {
  const DayMinutes(this.day, this.minutes);

  final DateTime day;
  final int minutes;
}

class StoryRef {
  const StoryRef({required this.id, required this.title, this.emoji = '🌙', this.value = ''});

  final String id;
  final String title;
  final String emoji;
  final String value;
}

class ValueCount {
  const ValueCount(this.value, this.count);

  final String value;
  final int count;
}

class FollowReport {
  const FollowReport({
    this.period = FollowPeriod.week,
    this.current = const RangeFigures(),
    this.previous = const RangeFigures(),
    this.byDay = const [],
    this.totalMinutes = 0,
    this.totalDays = 0,
    this.totalStoriesListened = 0,
    this.totalStoriesCompleted = 0,
    this.distinctStories = 0,
    this.totalLessons = 0,
    this.totalSpeakWords = 0,
    this.speakLevelsDone = 0,
    this.progressPoints = 0,
    this.lessonXp = 0,
    this.speakPoints = 0,
    this.storyPoints = 0,
    this.level = 1,
    this.intoLevel = 0,
    this.lastStory,
    this.lastStoryCompleted = false,
    this.lastStoryAt,
    this.favorites = const [],
    this.valuesAll = const [],
    this.topValue,
    this.lastActivityKind,
    this.lastActivityTitle,
    this.lastActivityAt,
    this.suggestion,
    this.trickyWords = const [],
    this.weakSkills = const [],
  });

  final FollowPeriod period;
  final RangeFigures current;
  final RangeFigures previous;
  final List<DayMinutes> byDay;
  final int totalMinutes;
  final int totalDays;
  final int totalStoriesListened;
  final int totalStoriesCompleted;
  final int distinctStories;
  final int totalLessons;
  final int totalSpeakWords;
  final int speakLevelsDone;

  /// Progress points = lesson XP + speaking-game points + 20 per finished story.
  final int progressPoints;
  final int lessonXp;
  final int speakPoints;
  final int storyPoints;

  /// 1 + points / 500.
  final int level;
  final int intoLevel;

  final StoryRef? lastStory;
  final bool lastStoryCompleted;
  final DateTime? lastStoryAt;
  final List<StoryRef> favorites;
  final List<ValueCount> valuesAll;
  final String? topValue;

  /// lesson | speak | story
  final String? lastActivityKind;
  final String? lastActivityTitle;
  final DateTime? lastActivityAt;

  /// An unfinished story picked from the child's own history.
  final StoryRef? suggestion;
  final List<String> trickyWords;
  final List<String> weakSkills;

  bool get neverUsed => totalDays == 0;
}
