// AI tutor, role-play conversations and the parent's log (Phase 8).
// Everything goes through the Edge Function "ai-chat"; the app never sees the API key.

class AiStatus {
  const AiStatus({required this.enabled, required this.usedToday, required this.dailyLimit, required this.monthCost, required this.monthlyBudget});
  final bool enabled;
  final int usedToday;
  final int dailyLimit;
  final double monthCost;
  final double monthlyBudget;

  int get remainingToday => (dailyLimit - usedToday).clamp(0, dailyLimit);
}

class AiScenario {
  const AiScenario({
    required this.code,
    required this.lang,
    required this.title,
    required this.titleAr,
    required this.persona,
    required this.goal,
    required this.emoji,
  });
  final String code;

  /// 'en' or 'fr': the language of the conversation.
  final String lang;
  final String title;
  final String titleAr;
  final String persona;
  final String goal;
  final String emoji;
}

class AiChatMessage {
  const AiChatMessage({required this.fromLearner, required this.text, this.flagged = false, this.at});
  final bool fromLearner;
  final String text;
  final bool flagged;
  final DateTime? at;
}

class AiFeedback {
  const AiFeedback({
    required this.summary,
    this.goalReached = false,
    this.grammar = const [],
    this.betterWords = const [],
    this.phrases = const [],
    this.newWords = const [],
  });
  final String summary;
  final bool goalReached;
  final List<(String, String)> grammar;
  final List<(String, String)> betterWords;
  final List<String> phrases;
  final List<String> newWords;
}

/// One answer of the gateway.
class AiReply {
  const AiReply({required this.conversationId, this.text, this.feedback, this.flagged = false, this.remainingToday});
  final String conversationId;
  final String? text;
  final AiFeedback? feedback;
  final bool flagged;
  final int? remainingToday;
}

class AiConversationSummary {
  const AiConversationSummary({
    required this.id,
    required this.kind,
    required this.title,
    required this.startedAt,
    required this.lastAt,
    required this.messages,
    this.scenario,
    this.preview,
    this.flagged = false,
    this.hasFeedback = false,
  });
  final String id;

  /// 'tutor' or 'roleplay'
  final String kind;
  final String title;
  final String? scenario;
  final DateTime startedAt;
  final DateTime lastAt;
  final int messages;
  final String? preview;
  final bool flagged;
  final bool hasFeedback;
}

class AiConversation {
  const AiConversation({
    required this.id,
    required this.profileId,
    required this.kind,
    required this.title,
    required this.messages,
    this.scenario,
    this.feedback,
    this.flagged = false,
  });
  final String id;
  final String profileId;
  final String kind;
  final String title;
  final String? scenario;
  final List<AiChatMessage> messages;
  final AiFeedback? feedback;
  final bool flagged;
}
