import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/l10n/app_strings.dart';
import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'domain/models.dart';
import 'state/session.dart';

class FamilyLearnApp extends ConsumerWidget {
  const FamilyLearnApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(routerProvider);
    final locale = ref.watch(localeProvider);
    final profile = ref.watch(currentProfileProvider);
    final themeMode = ref.watch(sessionProvider.select((s) => s.themeMode));
    // Children get the playful theme; adults and the sign-in flow get the pro theme.
    final mode = profile?.uiMode ?? UiMode.pro;

    return MaterialApp.router(
      title: 'Family Learn',
      debugShowCheckedModeBanner: false,
      routerConfig: router,
      locale: locale,
      supportedLocales: AppStrings.supportedLocales,
      localizationsDelegates: const [
        AppStrings.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: AppTheme.forMode(mode),
      darkTheme: AppTheme.forMode(mode, brightness: Brightness.dark),
      themeMode: themeMode,
    );
  }
}
