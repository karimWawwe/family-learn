import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../core/widgets/common.dart';
import '../../data/mock/mock_data.dart';
import '../../domain/learning.dart';
import '../../domain/models.dart';
import '../../state/learning.dart';
import '../../state/session.dart';

// Phase 4: XP, coins, stars, streak, today's minutes and "Continue" are REAL.
// The daily plan and skill mastery are still MOCK DATA until Phase 6.

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    return p.uiMode == UiMode.kid ? _KidHome(profile: p) : _ProHome(profile: p);
  }
}

void openPlanItem(BuildContext context, DailyPlanItem item) {
  switch (item.type) {
    case PlanItemType.lesson:
    case PlanItemType.practice:
    case PlanItemType.game:
      // The plan is MOCK until Phase 6: open the real course map instead.
      context.go(Routes.learn);
    case PlanItemType.review:
      context.go(Routes.review);
    case PlanItemType.vocabulary:
      context.push(Routes.vocab);
    case PlanItemType.speaking:
      context.push(Routes.roleplay);
  }
}

IconData planIcon(PlanItemType t) => switch (t) {
      PlanItemType.review => Icons.replay,
      PlanItemType.lesson => Icons.play_lesson_outlined,
      PlanItemType.practice => Icons.fitness_center,
      PlanItemType.game => Icons.sports_esports_outlined,
      PlanItemType.speaking => Icons.mic_none,
      PlanItemType.vocabulary => Icons.style_outlined,
    };

// ---------------------------------------------------------------- kid home
/// Opens the next lesson (in progress or available), else the course map.
void openNextLesson(BuildContext context, LessonSummary? next) {
  if (next == null) {
    context.go(Routes.learn);
  } else {
    context.push(Routes.lesson(next.id));
  }
}

class _KidHome extends ConsumerWidget {
  const _KidHome({required this.profile});

  final LearnerProfile profile;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final plan = MockData.planFor(profile);
    final wallet = ref.watch(walletProvider(profile.id)).valueOrNull ?? const ProfileWallet();
    final courses = ref.watch(courseMapProvider(profile.id)).valueOrNull;
    final next = courses == null ? null : nextLesson(courses);
    final weak = MockData.masteryFor(profile).where((m) => m.isWeak).toList();
    final doneMin = wallet.minutesToday;
    final totalMin = profile.dailyMinutesGoal;

    return AccountScaffold(
      body: RefreshIndicator(
       onRefresh: () async {
         ref.invalidate(courseMapProvider(profile.id));
         try {
           await ref.refresh(walletProvider(profile.id).future);
         } catch (_) {
           // keep showing the last numbers
         }
       },
       child: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: Row(
              children: [
                CircleAvatar(radius: 28, backgroundColor: const Color(0xFFFFE8D6), child: Text(profile.avatarEmoji, style: const TextStyle(fontSize: 30))),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${s.t('hello')} ${profile.displayName}!', style: context.text.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                      Text(s.f('level', [wallet.level]), style: context.text.bodyMedium),
                    ],
                  ),
                ),
                _Pill(icon: '🔥', value: '${wallet.streakDays}'),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Row(
              children: [
                Expanded(child: _Pill(icon: '⚡', value: '${wallet.xp} XP', wide: true)),
                const SizedBox(width: 8),
                Expanded(child: _Pill(icon: '🪙', value: '${wallet.coins}', wide: true)),
                const SizedBox(width: 8),
                Expanded(child: _Pill(icon: '⭐', value: '${wallet.stars}', wide: true)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Card(
              color: context.colors.primary,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s.t('todaysMission'), style: context.text.titleLarge?.copyWith(color: context.colors.onPrimary, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Text(s.f('minutesOfGoal', [doneMin, totalMin]), style: TextStyle(color: context.colors.onPrimary)),
                    const SizedBox(height: 12),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: totalMin == 0 ? 0.0 : (doneMin / totalMin).clamp(0.0, 1.0).toDouble(),
                        minHeight: 12,
                        color: const Color(0xFFFFD166),
                        backgroundColor: context.colors.onPrimary.withValues(alpha: 0.25),
                      ),
                    ),
                    const SizedBox(height: 16),
                    FilledButton.tonal(
                      onPressed: () => openNextLesson(context, next),
                      child: Text(
                        next == null ? s.t('courses') : '${s.t('continueLearning')}: ${next.title}',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const _MockLabel(),
          for (final item in plan) _KidPlanTile(item: item),
          if (weak.isNotEmpty) ...[
            SectionTitle(s.t('weakAreas')),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final w in weak)
                    ActionChip(
                      avatar: const Text('💪'),
                      label: Text('${w.name} ${(w.mastery * 100).round()}%'),
                      onPressed: () => context.go(Routes.review),
                    ),
                ],
              ),
            ),
          ],
        ],
       ),
      ),
    );
  }
}

/// Small note above the parts of the home screen that are still MOCK DATA.
class _MockLabel extends StatelessWidget {
  const _MockLabel();

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
        child: Row(
          children: [
            const Icon(Icons.science_outlined, size: 16, color: Color(0xFF7A5B00)),
            const SizedBox(width: 6),
            Expanded(child: Text(context.s.t('planMockNote'), style: context.text.bodySmall)),
          ],
        ),
      );
}

class _Pill extends StatelessWidget {
  const _Pill({required this.icon, required this.value, this.wide = false});

  final String icon;
  final String value;
  final bool wide;

  @override
  Widget build(BuildContext context) {
    final label = Text(value, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800));
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(color: context.colors.surface, borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: wide ? MainAxisSize.max : MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(icon, style: const TextStyle(fontSize: 18)),
          const SizedBox(width: 6),
          // Flexible only when the pill has a bounded width (inside Expanded);
          // a non-wide pill sits in a Row with unbounded width, where a flex child asserts.
          if (wide) Flexible(child: label) else label,
        ],
      ),
    );
  }
}

class _KidPlanTile extends StatelessWidget {
  const _KidPlanTile({required this.item});

  final DailyPlanItem item;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      child: Card(
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          leading: CircleAvatar(
            backgroundColor: item.done ? AppTokens.good : context.colors.secondaryContainer,
            child: Icon(item.done ? Icons.check : planIcon(item.type), color: item.done ? Colors.white : context.colors.onSecondaryContainer),
          ),
          title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(item.subtitle),
          trailing: Text(s.f('minutes', [item.minutes])),
          onTap: () => openPlanItem(context, item),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- pro home
class _ProHome extends ConsumerWidget {
  const _ProHome({required this.profile});

  final LearnerProfile profile;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final plan = MockData.planFor(profile);
    final wallet = ref.watch(walletProvider(profile.id)).valueOrNull ?? const ProfileWallet();
    final courses = ref.watch(courseMapProvider(profile.id)).valueOrNull;
    final next = courses == null ? null : nextLesson(courses);
    final skills = MockData.masteryFor(profile);
    final review = MockData.reviewFor(profile);
    final doneMin = wallet.minutesToday;

    return AccountScaffold(
      title: '${s.t('goodMorning')}, ${profile.displayName}',
      actions: [
        if (profile.isParent)
          IconButton(tooltip: s.t('parentDashboard'), icon: const Icon(Icons.family_restroom), onPressed: () => context.push(Routes.parent)),
      ],
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            child: Row(
              children: [
                Expanded(child: StatTile(label: s.t('dailyGoal'), value: s.f('minutesOfGoal', [doneMin, profile.dailyMinutesGoal]), icon: Icons.timer_outlined)),
                Expanded(child: StatTile(label: 'XP', value: '${wallet.xp}', icon: Icons.bolt, color: AppTokens.xp)),
                Expanded(child: StatTile(label: s.f('streak', [wallet.streakDays]), value: '🔥 ${wallet.streakDays}', icon: Icons.local_fire_department_outlined, color: AppTokens.warn)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: FilledButton.icon(
              onPressed: () => openNextLesson(context, next),
              icon: const Icon(Icons.play_arrow),
              label: Text(next == null ? s.t('courses') : '${s.t('continueLearning')}: ${next.title}', overflow: TextOverflow.ellipsis),
            ),
          ),
          SectionTitle(s.t('todaysPlan')),
          const _MockLabel(),
          for (final item in plan)
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: ListTile(
                leading: Icon(item.done ? Icons.check_circle : planIcon(item.type), color: item.done ? AppTokens.good : context.colors.primary),
                title: Text(item.title),
                subtitle: Text(item.subtitle),
                trailing: Text(s.f('minutes', [item.minutes])),
                onTap: () => openPlanItem(context, item),
              ),
            ),
          SectionTitle(
            s.t('reviewToday'),
            trailing: TextButton(onPressed: () => context.go(Routes.review), child: Text(s.f('reviewDue', [review.length]))),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => context.push(Routes.roleplay),
                    icon: const Icon(Icons.record_voice_over_outlined),
                    label: Text(s.t('roleplay')),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => context.push(Routes.vocab),
                    icon: const Icon(Icons.style_outlined),
                    label: Text(s.t('vocabulary')),
                  ),
                ),
              ],
            ),
          ),
          SectionTitle(s.t('skills')),
          for (final sk in skills) MasteryBar(label: sk.name, value: sk.mastery),
        ],
      ),
    );
  }
}
