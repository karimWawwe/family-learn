import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../core/widgets/common.dart';
import '../../domain/learning.dart';
import '../../domain/models.dart';
import '../../state/learning.dart';
import '../../state/plan.dart';
import '../../state/session.dart';
import '../plan/plan_widgets.dart';

// Phase 4: XP, coins, stars, streak, today's minutes and "Continue" are REAL.
// Phase 6: today's plan, weak skills and mastery are REAL too (daily_plan / review_overview).

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    return p.uiMode == UiMode.kid ? _KidHome(profile: p) : _ProHome(profile: p);
  }
}

// ---------------------------------------------------------------- kid home
/// Opens the next lesson (in progress or available), else the course map.
void openNextLesson(BuildContext context, LessonSummary? next) {
  if (next == null) {
    context.go(Routes.learn);
  } else {
    context.push(Routes.lesson(next.id));
  }
}

class _KidHome extends ConsumerWidget {
  const _KidHome({required this.profile});

  final LearnerProfile profile;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final wallet = ref.watch(walletProvider(profile.id)).valueOrNull ?? const ProfileWallet();
    final courses = ref.watch(courseMapProvider(profile.id)).valueOrNull;
    final next = courses == null ? null : nextLesson(courses);
    final planFailed = ref.watch(dailyPlanProvider(profile.id)).hasError;
    final doneMin = wallet.minutesToday;
    final totalMin = profile.dailyMinutesGoal;

    return AccountScaffold(
      body: RefreshIndicator(
       onRefresh: () async {
         ref.invalidate(courseMapProvider(profile.id));
         ref.invalidate(dailyPlanProvider(profile.id));
         ref.invalidate(reviewOverviewProvider(profile.id));
         try {
           await ref.refresh(walletProvider(profile.id).future);
         } catch (_) {
           // keep showing the last numbers
         }
       },
       child: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: Row(
              children: [
                CircleAvatar(radius: 28, backgroundColor: const Color(0xFFFFE8D6), child: Text(profile.avatarEmoji, style: const TextStyle(fontSize: 30))),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${s.t('hello')} ${profile.displayName}!', style: context.text.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                      Text(s.f('level', [wallet.level]), style: context.text.bodyMedium),
                    ],
                  ),
                ),
                _Pill(icon: '🔥', value: '${wallet.streakDays}'),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Row(
              children: [
                Expanded(child: _Pill(icon: '⚡', value: '${wallet.xp} XP', wide: true)),
                const SizedBox(width: 8),
                Expanded(child: _Pill(icon: '🪙', value: '${wallet.coins}', wide: true)),
                const SizedBox(width: 8),
                Expanded(child: _Pill(icon: '⭐', value: '${wallet.stars}', wide: true)),
              ],
            ),
          ),
          if (!planFailed) TodayPlanSection(profile: profile, kid: true),
          if (planFailed) Padding(
            padding: const EdgeInsets.all(16),
            child: Card(
              color: context.colors.primary,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s.t('todaysMission'), style: context.text.titleLarge?.copyWith(color: context.colors.onPrimary, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Text(s.f('minutesOfGoal', [doneMin, totalMin]), style: TextStyle(color: context.colors.onPrimary)),
                    const SizedBox(height: 12),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: totalMin == 0 ? 0.0 : (doneMin / totalMin).clamp(0.0, 1.0).toDouble(),
                        minHeight: 12,
                        color: const Color(0xFFFFD166),
                        backgroundColor: context.colors.onPrimary.withValues(alpha: 0.25),
                      ),
                    ),
                    const SizedBox(height: 16),
                    FilledButton.tonal(
                      onPressed: () => openNextLesson(context, next),
                      child: Text(
                        next == null ? s.t('courses') : '${s.t('continueLearning')}: ${next.title}',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const _SpeakGameCard(),
          const _BedtimeCard(),
          const _MathGamesRow(),
          WeakSkillsChips(profileId: profile.id),
        ],
       ),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.icon, required this.value, this.wide = false});

  final String icon;
  final String value;
  final bool wide;

  @override
  Widget build(BuildContext context) {
    final label = Text(value, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800));
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(color: context.colors.surface, borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: wide ? MainAxisSize.max : MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(icon, style: const TextStyle(fontSize: 18)),
          const SizedBox(width: 6),
          // Flexible only when the pill has a bounded width (inside Expanded);
          // a non-wide pill sits in a Row with unbounded width, where a flex child asserts.
          if (wide) Flexible(child: label) else label,
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- pro home
class _ProHome extends ConsumerWidget {
  const _ProHome({required this.profile});

  final LearnerProfile profile;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final wallet = ref.watch(walletProvider(profile.id)).valueOrNull ?? const ProfileWallet();
    final courses = ref.watch(courseMapProvider(profile.id)).valueOrNull;
    final next = courses == null ? null : nextLesson(courses);
    final due = ref.watch(dailyPlanProvider(profile.id)).valueOrNull?.dueReview ?? 0;
    final doneMin = wallet.minutesToday;

    return AccountScaffold(
      title: '${s.t('goodMorning')}, ${profile.displayName}',
      actions: [
        if (profile.isParent)
          IconButton(tooltip: s.t('parentDashboard'), icon: const Icon(Icons.family_restroom), onPressed: () => context.push(Routes.parent)),
      ],
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            child: Row(
              children: [
                Expanded(child: StatTile(label: s.t('dailyGoal'), value: s.f('minutesOfGoal', [doneMin, profile.dailyMinutesGoal]), icon: Icons.timer_outlined)),
                Expanded(child: StatTile(label: 'XP', value: '${wallet.xp}', icon: Icons.bolt, color: AppTokens.xp)),
                Expanded(child: StatTile(label: s.f('streak', [wallet.streakDays]), value: '🔥 ${wallet.streakDays}', icon: Icons.local_fire_department_outlined, color: AppTokens.warn)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: FilledButton.icon(
              onPressed: () => openNextLesson(context, next),
              icon: const Icon(Icons.play_arrow),
              label: Text(next == null ? s.t('courses') : '${s.t('continueLearning')}: ${next.title}', overflow: TextOverflow.ellipsis),
            ),
          ),
          TodayPlanSection(profile: profile, kid: false),
          SectionTitle(
            s.t('reviewToday'),
            trailing: TextButton(onPressed: () => context.go(Routes.review), child: Text(s.f('reviewDue', [due]))),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => context.push(Routes.roleplay),
                    icon: const Icon(Icons.record_voice_over_outlined),
                    label: Text(s.t('roleplay')),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => context.push(Routes.vocab),
                    icon: const Icon(Icons.style_outlined),
                    label: Text(s.t('vocabulary')),
                  ),
                ),
              ],
            ),
          ),
          SkillMasteryList(profileId: profile.id),
        ],
      ),
    );
  }
}

/// Big entry to the speaking game on the child's home screen.
class _SpeakGameCard extends StatelessWidget {
  const _SpeakGameCard();

  @override
  Widget build(BuildContext context) {
    final ar = context.s.isArabic;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: () => context.push(Routes.speak),
        child: Ink(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(colors: [Color(0xFFFF6B6B), Color(0xFFFF9F1C)]),
          ),
          child: Row(
            children: [
              const Text('🎤', style: TextStyle(fontSize: 42)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(ar ? 'ألعاب النطق' : 'Speaking games',
                        style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                    Text(ar ? 'اقرأ الكلمة بصوتك واجمع النجوم ⭐' : 'Say the word out loud and win stars ⭐',
                        style: const TextStyle(color: Colors.white)),
                  ],
                ),
              ),
              const Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 40),
            ],
          ),
        ),
      ),
    );
  }
}

/// Entry to "حكاية قبل النوم" on the child's home screen.
class _BedtimeCard extends StatelessWidget {
  const _BedtimeCard();

  @override
  Widget build(BuildContext context) {
    final ar = context.s.isArabic;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: () => context.push(Routes.bedtime),
        child: Ink(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(colors: [Color(0xFF1E2552), Color(0xFF3B2F6B)]),
          ),
          child: Row(
            children: [
              const Text('🌙', style: TextStyle(fontSize: 42)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(ar ? 'حكاية قبل النوم' : 'Bedtime stories',
                        style: const TextStyle(color: Color(0xFFFFE9B0), fontSize: 20, fontWeight: FontWeight.w900)),
                    Text(ar ? 'قصص هادئة عن الأخلاق وقصص الأنبياء 🕌' : 'Calm stories about values and the prophets 🕌',
                        style: const TextStyle(color: Color(0xFFD9DBF2))),
                  ],
                ),
              ),
              const Icon(Icons.play_circle_fill_rounded, color: Color(0xFFFFE9B0), size: 40),
            ],
          ),
        ),
      ),
    );
  }
}

/// Two small cards: "جدول الضرب" and "تعلّم الوقت".
class _MathGamesRow extends StatelessWidget {
  const _MathGamesRow();

  @override
  Widget build(BuildContext context) {
    final ar = context.s.isArabic;
    Widget card(String emoji, String title, String sub, List<Color> colors, String route) => Expanded(
          child: InkWell(
            borderRadius: BorderRadius.circular(22),
            onTap: () => context.push(route),
            child: Ink(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: LinearGradient(colors: colors)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(emoji, style: const TextStyle(fontSize: 32)),
                  const SizedBox(height: 4),
                  Text(title, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900)),
                  Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 13)),
                ],
              ),
            ),
          ),
        );
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            card('✖️', ar ? 'جدول الضرب' : 'Times tables', ar ? 'العب واجمع النجوم' : 'Play and win stars',
                const [Color(0xFF7C4DFF), Color(0xFF3A86FF)], Routes.mathTimes),
            const SizedBox(width: 12),
            card('⏰', ar ? 'تعلّم الوقت' : 'Telling the time', ar ? 'اقرأ الساعة واضبط العقارب' : 'Read clocks, set the hands',
                const [Color(0xFF2EC4B6), Color(0xFF3A86FF)], Routes.mathClock),
          ],
        ),
      ),
    );
  }
}
