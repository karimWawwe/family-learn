import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/router/app_router.dart';
import '../../core/speech/speech_engine.dart';
import '../../domain/math_games.dart';
import '../../state/bedtime.dart';
import '../../state/session.dart';
import '../../state/speak_game.dart';
import 'math_logic.dart';
import 'math_widgets.dart';

// ============================================================================
//  Choose a table and a level
// ============================================================================
class TimesHomeScreen extends ConsumerStatefulWidget {
  const TimesHomeScreen({super.key});

  @override
  ConsumerState<TimesHomeScreen> createState() => _TimesHomeScreenState();
}

class _TimesHomeScreenState extends ConsumerState<TimesHomeScreen> {
  TimesLevel _level = TimesLevel.easy;

  void _start(String table) => context.push(Routes.mathTimesPlay(table, _level.name));

  @override
  Widget build(BuildContext context) {
    final arabic = useArabicDigits(context, ref);
    final async = ref.watch(mathProvider);
    final st = async.valueOrNull ?? const MathState();
    final levelLabels = {
      TimesLevel.easy: tr(context, 'سهل', 'Easy'),
      TimesLevel.medium: tr(context, 'متوسط', 'Medium'),
      TimesLevel.hard: tr(context, 'صعب', 'Hard'),
    };
    final levelHelp = {
      TimesLevel.easy: tr(context, '× ١ إلى ٥ · ٣ خيارات', '× 1 to 5 · 3 choices'),
      TimesLevel.medium: tr(context, '× ١ إلى ١٠ · ٤ خيارات', '× 1 to 10 · 4 choices'),
      TimesLevel.hard: tr(context, '× ١ إلى ١٢ · وأسئلة «٤ × ؟ = ٢٤»', '× 1 to 12 · and "4 × ? = 24"'),
    };
    return Scaffold(
      appBar: AppBar(
        title: Text(tr(context, '✖️ جدول الضرب', '✖️ Times tables')),
        centerTitle: true,
        actions: const [DigitsToggle()],
      ),
      body: LayoutBuilder(builder: (context, box) {
        final cols = box.maxWidth >= 900 ? 6 : (box.maxWidth >= 560 ? 4 : 3);
        return ListView(
          padding: EdgeInsets.symmetric(horizontal: box.maxWidth > 900 ? (box.maxWidth - 900) / 2 + 16 : 16, vertical: 12),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: const LinearGradient(colors: [kMathPurple, kMathSky]),
              ),
              child: Row(
                children: [
                  const Text('🧮', style: TextStyle(fontSize: 42)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tr(context, 'اختر جدولًا والعب!', 'Pick a table and play!'),
                            style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                        Text(
                          tr(context, '⭐ ${nd(st.stars, arabic)} نجمة · 🏆 ${nd(st.points, arabic)} نقطة',
                              '⭐ ${st.stars} stars · 🏆 ${st.points} points'),
                          style: const TextStyle(color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            if (async.hasError)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(mathError(context, async.error!), style: const TextStyle(color: kMathCoral)),
              ),
            const SizedBox(height: 14),
            Text(tr(context, 'المستوى', 'Level'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 6),
            SegmentedButton<TimesLevel>(
              segments: [for (final l in TimesLevel.values) ButtonSegment(value: l, label: Text(levelLabels[l]!))],
              selected: {_level},
              onSelectionChanged: (v) => setState(() => _level = v.first),
            ),
            const SizedBox(height: 4),
            Text(levelHelp[_level]!, style: TextStyle(color: Colors.blueGrey.shade600)),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: kMathCoral, minimumSize: const Size(64, 60)),
                onPressed: () => _start('mixed'),
                icon: const Text('🎲', style: TextStyle(fontSize: 24)),
                label: Text(tr(context, 'جداول مختلطة', 'Mixed tables'), style: const TextStyle(fontSize: 18)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Center(child: StarsRow(st.best(MathGame.times, 'mixed-${_level.name}').bestStars, size: 18)),
            ),
            const SizedBox(height: 12),
            Text(tr(context, 'أو اختر جدولًا', 'Or pick one table'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 8),
            GridView.count(
              crossAxisCount: cols,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.05,
              children: [
                for (var t = 1; t <= 12; t++)
                  _TableTile(
                    label: '× ${nd(t, arabic)}',
                    stars: st.best(MathGame.times, 't$t-${_level.name}').bestStars,
                    color: [kMathSky, kMathMint, kMathPurple, kMathCoral][t % 4],
                    onTap: () => _start('t$t'),
                  ),
              ],
            ),
            const SizedBox(height: 24),
          ],
        );
      }),
    );
  }
}

class _TableTile extends StatelessWidget {
  const _TableTile({required this.label, required this.stars, required this.color, required this.onTap});

  final String label;
  final int stars;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Material(
        color: color.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(22),
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Directionality(
                textDirection: TextDirection.ltr,
                child: Text(label, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: color)),
              ),
              const SizedBox(height: 4),
              StarsRow(stars, size: 16),
            ],
          ),
        ),
      );
}

// ============================================================================
//  A round
// ============================================================================
class TimesPlayScreen extends ConsumerStatefulWidget {
  const TimesPlayScreen({super.key, required this.table, required this.level});

  /// 't4' or 'mixed'
  final String table;
  final String level;

  @override
  ConsumerState<TimesPlayScreen> createState() => _TimesPlayScreenState();
}

class _TimesPlayScreenState extends ConsumerState<TimesPlayScreen> with TickerProviderStateMixin {
  late TimesRound _round;
  late final SpeechEngine _engine;
  late final AnimationController _burst;
  late final AnimationController _shake;
  final Stopwatch _clock = Stopwatch();

  String? _message;
  String _kind = 'good';
  int? _picked;
  final Set<int> _wrong = {};
  bool _locked = false; // between questions
  Timer? _next;

  bool _done = false;
  bool _saving = false;
  String? _saveError;
  bool _newBest = false;
  MathRoundResult? _result;

  @override
  void initState() {
    super.initState();
    _engine = ref.read(speechEngineProvider);
    _burst = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _shake = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));
    _newRound();
  }

  void _newRound() {
    final t = widget.table == 'mixed' ? null : int.tryParse(widget.table.replaceFirst('t', ''));
    final level = TimesLevel.values.firstWhere((l) => l.name == widget.level, orElse: () => TimesLevel.easy);
    _round = TimesRound(table: (t != null && t >= 1 && t <= 12) ? t : null, level: level);
    _clock
      ..reset()
      ..start();
    _message = null;
    _picked = null;
    _wrong.clear();
    _locked = false;
    _done = false;
    _saving = false;
    _saveError = null;
    _newBest = false;
    _result = null;
  }

  @override
  void dispose() {
    _next?.cancel();
    _burst.dispose();
    _shake.dispose();
    super.dispose();
  }

  void _pick(int value) {
    if (_locked || _done || _wrong.contains(value)) return;
    final arabic = readArabicDigits(context, ref);
    final q = _round.current;
    final fb = _round.answer(value);
    setState(() => _picked = value);
    switch (fb.outcome) {
      case AnswerOutcome.correct:
        _engine.playSfx(Sfx.success);
        _burst.forward(from: 0);
        setState(() {
          _locked = true;
          _kind = 'good';
          _message = fb.streak >= 3
              ? tr(context, 'أحسنت! 🔥 ${nd(fb.streak, arabic)} صح متتالية', 'Great! 🔥 ${fb.streak} in a row')
              : _round.triesOnQuestion == 1
                  ? tr(context, 'ممتاز! إجابة صحيحة 🌟', 'Excellent! Correct 🌟')
                  : tr(context, 'أحسنت، صحّحتها! 👏', 'Well done, you fixed it! 👏');
        });
        _next = Timer(const Duration(milliseconds: 1200), _advance);
      case AnswerOutcome.tryAgain:
        _engine.playSfx(Sfx.tryAgain);
        _shake.forward(from: 0);
        setState(() {
          _wrong.add(value);
          _kind = 'retry';
          _message = q.missing
              ? tr(context, 'قريب! فكّر: ${nd(q.a, arabic)} × كم = ${nd(q.product, arabic)}؟ عُدّ بـ ${nd(q.a, arabic)}: ${TimesRound.skipCount(q.b, q.a, arabic)}',
                  'Close! ${q.a} × what = ${q.product}? Count by ${q.a}: ${TimesRound.skipCount(q.b, q.a, false)}')
              : tr(context, 'حاول مرة أخرى 💪 تلميح: ${TimesRound.repeatedAddition(q.a, q.b, arabic)}',
                  'Try again 💪 Hint: ${TimesRound.repeatedAddition(q.a, q.b, false)}');
        });
      case AnswerOutcome.revealed:
        _engine.playSfx(Sfx.tryAgain);
        setState(() {
          _wrong.add(value);
          _locked = true;
          _kind = 'reveal';
          _message = q.missing
              ? tr(context, 'الجواب ${nd(q.b, arabic)} لأن ${nd(q.a, arabic)} × ${nd(q.b, arabic)} = ${nd(q.product, arabic)}. ستتذكرها المرة القادمة 😊',
                  'It is ${q.b}, because ${q.a} × ${q.b} = ${q.product}. You will remember next time 😊')
              : tr(context, '${nd(q.a, arabic)} × ${nd(q.b, arabic)} = ${nd(q.product, arabic)}. لا بأس، ستتذكرها المرة القادمة 😊',
                  '${q.a} × ${q.b} = ${q.product}. That\'s OK, you will remember next time 😊');
        });
        _next = Timer(const Duration(milliseconds: 2600), _advance);
    }
  }

  void _advance() {
    if (!mounted) return;
    _round.next();
    if (_round.finished) {
      _finish();
      return;
    }
    setState(() {
      _message = null;
      _picked = null;
      _wrong.clear();
      _locked = false;
    });
  }

  Future<void> _finish() async {
    _clock.stop();
    final r = _result ??
        MathRoundResult(
          game: MathGame.times,
          level: _round.levelId,
          correct: _round.correct,
          total: _round.questions.length,
          stars: MathRoundResult.starsFor(_round.correct, _round.questions.length),
          points: _round.points + (MathRoundResult.starsFor(_round.correct, _round.questions.length) == 3 ? 20 : 0),
          seconds: _clock.elapsed.inSeconds,
        );
    final before = ref.read(mathProvider).valueOrNull?.best(MathGame.times, r.level);
    _engine.playSfx(Sfx.levelUp);
    setState(() {
      _result = r;
      _done = true;
      _saving = true;
      _saveError = null;
    });
    final p = ref.read(currentProfileProvider);
    if (p == null) {
      setState(() => _saving = false);
      return;
    }
    try {
      await ref.read(mathRepositoryProvider).finish(p, r);
      if (!mounted) return;
      ref.invalidate(mathProvider);
      setState(() {
        _saving = false;
        _newBest = before != null && before.plays > 0 && (r.stars > before.bestStars || r.points > before.bestPoints);
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _saving = false;
        _saveError = mathError(context, e);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final arabic = useArabicDigits(context, ref);
    if (_done && _result != null) {
      final r = _result!;
      return Scaffold(
        backgroundColor: const Color(0xFFF3F6FF),
        body: SafeArea(
          child: RoundResultView(
            title: tr(context, 'انتهت الجولة!', 'Round complete!'),
            correct: r.correct,
            total: r.total,
            stars: r.stars,
            points: r.points,
            arabic: arabic,
            saving: _saving,
            saveError: _saveError,
            newBest: _newBest,
            onRetrySave: _finish,
            onPlayAgain: () => setState(_newRound),
            onChoose: () => context.pop(),
          ),
        ),
      );
    }
    if (_round.questions.isEmpty) {
      return Scaffold(appBar: AppBar(), body: Center(child: Text(tr(context, 'لا توجد أسئلة.', 'No questions.'))));
    }
    final q = _round.current;
    final question = q.missing
        ? '${nd(q.a, arabic)} × ؟ = ${nd(q.product, arabic)}'
        : '${nd(q.a, arabic)} × ${nd(q.b, arabic)} = ؟';
    final keys = [
      LogicalKeyboardKey.digit1, LogicalKeyboardKey.digit2, LogicalKeyboardKey.digit3, LogicalKeyboardKey.digit4, //
    ];
    return CallbackShortcuts(
      bindings: {
        for (var i = 0; i < q.options.length && i < keys.length; i++) SingleActivator(keys[i]): () => _pick(q.options[i]),
      },
      child: Focus(
        autofocus: true,
        child: Scaffold(
          backgroundColor: const Color(0xFFF3F6FF),
          body: SafeArea(
            child: Stack(
              children: [
                Column(
                  children: [
                    RoundTopBar(progress: _round.progress, points: _round.points, onClose: () => context.pop(), arabic: arabic),
                    Text(
                      tr(context, 'سؤال ${nd(_round.index + 1, arabic)} من ${nd(_round.questions.length, arabic)}',
                          'Question ${_round.index + 1} of ${_round.questions.length}'),
                      style: TextStyle(color: Colors.blueGrey.shade600),
                    ),
                    Expanded(
                      child: Center(
                        child: SingleChildScrollView(
                          padding: const EdgeInsets.all(20),
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 560),
                            child: Column(
                              children: [
                                AnimatedBuilder(
                                  animation: _shake,
                                  builder: (_, child) => Transform.translate(
                                    offset: Offset(10 * (1 - _shake.value) * (((_shake.value * 6).floor().isEven) ? 1 : -1), 0),
                                    child: child,
                                  ),
                                  child: Container(
                                    width: double.infinity,
                                    padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 16),
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(32),
                                      boxShadow: [BoxShadow(color: kMathSky.withValues(alpha: 0.15), blurRadius: 18, offset: const Offset(0, 8))],
                                    ),
                                    child: Directionality(
                                      textDirection: TextDirection.ltr,
                                      child: FittedBox(
                                        fit: BoxFit.scaleDown,
                                        child: Text(question,
                                            style: const TextStyle(fontSize: 64, fontWeight: FontWeight.w900, color: Color(0xFF2B2D42))),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 20),
                                Wrap(
                                  alignment: WrapAlignment.center,
                                  spacing: 12,
                                  runSpacing: 12,
                                  children: [
                                    for (var i = 0; i < q.options.length; i++)
                                      _OptionButton(
                                        label: nd(q.options[i], arabic),
                                        keyHint: nd(i + 1, arabic),
                                        state: _wrong.contains(q.options[i])
                                            ? 'wrong'
                                            : (_locked && q.options[i] == q.answer)
                                                ? 'right'
                                                : (_picked == q.options[i] ? 'picked' : 'idle'),
                                        onTap: () => _pick(q.options[i]),
                                      ),
                                  ],
                                ),
                                const SizedBox(height: 20),
                                FeedbackBanner(text: _message, kind: _kind),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                Positioned.fill(
                  child: AnimatedBuilder(animation: _burst, builder: (_, __) => StarBurst(t: _burst.value)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _OptionButton extends StatelessWidget {
  const _OptionButton({required this.label, required this.keyHint, required this.state, required this.onTap});

  final String label;
  final String keyHint;

  /// idle | picked | right | wrong
  final String state;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final (bg, fg, border) = switch (state) {
      'right' => (const Color(0xFFD9F7E6), kMathGood, kMathGood),
      'wrong' => (const Color(0xFFFFE8E0), const Color(0xFFB23A1E), const Color(0xFFFFB4A1)),
      _ => (Colors.white, const Color(0xFF2B2D42), const Color(0xFFD6DEF0)),
    };
    return SizedBox(
      width: 120,
      height: 96,
      child: Material(
        color: bg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: border, width: 3)),
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: state == 'wrong' ? null : onTap,
          child: Stack(
            children: [
              Center(
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text(label, style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: fg)),
                ),
              ),
              PositionedDirectional(
                top: 6,
                start: 10,
                child: Text(keyHint, style: TextStyle(fontSize: 12, color: Colors.blueGrey.shade300)),
              ),
              if (state == 'right') const PositionedDirectional(top: 4, end: 8, child: Text('✅')),
            ],
          ),
        ),
      ),
    );
  }
}
