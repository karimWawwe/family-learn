import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/router/app_router.dart';
import '../../core/speech/speech_engine.dart';
import '../../domain/math_games.dart';
import '../../state/bedtime.dart';
import '../../state/session.dart';
import '../../state/speak_game.dart';
import 'clock_face.dart';
import 'math_logic.dart';
import 'math_widgets.dart';

class _ClockLevelInfo {
  const _ClockLevelInfo(this.emoji, this.ar, this.en, this.helpAr, this.helpEn, this.color);
  final String emoji;
  final String ar;
  final String en;
  final String helpAr;
  final String helpEn;
  final Color color;
}

const _levels = <int, _ClockLevelInfo>{
  1: _ClockLevelInfo('🕐', 'الساعات الكاملة', "O'clock", 'العقرب الطويل على ١٢', 'Long hand on 12', kMathSky),
  2: _ClockLevelInfo('🕧', 'نصف الساعة', 'Half past', 'العقرب الطويل على ٦ = ٣٠ دقيقة', 'Long hand on 6 = 30 minutes', kMathMint),
  3: _ClockLevelInfo('🕒', 'الأرباع', 'Quarters', 'على ٣ = ١٥ · على ٩ = ٤٥', 'On 3 = 15 · on 9 = 45', kMathPurple),
  4: _ClockLevelInfo('🕔', 'كل ٥ دقائق', 'Every 5 minutes', 'عُدّ بالخمسات: ٥، ١٠، ١٥…', 'Count by fives: 5, 10, 15…', kMathCoral),
  5: _ClockLevelInfo('⏱️', 'أي دقيقة', 'Any minute', 'الخمسات ثم الشُّرَط الصغيرة', 'Fives, then the small marks', kMathGold),
};

// ============================================================================
//  Choose a level
// ============================================================================
class ClockHomeScreen extends ConsumerWidget {
  const ClockHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final arabic = useArabicDigits(context, ref);
    final async = ref.watch(mathProvider);
    final st = async.valueOrNull ?? const MathState();
    return Scaffold(
      appBar: AppBar(
        title: Text(tr(context, '⏰ تعلّم الوقت', '⏰ Telling the time')),
        centerTitle: true,
        actions: const [DigitsToggle()],
      ),
      body: LayoutBuilder(builder: (context, box) {
        final side = box.maxWidth > 720 ? (box.maxWidth - 720) / 2 + 16 : 16.0;
        return ListView(
          padding: EdgeInsets.symmetric(horizontal: side, vertical: 12),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: const LinearGradient(colors: [kMathMint, kMathSky]),
              ),
              child: Row(
                children: [
                  AnalogClock(time: const ClockTime(3, 0), size: 84, arabic: arabic),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tr(context, 'اقرأ الساعة واضبط العقارب!', 'Read the clock and set the hands!'),
                            style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 4),
                        Text(
                          tr(context, 'العقرب القصير 🟣 للساعة، والطويل 🔴 للدقائق',
                              'Short hand 🟣 = hours, long hand 🔴 = minutes'),
                          style: const TextStyle(color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            if (async.hasError)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(mathError(context, async.error!), style: const TextStyle(color: kMathCoral)),
              ),
            const SizedBox(height: 14),
            for (var n = 1; n <= 5; n++) ...[
              _LevelCard(
                n: n,
                info: _levels[n]!,
                arabic: arabic,
                open: st.clockOpen(n),
                stars: st.best(MathGame.clock, 'clock-$n').bestStars,
                onTap: () => context.push(Routes.mathClockPlay(n)),
              ),
              const SizedBox(height: 10),
            ],
            const SizedBox(height: 20),
          ],
        );
      }),
    );
  }
}

class _LevelCard extends StatelessWidget {
  const _LevelCard({required this.n, required this.info, required this.arabic, required this.open, required this.stars, required this.onTap});

  final int n;
  final _ClockLevelInfo info;
  final bool arabic;
  final bool open;
  final int stars;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = open ? info.color : Colors.grey;
    return Material(
      color: color.withValues(alpha: open ? 0.14 : 0.08),
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: open
            ? onTap
            : () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text(tr(context, 'أكمل المستوى ${nd(n - 1, arabic)} أولًا ليفتح هذا المستوى 🔒',
                      'Finish level ${n - 1} first to open this one 🔒')),
                )),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              CircleAvatar(
                radius: 26,
                backgroundColor: color,
                child: Text(open ? info.emoji : '🔒', style: const TextStyle(fontSize: 24)),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${tr(context, 'المستوى', 'Level')} ${nd(n, arabic)}: ${tr(context, info.ar, info.en)}',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: open ? const Color(0xFF2B2D42) : Colors.grey)),
                    Text(tr(context, info.helpAr, info.helpEn), style: TextStyle(color: Colors.blueGrey.shade600)),
                  ],
                ),
              ),
              if (open) StarsRow(stars, size: 18),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================================
//  A round
// ============================================================================
class ClockPlayScreen extends ConsumerStatefulWidget {
  const ClockPlayScreen({super.key, required this.level});

  final int level;

  @override
  ConsumerState<ClockPlayScreen> createState() => _ClockPlayScreenState();
}

class _ClockPlayScreenState extends ConsumerState<ClockPlayScreen> with TickerProviderStateMixin {
  late ClockRound _round;
  late final SpeechEngine _engine;
  late final AnimationController _burst;
  late final AnimationController _shake;
  final Stopwatch _clock = Stopwatch();

  String? _message;
  String _kind = 'good';
  final Set<ClockTime> _wrong = {};
  bool _locked = false;
  ClockTime _set = const ClockTime(12, 0);
  Timer? _next;
  Timer? _reveal;

  bool _done = false;
  bool _saving = false;
  String? _saveError;
  bool _newBest = false;
  MathRoundResult? _result;

  int get _level => widget.level.clamp(1, 5);

  @override
  void initState() {
    super.initState();
    _engine = ref.read(speechEngineProvider);
    _burst = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _shake = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));
    _newRound();
  }

  void _newRound() {
    _round = ClockRound(level: _level);
    _clock
      ..reset()
      ..start();
    _resetQuestion();
    _done = false;
    _saving = false;
    _saveError = null;
    _newBest = false;
    _result = null;
  }

  void _resetQuestion() {
    _message = null;
    _wrong.clear();
    _locked = false;
    _reveal?.cancel();
    // start the hands somewhere different from the answer
    if (!_round.finished) {
      final t = _round.current.time;
      _set = ClockTime(t.hour == 12 ? 3 : 12, 0);
    }
  }

  @override
  void dispose() {
    _next?.cancel();
    _reveal?.cancel();
    _burst.dispose();
    _shake.dispose();
    super.dispose();
  }

  String _hint(ClockTime answer, ClockTime given, bool arabic) {
    final q = _round.current;
    if (q.task == ClockTask.setHands) {
      if (given.hour % 12 != answer.hour % 12 && given.minute == answer.minute) {
        return tr(context, 'الدقائق صحيحة 👍 الآن حرّك العقرب القصير 🟣 إلى ${nd(answer.hour, arabic)}',
            'Minutes are right 👍 Now move the short hand 🟣 to ${answer.hour}');
      }
      if (given.hour % 12 == answer.hour % 12 && given.minute != answer.minute) {
        return tr(context, 'الساعة صحيحة 👍 الآن حرّك العقرب الطويل 🔴 إلى ${nd(answer.minute, arabic)} دقيقة. ${_minuteTip(answer.minute, arabic)}',
            'Hour is right 👍 Now move the long hand 🔴 to ${answer.minute} minutes. ${_minuteTip(answer.minute, false)}');
      }
    }
    return tr(context, 'حاول مرة أخرى 💪 العقرب القصير 🟣 للساعة، والطويل 🔴 للدقائق. ${_minuteTip(answer.minute, arabic)}',
        'Try again 💪 Short hand 🟣 = hour, long hand 🔴 = minutes. ${_minuteTip(answer.minute, false)}');
  }

  String _minuteTip(int minute, bool arabic) {
    if (minute == 0) return tr(context, 'إذا كان الطويل على ١٢ فهي ساعة كاملة.', 'Long hand on 12 means o\'clock.');
    if (minute == 30) return tr(context, 'الطويل على ٦ يعني ٣٠ دقيقة (نصف ساعة).', 'Long hand on 6 means 30 minutes (half past).');
    if (minute == 15) return tr(context, 'الطويل على ٣ يعني ١٥ دقيقة (ربع).', 'Long hand on 3 means 15 minutes (quarter past).');
    if (minute == 45) return tr(context, 'الطويل على ٩ يعني ٤٥ دقيقة.', 'Long hand on 9 means 45 minutes.');
    if (minute % 5 == 0) {
      return tr(context, 'كل رقم على الساعة = ٥ دقائق. عُدّ بالخمسات حتى ${nd(minute, arabic)}.',
          'Each number = 5 minutes. Count by fives to $minute.');
    }
    return tr(context, 'عُدّ بالخمسات حتى ${nd(minute - minute % 5, arabic)} ثم زِد ${nd(minute % 5, arabic)} شُرَط صغيرة.',
        'Count by fives to ${minute - minute % 5}, then ${minute % 5} small marks more.');
  }

  void _answer(ClockTime choice) {
    if (_locked || _done || _wrong.contains(choice)) return;
    final arabic = readArabicDigits(context, ref);
    final q = _round.current;
    final fb = _round.answer(choice);
    switch (fb.outcome) {
      case AnswerOutcome.correct:
        _engine.playSfx(Sfx.success);
        _burst.forward(from: 0);
        setState(() {
          _locked = true;
          _kind = 'good';
          _message = fb.streak >= 3
              ? tr(context, 'رائع! 🔥 ${nd(fb.streak, arabic)} صح متتالية', 'Awesome! 🔥 ${fb.streak} in a row')
              : _round.triesOnQuestion == 1
                  ? tr(context, 'ممتاز! الساعة ${q.time.digital(arabic)} 🌟', 'Excellent! It is ${q.time.digital(false)} 🌟')
                  : tr(context, 'أحسنت، صحّحتها! 👏', 'Well done, you fixed it! 👏');
        });
        _next = Timer(const Duration(milliseconds: 1300), _advance);
      case AnswerOutcome.tryAgain:
        _engine.playSfx(Sfx.tryAgain);
        _shake.forward(from: 0);
        setState(() {
          if (q.task != ClockTask.setHands) _wrong.add(choice);
          _kind = 'retry';
          _message = _hint(q.time, choice, arabic);
        });
      case AnswerOutcome.revealed:
        _engine.playSfx(Sfx.tryAgain);
        setState(() {
          if (q.task != ClockTask.setHands) _wrong.add(choice);
          _locked = true;
          _kind = 'reveal';
          _message = tr(context, 'الوقت الصحيح ${q.time.digital(arabic)}. انظر: القصير 🟣 عند ${nd(q.time.hour, arabic)} والطويل 🔴 عند ${nd(q.time.minute, arabic)} دقيقة 😊',
              'The right time is ${q.time.digital(false)}. Look: short hand 🟣 at ${q.time.hour}, long hand 🔴 at ${q.time.minute} minutes 😊');
        });
        if (q.task == ClockTask.setHands) _animateTo(q.time);
        _next = Timer(const Duration(milliseconds: 3200), _advance);
    }
  }

  /// Move the hands step by step to the right time so the child sees it.
  void _animateTo(ClockTime target) {
    _reveal?.cancel();
    _reveal = Timer.periodic(const Duration(milliseconds: 60), (t) {
      if (!mounted || _set.same(target)) {
        t.cancel();
        return;
      }
      setState(() {
        if (_set.hour % 12 != target.hour % 12) {
          _set = ClockTime(_set.hour % 12 + 1, _set.minute);
        } else {
          final d = (target.minute - _set.minute + 60) % 60;
          final stepM = d >= 5 ? 5 : 1;
          _set = ClockTime(_set.hour, (_set.minute + stepM) % 60);
        }
      });
    });
  }

  void _advance() {
    if (!mounted) return;
    _round.next();
    if (_round.finished) {
      _finish();
      return;
    }
    setState(_resetQuestion);
  }

  Future<void> _finish() async {
    _clock.stop();
    final total = _round.questions.length;
    final stars = MathRoundResult.starsFor(_round.correct, total);
    final r = _result ??
        MathRoundResult(
          game: MathGame.clock,
          level: _round.levelId,
          correct: _round.correct,
          total: total,
          stars: stars,
          points: _round.points + (stars == 3 ? 20 : 0),
          seconds: _clock.elapsed.inSeconds,
        );
    final before = ref.read(mathProvider).valueOrNull?.best(MathGame.clock, r.level);
    _engine.playSfx(Sfx.levelUp);
    setState(() {
      _result = r;
      _done = true;
      _saving = true;
      _saveError = null;
    });
    final p = ref.read(currentProfileProvider);
    if (p == null) {
      setState(() => _saving = false);
      return;
    }
    try {
      await ref.read(mathRepositoryProvider).finish(p, r);
      if (!mounted) return;
      ref.invalidate(mathProvider);
      setState(() {
        _saving = false;
        _newBest = before != null && before.plays > 0 && (r.stars > before.bestStars || r.points > before.bestPoints);
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _saving = false;
        _saveError = mathError(context, e);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final arabic = useArabicDigits(context, ref);
    if (_done && _result != null) {
      final r = _result!;
      final opened = _level < 5;
      return Scaffold(
        backgroundColor: const Color(0xFFF3F6FF),
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: RoundResultView(
                  title: tr(context, 'انتهت الجولة!', 'Round complete!'),
                  correct: r.correct,
                  total: r.total,
                  stars: r.stars,
                  points: r.points,
                  arabic: arabic,
                  saving: _saving,
                  saveError: _saveError,
                  newBest: _newBest,
                  onRetrySave: _finish,
                  onPlayAgain: () => setState(_newRound),
                  onChoose: () => context.pop(),
                ),
              ),
              if (opened && !_saving && _saveError == null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 16, left: 24, right: 24),
                  child: TextButton.icon(
                    onPressed: () => context.pushReplacement(Routes.mathClockPlay(_level + 1)),
                    icon: const Icon(Icons.arrow_forward_rounded),
                    label: Text(tr(context, 'المستوى ${nd(_level + 1, arabic)} مفتوح الآن! جرّبه', 'Level ${_level + 1} is open now! Try it')),
                  ),
                ),
            ],
          ),
        ),
      );
    }

    final st = ref.watch(mathProvider).valueOrNull;
    if (st != null && !st.clockOpen(_level)) {
      return Scaffold(
        appBar: AppBar(),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(tr(context, 'هذا المستوى مقفل 🔒 أكمل المستوى ${nd(_level - 1, arabic)} أولًا.',
                'This level is locked 🔒 Finish level ${_level - 1} first.'),
                textAlign: TextAlign.center, style: const TextStyle(fontSize: 18)),
          ),
        ),
      );
    }
    if (_round.questions.isEmpty) {
      return Scaffold(appBar: AppBar(), body: Center(child: Text(tr(context, 'لا توجد أسئلة.', 'No questions.'))));
    }

    final q = _round.current;
    final prompt = switch (q.task) {
      ClockTask.readAnalog => tr(context, 'كم الساعة؟', 'What time is it?'),
      ClockTask.setHands => tr(context, 'اضبط العقارب على هذا الوقت', 'Set the hands to this time'),
      ClockTask.matchAnalog => tr(context, 'أي ساعة تُظهر هذا الوقت؟', 'Which clock shows this time?'),
    };
    final keys = [LogicalKeyboardKey.digit1, LogicalKeyboardKey.digit2, LogicalKeyboardKey.digit3, LogicalKeyboardKey.digit4];

    return CallbackShortcuts(
      bindings: {
        if (q.task != ClockTask.setHands)
          for (var i = 0; i < q.options.length && i < keys.length; i++) SingleActivator(keys[i]): () => _answer(q.options[i]),
        if (q.task == ClockTask.setHands) const SingleActivator(LogicalKeyboardKey.enter): () => _answer(_set),
      },
      child: Focus(
        autofocus: true,
        child: Scaffold(
          backgroundColor: const Color(0xFFF3F6FF),
          body: SafeArea(
            child: Stack(
              children: [
                Column(
                  children: [
                    RoundTopBar(progress: _round.progress, points: _round.points, onClose: () => context.pop(), arabic: arabic),
                    Text(
                      tr(context, 'سؤال ${nd(_round.index + 1, arabic)} من ${nd(_round.questions.length, arabic)}',
                          'Question ${_round.index + 1} of ${_round.questions.length}'),
                      style: TextStyle(color: Colors.blueGrey.shade600),
                    ),
                    Expanded(
                      child: LayoutBuilder(builder: (context, box) {
                        final big = (box.maxWidth - 40).clamp(160.0, 280.0);
                        return Center(
                          child: SingleChildScrollView(
                            padding: const EdgeInsets.all(20),
                            child: ConstrainedBox(
                              constraints: const BoxConstraints(maxWidth: 620),
                              child: Column(
                                children: [
                                  Text(prompt,
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: kMathPurple)),
                                  const SizedBox(height: 14),
                                  AnimatedBuilder(
                                    animation: _shake,
                                    builder: (_, child) => Transform.translate(
                                      offset: Offset(10 * (1 - _shake.value) * (((_shake.value * 6).floor().isEven) ? 1 : -1), 0),
                                      child: child,
                                    ),
                                    child: _questionBody(q, arabic, big, box.maxWidth),
                                  ),
                                  const SizedBox(height: 18),
                                  FeedbackBanner(text: _message, kind: _kind),
                                ],
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                  ],
                ),
                Positioned.fill(
                  child: AnimatedBuilder(animation: _burst, builder: (_, __) => StarBurst(t: _burst.value)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _questionBody(ClockQuestion q, bool arabic, double big, double width) {
    switch (q.task) {
      case ClockTask.readAnalog:
        return Column(
          children: [
            AnalogClock(time: q.time, size: big, arabic: arabic, highlight: _locked && _kind == 'good' ? kMathGood : null),
            const SizedBox(height: 18),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 12,
              runSpacing: 12,
              children: [
                for (var i = 0; i < q.options.length; i++)
                  _DigitalOption(
                    label: q.options[i].digital(arabic),
                    keyHint: nd(i + 1, arabic),
                    state: _optionState(q, q.options[i]),
                    onTap: () => _answer(q.options[i]),
                  ),
              ],
            ),
          ],
        );
      case ClockTask.setHands:
        return Column(
          children: [
            _DigitalDisplay(q.time.digital(arabic)),
            const SizedBox(height: 14),
            SettableClock(
              value: _set,
              step: ClockRound.stepFor(_level),
              arabic: arabic,
              size: big,
              enabled: !_locked,
              highlight: _locked && _kind == 'good' ? kMathGood : null,
              onChanged: (t) => setState(() => _set = t),
            ),
            const SizedBox(height: 6),
            Text(
              tr(context, 'اسحب قرب المركز للعقرب القصير، وقرب الحافة للطويل — أو استخدم الأزرار',
                  'Drag near the centre for the short hand, near the edge for the long one — or use the buttons'),
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.blueGrey.shade600, fontSize: 13),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: 240,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: kMathGood, minimumSize: const Size(64, 56)),
                onPressed: _locked ? null : () => _answer(_set),
                icon: const Icon(Icons.check_rounded),
                label: Text(tr(context, 'تحقّق', 'Check'), style: const TextStyle(fontSize: 20)),
              ),
            ),
          ],
        );
      case ClockTask.matchAnalog:
        final small = width < 420 ? (width - 60) / 2 : 150.0;
        return Column(
          children: [
            _DigitalDisplay(q.time.digital(arabic)),
            const SizedBox(height: 16),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 12,
              runSpacing: 12,
              children: [
                for (var i = 0; i < q.options.length; i++)
                  _ClockOption(
                    time: q.options[i],
                    size: small.clamp(110.0, 170.0),
                    arabic: arabic,
                    keyHint: nd(i + 1, arabic),
                    state: _optionState(q, q.options[i]),
                    onTap: () => _answer(q.options[i]),
                  ),
              ],
            ),
          ],
        );
    }
  }

  String _optionState(ClockQuestion q, ClockTime o) {
    if (_wrong.contains(o)) return 'wrong';
    if (_locked && o.same(q.time)) return 'right';
    return 'idle';
  }
}

class _DigitalDisplay extends StatelessWidget {
  const _DigitalDisplay(this.text);

  final String text;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF2B2D42),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: kMathSky.withValues(alpha: 0.2), blurRadius: 14, offset: const Offset(0, 6))],
        ),
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: Text(text, style: const TextStyle(fontSize: 52, fontWeight: FontWeight.w900, color: Color(0xFF7CFFCB), letterSpacing: 2)),
        ),
      );
}

(Color, Color, Color) _stateColors(String state) => switch (state) {
      'right' => (const Color(0xFFD9F7E6), kMathGood, kMathGood),
      'wrong' => (const Color(0xFFFFE8E0), const Color(0xFFB23A1E), const Color(0xFFFFB4A1)),
      _ => (Colors.white, const Color(0xFF2B2D42), const Color(0xFFD6DEF0)),
    };

class _DigitalOption extends StatelessWidget {
  const _DigitalOption({required this.label, required this.keyHint, required this.state, required this.onTap});

  final String label;
  final String keyHint;
  final String state;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final (bg, fg, border) = _stateColors(state);
    return SizedBox(
      width: 140,
      height: 84,
      child: Material(
        color: bg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: border, width: 3)),
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: state == 'wrong' ? null : onTap,
          child: Stack(
            children: [
              Center(
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text(label, style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: fg)),
                ),
              ),
              PositionedDirectional(top: 6, start: 10, child: Text(keyHint, style: TextStyle(fontSize: 12, color: Colors.blueGrey.shade300))),
              if (state == 'right') const PositionedDirectional(top: 4, end: 8, child: Text('✅')),
            ],
          ),
        ),
      ),
    );
  }
}

class _ClockOption extends StatelessWidget {
  const _ClockOption({required this.time, required this.size, required this.arabic, required this.keyHint, required this.state, required this.onTap});

  final ClockTime time;
  final double size;
  final bool arabic;
  final String keyHint;
  final String state;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final (bg, _, border) = _stateColors(state);
    return Material(
      color: bg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: border, width: 3)),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: state == 'wrong' ? null : onTap,
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(10),
              child: Opacity(
                opacity: state == 'wrong' ? 0.45 : 1,
                child: AnalogClock(time: time, size: size, arabic: arabic, highlight: state == 'right' ? kMathGood : null),
              ),
            ),
            PositionedDirectional(top: 6, start: 10, child: Text(keyHint, style: TextStyle(fontSize: 12, color: Colors.blueGrey.shade400))),
            if (state == 'right') const PositionedDirectional(top: 4, end: 8, child: Text('✅')),
          ],
        ),
      ),
    );
  }
}
