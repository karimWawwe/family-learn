import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'math_logic.dart';
import 'math_widgets.dart';

/// A colourful clock with an hour hand (short, purple) and a minute hand (long, coral).
class AnalogClock extends StatelessWidget {
  const AnalogClock({super.key, required this.time, this.size = 220, required this.arabic, this.highlight});

  final ClockTime time;
  final double size;
  final bool arabic;

  /// Ring colour (e.g. green when right).
  final Color? highlight;

  @override
  Widget build(BuildContext context) => Semantics(
        label: time.digital(false),
        child: SizedBox(
          width: size,
          height: size,
          child: CustomPaint(painter: _ClockPainter(time.hour, time.minute, arabic, highlight)),
        ),
      );
}

class _ClockPainter extends CustomPainter {
  _ClockPainter(this.hour, this.minute, this.arabic, this.highlight);

  final int hour;
  final int minute;
  final bool arabic;
  final Color? highlight;

  @override
  void paint(Canvas canvas, Size size) {
    final r = size.shortestSide / 2;
    final c = Offset(size.width / 2, size.height / 2);

    // ring + face
    canvas.drawCircle(c, r, Paint()..shader = const SweepGradient(colors: [kMathSky, kMathMint, kMathGold, kMathCoral, kMathPurple, kMathSky]).createShader(Rect.fromCircle(center: c, radius: r)));
    if (highlight != null) canvas.drawCircle(c, r, Paint()..color = highlight!);
    canvas.drawCircle(c, r * 0.9, Paint()..color = Colors.white);
    canvas.drawCircle(c, r * 0.9, Paint()..color = const Color(0xFFF4F8FF)..style = PaintingStyle.stroke..strokeWidth = 2);

    // minute marks
    for (var i = 0; i < 60; i++) {
      final a = i / 60 * 2 * math.pi - math.pi / 2;
      final big = i % 5 == 0;
      final p1 = c + Offset(math.cos(a), math.sin(a)) * (r * (big ? 0.76 : 0.81));
      final p2 = c + Offset(math.cos(a), math.sin(a)) * (r * 0.86);
      canvas.drawLine(p1, p2, Paint()
        ..color = big ? const Color(0xFF2B2D42) : const Color(0xFFB0B8CC)
        ..strokeWidth = big ? 3 : 1.4
        ..strokeCap = StrokeCap.round);
    }

    // numbers 1-12
    for (var n = 1; n <= 12; n++) {
      final a = n / 12 * 2 * math.pi - math.pi / 2;
      final p = c + Offset(math.cos(a), math.sin(a)) * (r * 0.62);
      final tp = TextPainter(
        text: TextSpan(
          text: nd(n, arabic),
          style: TextStyle(fontSize: r * 0.17, fontWeight: FontWeight.w900, color: n % 3 == 0 ? kMathPurple : const Color(0xFF2B2D42)),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, p - Offset(tp.width / 2, tp.height / 2));
    }

    // hands
    void hand(double angle, double len, double width, Color color) {
      final a = angle - math.pi / 2;
      canvas.drawLine(
        c,
        c + Offset(math.cos(a), math.sin(a)) * len,
        Paint()
          ..color = color
          ..strokeWidth = width
          ..strokeCap = StrokeCap.round,
      );
    }

    hand(ClockRound.hourAngle(hour, minute), r * 0.42, r * 0.075, kMathPurple);
    hand(ClockRound.minuteAngle(minute), r * 0.7, r * 0.045, kMathCoral);
    canvas.drawCircle(c, r * 0.07, Paint()..color = const Color(0xFF2B2D42));
    canvas.drawCircle(c, r * 0.03, Paint()..color = kMathGold);
  }

  @override
  bool shouldRepaint(_ClockPainter old) =>
      old.hour != hour || old.minute != minute || old.arabic != arabic || old.highlight != highlight;
}

/// A clock whose hands the child moves: drag near the centre for the hour hand,
/// near the edge for the minute hand, or use the buttons / arrow keys
/// (←/→ minutes, ↑/↓ hours).
class SettableClock extends StatefulWidget {
  const SettableClock({
    super.key,
    required this.value,
    required this.step,
    required this.arabic,
    required this.onChanged,
    this.size = 260,
    this.enabled = true,
    this.highlight,
  });

  final ClockTime value;

  /// Minute step (60 = hours only).
  final int step;
  final bool arabic;
  final ValueChanged<ClockTime> onChanged;
  final double size;
  final bool enabled;
  final Color? highlight;

  @override
  State<SettableClock> createState() => _SettableClockState();
}

class _SettableClockState extends State<SettableClock> {
  bool _dragMinute = true;

  ClockTime _withMinute(int m) => ClockTime(widget.value.hour, ((m % 60) + 60) % 60);
  ClockTime _withHour(int h) => ClockTime(((h - 1) % 12 + 12) % 12 + 1, widget.value.minute);

  void _drag(Offset local, {bool start = false}) {
    if (!widget.enabled) return;
    final c = Offset(widget.size / 2, widget.size / 2);
    final d = local - c;
    if (start) _dragMinute = widget.step < 60 && d.distance > widget.size * 0.28;
    var a = math.atan2(d.dx, -d.dy); // 0 at 12 o'clock, clockwise
    if (a < 0) a += 2 * math.pi;
    if (_dragMinute) {
      final raw = a / (2 * math.pi) * 60;
      final m = ((raw / widget.step).round() * widget.step) % 60;
      if (m != widget.value.minute) widget.onChanged(_withMinute(m));
    } else {
      var h = (a / (2 * math.pi) * 12).round() % 12;
      if (h == 0) h = 12;
      if (h != widget.value.hour) widget.onChanged(_withHour(h));
    }
  }

  void _minute(int dir) {
    if (!widget.enabled || widget.step >= 60) return;
    widget.onChanged(_withMinute(widget.value.minute + dir * widget.step));
  }

  void _hour(int dir) {
    if (!widget.enabled) return;
    widget.onChanged(_withHour(widget.value.hour + dir));
  }

  @override
  Widget build(BuildContext context) {
    final minutesOn = widget.step < 60;
    return Focus(
      autofocus: true,
      onKeyEvent: (node, e) {
        if (e is! KeyDownEvent && e is! KeyRepeatEvent) return KeyEventResult.ignored;
        if (e.logicalKey == LogicalKeyboardKey.arrowRight) {
          _minute(1);
        } else if (e.logicalKey == LogicalKeyboardKey.arrowLeft) {
          _minute(-1);
        } else if (e.logicalKey == LogicalKeyboardKey.arrowUp) {
          _hour(1);
        } else if (e.logicalKey == LogicalKeyboardKey.arrowDown) {
          _hour(-1);
        } else {
          return KeyEventResult.ignored;
        }
        return KeyEventResult.handled;
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          GestureDetector(
            onPanStart: (d) => _drag(d.localPosition, start: true),
            onPanUpdate: (d) => _drag(d.localPosition),
            onTapDown: (d) => _drag(d.localPosition, start: true),
            child: AnalogClock(time: widget.value, size: widget.size, arabic: widget.arabic, highlight: widget.highlight),
          ),
          const SizedBox(height: 10),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Wrap(
              alignment: WrapAlignment.center,
              spacing: 10,
              runSpacing: 8,
              children: [
                _Stepper(
                  color: kMathPurple,
                  label: tr(context, 'الساعة', 'Hour'),
                  onMinus: widget.enabled ? () => _hour(-1) : null,
                  onPlus: widget.enabled ? () => _hour(1) : null,
                ),
                if (minutesOn)
                  _Stepper(
                    color: kMathCoral,
                    label: tr(context, 'الدقائق', 'Minutes'),
                    onMinus: widget.enabled ? () => _minute(-1) : null,
                    onPlus: widget.enabled ? () => _minute(1) : null,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Stepper extends StatelessWidget {
  const _Stepper({required this.color, required this.label, required this.onMinus, required this.onPlus});

  final Color color;
  final String label;
  final VoidCallback? onMinus;
  final VoidCallback? onPlus;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
        decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(30)),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(onPressed: onMinus, icon: Icon(Icons.remove_circle, color: color, size: 32), tooltip: '−'),
            Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 16)),
            IconButton(onPressed: onPlus, icon: Icon(Icons.add_circle, color: color, size: 32), tooltip: '+'),
          ],
        ),
      );
}
