import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/app_strings.dart';
import '../../domain/account.dart';
import 'math_logic.dart';

const kMathPurple = Color(0xFF7C4DFF);
const kMathSky = Color(0xFF3A86FF);
const kMathMint = Color(0xFF2EC4B6);
const kMathCoral = Color(0xFFFF6B6B);
const kMathGold = Color(0xFFFFC233);
const kMathGood = Color(0xFF1E9E5A);

String tr(BuildContext c, String ar, String en) => AppStrings.of(c).isArabic ? ar : en;

/// Arabic-Indic digits (١٢٣) or Western digits (123). Starts from the profile's
/// UI language and can be switched in the games.
final arabicDigitsProvider = StateProvider<bool?>((ref) => null);

bool useArabicDigits(BuildContext context, WidgetRef ref) =>
    ref.watch(arabicDigitsProvider) ?? AppStrings.of(context).isArabic;

/// Same, for tap handlers (reads without listening).
bool readArabicDigits(BuildContext context, WidgetRef ref) =>
    ref.read(arabicDigitsProvider) ?? AppStrings.of(context).isArabic;

String mathError(BuildContext c, Object e) {
  if (e is AuthFailure && e.code == 'math_not_installed') {
    return tr(c, 'الألعاب تحتاج تحديث قاعدة البيانات (ملف SQL الخاص بألعاب الرياضيات). اطلب من الوالد تثبيته.',
        'The games need the math-games database update (SQL file). Ask a parent to install it.');
  }
  if (e is AuthFailure && e.code == 'network') {
    return tr(c, 'لا يوجد اتصال. تأكد من الإنترنت وحاول مرة أخرى.', 'No connection. Check the internet and try again.');
  }
  if (e is AuthFailure && e.code == 'lesson_locked') {
    return tr(c, 'أنهِ المستوى الذي قبله أولًا.', 'Finish the level before first.');
  }
  return tr(c, 'حدث خطأ. حاول مرة أخرى.', 'Something went wrong. Please try again.');
}

class DigitsToggle extends ConsumerWidget {
  const DigitsToggle({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final arabic = useArabicDigits(context, ref);
    return TextButton(
      onPressed: () => ref.read(arabicDigitsProvider.notifier).state = !arabic,
      child: Text(arabic ? '١٢٣' : '123', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
    );
  }
}

class StarsRow extends StatelessWidget {
  const StarsRow(this.stars, {super.key, this.size = 22});

  final int stars;
  final double size;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (var s = 1; s <= 3; s++)
            Icon(Icons.star_rounded, size: size, color: s <= stars ? kMathGold : Colors.grey.shade300),
        ],
      );
}

/// Top bar of a round: close, progress, points.
class RoundTopBar extends StatelessWidget {
  const RoundTopBar({super.key, required this.progress, required this.points, required this.onClose, required this.arabic});

  final double progress;
  final int points;
  final VoidCallback onClose;
  final bool arabic;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(8, 8, 16, 4),
        child: Row(
          children: [
            IconButton(
              tooltip: tr(context, 'إغلاق', 'Close'),
              icon: const Icon(Icons.close_rounded, size: 30),
              onPressed: onClose,
            ),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: TweenAnimationBuilder<double>(
                  tween: Tween(end: progress),
                  duration: const Duration(milliseconds: 400),
                  builder: (_, v, __) => LinearProgressIndicator(
                    value: v,
                    minHeight: 16,
                    color: kMathMint,
                    backgroundColor: const Color(0xFFDDE5F5),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(color: const Color(0xFFFFF4D6), borderRadius: BorderRadius.circular(20)),
              child: Text('⭐ ${nd(points, arabic)}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            ),
          ],
        ),
      );
}

/// Friendly feedback line under a question.
class FeedbackBanner extends StatelessWidget {
  const FeedbackBanner({super.key, required this.text, required this.kind});

  final String? text;

  /// good | retry | reveal
  final String kind;

  @override
  Widget build(BuildContext context) {
    final (bg, fg) = switch (kind) {
      'good' => (const Color(0xFFD9F7E6), const Color(0xFF12613A)),
      'reveal' => (const Color(0xFFE3EEFF), const Color(0xFF1B3F7A)),
      _ => (const Color(0xFFFFF1D6), const Color(0xFF7A4B00)),
    };
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 250),
      transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
      child: text == null
          ? const SizedBox(height: 8, key: ValueKey('none'))
          : Container(
              key: ValueKey(text),
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(18)),
              child: Text(text!, textAlign: TextAlign.center, style: TextStyle(color: fg, fontSize: 18, fontWeight: FontWeight.w700)),
            ),
    );
  }
}

/// End of a round: stars, points, best result, play again.
class RoundResultView extends StatelessWidget {
  const RoundResultView({
    super.key,
    required this.title,
    required this.correct,
    required this.total,
    required this.stars,
    required this.points,
    required this.arabic,
    required this.saving,
    required this.saveError,
    required this.newBest,
    required this.onRetrySave,
    required this.onPlayAgain,
    required this.onChoose,
  });

  final String title;
  final int correct;
  final int total;
  final int stars;
  final int points;
  final bool arabic;
  final bool saving;
  final String? saveError;
  final bool newBest;
  final VoidCallback onRetrySave;
  final VoidCallback onPlayAgain;
  final VoidCallback onChoose;

  @override
  Widget build(BuildContext context) {
    final msg = stars == 3
        ? tr(context, 'ممتاز! ثلاث نجوم 🌟', 'Excellent! Three stars 🌟')
        : stars == 2
            ? tr(context, 'عمل رائع! تقدر توصل لثلاث نجوم 💪', 'Great work! You can reach three stars 💪')
            : tr(context, 'أحسنت لأنك أكملت الجولة! كل مرة تتحسّن أكثر 😊', 'Well done for finishing! You get better every time 😊');
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0.3, end: 1),
                duration: const Duration(milliseconds: 700),
                curve: Curves.elasticOut,
                builder: (_, v, child) => Transform.scale(scale: v, child: child),
                child: const Text('🏆', style: TextStyle(fontSize: 88)),
              ),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: kMathPurple)),
              const SizedBox(height: 12),
              StarsRow(stars, size: 56),
              const SizedBox(height: 6),
              Text(msg, textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              const SizedBox(height: 14),
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 8,
                runSpacing: 8,
                children: [
                  _Pill('✅ ${nd(correct, arabic)} / ${nd(total, arabic)}'),
                  _Pill('🏆 +${nd(points, arabic)} ${tr(context, 'نقطة', 'points')}'),
                ],
              ),
              if (newBest) ...[
                const SizedBox(height: 10),
                Text(tr(context, '🎉 نتيجة جديدة أفضل! حفظناها لك', '🎉 New best result! Saved for you'),
                    style: const TextStyle(color: kMathGood, fontWeight: FontWeight.w900, fontSize: 16)),
              ],
              const SizedBox(height: 18),
              if (saving) ...[
                const CircularProgressIndicator(),
                const SizedBox(height: 6),
                Text(tr(context, 'جاري حفظ النتيجة…', 'Saving…')),
              ] else if (saveError != null) ...[
                Text(saveError!, textAlign: TextAlign.center, style: const TextStyle(color: kMathCoral)),
                const SizedBox(height: 6),
                FilledButton.icon(onPressed: onRetrySave, icon: const Icon(Icons.refresh), label: Text(tr(context, 'حاول الحفظ مرة أخرى', 'Try saving again'))),
              ],
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  autofocus: true,
                  onPressed: onPlayAgain,
                  icon: const Icon(Icons.replay_rounded),
                  label: Text(tr(context, 'العب مرة أخرى', 'Play again')),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: onChoose,
                  icon: const Icon(Icons.grid_view_rounded),
                  label: Text(tr(context, 'اختر جولة أخرى', 'Choose another round')),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill(this.text);

  final String text;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
      );
}

/// Little burst of stars on a right answer.
class StarBurst extends StatelessWidget {
  const StarBurst({super.key, required this.t});

  final double t;

  @override
  Widget build(BuildContext context) => IgnorePointer(
        child: CustomPaint(painter: _BurstPainter(t), size: Size.infinite),
      );
}

class _BurstPainter extends CustomPainter {
  _BurstPainter(this.t);

  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    if (t <= 0 || t >= 1) return;
    final c = Offset(size.width / 2, size.height * 0.35);
    final paint = Paint();
    for (var i = 0; i < 14; i++) {
      final a = i / 14 * 2 * math.pi;
      final r = 30 + 140 * Curves.easeOut.transform(t);
      paint.color = [kMathGold, kMathCoral, kMathMint, kMathSky][i % 4].withValues(alpha: 1 - t);
      canvas.drawCircle(c + Offset(math.cos(a) * r, math.sin(a) * r), 6 * (1 - t) + 2, paint);
    }
  }

  @override
  bool shouldRepaint(_BurstPainter old) => old.t != t;
}
