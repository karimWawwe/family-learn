import 'dart:math' as math;

/// Pure game rules for the math games (unit-tested, no Flutter).

/// 0-9 -> ٠-٩ when [arabic] is on.
String nd(Object value, bool arabic) {
  final s = '$value';
  if (!arabic) return s;
  const ar = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  final b = StringBuffer();
  for (final c in s.split('')) {
    final i = '0123456789'.indexOf(c);
    b.write(i >= 0 ? ar[i] : c);
  }
  return b.toString();
}

// ============================================================================
//  Times tables
// ============================================================================
enum TimesLevel { easy, medium, hard }

class TimesQuestion {
  const TimesQuestion({required this.a, required this.b, required this.options, this.missing = false});

  /// a × b. When [missing], the child finds b in "a × ? = a·b".
  final int a;
  final int b;
  final List<int> options;
  final bool missing;

  int get product => a * b;
  int get answer => missing ? b : product;
}

enum AnswerOutcome { correct, tryAgain, revealed }

class TimesFeedback {
  const TimesFeedback(this.outcome, this.points, this.streak);

  final AnswerOutcome outcome;
  final int points;
  final int streak;
}

/// A short round (10 questions by default) of one table or mixed tables.
///  * 1st try right: 10 points + streak bonus (up to +5);
///  * 2nd try right: 5 points; 2nd try wrong: the answer is shown, 0 points.
class TimesRound {
  TimesRound({this.table, required this.level, this.total = 10, math.Random? random})
      : _rnd = random ?? math.Random() {
    _make();
  }

  /// null = mixed tables.
  final int? table;
  final TimesLevel level;
  final int total;
  final math.Random _rnd;

  final List<TimesQuestion> questions = [];
  int index = 0;
  int triesOnQuestion = 0;
  int correct = 0;
  int points = 0;
  int streak = 0;
  int bestStreak = 0;

  /// Level id saved on the server: t4-easy, mixed-hard ...
  String get levelId => '${table == null ? 'mixed' : 't$table'}-${level.name}';
  bool get finished => index >= questions.length;
  TimesQuestion get current => questions[index];
  double get progress => questions.isEmpty ? 0 : index / questions.length;

  int get _maxB => switch (level) { TimesLevel.easy => 5, TimesLevel.medium => 10, TimesLevel.hard => 12 };
  int get _optionCount => level == TimesLevel.easy ? 3 : 4;
  List<int> get _mixedTables => switch (level) {
        TimesLevel.easy => [2, 3, 4, 5],
        TimesLevel.medium => [2, 3, 4, 5, 6, 7, 8, 9, 10],
        TimesLevel.hard => [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
      };

  void _make() {
    final seen = <String>{};
    var guard = 0;
    while (questions.length < total && guard++ < 500) {
      final a = table ?? _mixedTables[_rnd.nextInt(_mixedTables.length)];
      final b = 1 + _rnd.nextInt(_maxB);
      final key = '$a×$b';
      if (seen.contains(key) && guard < 300) continue;
      seen.add(key);
      final missing = level == TimesLevel.hard && _rnd.nextDouble() < 0.3 && b > 1;
      questions.add(TimesQuestion(a: a, b: b, missing: missing, options: _options(a, b, missing)));
    }
  }

  List<int> _options(int a, int b, bool missing) {
    final answer = missing ? b : a * b;
    final pool = <int>{};
    if (missing) {
      pool.addAll([b - 1, b + 1, b + 2, b - 2, a]);
    } else {
      pool.addAll([a * (b + 1), a * (b - 1), (a + 1) * b, (a - 1) * b, a * b + 1, a * b - 1, a + b, a * b + 10]);
    }
    pool.removeWhere((v) => v <= 0 || v == answer);
    final list = pool.toList()..shuffle(_rnd);
    final opts = [answer, ...list.take(_optionCount - 1)]..shuffle(_rnd);
    return opts;
  }

  TimesFeedback answer(int value) {
    final q = current;
    triesOnQuestion++;
    if (value == q.answer) {
      final first = triesOnQuestion == 1;
      var gained = first ? 10 : 5;
      if (first) {
        streak++;
        bestStreak = math.max(bestStreak, streak);
        gained += math.min(streak - 1, 5);
      } else {
        streak = 0;
      }
      correct++;
      points += gained;
      return TimesFeedback(AnswerOutcome.correct, gained, streak);
    }
    streak = 0;
    if (triesOnQuestion >= 2) return TimesFeedback(AnswerOutcome.revealed, 0, 0);
    return TimesFeedback(AnswerOutcome.tryAgain, 0, 0);
  }

  void next() {
    if (finished) return;
    index++;
    triesOnQuestion = 0;
  }

  /// "6 + 6 + 6 + 6" (shown as a hint).
  static String repeatedAddition(int a, int b, bool arabic) =>
      List.filled(a, nd(b, arabic)).join(' + ');

  /// "6, 12, 18, 24" (counting by the table).
  static String skipCount(int a, int b, bool arabic) =>
      [for (var i = 1; i <= a; i++) nd(b * i, arabic)].join(arabic ? '، ' : ', ');
}

// ============================================================================
//  Clock
// ============================================================================
class ClockTime {
  const ClockTime(this.hour, this.minute);

  /// 1..12
  final int hour;

  /// 0..59
  final int minute;

  String digital(bool arabic) => nd('$hour:${minute.toString().padLeft(2, '0')}', arabic);

  bool same(ClockTime o) => hour % 12 == o.hour % 12 && minute == o.minute;

  @override
  bool operator ==(Object other) => other is ClockTime && same(other);

  @override
  int get hashCode => (hour % 12) * 60 + minute;
}

enum ClockTask {
  /// look at the hands, pick the digital time
  readAnalog,

  /// set the hands to the digital time shown
  setHands,

  /// look at the digital time, pick the matching clock
  matchAnalog,
}

class ClockQuestion {
  const ClockQuestion(this.task, this.time, this.options);

  final ClockTask task;
  final ClockTime time;

  /// For readAnalog / matchAnalog.
  final List<ClockTime> options;
}

/// Levels: 1 o'clock · 2 half past · 3 quarters · 4 every 5 minutes · 5 any minute.
class ClockRound {
  ClockRound({required this.level, this.total = 8, math.Random? random}) : _rnd = random ?? math.Random() {
    _make();
  }

  final int level;
  final int total;
  final math.Random _rnd;

  final List<ClockQuestion> questions = [];
  int index = 0;
  int triesOnQuestion = 0;
  int correct = 0;
  int points = 0;
  int streak = 0;

  String get levelId => 'clock-$level';
  bool get finished => index >= questions.length;
  ClockQuestion get current => questions[index];
  double get progress => questions.isEmpty ? 0 : index / questions.length;

  /// Minute step the hands snap to when the child sets them.
  static int stepFor(int level) => switch (level) { 1 => 60, 2 => 30, 3 => 15, 4 => 5, _ => 1 };

  List<int> get _minutes => switch (level) {
        1 => [0],
        2 => [0, 30],
        3 => [0, 15, 30, 45],
        4 => [for (var m = 0; m < 60; m += 5) m],
        _ => [for (var m = 0; m < 60; m++) m],
      };

  ClockTime _random() {
    final mins = _minutes;
    // from level 2 on, mostly the NEW kind of time
    var m = mins[_rnd.nextInt(mins.length)];
    if (level >= 2 && m == 0 && _rnd.nextDouble() < 0.6) m = mins[1 + _rnd.nextInt(mins.length - 1)];
    return ClockTime(1 + _rnd.nextInt(12), m);
  }

  void _make() {
    final tasks = [ClockTask.readAnalog, ClockTask.setHands, ClockTask.matchAnalog];
    final seen = <int>{};
    var guard = 0;
    while (questions.length < total && guard++ < 300) {
      final t = _random();
      if (seen.contains(t.hashCode) && guard < 200) continue;
      seen.add(t.hashCode);
      final task = tasks[questions.length % 3];
      questions.add(ClockQuestion(task, t, task == ClockTask.setHands ? const [] : _options(t, task == ClockTask.readAnalog ? 4 : 3)));
    }
    questions.shuffle(_rnd);
  }

  List<ClockTime> _options(ClockTime t, int n) {
    final step = stepFor(level) == 60 ? 60 : math.max(stepFor(level), 5);
    final pool = <ClockTime>{};
    int h(int x) => ((x - 1) % 12 + 12) % 12 + 1;
    pool.add(ClockTime(h(t.hour + 1), t.minute));
    pool.add(ClockTime(h(t.hour - 1), t.minute));
    // hands swapped (a classic mix-up): the hour hand read as minutes and the other way
    pool.add(ClockTime(t.minute < 5 ? 12 : h(t.minute ~/ 5), (t.hour % 12) * 5));
    if (step < 60) {
      pool.add(ClockTime(t.hour, (t.minute + step) % 60));
      pool.add(ClockTime(t.hour, (t.minute - step + 60) % 60));
    } else {
      pool.add(ClockTime(h(t.hour + 6), 0));
    }
    pool.removeWhere((o) => o.same(t));
    final list = pool.toList()..shuffle(_rnd);
    return [t, ...list.take(n - 1)]..shuffle(_rnd);
  }

  /// [choice] for readAnalog/matchAnalog, or the time the child set for setHands.
  TimesFeedback answer(ClockTime choice) {
    triesOnQuestion++;
    if (choice.same(current.time)) {
      final first = triesOnQuestion == 1;
      var gained = first ? 10 : 5;
      if (first) {
        streak++;
        gained += math.min(streak - 1, 5);
      } else {
        streak = 0;
      }
      correct++;
      points += gained;
      return TimesFeedback(AnswerOutcome.correct, gained, streak);
    }
    streak = 0;
    if (triesOnQuestion >= 2) return const TimesFeedback(AnswerOutcome.revealed, 0, 0);
    return const TimesFeedback(AnswerOutcome.tryAgain, 0, 0);
  }

  void next() {
    if (finished) return;
    index++;
    triesOnQuestion = 0;
  }

  /// Angles in radians from 12 o'clock, clockwise.
  static double minuteAngle(int minute) => minute / 60 * 2 * math.pi;
  static double hourAngle(int hour, int minute) => ((hour % 12) + minute / 60) / 12 * 2 * math.pi;
}
