import 'package:flutter/material.dart';

/// Non-web builds: videos play in the web app only.
Widget buildUnitVideo({required String src, required String poster, required void Function() onWatched}) =>
    const ColoredBox(
      color: Colors.black,
      child: Center(child: Text('▶ Video plays in the web app', style: TextStyle(color: Colors.white))),
    );
