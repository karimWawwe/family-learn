import 'dart:js_interop';
import 'dart:ui_web' as ui_web;

import 'package:flutter/widgets.dart';

// A real HTML <video> element (native play / pause / replay / full screen,
// works on iPhone, iPad, Android and desktop browsers).

@JS('document')
external _Doc get _document;

extension type _Doc._(JSObject _) implements JSObject {
  external _Video createElement(String tag);
}

extension type _Video._(JSObject _) implements JSObject {
  external set src(String v);
  external set poster(String v);
  external set controls(bool v);
  external set preload(String v);
  external void setAttribute(String name, String value);
  external _Style get style;
  external void addEventListener(String type, JSFunction listener);
  external double get currentTime;
  external double get duration;
}

extension type _Style._(JSObject _) implements JSObject {
  external set width(String v);
  external set height(String v);
  external set backgroundColor(String v);
  external set objectFit(String v);
  external set borderRadius(String v);
}

final Set<String> _registered = <String>{};
final Map<String, void Function()> _onWatched = <String, void Function()>{};
final Set<String> _reported = <String>{};

Widget buildUnitVideo({required String src, required String poster, required void Function() onWatched}) {
  final viewType = 'fl-unit-video-$src';
  _onWatched[viewType] = onWatched;
  if (_registered.add(viewType)) {
    ui_web.platformViewRegistry.registerViewFactory(viewType, (int viewId) {
      final v = _document.createElement('video');
      v.src = src;
      v.poster = poster;
      v.controls = true;
      v.preload = 'metadata';
      v.setAttribute('playsinline', '');
      v.setAttribute('webkit-playsinline', '');
      v.style.width = '100%';
      v.style.height = '100%';
      v.style.backgroundColor = '#000';
      v.style.objectFit = 'contain';
      v.style.borderRadius = '16px';
      void report() {
        final key = '$viewType#$viewId';
        if (_reported.add(key)) _onWatched[viewType]?.call();
      }

      v.addEventListener('ended', ((JSAny e) => report()).toJS);
      v.addEventListener('timeupdate', ((JSAny e) {
        final d = v.duration;
        if (d > 0 && v.currentTime >= d * 0.8) report();
      }).toJS);
      return v;
    });
  }
  return HtmlElementView(viewType: viewType);
}
