import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../domain/account.dart';
import '../../domain/eng_unit.dart';
import '../../state/eng_unit.dart';
import '../../state/session.dart';
import 'video_view_stub.dart' if (dart.library.js_interop) 'video_view_web.dart' as video;

// "English Grammar – Capitalization and Financial Literacy"
// Lesson, 3 videos, interactive capitalization exercises (tap the wrong words),
// debit vs credit cards, stars, stages that open one after another, and a
// report card for the parent dashboard.

const engUnitRoute = '/unit/caps';

const _ink = Color(0xFF1F2A44);
const _accent = Color(0xFF3A86FF);
const _good = Color(0xFF1E9E5A);
const _bad = Color(0xFFD64545);

Widget _ar(String t, {TextStyle? style, TextAlign align = TextAlign.right}) =>
    Text(t, textDirection: TextDirection.rtl, textAlign: align, style: style);

Widget _en(String t, {TextStyle? style}) => Text(t, textDirection: TextDirection.ltr, style: style);

/// Saves one event and refreshes the unit's progress everywhere.
Future<EngUnitState?> _save(WidgetRef ref, BuildContext context, String item, String kind, {bool correct = true, int stars = 0}) async {
  final p = ref.read(currentProfileProvider);
  if (p == null) return null;
  try {
    final st = await ref.read(engUnitRepositoryProvider).log(p, item, kind, correct: correct, stars: stars);
    ref.invalidate(engUnitProvider);
    ref.invalidate(engUnitForProvider(p.id));
    return st;
  } catch (e) {
    if (context.mounted) {
      final ar = context.s.isArabic;
      final notInstalled = e is AuthFailure && e.code == 'unit_not_installed';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(notInstalled
            ? (ar ? 'الدرس لم يُفعَّل في قاعدة البيانات بعد.' : 'The unit is not installed in the database yet.')
            : (ar ? 'تعذّر حفظ النتيجة، تأكد من الإنترنت.' : 'Could not save your result. Check the internet.')),
      ));
    }
    return null;
  }
}

// ============================================================ home entry card
/// Card on the home screen (kids and adults).
class EngUnitHomeCard extends ConsumerWidget {
  const EngUnitHomeCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ar = context.s.isArabic;
    final st = ref.watch(engUnitProvider).valueOrNull;
    final pct = st == null ? null : (st.completion * 100).round();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: () => context.push(engUnitRoute),
        child: Ink(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(colors: [Color(0xFF0B6E4F), Color(0xFF3A86FF)]),
          ),
          child: Row(
            children: [
              const Text('🔠', style: TextStyle(fontSize: 42)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(ar ? 'درس جديد: الحروف الكبيرة والبطاقات البنكية' : 'New unit: Capitalization & money skills',
                        style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 2),
                    Text(
                      pct == null
                          ? (ar ? 'فيديوهات وتمارين تفاعلية ونجوم ⭐' : 'Videos, interactive exercises and stars ⭐')
                          : (ar ? 'أنجزت $pct% · ⭐ ${st!.stars}' : '$pct% done · ⭐ ${st!.stars}'),
                      style: const TextStyle(color: Colors.white),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 40),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================ unit home
class EngUnitHomeScreen extends ConsumerWidget {
  const EngUnitHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ar = context.s.isArabic;
    final async = ref.watch(engUnitProvider);
    final st = async.valueOrNull ?? const EngUnitState();
    final notInstalled = async.error is AuthFailure && (async.error! as AuthFailure).code == 'unit_not_installed';

    void open(Widget page) => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));

    return AccountScaffold(
      title: ar ? 'الإنجليزي: الحروف الكبيرة والثقافة المالية' : 'English Grammar – Capitalization',
      body: RefreshIndicator(
        onRefresh: () async {
          try {
            await ref.refresh(engUnitProvider.future);
          } catch (_) {}
        },
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
          children: [
            if (async.isLoading && async.valueOrNull == null) const LinearProgressIndicator(),
            if (async.hasError)
              Card(
                color: const Color(0xFFFFF1F0),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(notInstalled
                      ? (ar ? 'الدرس لم يُفعَّل في قاعدة البيانات بعد.' : 'The unit is not installed in the database yet.')
                      : (ar ? 'تعذّر تحميل التقدّم. اسحب للتحديث.' : 'Could not load your progress. Pull to refresh.')),
                ),
              ),
            _UnitHeader(st: st),
            const SizedBox(height: 16),
            _SectionLabel(ar ? 'القسم أ: تصحيح أخطاء الحروف الكبيرة' : 'Section A: Correct capitalization errors'),
            _StageTile(stage: unitStages[0], st: st, onOpen: () => open(const CapsRulesScreen())),
            _StageTile(stage: unitStages[1], st: st, onOpen: () => open(const CapsPracticeScreen(stage: 2))),
            _StageTile(stage: unitStages[2], st: st, onOpen: () => open(const CapsPracticeScreen(stage: 3))),
            const SizedBox(height: 12),
            _SectionLabel(ar ? 'القسم ب: بطاقة الخصم وبطاقة الائتمان' : 'Section B: Debit cards and credit cards'),
            _StageTile(stage: unitStages[3], st: st, onOpen: () => open(const CardsLessonScreen())),
            const SizedBox(height: 12),
            _SectionLabel(ar ? 'تعلّم بالفيديو' : 'Video learning'),
            Card(
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                leading: const CircleAvatar(backgroundColor: Color(0xFFE8F0FF), child: Text('🎬', style: TextStyle(fontSize: 22))),
                title: Text(ar ? '3 فيديوهات' : '3 videos', style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(ar ? 'شاهدت ${st.videosWatched} من ${unitVideos.length}' : 'Watched ${st.videosWatched} of ${unitVideos.length}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => open(const UnitVideosScreen()),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 8, 4, 8),
        child: Text(text, style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
      );
}

class _UnitHeader extends StatelessWidget {
  const _UnitHeader({required this.st});
  final EngUnitState st;

  @override
  Widget build(BuildContext context) {
    final ar = context.s.isArabic;
    final pct = (st.completion * 100).round();
    final stage = st.currentStage;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(colors: [Color(0xFF1F2A44), Color(0xFF3A86FF)]),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _en('English Grammar – Capitalization and Financial Literacy',
              style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(ar ? 'الحروف الكبيرة في الإنجليزي + الفرق بين بطاقة الخصم وبطاقة الائتمان' : 'Capital letters + the difference between debit and credit cards',
              style: const TextStyle(color: Color(0xFFDDE6FF))),
          const SizedBox(height: 14),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: st.completion,
              minHeight: 12,
              color: const Color(0xFFFFD166),
              backgroundColor: Colors.white.withValues(alpha: 0.25),
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _HeaderPill('📈 $pct%'),
              _HeaderPill('⭐ ${st.stars}/${st.maxStars}'),
              _HeaderPill('✅ ${st.correct}  ✖ ${st.wrong}'),
              _HeaderPill('🎬 ${st.videosWatched}/${unitVideos.length}'),
              _HeaderPill(stage > unitStages.length
                  ? (ar ? '🏆 أنهيت الوحدة' : '🏆 Unit complete')
                  : (ar ? '📍 المرحلة $stage' : '📍 Stage $stage')),
            ],
          ),
        ],
      ),
    );
  }
}

class _HeaderPill extends StatelessWidget {
  const _HeaderPill(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(20)),
        child: Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      );
}

class _StageTile extends StatelessWidget {
  const _StageTile({required this.stage, required this.st, required this.onOpen});
  final UnitStage stage;
  final EngUnitState st;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final ar = context.s.isArabic;
    final open = st.stageOpen(stage.n);
    final done = st.stageDone(stage.n);
    final answerItems = stage.items.where((i) => i != engUnitReadItem).toList();
    final solved = stage.items.where(st.done).length;
    final stars = answerItems.fold<int>(0, (s, i) => s + st.item(i).bestStars);
    final sub = !open
        ? (ar ? '🔒 أكمل المرحلة السابقة لفتحها' : '🔒 Finish the stage before to open it')
        : answerItems.isEmpty
            ? (done ? (ar ? 'تمت القراءة ✓' : 'Read ✓') : (ar ? 'اقرأ القواعد السبع' : 'Read the 7 rules'))
            : (ar ? 'حللت $solved من ${stage.items.length} · ⭐ $stars' : 'Solved $solved of ${stage.items.length} · ⭐ $stars');
    return Card(
      child: ListTile(
        enabled: open,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: done ? const Color(0xFFDDF5E7) : (open ? const Color(0xFFE8F0FF) : const Color(0xFFEDEDED)),
          child: Text(done ? '✅' : (open ? stage.emoji : '🔒'), style: const TextStyle(fontSize: 20)),
        ),
        title: Text('${ar ? 'المرحلة' : 'Stage'} ${stage.n}: ${ar ? stage.titleAr : stage.titleEn}',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(sub),
        trailing: Icon(open ? Icons.chevron_right : Icons.lock_outline),
        onTap: open ? onOpen : null,
      ),
    );
  }
}

// ============================================================ rules
class CapsRulesScreen extends ConsumerWidget {
  const CapsRulesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ar = context.s.isArabic;
    final st = ref.watch(engUnitProvider).valueOrNull ?? const EngUnitState();
    return AccountScaffold(
      title: ar ? 'قواعد الحروف الكبيرة' : 'Capitalization rules',
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          Card(
            color: const Color(0xFFFFF8E6),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _en('Capital letters (A, B, C) start special names. Lowercase letters (a, b, c) are for ordinary words.',
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  const SizedBox(height: 6),
                  _ar('الحروف الكبيرة (Capital) نبدأ بها الأسماء الخاصة، والحروف الصغيرة (lowercase) للكلمات العادية.'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          for (final r in capsRules)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  textDirection: TextDirection.ltr,
                  children: [
                    CircleAvatar(radius: 16, backgroundColor: _accent, child: Text('${r.n}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800))),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _en(r.en, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: _ink)),
                          const SizedBox(height: 4),
                          _ar(r.ar, style: TextStyle(color: context.colors.onSurfaceVariant)),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(color: const Color(0xFFE8F0FF), borderRadius: BorderRadius.circular(10)),
                            child: _en('e.g. ${r.example}', style: const TextStyle(fontStyle: FontStyle.italic)),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 12),
          FilledButton.icon(
            icon: Icon(st.read ? Icons.check_circle : Icons.menu_book),
            label: Text(st.read
                ? (ar ? 'قرأت القواعد ✓ — ابدأ التدريب' : 'Rules read ✓ — start practising')
                : (ar ? 'قرأت القواعد وفهمتها' : 'I have read the rules')),
            onPressed: () async {
              if (!st.read) await _save(ref, context, engUnitReadItem, 'read');
              if (context.mounted) {
                Navigator.of(context).pushReplacement(MaterialPageRoute<void>(builder: (_) => const CapsPracticeScreen(stage: 2)));
              }
            },
          ),
        ],
      ),
    );
  }
}

// ============================================================ practice
class CapsPracticeScreen extends ConsumerStatefulWidget {
  const CapsPracticeScreen({super.key, required this.stage});
  final int stage;

  @override
  ConsumerState<CapsPracticeScreen> createState() => _CapsPracticeScreenState();
}

class _CapsPracticeScreenState extends ConsumerState<CapsPracticeScreen> {
  int _index = 0;

  List<CapsExercise> get _list {
    final ids = unitStages[widget.stage - 1].items;
    return capsExercises.where((e) => ids.contains(e.id)).toList();
  }

  @override
  Widget build(BuildContext context) {
    final ar = context.s.isArabic;
    final st = ref.watch(engUnitProvider).valueOrNull ?? const EngUnitState();
    final list = _list;
    final ex = list[_index];
    final allDone = list.every((e) => st.done(e.id));
    final nextOpen = widget.stage < unitStages.length && st.stageOpen(widget.stage + 1);
    return AccountScaffold(
      title: ar ? unitStages[widget.stage - 1].titleAr : unitStages[widget.stage - 1].titleEn,
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          // Exercise picker: revisit any sentence at any time.
          SizedBox(
            height: 52,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                for (var i = 0; i < list.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      selected: i == _index,
                      onSelected: (_) => setState(() => _index = i),
                      avatar: st.done(list[i].id) ? const Icon(Icons.check_circle, color: _good, size: 18) : null,
                      label: Text('${capsExercises.indexOf(list[i]) + 1}  ${'⭐' * st.item(list[i].id).bestStars}'),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          CapsExerciseCard(
            key: ValueKey(ex.id),
            exercise: ex,
            number: capsExercises.indexOf(ex) + 1,
            onNext: _index < list.length - 1 ? () => setState(() => _index++) : null,
          ),
          if (allDone) ...[
            const SizedBox(height: 16),
            Card(
              color: const Color(0xFFDDF5E7),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(ar ? '🎉 أحسنت! أنهيت هذه المرحلة.' : '🎉 Well done! You finished this stage.',
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 8),
                    if (nextOpen)
                      FilledButton(
                        onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute<void>(
                          builder: (_) => widget.stage + 1 == 4 ? const CardsLessonScreen() : CapsPracticeScreen(stage: widget.stage + 1),
                        )),
                        child: Text(ar ? 'افتح المرحلة التالية ←' : 'Open the next stage →'),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// One sentence: tap the words with wrong capital letters, then check.
class CapsExerciseCard extends ConsumerStatefulWidget {
  const CapsExerciseCard({super.key, required this.exercise, required this.number, this.onNext});
  final CapsExercise exercise;
  final int number;
  final VoidCallback? onNext;

  @override
  ConsumerState<CapsExerciseCard> createState() => _CapsExerciseCardState();
}

class _CapsExerciseCardState extends ConsumerState<CapsExerciseCard> {
  final Set<int> _picked = {};
  bool _checked = false;
  bool _right = false;
  bool _showAnswer = false;
  bool _saving = false;
  int _earned = 0;

  CapsExercise get ex => widget.exercise;

  Future<void> _check() async {
    final wrong = ex.wrongIndexes;
    final right = _picked.length == wrong.length && _picked.containsAll(wrong);
    final before = ref.read(engUnitProvider).valueOrNull?.item(ex.id) ?? const UnitItemStat();
    // Stars count from the attempts made before this item was first solved.
    final attemptNo = before.solved ? 1 : before.attempts + 1;
    final stars = right ? starsForAttempt(attemptNo) : 0;
    setState(() {
      _checked = true;
      _right = right;
      _showAnswer = right;
      _earned = stars;
      _saving = true;
    });
    await _save(ref, context, ex.id, 'answer', correct: right, stars: stars);
    if (mounted) setState(() => _saving = false);
  }

  void _retry() => setState(() {
        _picked.clear();
        _checked = false;
        _right = false;
        _showAnswer = false;
        _earned = 0;
      });

  @override
  Widget build(BuildContext context) {
    final ar = context.s.isArabic;
    final tokens = ex.tokens;
    final wrong = ex.wrongIndexes;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(ar ? 'الجملة ${widget.number}' : 'Sentence ${widget.number}',
                style: context.text.labelLarge?.copyWith(color: _accent, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            _en('Tap the ${wrong.length} words with capitalization errors.', style: const TextStyle(fontWeight: FontWeight.w700)),
            _ar('اضغط على الكلمات (${wrong.length}) التي فيها خطأ في الحرف الكبير أو الصغير.',
                style: TextStyle(color: context.colors.onSurfaceVariant, fontSize: 13)),
            const SizedBox(height: 14),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Wrap(
                spacing: 6,
                runSpacing: 8,
                children: [
                  for (var i = 0; i < tokens.length; i++) _token(i, tokens[i], wrong),
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (!_checked)
              FilledButton.icon(
                onPressed: _picked.isEmpty ? null : _check,
                icon: const Icon(Icons.check),
                label: Text(ar ? 'تحقّق من إجابتي' : 'Check my answer'),
              ),
            if (_checked) ..._feedback(ar, wrong),
          ],
        ),
      ),
    );
  }

  Widget _token(int i, String word, Set<int> wrong) {
    final picked = _picked.contains(i);
    Color bg = const Color(0xFFF2F4F8);
    Color fg = _ink;
    var text = word;
    if (_checked) {
      final isWrong = wrong.contains(i);
      if (_showAnswer && isWrong) {
        text = ex.corrected(i);
        bg = const Color(0xFFDDF5E7);
        fg = _good;
      } else if (picked && isWrong) {
        bg = const Color(0xFFDDF5E7);
        fg = _good;
      } else if (picked && !isWrong) {
        bg = const Color(0xFFFFE3E3);
        fg = _bad;
      }
    } else if (picked) {
      bg = const Color(0xFFFFE9A8);
    }
    return Material(
      color: bg,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: _checked
            ? null
            : () => setState(() {
                  if (!_picked.remove(i)) _picked.add(i);
                }),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
          child: Text(text,
              style: TextStyle(
                fontSize: 17,
                color: fg,
                fontWeight: picked || (_showAnswer && wrong.contains(i)) ? FontWeight.w800 : FontWeight.w500,
                decoration: _checked && picked && !wrong.contains(i) ? TextDecoration.lineThrough : null,
              )),
        ),
      ),
    );
  }

  List<Widget> _feedback(bool ar, Set<int> wrong) {
    final missed = wrong.difference(_picked).length;
    final extra = _picked.difference(wrong).length;
    return [
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: _right ? const Color(0xFFDDF5E7) : const Color(0xFFFFF1F0),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              _right
                  ? (ar ? '🎉 إجابة صحيحة! +$_earned ⭐' : '🎉 Correct! +$_earned ⭐')
                  : (ar
                      ? 'ليست صحيحة تماماً — فاتتك $missed وأخطأت في $extra. حاول مرة أخرى 💪'
                      : 'Not quite — you missed $missed and picked $extra wrong. Try again 💪'),
              style: TextStyle(fontWeight: FontWeight.w800, color: _right ? _good : _bad),
            ),
            if (_saving) const Padding(padding: EdgeInsets.only(top: 6), child: LinearProgressIndicator()),
          ],
        ),
      ),
      if (_showAnswer) ...[
        const SizedBox(height: 12),
        Text(ar ? 'الإجابة الصحيحة:' : 'Correct answer:', style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Wrap(
          spacing: 8,
          runSpacing: 6,
          children: [
            for (final f in ex.fixes.entries)
              Chip(
                backgroundColor: const Color(0xFFE8F0FF),
                label: _en('${f.key} → ${f.value}', style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
          ],
        ),
        const SizedBox(height: 6),
        _en(ex.correctedSentence, style: const TextStyle(fontSize: 15, fontStyle: FontStyle.italic)),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: const Color(0xFFFFF8E6), borderRadius: BorderRadius.circular(14)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _en('Why? ${ex.whyEn}'),
              const SizedBox(height: 6),
              _ar('لماذا؟ ${ex.whyAr}'),
            ],
          ),
        ),
      ],
      const SizedBox(height: 12),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          if (!_right)
            FilledButton.icon(onPressed: _retry, icon: const Icon(Icons.refresh), label: Text(ar ? 'حاول مرة أخرى' : 'Try again')),
          if (!_right && !_showAnswer)
            OutlinedButton.icon(
              onPressed: () => setState(() => _showAnswer = true),
              icon: const Icon(Icons.visibility_outlined),
              label: Text(ar ? 'أظهر الإجابة' : 'Show the answer'),
            ),
          if (_right)
            OutlinedButton.icon(onPressed: _retry, icon: const Icon(Icons.replay), label: Text(ar ? 'أعد التمرين' : 'Practise again')),
          if (widget.onNext != null)
            FilledButton.tonalIcon(
              onPressed: widget.onNext,
              icon: const Icon(Icons.arrow_forward),
              label: Text(ar ? 'الجملة التالية' : 'Next sentence'),
            ),
        ],
      ),
    ];
  }
}

// ============================================================ videos
class UnitVideosScreen extends ConsumerWidget {
  const UnitVideosScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ar = context.s.isArabic;
    final st = ref.watch(engUnitProvider).valueOrNull ?? const EngUnitState();
    return AccountScaffold(
      title: ar ? 'تعلّم بالفيديو' : 'Video learning',
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          Text(ar ? 'اضغط ▶ للتشغيل. تقدر توقف، تعيد، أو تفتح الشاشة الكاملة من أزرار الفيديو.' : 'Press ▶ to play. Use the video buttons to pause, replay or go full screen.',
              style: TextStyle(color: context.colors.onSurfaceVariant)),
          const SizedBox(height: 12),
          for (final v in unitVideos)
            Card(
              clipBehavior: Clip.antiAlias,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    AspectRatio(
                      aspectRatio: 16 / 9,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: video.buildUnitVideo(
                          src: v.src,
                          poster: v.poster,
                          onWatched: () {
                            final now = ref.read(engUnitProvider).valueOrNull;
                            if (now != null && now.videos.contains(v.id)) return;
                            _save(ref, context, v.id, 'video');
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(child: _en(v.titleEn, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                        if (st.videos.contains(v.id))
                          Chip(
                            backgroundColor: const Color(0xFFDDF5E7),
                            label: Text(ar ? 'تمت المشاهدة ✓' : 'Watched ✓', style: const TextStyle(color: _good, fontWeight: FontWeight.w700)),
                          ),
                      ],
                    ),
                    _ar(v.titleAr, style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 6),
                    _en(v.descEn),
                    const SizedBox(height: 4),
                    _ar(v.descAr, style: TextStyle(color: context.colors.onSurfaceVariant)),
                    const SizedBox(height: 4),
                    Text('⏱ ${v.seconds}s', style: context.text.labelSmall),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ============================================================ debit vs credit
class CardsLessonScreen extends ConsumerStatefulWidget {
  const CardsLessonScreen({super.key});

  @override
  ConsumerState<CardsLessonScreen> createState() => _CardsLessonScreenState();
}

class _CardsLessonScreenState extends ConsumerState<CardsLessonScreen> {
  int? _choice;
  bool _checked = false;
  int _earned = 0;

  static const _options = [
    "\$130 will be removed from Preston's bank account within a few days.",
    "\$130 will not be removed from Preston's bank account at this time. Instead, he can pay it off over time, possibly with interest.",
  ];

  Future<void> _check() async {
    final right = _choice == 1;
    final before = ref.read(engUnitProvider).valueOrNull?.item(engUnitQuizItem) ?? const UnitItemStat();
    final stars = right ? starsForAttempt(before.solved ? 1 : before.attempts + 1) : 0;
    setState(() {
      _checked = true;
      _earned = stars;
    });
    await _save(ref, context, engUnitQuizItem, 'answer', correct: right, stars: stars);
  }

  Widget _cardBox(String emoji, String title, String titleAr, List<String> en, List<String> ar, Color color) => Card(
        color: color,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _en('$emoji $title', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
              _ar(titleAr, style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              for (var i = 0; i < en.length; i++) ...[
                _en('• ${en[i]}', style: const TextStyle(fontSize: 15)),
                _ar(ar[i], style: TextStyle(fontSize: 13, color: Colors.black.withValues(alpha: 0.65))),
                const SizedBox(height: 6),
              ],
            ],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final ar = context.s.isArabic;
    final right = _choice == 1;
    return AccountScaffold(
      title: ar ? 'بطاقة الخصم وبطاقة الائتمان' : 'Debit cards and credit cards',
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          _cardBox('💳', 'Debit card', 'بطاقة الخصم (Debit)', const [
            'Money is deducted directly from the bank account.',
            'You generally spend money you already have.',
            'Transactions reduce your available bank balance.',
          ], const [
            'المبلغ يُخصم مباشرة من حسابك في البنك.',
            'غالباً تصرف من فلوس موجودة عندك فعلاً.',
            'كل عملية شراء تُنقص رصيدك المتاح في البنك.',
          ], const Color(0xFFE8F7EF)),
          _cardBox('💳', 'Credit card', 'بطاقة الائتمان (Credit)', const [
            'The bank or card issuer pays for the purchase initially.',
            'You repay the amount later.',
            'You may pay interest if you do not pay the full balance by the due date.',
          ], const [
            'البنك أو شركة البطاقة يدفع ثمن الشراء أولاً.',
            'أنت تسدّد المبلغ لاحقاً.',
            'قد تدفع فائدة إذا لم تسدّد المبلغ كاملاً قبل موعد الاستحقاق.',
          ], const Color(0xFFFFF3E0)),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(ar ? 'سؤال' : 'Question', style: context.text.labelLarge?.copyWith(color: _accent, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  _en('Preston buys a season pass to the Coaster Creek amusement park. The season pass costs \$130, and Preston pays for it using his credit card.',
                      style: const TextStyle(fontSize: 16)),
                  const SizedBox(height: 8),
                  _en('Which statement is true?', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  const SizedBox(height: 10),
                  for (var i = 0; i < _options.length; i++)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Material(
                        color: _checked
                            ? (i == 1 ? const Color(0xFFDDF5E7) : (i == _choice ? const Color(0xFFFFE3E3) : const Color(0xFFF2F4F8)))
                            : (i == _choice ? const Color(0xFFE8F0FF) : const Color(0xFFF2F4F8)),
                        borderRadius: BorderRadius.circular(14),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: _checked ? null : () => setState(() => _choice = i),
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Row(
                              textDirection: TextDirection.ltr,
                              children: [
                                Icon(i == _choice ? Icons.radio_button_checked : Icons.radio_button_off, color: _accent),
                                const SizedBox(width: 10),
                                Expanded(child: _en('Option ${i + 1}: ${_options[i]}')),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  if (!_checked)
                    FilledButton.icon(
                      onPressed: _choice == null ? null : _check,
                      icon: const Icon(Icons.check),
                      label: Text(ar ? 'تحقّق من إجابتي' : 'Check my answer'),
                    ),
                  if (_checked) ...[
                    Text(
                      right
                          ? (ar ? '🎉 إجابة صحيحة! +$_earned ⭐' : '🎉 Correct! +$_earned ⭐')
                          : (ar ? 'ليست صحيحة — الإجابة الصحيحة هي الخيار 2.' : 'Not quite — the correct answer is Option 2.'),
                      style: TextStyle(fontWeight: FontWeight.w800, color: right ? _good : _bad),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: const Color(0xFFFFF8E6), borderRadius: BorderRadius.circular(14)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _en('Why? Preston used a credit card, so the card company pays the park now. '
                              'The money does not leave his bank account yet. He pays the card company later — '
                              'and if he does not pay the full amount by the due date, he may pay interest. '
                              'Option 1 describes a debit card.'),
                          const SizedBox(height: 6),
                          _ar('لماذا؟ بريستون دفع ببطاقة ائتمان، يعني شركة البطاقة هي اللي دفعت للملاهي الآن، '
                              'ولن يُخصم المبلغ من حسابه البنكي في هذا الوقت. سيسدّد المبلغ لاحقاً، '
                              'وإذا لم يسدّده كاملاً قبل موعد الاستحقاق قد يدفع فائدة. الخيار 1 يصف بطاقة الخصم.'),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: () => setState(() {
                        _checked = false;
                        _choice = null;
                        _earned = 0;
                      }),
                      icon: const Icon(Icons.refresh),
                      label: Text(right ? (ar ? 'أعد السؤال' : 'Try it again') : (ar ? 'حاول مرة أخرى' : 'Try again')),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================ parent dashboard
/// The unit's results for one child (parent dashboard > child report).
class EngUnitReportCard extends ConsumerWidget {
  const EngUnitReportCard({super.key, required this.profileId});
  final String profileId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ar = context.s.isArabic;
    final async = ref.watch(engUnitForProvider(profileId));
    final st = async.valueOrNull;
    Widget pill(String icon, String text) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(color: context.colors.surfaceContainerHighest, borderRadius: BorderRadius.circular(20)),
          child: Text('$icon $text', style: const TextStyle(fontWeight: FontWeight.w700)),
        );
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(ar ? '🔠 وحدة الإنجليزي: الحروف الكبيرة والثقافة المالية' : '🔠 English unit: Capitalization & financial literacy',
                  style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              if (async.hasError)
                Text(async.error is AuthFailure && (async.error! as AuthFailure).code == 'unit_not_installed'
                    ? (ar ? 'الوحدة لم تُفعَّل في قاعدة البيانات بعد.' : 'The unit is not installed in the database yet.')
                    : (ar ? 'تعذّر تحميل النتائج.' : 'Could not load the results.'))
              else if (st == null)
                const LinearProgressIndicator()
              else ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(value: st.completion, minHeight: 10, color: AppTokens.good),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    pill('📈', '${(st.completion * 100).round()}% ${ar ? 'مكتمل' : 'complete'}'),
                    pill('✅', '${st.correct} ${ar ? 'صحيحة' : 'correct'}'),
                    pill('✖', '${st.wrong} ${ar ? 'خاطئة' : 'incorrect'}'),
                    pill('🔁', '${st.attempts} ${ar ? 'محاولة' : 'attempts'}'),
                    pill('🎬', '${st.videosWatched}/${unitVideos.length} ${ar ? 'فيديو' : 'videos'}'),
                    pill('⭐', '${st.stars}/${st.maxStars}'),
                    pill('📍', st.currentStage > unitStages.length
                        ? (ar ? 'أنهى الوحدة' : 'Unit complete')
                        : '${ar ? 'المرحلة' : 'Stage'} ${st.currentStage}/${unitStages.length}'),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
