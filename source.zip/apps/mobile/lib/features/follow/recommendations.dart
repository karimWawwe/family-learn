import '../../domain/follow.dart';

/// One suggestion for the parent, built only from the child's real report.
class FollowTip {
  const FollowTip(this.emoji, this.text, {this.storyId});

  final String emoji;
  final String text;

  /// When the tip suggests a story, its id (the parent can open it).
  final String? storyId;
}

/// Simple rules on the child's own numbers (never a comparison with another child).
List<FollowTip> buildTips(FollowReport r, String name, {required bool ar}) {
  final tips = <FollowTip>[];
  final c = r.current;
  final p = r.previous;
  final periodAr = switch (r.period) { FollowPeriod.day => 'اليوم', FollowPeriod.week => 'هذا الأسبوع', FollowPeriod.month => 'هذا الشهر' };
  final periodEn = switch (r.period) { FollowPeriod.day => 'today', FollowPeriod.week => 'this week', FollowPeriod.month => 'this month' };
  final prevAr = switch (r.period) { FollowPeriod.day => 'أمس', FollowPeriod.week => 'الأسبوع الماضي', FollowPeriod.month => 'الشهر الماضي' };
  final prevEn = switch (r.period) { FollowPeriod.day => 'yesterday', FollowPeriod.week => 'last week', FollowPeriod.month => 'last month' };
  final sug = r.suggestion;

  if (r.neverUsed) {
    tips.add(FollowTip(
      '🌱',
      ar
          ? '$name لم يبدأ استخدام التطبيق بعد. يمكن البدء بقصة قصيرة قبل النوم${sug == null ? '' : ': «${sug.title}»'}.'
          : '$name has not used the app yet. A short bedtime story is a gentle start${sug == null ? '' : ': "${sug.title}"'}.',
      storyId: sug?.id,
    ));
    return tips;
  }

  // Stories
  if (c.storiesCompleted == 0) {
    tips.add(FollowTip(
      '🌙',
      ar
          ? '$name لم يكمل قصة $periodAr، ويمكن تشجيعه على الاستماع إلى قصة قصيرة قبل النوم${sug == null ? '' : ' مثل «${sug.title}»'}.'
          : '$name did not finish a story $periodEn. Try a short bedtime story together${sug == null ? '' : ', like "${sug.title}"'}.',
      storyId: sug?.id,
    ));
  } else if (r.topValue != null && sug != null) {
    final same = sug.value == r.topValue;
    tips.add(FollowTip(
      '📖',
      ar
          ? (same
              ? '$name يستمتع بقصص «${r.topValue}»، ويمكن تجربة قصة جديدة عنها: «${sug.title}».'
              : '$name يستمتع بالقصص الأخلاقية، ويمكن تجربة قصة جديدة عن «${sug.value}»: «${sug.title}».')
          : (same
              ? '$name enjoys stories about "${r.topValue}". Try a new one: "${sug.title}".'
              : '$name enjoys the value stories. Try a new one about "${sug.value}": "${sug.title}".'),
      storyId: sug.id,
    ));
  } else if (sug == null && r.totalStoriesCompleted > 0) {
    tips.add(FollowTip('🏆', ar ? '$name أكمل كل القصص المتاحة! يمكن إعادة قصته المفضلة معه.' : '$name finished every story! Replay a favourite together.'));
  }

  // Days used compared with the previous period (not for "day")
  if (r.period != FollowPeriod.day) {
    if (c.daysUsed > p.daysUsed && p.daysUsed > 0) {
      tips.add(FollowTip('📈', ar
          ? 'تقدّم جميل: استخدم $name التطبيق ${c.daysUsed} أيام $periodAr مقابل ${p.daysUsed} $prevAr. شجّعه على الاستمرار.'
          : 'Nice progress: $name used the app ${c.daysUsed} days $periodEn vs ${p.daysUsed} $prevEn.'));
    } else if (c.daysUsed < p.daysUsed) {
      tips.add(FollowTip('⏰', ar
          ? 'استخدام $name أقل من $prevAr (${c.daysUsed} مقابل ${p.daysUsed} أيام). جلسة قصيرة يوميًا (10 دقائق) تساعده على الاستمرار.'
          : '$name used the app less than $prevEn (${c.daysUsed} vs ${p.daysUsed} days). A short daily session helps.'));
    }
  }

  // Lessons accuracy / weak skills
  final acc = c.accuracy;
  if (r.weakSkills.isNotEmpty) {
    tips.add(FollowTip('🧩', ar
        ? 'يحتاج $name إلى مراجعة: ${r.weakSkills.join('، ')}.'
        : '$name could review: ${r.weakSkills.join(', ')}.'));
  } else if (acc != null && c.questions >= 5 && acc >= 0.85) {
    tips.add(FollowTip('⭐', ar
        ? 'دقة $name في الدروس ممتازة $periodAr (${(acc * 100).round()}%).'
        : "$name's lesson accuracy is excellent $periodEn (${(acc * 100).round()}%)."));
  }

  // Speaking game
  if (r.trickyWords.isNotEmpty) {
    tips.add(FollowTip('🎤', ar
        ? 'يمكن التدرب مع $name على نطق: ${r.trickyWords.join('، ')}.'
        : 'Practise saying these words with $name: ${r.trickyWords.join(', ')}.'));
  } else if (c.speakLevels == 0 && r.speakLevelsDone == 0) {
    tips.add(FollowTip('🎤', ar
        ? 'لم يجرّب $name ألعاب النطق بعد، وهي تساعده على نطق كلمات كتابه بالإنجليزية.'
        : '$name has not tried the speaking games yet; they help with the English words from school.'));
  }

  // Math games
  final macc = c.mathAccuracy;
  if (c.mathRounds == 0 && r.mathPoints == 0) {
    tips.add(FollowTip('🧮', ar
        ? 'جرّب مع $name لعبة «جدول الضرب» أو «تعلّم الوقت» من قائمة المزيد؛ الجولة قصيرة (دقيقتان تقريبًا).'
        : 'Try the "Times tables" or "Telling the time" game with $name (in More); a round takes about two minutes.'));
  } else if (macc != null && c.mathTotal >= 10 && macc < 0.6) {
    tips.add(FollowTip('🧮', ar
        ? 'دقة $name في ألعاب الرياضيات $periodAr ${(macc * 100).round()}%؛ يفيد اللعب بالمستوى السهل أو جدول واحد قبل المختلط.'
        : "$name's math-games accuracy $periodEn is ${(macc * 100).round()}%; the easy level or a single table may help before mixed."));
  }

  // Favourite story
  if (r.favorites.isNotEmpty && c.storiesCompleted == 0) {
    tips.add(FollowTip('❤️', ar
        ? 'قصة $name المفضلة «${r.favorites.first.title}»، ويمكن قراءتها معه الليلة.'
        : '$name\'s favourite story is "${r.favorites.first.title}" - maybe tonight?', storyId: r.favorites.first.id));
  }
  return tips;
}
