import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../core/widgets/common.dart';
import '../../domain/account.dart';
import '../../domain/follow.dart';
import '../../domain/models.dart';
import '../../state/account.dart';
import '../../state/bedtime.dart';
import '../../state/session.dart';
import 'recommendations.dart';

/// "لوحة متابعة الوالدين" - parent only (the router also blocks children).
/// Every number comes from parent_follow() in the database and refreshes by itself.
class ParentFollowScreen extends ConsumerStatefulWidget {
  const ParentFollowScreen({super.key});

  @override
  ConsumerState<ParentFollowScreen> createState() => _ParentFollowScreenState();
}

class _ParentFollowScreenState extends ConsumerState<ParentFollowScreen> with WidgetsBindingObserver {
  String? _childId;
  FollowPeriod _period = FollowPeriod.week;
  Timer? _auto;
  DateTime _updated = DateTime.now();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // Live: refresh every 30 seconds while the screen is open.
    _auto = Timer.periodic(const Duration(seconds: 30), (_) => _refresh());
  }

  @override
  void dispose() {
    _auto?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  void _refresh() {
    final id = _childId;
    if (!mounted || id == null) return;
    ref.invalidate(followProvider((id, _period)));
    setState(() => _updated = DateTime.now());
  }

  bool get _ar => AppStrings.of(context).isArabic;
  String _t(String ar, String en) => _ar ? ar : en;

  @override
  Widget build(BuildContext context) {
    final me = ref.watch(currentProfileProvider);
    final account = ref.watch(accountProvider).valueOrNull;
    final title = _t('لوحة متابعة الوالدين', 'Parent follow-up');
    if (me == null || account == null) return const SizedBox.shrink();
    if (!me.isParent || !account.isParentAccount) {
      return AccountScaffold(title: title, body: EmptyState(emoji: '🔒', message: _t('للوالدين فقط', 'Parents only')));
    }
    final children = account.children;
    if (children.isEmpty) {
      return AccountScaffold(title: title, body: EmptyState(emoji: '👶', message: _t('لم تتم إضافة أطفال بعد', 'No children yet')));
    }
    _childId ??= children.first.id;
    if (!children.any((c) => c.id == _childId)) _childId = children.first.id;
    final child = children.firstWhere((c) => c.id == _childId);
    final async = ref.watch(followProvider((child.id, _period)));

    return AccountScaffold(
      title: title,
      actions: [
        IconButton(tooltip: _t('تحديث', 'Refresh'), onPressed: _refresh, icon: const Icon(Icons.refresh)),
      ],
      body: RefreshIndicator(
        onRefresh: () async {
          setState(() => _updated = DateTime.now());
          try {
            await ref.refresh(followProvider((child.id, _period)).future);
          } catch (_) {}
        },
        child: LayoutBuilder(builder: (context, box) {
          final wide = box.maxWidth >= 720;
          return ListView(
            padding: EdgeInsets.symmetric(horizontal: math.max(8, (box.maxWidth - 1100) / 2), vertical: 8),
            children: [
              // child switcher (no ranking, no comparison between children)
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final c in children)
                      ChoiceChip(
                        avatar: Text(c.avatarEmoji),
                        label: Text(c.displayName, style: const TextStyle(fontWeight: FontWeight.w700)),
                        selected: c.id == child.id,
                        onSelected: (_) => setState(() => _childId = c.id),
                      ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
                child: SegmentedButton<FollowPeriod>(
                  segments: [
                    ButtonSegment(value: FollowPeriod.day, label: Text(_t('يومي', 'Daily'))),
                    ButtonSegment(value: FollowPeriod.week, label: Text(_t('أسبوعي', 'Weekly'))),
                    ButtonSegment(value: FollowPeriod.month, label: Text(_t('شهري', 'Monthly'))),
                  ],
                  selected: {_period},
                  onSelectionChanged: (v) => setState(() => _period = v.first),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 2, 12, 4),
                child: Text(
                  _t('يتحدّث تلقائيًا · آخر تحديث ${_clock(_updated)}', 'Updates automatically · last update ${_clock(_updated)}'),
                  style: context.text.bodySmall?.copyWith(color: context.colors.onSurfaceVariant),
                ),
              ),
              if (async.hasError)
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: ErrorText(async.error is AuthFailure && (async.error! as AuthFailure).code == 'bedtime_not_installed'
                      ? _t('اللوحة تحتاج تحديث قاعدة البيانات (ملف SQL الخاص بالقصص والمتابعة).',
                          'This page needs the stories/follow-up database update (SQL file).')
                      : failureText(context, async.error!)),
                ),
              if (async.isLoading && async.valueOrNull == null) const LinearProgressIndicator(),
              if (async.valueOrNull != null) ..._body(context, child, async.valueOrNull!, wide),
            ],
          );
        }),
      ),
    );
  }

  // ---------------------------------------------------------------- sections
  List<Widget> _body(BuildContext context, LearnerProfile child, FollowReport r, bool wide) {
    final c = r.current;
    final p = r.previous;
    final name = child.displayName;
    final periodTitle = switch (r.period) {
      FollowPeriod.day => _t('اليوم', 'today'),
      FollowPeriod.week => _t('هذا الأسبوع', 'this week'),
      FollowPeriod.month => _t('هذا الشهر', 'this month'),
    };
    final prevTitle = switch (r.period) {
      FollowPeriod.day => _t('أمس', 'yesterday'),
      FollowPeriod.week => _t('الأسبوع الماضي', 'last week'),
      FollowPeriod.month => _t('الشهر الماضي', 'last month'),
    };
    final tips = buildTips(r, name, ar: _ar);

    Widget grid(List<Widget> items, {int cols = 2}) => LayoutBuilder(builder: (context, box) {
          final n = box.maxWidth >= 900 ? math.max(cols, 3) : (box.maxWidth >= 520 ? cols : 1);
          final w = (box.maxWidth - (n - 1) * 8) / n;
          return Wrap(spacing: 8, runSpacing: 8, children: [for (final i in items) SizedBox(width: w, child: i)]);
        });

    final kpis = [
      _Kpi(icon: '⏱️', label: _t('وقت التعلّم', 'Learning time'), now: c.minutesTotal, before: p.minutesTotal, unit: _t('د', 'min'), prev: prevTitle),
      _Kpi(icon: '📅', label: _t('أيام الاستخدام', 'Days used'), now: c.daysUsed, before: p.daysUsed, prev: prevTitle),
      _Kpi(icon: '🌙', label: _t('قصص مكتملة', 'Stories finished'), now: c.storiesCompleted, before: p.storiesCompleted, prev: prevTitle),
      _Kpi(icon: '🎧', label: _t('دقائق الاستماع للقصص', 'Story minutes'), now: c.minutesStories, before: p.minutesStories, unit: _t('د', 'min'), prev: prevTitle),
      _Kpi(icon: '📚', label: _t('دروس منتهية', 'Lessons finished'), now: c.lessonsDone, before: p.lessonsDone, prev: prevTitle),
      _Kpi(icon: '🎤', label: _t('كلمات نطقها صح', 'Words said right'), now: c.speakWords, before: p.speakWords, prev: prevTitle),
      _Kpi(icon: '🧮', label: _t('جولات الرياضيات', 'Math rounds'), now: c.mathRounds, before: p.mathRounds, prev: prevTitle),
    ];

    return [
      // headline report, like: "تقرير ياسين هذا الأسبوع"
      _Section(
        title: _t('تقرير $name $periodTitle', "$name's report $periodTitle"),
        emoji: child.avatarEmoji,
        child: r.neverUsed
            ? Text(_t('لا يوجد نشاط مسجّل بعد لـ $name.', 'No activity saved for $name yet.'))
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _Bullet(_t('${c.daysUsed} ${_days(c.daysUsed)} استخدام.', '${c.daysUsed} day(s) used.')),
                  _Bullet(_t('${c.storiesCompleted} ${c.storiesCompleted == 1 ? 'قصة مكتملة' : 'قصص مكتملة'} (من ${c.storiesListened} بدأها).',
                      '${c.storiesCompleted} stories finished (${c.storiesListened} started).')),
                  _Bullet(_t('${c.minutesStories} دقيقة استماع للقصص.', '${c.minutesStories} minutes of stories.')),
                  _Bullet(_t('${c.values.length} ${c.values.length == 1 ? 'قيمة أخلاقية' : 'قيم أخلاقية'} تم تعلّمها${c.values.isEmpty ? '' : ': ${c.values.join('، ')}'}.',
                      '${c.values.length} values learned${c.values.isEmpty ? '' : ': ${c.values.join(', ')}'}.')),
                  _Bullet(_t('${c.minutesTotal} دقيقة تعلّم (دروس ${c.minutesLessons} · قصص ${c.minutesStories} · نطق ${c.minutesSpeaking} · رياضيات ${c.minutesMath}).',
                      '${c.minutesTotal} learning minutes (lessons ${c.minutesLessons} · stories ${c.minutesStories} · speaking ${c.minutesSpeaking} · math ${c.minutesMath}).')),
                  if (c.mathRounds > 0)
                    _Bullet(_t('${c.mathRounds} ${c.mathRounds == 1 ? 'جولة' : 'جولات'} في جدول الضرب وتعلّم الوقت، بدقة ${((c.mathAccuracy ?? 0) * 100).round()}%.',
                        '${c.mathRounds} times-tables / clock rounds, ${((c.mathAccuracy ?? 0) * 100).round()}% right.')),
                  if (r.lastStory != null) _Bullet(_t('آخر قصة: «${r.lastStory!.title}».', 'Last story: "${r.lastStory!.title}".')),
                ],
              ),
      ),
      _Section(
        title: _t('مقارنة بـ$prevTitle', 'Compared with $prevTitle'),
        emoji: '📈',
        subtitle: _t('يقارن $name بمستواه السابق فقط.', '$name is compared only with their own past.'),
        child: grid(kpis, cols: 3),
      ),
      _Section(
        title: _t('دقائق التعلّم يوميًا', 'Learning minutes per day'),
        emoji: '📊',
        child: _DayBars(days: r.byDay, ar: _ar),
      ),
      if (wide)
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: _progressSection(r)),
            Expanded(child: _totalsSection(r)),
          ],
        )
      else ...[
        _progressSection(r),
        _totalsSection(r),
      ],
      _storiesSection(context, r),
      _Section(
        title: _t('آخر نشاط', 'Last activity'),
        emoji: '🕒',
        child: r.lastActivityAt == null
            ? Text(_t('لا يوجد نشاط بعد.', 'No activity yet.'))
            : ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Text(switch (r.lastActivityKind) { 'lesson' => '📚', 'speak' => '🎤', 'math' => '🧮', _ => '🌙' },
                    style: const TextStyle(fontSize: 28)),
                title: Text(switch (r.lastActivityKind) {
                  'lesson' => _t('درس: ${r.lastActivityTitle}', 'Lesson: ${r.lastActivityTitle}'),
                  'speak' => _t('لعبة النطق: ${r.lastActivityTitle}', 'Speaking game: ${r.lastActivityTitle}'),
                  'math' => _t('لعبة: ${r.lastActivityTitle}', 'Game: ${r.lastActivityTitle == 'جدول الضرب' ? 'Times tables' : 'Telling the time'}'),
                  _ => _t('قصة: ${r.lastActivityTitle}', 'Story: ${r.lastActivityTitle}'),
                }),
                subtitle: Text(_ago(r.lastActivityAt!)),
              ),
      ),
      _Section(
        title: _t('توصيات لك', 'Suggestions for you'),
        emoji: '💡',
        subtitle: _t('مبنية على نشاط $name الفعلي.', "Based on $name's real activity."),
        child: Column(
          children: [
            for (final tip in tips)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Text(tip.emoji, style: const TextStyle(fontSize: 24)),
                title: Text(tip.text, style: const TextStyle(height: 1.5)),
              ),
            if (tips.isEmpty) Text(_t('لا توجد توصيات الآن - استمرّا هكذا! 🌟', 'Nothing to suggest now - keep it up! 🌟')),
          ],
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
        child: OutlinedButton.icon(
          onPressed: () => context.push(Routes.childReport(child.id)),
          icon: const Icon(Icons.insights_outlined),
          label: Text(_t('تقرير الدروس التفصيلي لـ $name', 'Detailed lessons report for $name')),
        ),
      ),
    ];
  }

  Widget _progressSection(FollowReport r) {
    final into = r.intoLevel / 500;
    return _Section(
      title: _t('مستوى التقدّم', 'Progress level'),
      emoji: '🏅',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(_t('المستوى ${r.level}', 'Level ${r.level}'),
              style: context.text.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(value: into.clamp(0.0, 1.0).toDouble(), minHeight: 10),
          ),
          const SizedBox(height: 6),
          Text(_t('${r.intoLevel} / 500 نقطة للمستوى التالي', '${r.intoLevel} / 500 points to the next level'),
              style: context.text.bodySmall),
          const SizedBox(height: 8),
          Text(
            _t('النقاط: دروس ${r.lessonXp} + ألعاب النطق ${r.speakPoints} + الرياضيات ${r.mathPoints} + قصص ${r.storyPoints} = ${r.progressPoints}',
                'Points: lessons ${r.lessonXp} + speaking ${r.speakPoints} + math ${r.mathPoints} + stories ${r.storyPoints} = ${r.progressPoints}'),
            style: context.text.bodySmall?.copyWith(color: context.colors.onSurfaceVariant),
          ),
        ],
      ),
    );
  }

  Widget _totalsSection(FollowReport r) => _Section(
        title: _t('منذ البداية', 'Since the start'),
        emoji: '🗂️',
        child: Column(
          children: [
            _Row(_t('إجمالي وقت التعلّم', 'Total learning time'), _t('${r.totalMinutes} دقيقة', '${r.totalMinutes} min')),
            _Row(_t('عدد أيام استخدام التطبيق', 'Days using the app'), '${r.totalDays}'),
            _Row(_t('القصص التي استمع إليها', 'Stories listened to'), '${r.totalStoriesListened}'),
            _Row(_t('القصص التي أكملها', 'Stories finished'), '${r.totalStoriesCompleted}'),
            _Row(_t('دروس منتهية', 'Lessons finished'), '${r.totalLessons}'),
            _Row(_t('كلمات نطقها صح', 'Words said right'), '${r.totalSpeakWords}'),
            _Row(_t('نقاط ألعاب الرياضيات', 'Math games points'), '${r.mathPoints}'),
          ],
        ),
      );

  Widget _storiesSection(BuildContext context, FollowReport r) => _Section(
        title: _t('القصص والقيم', 'Stories and values'),
        emoji: '🌙',
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_t('آخر قصة استمع إليها', 'Last story'), style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            r.lastStory == null
                ? Text(_t('لم يستمع إلى قصة بعد.', 'No story yet.'))
                : Text(
                    '${r.lastStory!.emoji} ${r.lastStory!.title} · ${r.lastStoryCompleted ? _t('مكتملة', 'finished') : _t('لم تكتمل', 'not finished')}'
                    '${r.lastStoryAt == null ? '' : ' · ${_ago(r.lastStoryAt!)}'}',
                  ),
            const SizedBox(height: 12),
            Text(_t('القصص المفضلة', 'Favourite stories'), style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            if (r.favorites.isEmpty) Text(_t('لا توجد بعد.', 'None yet.')),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [for (final f in r.favorites) Chip(avatar: Text(f.emoji), label: Text(f.title))],
            ),
            const SizedBox(height: 12),
            Text(_t('القيم والمواضيع التي تعلّمها', 'Values and topics learned'), style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            if (r.valuesAll.isEmpty) Text(_t('تظهر بعد إكمال أول قصة.', 'Shown after the first finished story.')),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final v in r.valuesAll)
                  Chip(
                    avatar: const Text('✨'),
                    label: Text('${v.value} ×${v.count}'),
                    backgroundColor: v.value == r.topValue ? const Color(0xFFFFF4D6) : null,
                  ),
              ],
            ),
          ],
        ),
      );

  // ---------------------------------------------------------------- text helpers
  String _days(int n) => n == 1 ? 'يوم' : (n == 2 ? 'يوما' : (n <= 10 ? 'أيام' : 'يومًا'));

  String _clock(DateTime d) => '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  String _ago(DateTime at) {
    final d = DateTime.now().difference(at.toLocal());
    if (d.inMinutes < 1) return _t('الآن', 'just now');
    if (d.inMinutes < 60) return _t('منذ ${d.inMinutes} دقيقة', '${d.inMinutes} min ago');
    if (d.inHours < 24) return _t('منذ ${d.inHours} ساعة', '${d.inHours} h ago');
    if (d.inDays == 1) return _t('أمس', 'yesterday');
    if (d.inDays < 30) return _t('منذ ${d.inDays} يوم', '${d.inDays} days ago');
    final l = at.toLocal();
    return '${l.day}/${l.month}/${l.year}';
  }
}

// ---------------------------------------------------------------- widgets
class _Section extends StatelessWidget {
  const _Section({required this.title, required this.emoji, required this.child, this.subtitle});

  final String title;
  final String emoji;
  final String? subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(emoji, style: const TextStyle(fontSize: 22)),
                    const SizedBox(width: 8),
                    Expanded(child: Text(title, style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w800))),
                  ],
                ),
                if (subtitle != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(subtitle!, style: context.text.bodySmall?.copyWith(color: context.colors.onSurfaceVariant)),
                  ),
                const SizedBox(height: 10),
                child,
              ],
            ),
          ),
        ),
      );
}

class _Bullet extends StatelessWidget {
  const _Bullet(this.text);

  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('•  ', style: TextStyle(fontWeight: FontWeight.w900)),
            Expanded(child: Text(text, style: const TextStyle(height: 1.5))),
          ],
        ),
      );
}

class _Row extends StatelessWidget {
  const _Row(this.label, this.value);

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          children: [
            Expanded(child: Text(label)),
            Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
      );
}

class _Kpi extends StatelessWidget {
  const _Kpi({required this.icon, required this.label, required this.now, required this.before, required this.prev, this.unit = ''});

  final String icon;
  final String label;
  final int now;
  final int before;
  final String prev;
  final String unit;

  @override
  Widget build(BuildContext context) {
    final ar = AppStrings.of(context).isArabic;
    final diff = now - before;
    final color = diff > 0 ? AppTokens.good : (diff < 0 ? AppTokens.warn : context.colors.onSurfaceVariant);
    final arrow = diff > 0 ? '▲' : (diff < 0 ? '▼' : '＝');
    final change = diff == 0
        ? (ar ? 'مثل $prev' : 'same as $prev')
        : (ar ? '$arrow ${diff.abs()} عن $prev' : '$arrow ${diff.abs()} vs $prev');
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: context.colors.surfaceContainerHighest.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$icon  $label', style: context.text.bodySmall, maxLines: 1, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 4),
          Text(unit.isEmpty ? '$now' : '$now $unit', style: context.text.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          Text(change, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _DayBars extends StatelessWidget {
  const _DayBars({required this.days, required this.ar});

  final List<DayMinutes> days;
  final bool ar;

  @override
  Widget build(BuildContext context) {
    if (days.isEmpty) return const SizedBox.shrink();
    final max = days.fold<int>(1, (m, d) => d.minutes > m ? d.minutes : m);
    final dense = days.length > 10;
    const wd = ['ن', 'ث', 'ر', 'خ', 'ج', 'س', 'ح'];
    const wdEn = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    return SizedBox(
      height: 150,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (var i = 0; i < days.length; i++)
            Expanded(
              child: Tooltip(
                message: '${days[i].day.day}/${days[i].day.month}: ${days[i].minutes} ${ar ? 'دقيقة' : 'min'}',
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: dense ? 1 : 4),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      if (!dense)
                        Text('${days[i].minutes}', style: context.text.labelSmall),
                      const SizedBox(height: 2),
                      Container(
                        height: 100 * days[i].minutes / max + 2,
                        decoration: BoxDecoration(
                          color: i == days.length - 1 ? context.colors.primary : context.colors.primary.withValues(alpha: 0.45),
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        dense ? (i % 5 == 4 || i == days.length - 1 ? '${days[i].day.day}' : '') : (ar ? wd : wdEn)[days[i].day.weekday - 1],
                        style: context.text.labelSmall,
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
