import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../core/widgets/common.dart';
import '../../data/learning/question_codec.dart';
import '../../domain/learning.dart';
import '../../domain/models.dart';
import '../../domain/plan.dart';
import '../../domain/questions.dart';
import '../../state/learning.dart';
import '../../state/plan.dart';
import '../../state/session.dart';
import '../questions/question_views.dart';

// Phase 4: courses, lessons and marking come from the server.
// Phase 6: the same player runs review sessions and the placement test (also marked on the server).

/// Loading / error / data for any async value, with a retry button.
class AsyncBody<T> extends StatelessWidget {
  const AsyncBody({super.key, required this.value, required this.onRetry, required this.data});

  final AsyncValue<T> value;
  final VoidCallback onRetry;
  final Widget Function(T data) data;

  @override
  Widget build(BuildContext context) {
    return value.when(
      skipLoadingOnRefresh: true,
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ErrorText(failureText(context, e)),
              const SizedBox(height: 12),
              OutlinedButton(onPressed: onRetry, child: Text(context.s.t('tryAgain'))),
            ],
          ),
        ),
      ),
      data: data,
    );
  }
}

// ---------------------------------------------------------------- course map
class CourseMapScreen extends ConsumerWidget {
  const CourseMapScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final s = context.s;
    final map = ref.watch(courseMapProvider(p.id));
    return AccountScaffold(
      title: s.t('courses'),
      actions: [
        IconButton(
          tooltip: s.t('placementTitle'),
          icon: const Icon(Icons.explore_outlined),
          onPressed: () => context.push(Routes.placement(p.id)),
        ),
      ],
      body: AsyncBody<List<Course>>(
        value: map,
        onRetry: () => ref.invalidate(courseMapProvider(p.id)),
        data: (courses) {
          if (courses.isEmpty) return EmptyState(emoji: '📚', message: s.t('noCourses'));
          return DefaultTabController(
            length: courses.length,
            child: Column(
              children: [
                TabBar(isScrollable: true, tabs: [for (final c in courses) Tab(text: c.title)]),
                Expanded(
                  child: RefreshIndicator(
                    // The lesson list scrolls inside the TabBarView's page view (depth 1).
                    notificationPredicate: (n) => n.depth == 1,
                    onRefresh: () async {
                      try {
                        await ref.refresh(courseMapProvider(p.id).future);
                      } catch (_) {
                        // the error is shown by AsyncBody
                      }
                    },
                    child: TabBarView(children: [for (final c in courses) _CoursePath(course: c)]),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _CoursePath extends StatelessWidget {
  const _CoursePath({required this.course});

  final Course course;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final all = [for (final u in course.units) ...u.lessons];
    final done = all.where((l) => l.status == LessonStatus.done).length;
    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Chip(avatar: const Icon(Icons.flag, size: 18), label: Text(course.levelLabel)),
              const Spacer(),
              Text(s.f('lessonsDoneOf', [done, all.length]), style: context.text.bodyMedium),
            ],
          ),
        ),
        for (var u = 0; u < course.units.length; u++) ...[
          SectionTitle('${s.t('unit')} ${u + 1}: ${course.units[u].title}'),
          for (final l in course.units[u].lessons) _LessonTile(lesson: l),
        ],
      ],
    );
  }
}

class _LessonTile extends StatelessWidget {
  const _LessonTile({required this.lesson});

  final LessonSummary lesson;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final (IconData icon, Color color) = switch (lesson.status) {
      LessonStatus.done => (Icons.check_circle, AppTokens.good),
      LessonStatus.inProgress => (Icons.play_circle_fill, context.colors.primary),
      LessonStatus.available => (Icons.play_circle_outline, context.colors.primary),
      LessonStatus.locked => (Icons.lock_outline, context.colors.outline),
      LessonStatus.placed => (Icons.verified_outlined, AppTokens.good),
    };
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: ListTile(
        leading: Icon(icon, color: color, size: 32),
        title: Text(lesson.title, textDirection: TextDirection.ltr),
        subtitle: Text(switch (lesson.status) {
          LessonStatus.locked => s.t('locked'),
          LessonStatus.placed => s.t('placedLesson'),
          _ => s.f('minutes', [lesson.minutes]),
        }),
        enabled: lesson.status != LessonStatus.locked,
        onTap: () => context.push(Routes.lesson(lesson.id)),
      ),
    );
  }
}

// ---------------------------------------------------------------- lesson player

/// What the player is running.
enum PlayMode { lesson, review, placement }

class LessonPlayerScreen extends ConsumerStatefulWidget {
  const LessonPlayerScreen({super.key, required this.lessonId, this.isPlacement = false, this.isReview = false});

  final String lessonId;
  final bool isPlacement;
  final bool isReview;

  PlayMode get mode => isPlacement ? PlayMode.placement : (isReview ? PlayMode.review : PlayMode.lesson);

  @override
  ConsumerState<LessonPlayerScreen> createState() => _LessonPlayerScreenState();
}

class _LessonPlayerScreenState extends ConsumerState<LessonPlayerScreen> {
  LessonSession? _session; // lesson mode
  PracticeSession? _practice; // review / placement mode
  List<Question> _questions = const [];
  bool _loading = true;
  String? _loadError;

  int _index = 0;
  Object? _answer;
  bool _busy = false;
  AnswerResult? _feedback; // null = not checked yet
  String? _error;
  int _correct = 0;
  bool _showHint = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final p = ref.read(currentProfileProvider);
    if (p == null) return;
    setState(() {
      _loading = true;
      _loadError = null;
    });
    try {
      if (widget.mode == PlayMode.lesson) {
        final session = await ref.read(learningRepositoryProvider).startLesson(p.id, widget.lessonId);
        if (!mounted) return;
        setState(() {
          _session = session;
          _questions = session.questions;
        });
      } else {
        final plan = ref.read(planRepositoryProvider);
        final practice = widget.mode == PlayMode.review ? await plan.startReview(p.id) : await plan.startPlacement(p.id);
        if (!mounted) return;
        setState(() {
          _practice = practice;
          _questions = practice.questions;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _loadError = failureText(context, e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Question get _q => _questions[_index];

  Future<void> _check() async {
    if (_busy) return;
    final session = _session;
    final practiceId = _practice?.sessionId;
    if (session == null && practiceId == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final r = session != null
          ? await ref.read(learningRepositoryProvider).submitAnswer(session.attemptId, _q.id, encodeResponse(_answer))
          : await ref.read(planRepositoryProvider).submitAnswer(practiceId!, _q.id, encodeResponse(_answer));
      if (!mounted) return;
      setState(() {
        _feedback = r;
        if (r.correct) _correct++;
      });
    } catch (e) {
      if (mounted) setState(() => _error = failureText(context, e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _next() async {
    if (_index + 1 < _questions.length) {
      setState(() {
        _index++;
        _answer = null;
        _feedback = null;
        _error = null;
        _showHint = false;
      });
      return;
    }
    final session = _session;
    final practiceId = _practice?.sessionId;
    if (session == null && practiceId == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final p = ref.read(currentProfileProvider);
      if (session != null) {
        final outcome = await ref.read(learningRepositoryProvider).finishLesson(session.attemptId);
        if (p != null) refreshProgress(ref, p.id);
        if (mounted) context.pushReplacement(Routes.lessonComplete, extra: outcome);
      } else {
        final outcome = await ref.read(planRepositoryProvider).finish(practiceId!);
        if (p != null) refreshProgress(ref, p.id);
        if (!mounted) return;
        context.pushReplacement(
            outcome.kind == PracticeKind.placement ? Routes.placementResult : Routes.practiceComplete,
            extra: outcome);
      }
    } catch (e) {
      if (mounted) setState(() => _error = failureText(context, e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    if (_loading) return const AccountScaffold(title: '', body: Center(child: CircularProgressIndicator()));
    if (_loadError == null && _questions.isEmpty && widget.mode == PlayMode.review) {
      return AccountScaffold(
        title: s.t('reviewToday'),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              EmptyState(emoji: '🌟', message: s.t('reviewEmpty')),
              FilledButton(onPressed: () => context.go(Routes.home), child: Text(s.t('navHome'))),
            ],
          ),
        ),
      );
    }
    if (_loadError != null || _questions.isEmpty) {
      return AccountScaffold(
        title: '',
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ErrorText(_loadError ?? s.t('err_not_found')),
                const SizedBox(height: 12),
                OutlinedButton(onPressed: _load, child: Text(s.t('tryAgain'))),
              ],
            ),
          ),
        ),
      );
    }
    final checked = _feedback != null;
    final count = s.f('questionOf', [_index + 1, _questions.length]);
    final title = switch (widget.mode) {
      PlayMode.lesson => count,
      PlayMode.review => '${s.t('reviewToday')} · $count',
      PlayMode.placement => '${s.t('placementTitle')} · $count',
    };
    final actions = <Widget>[
        if (_q.hint != null)
          IconButton(
            tooltip: s.t('hint'),
            icon: const Icon(Icons.lightbulb_outline),
            onPressed: () => setState(() => _showHint = true),
          ),
    ];
    final body = Column(
        children: [
          LinearProgressIndicator(value: (_index + (checked ? 1 : 0)) / _questions.length, minHeight: 6),
          if (_showHint && _q.hint != null)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: const Color(0xFFFFF8E1), borderRadius: BorderRadius.circular(12)),
              child: Text('💡 ${_q.hint!}', textDirection: TextDirection.ltr, style: const TextStyle(color: Color(0xFF5D4600))),
            ),
          Expanded(
            child: QuestionView(
              key: ValueKey(_q.id),
              question: _q,
              locked: checked || _busy,
              onAnswer: (a) => setState(() => _answer = a),
            ),
          ),
          if (_feedback != null) _FeedbackBar(result: _feedback!),
          if (_error != null) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: ErrorText(_error)),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
            child: SizedBox(
              width: double.infinity,
              child: BusyButton(
                busy: _busy,
                label: checked ? s.t(_index + 1 < _questions.length ? 'next' : 'finish') : s.t('check'),
                onPressed: checked ? _next : (_answer == null ? null : _check),
              ),
            ),
          ),
        ],
    );
    return AccountScaffold(title: title, actions: actions, body: body);
  }
}

class _FeedbackBar extends StatelessWidget {
  const _FeedbackBar({required this.result});

  final AnswerResult result;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final ok = result.correct;
    final color = ok ? AppTokens.good : AppTokens.bad;
    return Semantics(
      liveRegion: true,
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(14)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(ok ? Icons.check_circle : Icons.cancel, color: color),
                const SizedBox(width: 8),
                Text(ok ? s.t('correct') : s.t('notQuite'), style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 18)),
                const Spacer(),
                if (!ok)
                  TextButton.icon(
                    onPressed: () => context.push(Routes.tutor),
                    icon: const Icon(Icons.smart_toy_outlined, size: 18),
                    label: Text(s.t('explain')),
                  ),
              ],
            ),
            if (!ok) Text(s.f('correctAnswer', [result.correctText]), textDirection: TextDirection.ltr),
            if (result.explanation != null) ...[
              const SizedBox(height: 4),
              Text(result.explanation!, textDirection: TextDirection.ltr, style: context.text.bodySmall),
            ],
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- lesson complete
class LessonCompleteScreen extends StatelessWidget {
  const LessonCompleteScreen({super.key, this.outcome});

  /// Null only if the screen is opened without a result (e.g. app restored).
  final LessonOutcome? outcome;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final o = outcome;
    return AccountScaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(o == null || o.percent >= 70 ? '🎉' : '💪', style: const TextStyle(fontSize: 80)),
              const SizedBox(height: 12),
              Text(s.t('lessonComplete'), style: context.text.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
              if (o != null) ...[
                const SizedBox(height: 8),
                Semantics(
                  label: s.f('starsOf', [o.stars]),
                  child: Text('⭐' * o.stars + '☆' * (3 - o.stars), style: const TextStyle(fontSize: 32)),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(child: StatTile(label: s.t('accuracy'), value: '${o.correct}/${o.total}', icon: Icons.track_changes)),
                    Expanded(child: StatTile(label: 'XP', value: s.f('xpEarned', [o.xp]), icon: Icons.bolt, color: AppTokens.xp)),
                    Expanded(child: StatTile(label: s.t('coins'), value: '+${o.coins}', icon: Icons.monetization_on, color: AppTokens.coin)),
                  ],
                ),
                const SizedBox(height: 8),
                if (o.wallet.streakDays > 0) Text('🔥 ${s.f('streak', [o.wallet.streakDays])}', style: context.text.titleMedium),
              ],
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: FilledButton(onPressed: () => context.go(Routes.learn), child: Text(s.t('nextLesson'))),
              ),
              TextButton(onPressed: () => context.go(Routes.home), child: Text(s.t('navHome'))),
            ],
          ),
        ),
      ),
    );
  }
}
