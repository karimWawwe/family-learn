import 'package:flutter/material.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_theme.dart';
import '../../domain/account.dart';
import '../../domain/models.dart';

/// Editable learner used by "Create family" and "Add learner".
class LearnerDraft {
  LearnerDraft({this.isChild = true, this.grade = 3, this.uiLocale = 'en', this.avatar = '🦁'});

  final name = TextEditingController();
  bool isChild;
  int grade;
  String uiLocale;
  String avatar;

  void dispose() => name.dispose();

  NewLearner toNewLearner() => NewLearner(
        displayName: name.text.trim(),
        kind: isChild ? ProfileKind.child : ProfileKind.adult,
        grade: isChild ? grade : null,
        uiLocale: uiLocale,
        avatarEmoji: avatar,
      );
}

const kidAvatars = ['🦁', '🐼', '🐯', '🦊', '🐸', '🐙', '🚀', '⚽', '🦖', '🐬'];
const adultAvatars = ['🙂', '🧑‍💼', '👩‍💼', '👨‍🏫', '👩‍🏫', '🧔', '👩'];

class SectionLabel extends StatelessWidget {
  const SectionLabel(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 16, 4, 8),
        child: Text(text, style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
      );
}

/// App language for one profile (menus and instructions; lessons stay English).
class LocalePicker extends StatelessWidget {
  const LocalePicker({super.key, required this.value, required this.onChanged});

  final String value;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Row(
        children: [
          Expanded(child: Text(context.s.t('language'))),
          SegmentedButton<String>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: 'en', label: Text('English')),
              ButtonSegment(value: 'ar', label: Text('العربية')),
            ],
            selected: {value},
            onSelectionChanged: (v) => onChanged(v.first),
          ),
        ],
      ),
    );
  }
}

class LearnerCard extends StatelessWidget {
  const LearnerCard({super.key, required this.draft, required this.onChanged, this.onRemove});

  final LearnerDraft draft;
  final VoidCallback onChanged;
  final VoidCallback? onRemove;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final d = draft;
    final avatars = d.isChild ? kidAvatars : adultAvatars;
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Text(d.avatar, style: const TextStyle(fontSize: 32)),
                const SizedBox(width: 8),
                Expanded(
                  child: TextFormField(
                    controller: d.name,
                    maxLength: 40,
                    decoration: InputDecoration(labelText: s.t('name'), counterText: ''),
                    validator: (v) => (v ?? '').trim().isEmpty ? s.t('err_required') : null,
                  ),
                ),
                if (onRemove != null)
                  IconButton(tooltip: s.t('remove'), onPressed: onRemove, icon: const Icon(Icons.close)),
              ],
            ),
            const SizedBox(height: 8),
            SegmentedButton<bool>(
              segments: [
                ButtonSegment(value: false, label: Text(s.t('adult'))),
                ButtonSegment(value: true, label: Text(s.t('child'))),
              ],
              selected: {d.isChild},
              onSelectionChanged: (v) {
                d.isChild = v.first;
                d.avatar = d.isChild ? kidAvatars.first : adultAvatars.first;
                onChanged();
              },
            ),
            if (d.isChild)
              Row(
                children: [
                  Text(s.t('grade')),
                  Expanded(
                    child: Slider(
                      value: d.grade.toDouble(),
                      min: 1,
                      max: 12,
                      divisions: 11,
                      label: '${d.grade}',
                      onChanged: (v) {
                        d.grade = v.round();
                        onChanged();
                      },
                    ),
                  ),
                  Text('${d.grade}'),
                ],
              ),
            LocalePicker(
              value: d.uiLocale,
              onChanged: (v) {
                d.uiLocale = v;
                onChanged();
              },
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 4,
              children: [
                for (final a in avatars)
                  ChoiceChip(
                    label: Text(a, style: const TextStyle(fontSize: 20)),
                    selected: d.avatar == a,
                    onSelected: (_) {
                      d.avatar = a;
                      onChanged();
                    },
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
