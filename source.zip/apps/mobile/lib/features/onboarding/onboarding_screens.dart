import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../domain/account.dart';
import '../../state/account.dart';
import '../../state/session.dart';
import 'learner_form.dart';

// Phase 3: real accounts. Parent = e-mail + password (confirmed with a
// 6-digit e-mail code). Child's phone = one-time link code from the parent.

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) =>
      const Scaffold(body: Center(child: CircularProgressIndicator()));
}

class StartupErrorScreen extends ConsumerWidget {
  const StartupErrorScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(Icons.wifi_off, size: 56),
              const SizedBox(height: 16),
              Text(s.t('err_network'), textAlign: TextAlign.center, style: context.text.titleMedium),
              const SizedBox(height: 24),
              FilledButton(onPressed: () => ref.invalidate(accountProvider), child: Text(s.t('tryAgain'))),
            ],
          ),
        ),
      ),
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AccountScaffold(
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Spacer(),
            const Text('👨‍👦‍👦📚', textAlign: TextAlign.center, style: TextStyle(fontSize: 72)),
            const SizedBox(height: 16),
            Text(s.t('appName'), textAlign: TextAlign.center, style: context.text.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Text(s.t('welcomeTitle'), textAlign: TextAlign.center, style: context.text.titleLarge),
            const SizedBox(height: 8),
            Text(s.t('welcomeBody'), textAlign: TextAlign.center, style: context.text.bodyLarge?.copyWith(color: context.colors.onSurfaceVariant)),
            const Spacer(),
            FilledButton(onPressed: () => context.push(Routes.signUp), child: Text(s.t('getStarted'))),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: () => context.push(Routes.signIn), child: Text(s.t('haveAccount'))),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () => context.push(Routes.childDeviceLink),
              icon: const Icon(Icons.child_care),
              label: Text(s.t('isChildPhone')),
            ),
            const SizedBox(height: 8),
            const _LanguageToggle(),
          ],
        ),
      ),
    );
  }
}

class _LanguageToggle extends ConsumerWidget {
  const _LanguageToggle();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isAr = context.s.isArabic;
    return TextButton(
      onPressed: () => ref.read(sessionProvider.notifier).setLocale(Locale(isAr ? 'en' : 'ar')),
      child: Text(isAr ? 'English' : 'العربية'),
    );
  }
}

bool _looksLikeEmail(String v) => RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v.trim());

class _EmailField extends StatelessWidget {
  const _EmailField({required this.controller});
  final TextEditingController controller;

  @override
  Widget build(BuildContext context) => TextFormField(
        controller: controller,
        keyboardType: TextInputType.emailAddress,
        autofillHints: const [AutofillHints.email],
        textDirection: TextDirection.ltr,
        autocorrect: false,
        decoration: InputDecoration(labelText: context.s.t('email'), prefixIcon: const Icon(Icons.mail_outline)),
        validator: (v) => _looksLikeEmail(v ?? '') ? null : context.s.t('err_invalid_email'),
      );
}

class _PasswordField extends StatefulWidget {
  const _PasswordField({required this.controller, this.labelKey = 'password', this.isNew = false, this.validator});
  final TextEditingController controller;
  final String labelKey;
  final bool isNew;
  final FormFieldValidator<String>? validator;

  @override
  State<_PasswordField> createState() => _PasswordFieldState();
}

class _PasswordFieldState extends State<_PasswordField> {
  bool _hidden = true;

  @override
  Widget build(BuildContext context) => TextFormField(
        controller: widget.controller,
        obscureText: _hidden,
        textDirection: TextDirection.ltr,
        autofillHints: [widget.isNew ? AutofillHints.newPassword : AutofillHints.password],
        decoration: InputDecoration(
          labelText: context.s.t(widget.labelKey),
          helperText: widget.isNew ? context.s.t('passwordRule') : null,
          prefixIcon: const Icon(Icons.lock_outline),
          suffixIcon: IconButton(
            tooltip: context.s.t(_hidden ? 'showPassword' : 'hidePassword'),
            icon: Icon(_hidden ? Icons.visibility_outlined : Icons.visibility_off_outlined),
            onPressed: () => setState(() => _hidden = !_hidden),
          ),
        ),
        validator: widget.validator ??
            (v) {
              final t = v ?? '';
              if (t.isEmpty) return context.s.t('err_required');
              if (widget.isNew && t.length < 8) return context.s.t('err_weak_password');
              return null;
            },
      );
}

class _CodeField extends StatelessWidget {
  const _CodeField({required this.controller, required this.labelKey, this.minLength = 6, this.maxLength = 8});
  final TextEditingController controller;
  final String labelKey;
  final int minLength;
  final int maxLength;

  @override
  Widget build(BuildContext context) => TextFormField(
        controller: controller,
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        textDirection: TextDirection.ltr,
        autofillHints: const [AutofillHints.oneTimeCode],
        inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(maxLength)],
        style: context.text.headlineSmall?.copyWith(letterSpacing: 8, fontWeight: FontWeight.w700),
        decoration: InputDecoration(labelText: context.s.t(labelKey)),
        validator: (v) => (v ?? '').length >= minLength ? null : context.s.t('err_invalid_code'),
      );
}

// ---------------------------------------------------------------- sign in

class SignInScreen extends ConsumerStatefulWidget {
  const SignInScreen({super.key});

  @override
  ConsumerState<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends ConsumerState<SignInScreen> with BusyForm<SignInScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    await guard(() async {
      try {
        ref.read(sessionProvider.notifier).reset();
        await ref.read(accountProvider.notifier).run((r) => r.signIn(email: _email.text, password: _password.text));
      } on AuthFailure catch (e) {
        if (e.code != 'email_not_confirmed') rethrow;
        // Account exists but the e-mail was never confirmed: send a new code.
        await ref.read(authRepositoryProvider).resendSignUpCode(email: _email.text);
        if (mounted) context.push(Routes.verifyEmailFor(_email.text.trim()));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AccountScaffold(
      title: s.t('signIn'),
      body: AutofillGroup(
        child: Form(
          key: _form,
          child: ListView(
            padding: const EdgeInsets.all(24),
            children: [
              _EmailField(controller: _email),
              const SizedBox(height: 12),
              _PasswordField(controller: _password),
              Align(
                alignment: AlignmentDirectional.centerEnd,
                child: TextButton(onPressed: () => context.push(Routes.forgotPassword), child: Text(s.t('forgotPassword'))),
              ),
              ErrorText(error),
              const SizedBox(height: 16),
              BusyButton(label: s.t('signIn'), busy: busy, onPressed: _submit),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- sign up

class SignUpScreen extends ConsumerStatefulWidget {
  const SignUpScreen({super.key});

  @override
  ConsumerState<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends ConsumerState<SignUpScreen> with BusyForm<SignUpScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    await guard(() async {
      await ref.read(accountProvider.notifier).run((r) => r.signUp(email: _email.text, password: _password.text));
      if (mounted) context.push(Routes.verifyEmailFor(_email.text.trim()));
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AccountScaffold(
      title: s.t('signUp'),
      body: AutofillGroup(
        child: Form(
          key: _form,
          child: ListView(
            padding: const EdgeInsets.all(24),
            children: [
              Text(s.t('signUpBody'), style: context.text.bodyLarge),
              const SizedBox(height: 16),
              _EmailField(controller: _email),
              const SizedBox(height: 12),
              _PasswordField(controller: _password, isNew: true),
              const SizedBox(height: 12),
              _PasswordField(
                controller: _confirm,
                labelKey: 'confirmPassword',
                validator: (v) => v == _password.text ? null : s.t('err_password_mismatch'),
              ),
              ErrorText(error),
              const SizedBox(height: 20),
              BusyButton(label: s.t('continue'), busy: busy, onPressed: _submit),
            ],
          ),
        ),
      ),
    );
  }
}

class VerifyEmailScreen extends ConsumerStatefulWidget {
  const VerifyEmailScreen({super.key, required this.email});

  final String email;

  @override
  ConsumerState<VerifyEmailScreen> createState() => _VerifyEmailScreenState();
}

class _VerifyEmailScreenState extends ConsumerState<VerifyEmailScreen> with BusyForm<VerifyEmailScreen> {
  final _form = GlobalKey<FormState>();
  final _code = TextEditingController();
  bool _resent = false;

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    await guard(() async {
      ref.read(sessionProvider.notifier).reset();
      await ref.read(accountProvider.notifier).run((r) => r.verifySignUpCode(email: widget.email, code: _code.text));
    });
  }

  Future<void> _resend() async {
    await guard(() async {
      await ref.read(authRepositoryProvider).resendSignUpCode(email: widget.email);
      if (mounted) setState(() => _resent = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final demo = ref.watch(authRepositoryProvider).isDemo;
    return AccountScaffold(
      title: s.t('verifyEmail'),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const Icon(Icons.mark_email_unread_outlined, size: 56),
            const SizedBox(height: 16),
            Text(s.t('verifyEmailBody'), style: context.text.bodyLarge),
            const SizedBox(height: 4),
            Text(widget.email, textDirection: TextDirection.ltr, style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
            if (demo) ...[
              const SizedBox(height: 8),
              Text(s.f('demoCodeHint', ['123456']), style: context.text.bodySmall),
            ],
            const SizedBox(height: 20),
            _CodeField(controller: _code, labelKey: 'emailCode'),
            ErrorText(error),
            const SizedBox(height: 20),
            BusyButton(label: s.t('verify'), busy: busy, onPressed: _submit),
            const SizedBox(height: 8),
            TextButton(onPressed: busy ? null : _resend, child: Text(s.t(_resent ? 'codeResent' : 'resendCode'))),
            Text(s.t('checkSpam'), textAlign: TextAlign.center, style: context.text.bodySmall),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- forgot password

class ForgotPasswordScreen extends ConsumerStatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  ConsumerState<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends ConsumerState<ForgotPasswordScreen> with BusyForm<ForgotPasswordScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _code = TextEditingController();
  final _password = TextEditingController();
  bool _sent = false;

  @override
  void dispose() {
    _email.dispose();
    _code.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    await guard(() async {
      if (!_sent) {
        await ref.read(authRepositoryProvider).sendPasswordReset(email: _email.text);
        if (mounted) setState(() => _sent = true);
        return;
      }
      ref.read(sessionProvider.notifier).reset();
      await ref.read(accountProvider.notifier).run(
            (r) => r.resetPassword(email: _email.text, code: _code.text, newPassword: _password.text),
          );
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AccountScaffold(
      title: s.t('resetPassword'),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            Text(s.t(_sent ? 'resetCodeSent' : 'resetBody'), style: context.text.bodyLarge),
            const SizedBox(height: 16),
            _EmailField(controller: _email),
            if (_sent) ...[
              const SizedBox(height: 12),
              _CodeField(controller: _code, labelKey: 'emailCode'),
              const SizedBox(height: 12),
              _PasswordField(controller: _password, labelKey: 'newPassword', isNew: true),
            ],
            ErrorText(error),
            const SizedBox(height: 20),
            BusyButton(label: s.t(_sent ? 'save' : 'sendCode'), busy: busy, onPressed: _submit),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- family setup

class ConsentScreen extends ConsumerStatefulWidget {
  const ConsentScreen({super.key});

  @override
  ConsumerState<ConsentScreen> createState() => _ConsentScreenState();
}

class _ConsentScreenState extends ConsumerState<ConsentScreen> {
  bool _agreed = false;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final email = ref.watch(accountProvider).valueOrNull?.email;
    return AccountScaffold(
      title: s.t('consentTitle'),
      actions: [
        TextButton(
          onPressed: () => ref.read(accountProvider.notifier).run((r) => r.signOut()),
          child: Text(s.t('signOut')),
        ),
      ],
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          if (email != null) Text(email, textDirection: TextDirection.ltr, style: context.text.bodySmall),
          const SizedBox(height: 8),
          const Icon(Icons.shield_outlined, size: 56),
          const SizedBox(height: 16),
          Text(s.t('consentBody'), style: context.text.bodyLarge),
          const SizedBox(height: 16),
          CheckboxListTile(
            value: _agreed,
            onChanged: (v) => setState(() => _agreed = v ?? false),
            title: Text(s.t('consentAgree')),
            controlAffinity: ListTileControlAffinity.leading,
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _agreed
                ? () {
                    ref.read(consentGivenProvider.notifier).state = true;
                    context.push(Routes.createFamily);
                  }
                : null,
            child: Text(s.t('continue')),
          ),
        ],
      ),
    );
  }
}

class CreateFamilyScreen extends ConsumerStatefulWidget {
  const CreateFamilyScreen({super.key});

  @override
  ConsumerState<CreateFamilyScreen> createState() => _CreateFamilyScreenState();
}

class _CreateFamilyScreenState extends ConsumerState<CreateFamilyScreen> with BusyForm<CreateFamilyScreen> {
  final _form = GlobalKey<FormState>();
  final _familyName = TextEditingController();
  final _parentName = TextEditingController();
  String _parentLocale = 'en';
  final _learners = <LearnerDraft>[LearnerDraft()];

  @override
  void initState() {
    super.initState();
    _parentLocale = ref.read(localeProvider).languageCode;
  }

  @override
  void dispose() {
    _familyName.dispose();
    _parentName.dispose();
    for (final d in _learners) {
      d.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    if (!ref.read(consentGivenProvider)) {
      context.go(Routes.consent);
      return;
    }
    if (!_form.currentState!.validate()) return;
    final family = NewFamily(
      familyName: _familyName.text,
      parentName: _parentName.text,
      parentLocale: _parentLocale,
      learners: [for (final d in _learners) d.toNewLearner()],
    );
    await guard(() async {
      ref.read(sessionProvider.notifier).reset();
      await ref.read(accountProvider.notifier).run((r) => r.createFamily(family));
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AccountScaffold(
      title: s.t('createFamily'),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _familyName,
              maxLength: 60,
              decoration: InputDecoration(labelText: s.t('familyName')),
              validator: (v) => (v ?? '').trim().isEmpty ? s.t('err_required') : null,
            ),
            SectionLabel(s.t('you')),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    TextFormField(
                      controller: _parentName,
                      maxLength: 40,
                      decoration: InputDecoration(labelText: s.t('yourName')),
                      validator: (v) => (v ?? '').trim().isEmpty ? s.t('err_required') : null,
                    ),
                    LocalePicker(value: _parentLocale, onChanged: (v) => setState(() => _parentLocale = v)),
                  ],
                ),
              ),
            ),
            SectionLabel(s.t('learners')),
            for (var i = 0; i < _learners.length; i++)
              LearnerCard(
                key: ObjectKey(_learners[i]),
                draft: _learners[i],
                onChanged: () => setState(() {}),
                onRemove: _learners.length == 1
                    ? null
                    : () {
                        final removed = _learners[i];
                        setState(() => _learners.removeAt(i));
                        // dispose after the card has left the screen
                        WidgetsBinding.instance.addPostFrameCallback((_) => removed.dispose());
                      },
              ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _learners.length >= 9 ? null : () => setState(() => _learners.add(LearnerDraft())),
              icon: const Icon(Icons.person_add_alt_1),
              label: Text(s.t('addLearner')),
            ),
            ErrorText(error),
            const SizedBox(height: 16),
            BusyButton(label: s.t('createFamily'), busy: busy, onPressed: _submit),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- child's phone

class ChildDeviceLinkScreen extends ConsumerStatefulWidget {
  const ChildDeviceLinkScreen({super.key});

  @override
  ConsumerState<ChildDeviceLinkScreen> createState() => _ChildDeviceLinkScreenState();
}

class _ChildDeviceLinkScreenState extends ConsumerState<ChildDeviceLinkScreen> with BusyForm<ChildDeviceLinkScreen> {
  final _form = GlobalKey<FormState>();
  final _code = TextEditingController();

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    await guard(() async {
      ref.read(sessionProvider.notifier).reset();
      await ref.read(accountProvider.notifier).run((r) => r.linkThisDevice(code: _code.text));
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AccountScaffold(
      title: s.t('isChildPhone'),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const Text('📱➡️👨‍👦', textAlign: TextAlign.center, style: TextStyle(fontSize: 56)),
            const SizedBox(height: 16),
            Text(s.t('childLinkBody'), style: context.text.bodyLarge),
            const SizedBox(height: 20),
            _CodeField(controller: _code, labelKey: 'linkCode', maxLength: 6),
            ErrorText(error),
            const SizedBox(height: 20),
            BusyButton(label: s.t('linkPhone'), busy: busy, onPressed: _submit),
          ],
        ),
      ),
    );
  }
}
