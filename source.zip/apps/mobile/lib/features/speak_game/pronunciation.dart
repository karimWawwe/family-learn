import 'dart:math' as math;

/// Flexible pronunciation checker for the speaking game.
///
/// Speech recognisers write down what they *think* a child said, and with
/// children's voices they often pick a sound-alike ("cat" -> "Kat", "cut",
/// "cats", "the cat"). So instead of a literal text match we:
///  1. normalise both texts (case, punctuation, digits -> words, contractions);
///  2. accept listed sound-alikes (two / to / too / 2);
///  3. score spelling similarity AND a simple "sound key" similarity
///     (consonant skeleton: ph=f, c=k/s, silent letters ...);
///  4. look for the target anywhere in what was heard ("cat cat", "a cat");
///  5. check every alternative the recogniser offers and keep the best.
/// A score in 0..1 is then turned into correct / close / wrong, and silence,
/// noise or a very unsure recogniser become "unclear" (never "wrong").

enum SpeakResult { correct, close, wrong, unclear }

class SpeechAlt {
  const SpeechAlt(this.text, [this.confidence = 0]);

  final String text;

  /// 0..1. Some browsers (Safari) always report 0 = unknown.
  final double confidence;
}

class PronunciationVerdict {
  const PronunciationVerdict(this.result, this.score, this.heard, {this.reason});

  final SpeakResult result;
  final double score;
  final String heard;

  /// For [SpeakResult.unclear]: 'silence' | 'noise' | 'unsure'.
  final String? reason;

  String get resultCode => result.name;
}

class PronunciationChecker {
  const PronunciationChecker();

  /// [strictness] = minimum score for "correct" (0.6 very lenient .. 0.95 strict).
  PronunciationVerdict check({
    required String target,
    List<String> accepted = const [],
    required List<SpeechAlt> alternatives,
    double strictness = 0.8,
  }) {
    final alts = alternatives.where((a) => normalize(a.text).isNotEmpty).toList();
    if (alts.isEmpty) {
      return const PronunciationVerdict(SpeakResult.unclear, 0, '', reason: 'silence');
    }
    final t = normalize(target);
    final extra = {
      ...accepted.map(normalize).where((e) => e.isNotEmpty),
      // words that SOUND the same (four/for, eight/ate, sea/see ...)
      ...soundAlikes(t),
    };

    var best = -1.0;
    var bestText = alts.first.text;
    var bestConf = 0.0;
    for (final a in alts) {
      final sc = scoreText(t, normalize(a.text), accepted: extra);
      if (sc > best) {
        best = sc;
        bestText = a.text.trim();
        bestConf = a.confidence;
      }
    }

    final closeAt = math.max(0.45, strictness - 0.3);
    if (best >= strictness) return PronunciationVerdict(SpeakResult.correct, best, bestText);

    final heardWords = _tokens(normalize(bestText)).length;
    final targetWords = math.max(1, _tokens(t).length);
    // Lots of words for a one-word target and nothing like it: background talk / TV.
    if (best < closeAt && heardWords >= targetWords + 5) {
      return PronunciationVerdict(SpeakResult.unclear, best, bestText, reason: 'noise');
    }
    // The recogniser itself is very unsure (only browsers that report confidence).
    if (best < closeAt && bestConf > 0 && bestConf < 0.2) {
      return PronunciationVerdict(SpeakResult.unclear, best, bestText, reason: 'unsure');
    }
    if (best >= closeAt) return PronunciationVerdict(SpeakResult.close, best, bestText);
    return PronunciationVerdict(SpeakResult.wrong, best, bestText);
  }

  /// Score 0..1 for how well [heard] matches [target] (both already normalised).
  double scoreText(String target, String heard, {Set<String> accepted = const {}}) {
    if (target.isEmpty || heard.isEmpty) return 0;
    final targets = {target, ...accepted};
    if (targets.contains(heard)) return 1;

    final tt = _tokens(target);
    final hh = _tokens(heard);
    var best = 0.0;
    final shortAnswer = hh.length <= tt.length + 2;
    for (final cand in targets) {
      // sound-alikes only count in a short answer (not somewhere in background talk)
      if (cand != target && !shortAnswer) continue;
      final ct = _tokens(cand);
      best = math.max(best, _phraseScore(ct, hh));
      if (best >= 1) return 1;
    }
    // A listed sound-alike heard inside a SHORT answer ("a cat" / "the four").
    // Not inside long sentences, so background talk can't hit it by chance.
    if (shortAnswer) {
      for (final a in accepted) {
        if (' $heard '.contains(' $a ')) return 1;
      }
    }
    return best.clamp(0.0, 1.0).toDouble() * (tt.isEmpty ? 0 : 1);
  }

  double _phraseScore(List<String> t, List<String> h) {
    if (t.isEmpty || h.isEmpty) return 0;
    final n = t.length;
    final joinedT = t.join();
    var windowBest = 0.0;
    // Windows of n-1 .. n+1 heard words, compared as one string
    // (also catches "sun flower" for "sunflower" and "icecream" for "ice cream").
    for (var len = math.max(1, n - 1); len <= n + 1; len++) {
      for (var i = 0; i + len <= h.length; i++) {
        final w = h.sublist(i, i + len);
        windowBest = math.max(windowBest, wordSimilarity(joinedT, w.join()));
        if (windowBest >= 1) return 1;
      }
    }
    if (h.length < math.max(1, n - 1)) {
      windowBest = math.max(windowBest, wordSimilarity(joinedT, h.join()) * (h.length / n));
    }
    // In a long answer (background talk), a fuzzy look-alike is less trustworthy
    // than the exact word: "...go for a walk..." should not pass for "four".
    if (h.length > n + 2 && windowBest < 1) windowBest *= 0.8;
    if (n == 1) return windowBest;

    // For phrases: share of target words heard, in order.
    var found = 0;
    var from = 0;
    for (final tw in t) {
      for (var j = from; j < h.length; j++) {
        if (wordSimilarity(tw, h[j]) >= 0.8) {
          found++;
          from = j + 1;
          break;
        }
      }
    }
    final coverage = found / n;
    return math.max(windowBest, (windowBest + coverage) / 2);
  }

  /// Similarity of two single words: spelling OR sound skeleton.
  double wordSimilarity(String a, String b) {
    if (a == b) return 1;
    if (a.isEmpty || b.isEmpty) return 0;
    final strSim = 1 - _lev(a, b) / math.max(a.length, b.length);
    final ka = soundKey(a);
    final kb = soundKey(b);
    double keySim;
    if (ka.isEmpty && kb.isEmpty) {
      keySim = 0;
    } else {
      keySim = 1 - _keyDistance(ka, kb) / math.max(ka.length, kb.length);
    }
    // Plural / -ing / -ed endings the recogniser adds or drops ("cats" for "cat").
    final stemSim = (_isInflection(a, b) || _isInflection(b, a)) ? 0.95 : 0.0;
    // Keys of 1 letter carry little information: trust them less.
    final keyWeight = math.min(ka.length, kb.length) <= 1 ? 0.8 : 0.92;
    return [strSim, keySim * keyWeight, stemSim].reduce(math.max);
  }

  /// [b] is [a] with a plain ending the recogniser added: kite -> kites,
  /// box -> boxes, jump -> jumped / jumping, bake -> baked. "cap" -> "capes" is
  /// NOT one (that's a different word), so magic-e pairs stay apart.
  static bool _isInflection(String a, String b) {
    if (a.length < 3 || b.length <= a.length) return false;
    if (b == '${a}s' || b == '${a}ed' || b == '${a}ing') return true;
    if (b == '${a}es' && RegExp(r'(s|x|z|ch|sh)$').hasMatch(a)) return true;
    if (b == '${a}d' && a.endsWith('e')) return true;
    return false;
  }

  /// Consonant skeleton of an English word ("phone" -> "fn", "knife" -> "nf").
  static String soundKey(String word) {
    var s = word.toLowerCase().replaceAll(RegExp('[^a-z]'), '');
    if (s.isEmpty) return '';
    final firstVowel = 'aeiou'.contains(s[0]);
    const starts = {'kn': 'n', 'wr': 'r', 'ps': 's', 'gn': 'n', 'wh': 'w', 'mb': 'm'};
    for (final e in starts.entries) {
      if (s.startsWith(e.key)) {
        s = e.value + s.substring(2);
        break;
      }
    }
    s = s
        .replaceAll(RegExp(r'mb$'), 'm')
        .replaceAll('tch', 'ch')
        .replaceAll('sch', 'sk')
        .replaceAll('ph', 'f')
        .replaceAll(RegExp(r'gh(?=[^aeiou]|$)'), '')
        .replaceAll('gh', 'g')
        .replaceAll('ck', 'k')
        .replaceAll('dg', 'j')
        .replaceAll('sh', 'X')
        .replaceAll('ch', 'C')
        .replaceAll('th', '0')
        .replaceAll(RegExp(r'c(?=[eiy])'), 's')
        .replaceAll('c', 'k')
        .replaceAll('q', 'k')
        .replaceAll('x', 'ks')
        .replaceAll('z', 's');
    // "y" after the first letter is a vowel sound ("happy", "my").
    if (s.length > 1) s = s[0] + s.substring(1).replaceAll('y', 'a');
    s = s.replaceAll(RegExp('[aeiou]'), '');
    // Collapse doubled letters ("ll" -> "l"). (No look-behind: old iOS Safari lacks it.)
    final out = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      if (i == 0 || s[i] != s[i - 1]) out.write(s[i]);
    }
    return (firstVowel ? 'A' : '') + out.toString();
  }

  static int _lev(String a, String b) {
    if (a == b) return 0;
    if (a.isEmpty) return b.length;
    if (b.isEmpty) return a.length;
    var prev = List<int>.generate(b.length + 1, (i) => i);
    var cur = List<int>.filled(b.length + 1, 0);
    for (var i = 1; i <= a.length; i++) {
      cur[0] = i;
      for (var j = 1; j <= b.length; j++) {
        final cost = a.codeUnitAt(i - 1) == b.codeUnitAt(j - 1) ? 0 : 1;
        cur[j] = math.min(math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
      }
      final tmp = prev;
      prev = cur;
      cur = tmp;
    }
    return prev[b.length];
  }

  static List<String> _tokens(String s) => s.split(' ').where((e) => e.isNotEmpty).toList();

  /// Edit distance between two sound keys where voiced/voiceless pairs
  /// (b-p, d-t, g-k, v-f) cost only half: recognisers often swap them for
  /// children's voices ("dog" -> "dock"), but a really different word still
  /// differs in more than that.
  static double _keyDistance(String a, String b) {
    if (a == b) return 0;
    const pairs = {'bp', 'pb', 'dt', 'td', 'gk', 'kg', 'vf', 'fv', 'jC', 'Cj'};
    var prev = List<double>.generate(b.length + 1, (i) => i.toDouble());
    var cur = List<double>.filled(b.length + 1, 0);
    for (var i = 1; i <= a.length; i++) {
      cur[0] = i.toDouble();
      for (var j = 1; j <= b.length; j++) {
        final x = a[i - 1];
        final y = b[j - 1];
        final cost = x == y ? 0.0 : (pairs.contains('$x$y') ? 0.5 : 1.0);
        cur[j] = math.min(math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
      }
      final tmp = prev;
      prev = cur;
      cur = tmp;
    }
    return prev[b.length];
  }

  /// English homophones and letter names, for one-word targets. Only words that
  /// sound the SAME, so different words are still told apart.
  static const Map<String, List<String>> _homophones = {
    'one': ['won'], 'two': ['to', 'too'], 'four': ['for', 'fore'], 'eight': ['ate'],
    'sea': ['see'], 'see': ['sea'], 'bee': ['be'], 'be': ['bee'], 'eye': ['i', 'aye'], 'i': ['eye'],
    'write': ['right', 'rite'], 'right': ['write'], 'read': ['reed', 'red'], 'red': ['read'],
    'hour': ['our'], 'our': ['hour'], 'sun': ['son'], 'son': ['sun'], 'blue': ['blew'], 'blew': ['blue'],
    'nose': ['knows'], 'flower': ['flour'], 'night': ['knight'], 'knight': ['night'], 'meet': ['meat'],
    'meat': ['meet'], 'tail': ['tale'], 'tale': ['tail'], 'week': ['weak'], 'weak': ['week'],
    'hear': ['here'], 'here': ['hear'], 'pear': ['pair', 'pare'], 'pair': ['pear'], 'sail': ['sale'],
    'sale': ['sail'], 'fur': ['fir'], 'bear': ['bare'], 'deer': ['dear'], 'dear': ['deer'], 'hole': ['whole'],
    'whole': ['hole'], 'no': ['know'], 'know': ['no'], 'new': ['knew'], 'knew': ['new'], 'plane': ['plain'],
    'plain': ['plane'], 'rain': ['reign', 'rein'], 'road': ['rode', 'rowed'], 'steel': ['steal'], 'steal': ['steel'],
    'tea': ['tee'], 'way': ['weigh'], 'wait': ['weight'], 'weight': ['wait'], 'mail': ['male'], 'male': ['mail'],
    'ant': ['aunt'], 'aunt': ['ant'], 'knot': ['not'], 'not': ['knot'], 'by': ['buy', 'bye'], 'buy': ['by', 'bye'],
    'flu': ['flew'], 'board': ['bored'], 'bored': ['board'], 'sum': ['some'], 'some': ['sum'], 'won': ['one'],
    'cell': ['sell'], 'sell': ['cell'], 'scent': ['sent', 'cent'], 'border': ['boarder'], 'mayor': ['mare'],
    'graph': ['graf'],
    // letter names, as recognisers write them
    'a': ['hey', 'eh', 'ay'], 'b': ['be', 'bee'], 'c': ['see', 'sea'], 'd': ['dee'], 'e': ['ee'],
    'f': ['ef', 'eff'], 'g': ['gee', 'jee'], 'h': ['aitch', 'age'], 'j': ['jay'], 'k': ['kay', 'okay'],
    'l': ['el', 'elle'], 'm': ['em'], 'n': ['en', 'and'], 'o': ['oh', 'owe'], 'p': ['pee', 'pea'],
    'q': ['queue', 'cue'], 'r': ['are', 'ar'], 's': ['es', 'ess'], 't': ['tee', 'tea'], 'u': ['you', 'yu'],
    'v': ['vee'], 'w': ['double u'], 'x': ['ex'], 'y': ['why', 'wye'], 'z': ['zee', 'zed'],
  };

  /// Sound-alikes of a (normalised) one-word target.
  static Set<String> soundAlikes(String normalizedTarget) {
    if (normalizedTarget.contains(' ')) return const {};
    return {...?_homophones[normalizedTarget]};
  }

  static const _fillers = {'um', 'umm', 'uh', 'uhh', 'er', 'erm', 'hmm', 'mm', 'ah'};

  /// Lower case, no punctuation, digits written as words, single spaces.
  static String normalize(String input) {
    var s = input.toLowerCase().replaceAll(RegExp('[’‘`\']'), '');
    // Arabic: drop tashkeel and tatweel, unify letter shapes (أ إ آ -> ا, ة -> ه, ى -> ي)
    s = s
        .replaceAll(RegExp('[\u064B-\u0652\u0670\u0640]'), '')
        .replaceAll(RegExp('[\u0623\u0625\u0622]'), '\u0627')
        .replaceAll('\u0629', '\u0647')
        .replaceAll('\u0649', '\u064A');
    s = s.replaceAll('&', ' and ');
    // "10,000" -> "10000" (twice for "1,000,000")
    for (var i = 0; i < 2; i++) {
      s = s.replaceAllMapped(RegExp(r'(\d),(\d)'), (m) => '${m[1]}${m[2]}');
    }
    s = s.replaceAll(RegExp('[^a-z0-9 \u0621-\u064A]'), ' ');
    final parts = <String>[];
    for (final tok in s.split(RegExp(r'\s+'))) {
      if (tok.isEmpty) continue;
      final m = RegExp(r'^(\d+)(st|nd|rd|th)?$').firstMatch(tok);
      if (m != null) {
        final n = int.parse(m.group(1)!);
        final words = numberToWords(n);
        if (words != null) {
          parts.add(m.group(2) == null ? words : _ordinal(words));
          continue;
        }
      }
      if (_fillers.contains(tok)) continue;
      parts.add(tok);
    }
    return parts.join(' ');
  }

  static const _ones = [
    'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', //
    'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen',
  ];
  static const _tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

  static String? numberToWords(int n) {
    if (n < 0 || n > 999999) return null;
    if (n < 20) return _ones[n];
    if (n < 100) return n % 10 == 0 ? _tens[n ~/ 10] : '${_tens[n ~/ 10]} ${_ones[n % 10]}';
    if (n < 1000) {
      final rest = n % 100;
      return '${_ones[n ~/ 100]} hundred${rest == 0 ? '' : ' ${numberToWords(rest)}'}';
    }
    final rest = n % 1000;
    return '${numberToWords(n ~/ 1000)} thousand${rest == 0 ? '' : ' ${numberToWords(rest)}'}';
  }

  static String _ordinal(String words) {
    const special = {
      'one': 'first', 'two': 'second', 'three': 'third', 'five': 'fifth', //
      'eight': 'eighth', 'nine': 'ninth', 'twelve': 'twelfth',
    };
    final parts = words.split(' ');
    final last = parts.removeLast();
    final ord = special[last] ?? (last.endsWith('y') ? '${last.substring(0, last.length - 1)}ieth' : '${last}th');
    return [...parts, ord].join(' ');
  }
}
