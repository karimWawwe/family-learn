import 'dart:math' as math;

import 'package:flutter/widgets.dart';

import '../../core/l10n/app_strings.dart';

/// Texts of the speaking game (English + Arabic, follows the profile's UI language).
class SpeakStrings {
  SpeakStrings(this.ar);

  final bool ar;
  static final _rnd = math.Random();

  String _pick(List<String> l) => l[_rnd.nextInt(l.length)];

  /// Arabic or English.
  String t(String arText, String enText) => ar ? arText : enText;

  String get title => ar ? 'ألعاب النطق' : 'Speaking games';
  String get subtitle => ar ? 'اقرأ الكلمة بصوتك واجمع النجوم' : 'Read the word out loud and collect stars';
  String get sayIt => ar ? 'قلها!' : 'Say it!';
  String get tapToSpeak => ar ? 'اضغط على الميكروفون وقل الكلمة' : 'Tap the mic and say the word';
  String get tapToSpeakPhrase => ar ? 'اضغط على الميكروفون وقل الجملة' : 'Tap the mic and say the sentence';
  String get listening => ar ? 'أسمعك الآن… تكلّم' : 'Listening… speak now';
  String get checking => ar ? 'لحظة…' : 'Checking…';
  String get listen => ar ? 'استمع' : 'Listen';
  String get slow => ar ? 'ببطء' : 'Slowly';
  String get iHeard => ar ? 'سمعت:' : 'I heard:';
  String get skip => ar ? 'أرجع لها لاحقاً' : 'Try it later';
  String get meaning => ar ? 'المعنى' : 'Meaning';
  String get points => ar ? 'نقطة' : 'points';
  String get pointsShort => ar ? 'نقاط' : 'Points';
  String get stars => ar ? 'نجوم' : 'Stars';
  String get words => ar ? 'كلمات أتقنتها' : 'Words said';
  String get streak => ar ? 'أيام متتالية' : 'Day streak';
  String get levels => ar ? 'المستويات' : 'Levels';
  String get stickers => ar ? 'ملصقاتي' : 'My stickers';
  String get badges => ar ? 'الأوسمة' : 'Badges';
  String get noStickers => ar ? 'أنهِ مستوى لتحصل على أول ملصق!' : 'Finish a level to get your first sticker!';
  String get locked => ar ? 'أنهِ المستوى السابق أولاً' : 'Finish the level before first';
  String get play => ar ? 'العب' : 'Play';
  String get playAgain => ar ? 'العب مرة ثانية' : 'Play again';
  String get nextLevel => ar ? 'المستوى التالي' : 'Next level';
  String get backToLevels => ar ? 'المستويات' : 'Levels';
  String get levelDone => ar ? 'أنهيت المستوى!' : 'Level complete!';
  String get newSticker => ar ? 'ملصق جديد!' : 'New sticker!';
  String get saving => ar ? 'جاري حفظ النتيجة…' : 'Saving your result…';
  String get saveFailed => ar ? 'ما قدرنا نحفظ النتيجة. تأكد من الإنترنت.' : "Couldn't save your result. Check the internet.";
  String get retry => ar ? 'حاول مرة أخرى' : 'Try again';
  String get firstTry => ar ? 'من أول محاولة' : 'first try';
  String get wordOf => ar ? 'كلمة {0} من {1}' : 'Word {0} of {1}';
  String get fromBook => ar ? 'من الكتاب:' : 'From the book:';
  String get today => ar ? 'اليوم' : 'Today';
  String get notInstalled => ar
      ? 'اللعبة تحتاج تحديث قاعدة البيانات (ملف SQL الخاص بألعاب النطق). اطلب من الوالد تثبيته.'
      : 'The game needs the speaking-game database update (SQL file). Ask a parent to install it.';
  String get loadFailed => ar ? 'ما قدرنا نفتح اللعبة. تأكد من الإنترنت وحاول مرة أخرى.' : "Couldn't open the game. Check the internet and try again.";
  String get noLevels => ar ? 'لا توجد مستويات لهذا الحساب بعد.' : 'No levels for this profile yet.';

  // mic / browser problems
  String get notSupportedTitle => ar ? 'الميكروفون غير متاح هنا' : 'Speech is not available here';
  String get notSupportedBody => ar
      ? 'افتح التطبيق من Safari على الآيفون أو Chrome على أندرويد/الكمبيوتر. على الآيفون: الإعدادات ← Siri ← فعّل Siri، والإعدادات ← عام ← لوحة المفاتيح ← فعّل الإملاء (Dictation).'
      : 'Open the app in Safari on iPhone or Chrome on Android / computer. On iPhone also turn on Siri (Settings > Siri) and Dictation (Settings > General > Keyboard).';
  String get micBlocked => ar
      ? 'الميكروفون مقفل. اسمح للتطبيق باستخدام الميكروفون (على الآيفون: الإعدادات ← Safari ← الميكروفون ← سماح) ثم حاول مرة ثانية.'
      : 'The microphone is blocked. Allow microphone access for this app (iPhone: Settings > Safari > Microphone > Allow), then try again.';
  String get siriOff => ar
      ? 'التعرّف على الكلام مقفل. على الآيفون فعّل Siri والإملاء (Dictation) من الإعدادات ثم حاول مرة ثانية.'
      : 'Speech recognition is turned off. On iPhone turn on Siri and Dictation in Settings, then try again.';
  String get micMissing => ar ? 'ما لقينا ميكروفون يشتغل. تأكد منه وحاول مرة ثانية.' : "We couldn't find a working microphone. Check it and try again.";
  String get networkIssue => ar ? 'التعرّف على الصوت يحتاج إنترنت. تأكد من الاتصال وحاول مرة ثانية.' : 'Speech recognition needs the internet. Check the connection and try again.';

  // feedback
  String success() => _pick(ar
      ? ['أحسنت! 🎉', 'ممتاز! ⭐', 'رائع جداً!', 'برافو عليك! 👏', 'نطق مثالي! 🌟', 'أنت بطل! 🏆']
      : ['Great job! 🎉', 'Excellent! ⭐', 'Super! 👏', 'You did it! 🌟', 'Perfect! 🏆', 'Amazing! 🎊']);

  String firstTrySuccess() => _pick(ar
      ? ['من أول مرة! رائع! 🌟', 'ممتاز، من أول محاولة! ⭐⭐⭐']
      : ['First try! Wow! 🌟', 'Perfect, first try! ⭐⭐⭐']);

  String close() => _pick(ar
      ? ['ممتاز، اقتربت! حاول مرة أخرى 💪', 'قريب جداً! مرة ثانية 😊', 'تقريباً! جرّب مرة أخرى']
      : ['So close! Try again 💪', 'Almost there! One more time 😊', 'Nearly! Try again']);

  String wrong(int tries) => tries >= 3
      ? (ar ? 'استمع للكلمة جيداً وحاول مرة ثانية 👂' : 'Listen to the word and try again 👂')
      : _pick(ar
          ? ['حاول مرة أخرى، أنت تقدر! 💪', 'لا بأس، جرّب مرة ثانية 😊', 'استمع للكلمة وحاول مرة ثانية 👂']
          : ['Try again, you can do it! 💪', "That's OK, try once more 😊", 'Listen to the word and try again 👂']);

  String unclear(String? reason) => switch (reason) {
        'noise' => ar ? 'في أصوات حولك 🔊 جرّب مرة ثانية في مكان هادئ' : "It's a bit noisy 🔊 Try again somewhere quiet",
        'unsure' => ar ? 'ما سمعتك بوضوح. قرّب الجوال وتكلّم بوضوح 🙂' : "I didn't hear that clearly. Hold the phone closer 🙂",
        'network' => networkIssue,
        'mic' => micMissing,
        _ => ar ? 'ما سمعتك 🙉 تكلّم بصوت أعلى قليلاً' : "I couldn't hear you 🙉 Speak a little louder",
      };

  String combo(int n) => ar ? '🔥 $n مرات متتالية!' : '🔥 $n in a row!';

  String stars3() => ar ? 'ثلاث نجوم! أداء خرافي!' : 'Three stars! Fantastic!';
  String stars2() => ar ? 'نجمتان! عمل رائع!' : 'Two stars! Great work!';
  String stars1() => ar ? 'أحسنت! العب مرة ثانية لتجمع نجوم أكثر' : 'Well done! Play again for more stars';

  String hello(String name) => ar ? 'هيا يا $name! 🎤' : "Let's go, $name! 🎤";
}

extension SpeakStringsX on BuildContext {
  SpeakStrings get ss => SpeakStrings(AppStrings.of(this).isArabic);
}
