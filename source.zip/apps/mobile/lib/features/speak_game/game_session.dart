import 'dart:math' as math;

import '../../domain/speak_game.dart';
import 'pronunciation.dart';

/// Feedback for one try on the current word.
class TryFeedback {
  const TryFeedback({
    required this.result,
    required this.verdict,
    this.pointsGained = 0,
    this.wordStars = 0,
    this.triesOnWord = 0,
    this.combo = 0,
  });

  final SpeakResult result;
  final PronunciationVerdict verdict;
  final int pointsGained;

  /// 3 = first try, 2 = second, 1 = later.
  final int wordStars;

  /// Counted tries on this word so far (unclear ones are not counted).
  final int triesOnWord;
  final int combo;
}

/// Rules of one level run. Pure Dart so it is unit-tested.
///  * a word stays until it is said correctly (no moving on after a miss);
///  * unclear audio (silence / noise) is NOT counted as a try;
///  * after [skipAfter] tries the child may put the word aside: it comes back
///    at the end of the level, so every word is still said correctly once;
///  * points: 10 per word, +5 on the first try, +2 per first-try streak (max +10);
///    level bonus +20 (+10 more for 3 stars).
class SpeakSession {
  SpeakSession(this.level, {this.skipAfter = 5}) : _queue = List<int>.generate(level.words.length, (i) => i);

  final SpeakLevel level;
  final int skipAfter;
  final List<int> _queue;
  final Map<int, int> _tries = {};
  final Set<int> _done = {};

  int _triesOnCurrentVisit = 0;
  int points = 0;
  int combo = 0;
  int firstTry = 0;
  int totalTries = 0;
  int unclearCount = 0;

  List<SpeakWord> get words => level.words;
  int get total => words.length;
  int get doneCount => _done.length;
  bool get finished => _queue.isEmpty;
  double get progress => total == 0 ? 1 : doneCount / total;

  SpeakWord? get current => finished ? null : words[_queue.first];
  int get currentIndex => finished ? -1 : _queue.first;

  /// Counted tries on the current word (across visits).
  int get triesOnCurrent => finished ? 0 : (_tries[_queue.first] ?? 0);
  bool get canSkip => !finished && _triesOnCurrentVisit >= skipAfter && _queue.length > 1;

  TryFeedback register(PronunciationVerdict v) {
    if (finished) throw StateError('level finished');
    final i = _queue.first;
    if (v.result == SpeakResult.unclear) {
      unclearCount++;
      return TryFeedback(result: v.result, verdict: v, triesOnWord: _tries[i] ?? 0, combo: combo);
    }
    final n = (_tries[i] ?? 0) + 1;
    _tries[i] = n;
    _triesOnCurrentVisit++;
    totalTries++;
    if (v.result != SpeakResult.correct) {
      combo = 0;
      return TryFeedback(result: v.result, verdict: v, triesOnWord: n, combo: combo);
    }
    var gained = 10;
    if (n == 1) {
      gained += 5 + math.min(combo * 2, 10);
      combo++;
      firstTry++;
    } else {
      combo = 0;
    }
    points += gained;
    _done.add(i);
    return TryFeedback(
      result: v.result,
      verdict: v,
      pointsGained: gained,
      wordStars: n == 1 ? 3 : (n == 2 ? 2 : 1),
      triesOnWord: n,
      combo: combo,
    );
  }

  /// After a correct answer: go to the next word.
  void advance() {
    if (finished) return;
    if (_done.contains(_queue.first)) {
      _queue.removeAt(0);
      _triesOnCurrentVisit = 0;
    }
  }

  /// Put the current word aside; it comes back at the end.
  void skip() {
    if (!canSkip) return;
    _queue.add(_queue.removeAt(0));
    _triesOnCurrentVisit = 0;
    combo = 0;
  }

  int get levelStars {
    if (total == 0) return 1;
    final r = firstTry / total;
    return r >= 0.8 ? 3 : (r >= 0.5 ? 2 : 1);
  }

  int get levelBonus => 20 + (levelStars == 3 ? 10 : 0);

  SpeakPlayResult result() => SpeakPlayResult(
        levelId: level.id,
        points: points + levelBonus,
        stars: levelStars,
        words: total,
        firstTry: firstTry,
        attempts: totalTries,
      );
}
