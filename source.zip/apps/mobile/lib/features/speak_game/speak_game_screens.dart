import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/router/app_router.dart';
import '../../core/speech/speech_engine.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../domain/account.dart';
import '../../domain/speak_game.dart';
import '../../state/session.dart';
import '../../state/speak_game.dart';
import 'game_session.dart';
import 'pronunciation.dart';
import 'speak_strings.dart';

const _kGold = Color(0xFFFFC233);
const _kPurple = Color(0xFF7C4DFF);
const _kSky = Color(0xFF3A86FF);
const _kMint = Color(0xFF2EC4B6);
const _kCoral = Color(0xFFFF6B6B);

String _levelTitle(BuildContext c, SpeakLevel l) =>
    c.ss.ar && l.titleAr.isNotEmpty ? l.titleAr : l.title;

// ============================================================================
//  Game home: totals, level path, stickers and badges
// ============================================================================
class SpeakGameHomeScreen extends ConsumerWidget {
  const SpeakGameHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ss = context.ss;
    final p = ref.watch(currentProfileProvider);
    final async = ref.watch(speakGameProvider);
    final engine = ref.watch(speechEngineProvider);
    if (p == null) return const SizedBox.shrink();

    return Scaffold(
      appBar: AppBar(title: Text('🎤 ${ss.title}'), centerTitle: true),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => _ErrorView(
          message: e is AuthFailure && e.code == 'speak_not_installed' ? ss.notInstalled : ss.loadFailed,
          onRetry: () => ref.invalidate(speakGameProvider),
        ),
        data: (st) => RefreshIndicator(
          onRefresh: () async {
            try {
              await ref.refresh(speakGameProvider.future);
            } catch (_) {}
          },
          child: ListView(
            padding: const EdgeInsets.only(bottom: 32),
            children: [
              _StatsHeader(state: st, name: p.displayName, avatar: p.avatarEmoji),
              if (!engine.recognitionSupported)
                _NoticeCard(emoji: '🎙️', title: ss.notSupportedTitle, body: ss.notSupportedBody),
              if (st.levels.isNotEmpty) _GoalCard(state: st),
              SectionTitle(
                ss.t('المراحل', 'Stages'),
                trailing: Text(ss.t('🔓 مفتوحة  ·  🔒 مغلقة', '🔓 open  ·  🔒 locked'), style: context.text.bodySmall),
              ),
              if (st.levels.isEmpty) EmptyState(emoji: '📚', message: ss.noLevels),
              for (var i = 0; i < st.levels.length; i++)
                _LevelNode(
                  state: st,
                  level: st.levels[i],
                  index: i,
                  isNext: identical(st.nextLevel, st.levels[i]),
                ),
              SectionTitle(ss.stickers),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: st.stickers.isEmpty
                    ? Text(ss.noStickers, style: context.text.bodyMedium)
                    : Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: [
                          for (final s in st.stickers)
                            Container(
                              width: 56,
                              height: 56,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: context.colors.surface,
                                shape: BoxShape.circle,
                                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 6, offset: const Offset(0, 3))],
                              ),
                              child: Text(s, style: const TextStyle(fontSize: 30)),
                            ),
                        ],
                      ),
              ),
              SectionTitle(ss.badges),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final b in st.badges)
                      Opacity(
                        opacity: b.earned ? 1 : 0.35,
                        child: Chip(
                          avatar: Text(b.earned ? b.emoji : '🔒'),
                          label: Text(ss.ar ? b.nameAr : b.name),
                          backgroundColor: b.earned ? const Color(0xFFFFF4D6) : null,
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatsHeader extends StatelessWidget {
  const _StatsHeader({required this.state, required this.name, required this.avatar});

  final SpeakGameState state;
  final String name;
  final String avatar;

  @override
  Widget build(BuildContext context) {
    final ss = context.ss;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(colors: [_kPurple, _kSky], begin: Alignment.topLeft, end: Alignment.bottomRight),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(radius: 26, backgroundColor: Colors.white, child: Text(avatar, style: const TextStyle(fontSize: 28))),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(ss.hello(name), style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                    Text(ss.subtitle, style: TextStyle(color: Colors.white.withValues(alpha: 0.9))),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(child: _HeaderStat(icon: '⭐', value: '${state.stars}', label: ss.t('نجومي', 'Stars'))),
              Expanded(child: _HeaderStat(icon: '🏆', value: '${state.points}', label: ss.t('نقاطي', 'Points'))),
              Expanded(child: _HeaderStat(icon: '🔓', value: '${state.unlockedCount}', label: ss.t('مفتوحة', 'Open'))),
              Expanded(child: _HeaderStat(icon: '🔒', value: '${state.lockedCount}', label: ss.t('مغلقة', 'Locked'))),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            ss.t('🗣️ ${state.wordsMastered} كلمة نطقتَها صح   ·   🔥 ${state.dayStreak} أيام متتالية',
                '🗣️ ${state.wordsMastered} words said right   ·   🔥 ${state.dayStreak} day streak'),
            style: TextStyle(color: Colors.white.withValues(alpha: 0.95), fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}

class _HeaderStat extends StatelessWidget {
  const _HeaderStat({required this.icon, required this.value, required this.label});

  final String icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(16)),
        child: Column(
          children: [
            Text(icon, style: const TextStyle(fontSize: 20)),
            Text(value, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
            Text(label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: Colors.white.withValues(alpha: 0.9), fontSize: 11)),
          ],
        ),
      );
}

class _LevelNode extends StatelessWidget {
  const _LevelNode({required this.state, required this.level, required this.index, required this.isNext});

  final SpeakGameState state;
  final SpeakLevel level;
  final int index;
  final bool isNext;

  @override
  Widget build(BuildContext context) {
    final ss = context.ss;
    const offsets = [0.0, 0.45, 0.0, -0.45];
    final locked = !level.unlocked;
    final done = level.completed;
    final colors = locked
        ? [Colors.grey.shade400, Colors.grey.shade500]
        : done
            ? [_kGold, const Color(0xFFFF9F1C)]
            : [_kMint, _kSky];
    final caption = TextStyle(fontSize: 12, color: Colors.blueGrey.shade700, fontWeight: FontWeight.w600);
    return Align(
      alignment: Alignment(offsets[index % offsets.length], 0),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: InkWell(
          borderRadius: BorderRadius.circular(60),
          onTap: () => showStageSheet(context, state, level),
          child: SizedBox(
            width: 160,
            child: Column(
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    _Bouncy(
                      active: isNext && !locked,
                      child: Container(
                        width: 86,
                        height: 86,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(colors: colors, begin: Alignment.topLeft, end: Alignment.bottomRight),
                          border: Border.all(color: Colors.white, width: 4),
                          boxShadow: [BoxShadow(color: colors.last.withValues(alpha: 0.45), blurRadius: 10, offset: const Offset(0, 5))],
                        ),
                        child: Text(locked ? '🔒' : level.emoji, style: const TextStyle(fontSize: 38)),
                      ),
                    ),
                    Positioned(
                      top: -4,
                      right: -4,
                      child: CircleAvatar(
                        radius: 14,
                        backgroundColor: locked ? Colors.grey.shade600 : _kPurple,
                        child: Text('${index + 1}', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w900)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  _levelTitle(context, level),
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: context.text.titleSmall?.copyWith(fontWeight: FontWeight.w800),
                ),
                if (locked)
                  Text(ss.t('🔒 تحتاج ${level.requiredStars} ⭐', '🔒 needs ${level.requiredStars} ⭐'), style: caption)
                else ...[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      for (var s = 1; s <= 3; s++)
                        Icon(Icons.star_rounded, size: 20, color: s <= level.bestStars ? _kGold : Colors.grey.shade300),
                    ],
                  ),
                  if (done)
                    Text(ss.t('🏆 ${level.bestPoints}  ·  🔁 ${level.plays}', '🏆 ${level.bestPoints}  ·  🔁 ${level.plays}'), style: caption)
                  else
                    Text(ss.t('🔓 جديدة! العبها', '🔓 New! Play it'), style: caption),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// The next goal: which stage opens next and how many stars are still needed.
class _GoalCard extends StatelessWidget {
  const _GoalCard({required this.state});

  final SpeakGameState state;

  @override
  Widget build(BuildContext context) {
    final ss = context.ss;
    final next = state.nextLocked;
    final Widget body;
    if (next == null) {
      body = Text(ss.t('🎉 فتحتَ كل المراحل! أعد أي مرحلة لتجمع ثلاث نجوم في كل واحدة.',
          '🎉 All stages are open! Replay any stage to get three stars everywhere.'),
          style: const TextStyle(fontWeight: FontWeight.w700));
    } else {
      final idx = state.levels.indexOf(next);
      final prev = idx > 0 ? state.levels[idx - 1] : null;
      final needPrev = prev != null && !prev.completed;
      final missing = (next.requiredStars - state.stars).clamp(0, 999).toInt();
      final progress = next.requiredStars == 0 ? 1.0 : (state.stars / next.requiredStars).clamp(0.0, 1.0).toDouble();
      body = Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(ss.t('🎯 المرحلة التالية: ${idx + 1}. ${_levelTitle(context, next)}', '🎯 Next stage: ${idx + 1}. ${_levelTitle(context, next)}'),
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(value: progress, minHeight: 12, color: _kGold, backgroundColor: const Color(0xFFFFF1CC)),
          ),
          const SizedBox(height: 6),
          Text(ss.t('⭐ ${state.stars} من ${next.requiredStars} نجمة', '⭐ ${state.stars} of ${next.requiredStars} stars')),
          const SizedBox(height: 6),
          if (needPrev)
            Text(ss.t('أنهِ المرحلة ${idx} أولًا لتفتحها.', 'Finish stage $idx first to open it.'))
          else if (missing > 0) ...[
            Text(ss.t('باقي $missing ${missing == 1 ? 'نجمة' : 'نجوم'} فقط! أعد مرحلة سابقة وحسّن نتيجتك 💪',
                'Only $missing more stars! Replay an earlier stage to improve your result 💪')),
            if (state.improvable.isNotEmpty) ...[
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final l in state.improvable.take(4))
                    ActionChip(
                      avatar: Text(l.emoji),
                      label: Text('${_levelTitle(context, l)} ${'⭐' * l.bestStars}'),
                      onPressed: () => context.push(Routes.speakPlay(l.id)),
                    ),
                ],
              ),
            ],
          ],
        ],
      );
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Card(
        color: const Color(0xFFFFFBEF),
        child: Padding(padding: const EdgeInsets.all(16), child: body),
      ),
    );
  }
}

/// Details of a stage: play / replay, best result, or what is needed to open it.
Future<void> showStageSheet(BuildContext context, SpeakGameState state, SpeakLevel level) {
  final ss = context.ss;
  final idx = state.levels.indexOf(level);
  final prev = idx > 0 ? state.levels[idx - 1] : null;
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (sheet) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('${level.unlocked ? level.emoji : '🔒'}  ${ss.t('المرحلة', 'Stage')} ${idx + 1}',
                textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            Text(_levelTitle(context, level), textAlign: TextAlign.center, style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 12),
            if (!level.unlocked) ...[
              Text(ss.t('هذه المرحلة مغلقة الآن. لفتحها:', 'This stage is locked. To open it:'),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              if (prev != null)
                Text('${prev.completed ? '✅' : '⬜'} ${ss.t('أنهِ المرحلة $idx: ${_levelTitle(context, prev)}', 'Finish stage $idx: ${_levelTitle(context, prev)}')}'),
              Text('${state.stars >= level.requiredStars ? '✅' : '⬜'} ${ss.t('اجمع ${level.requiredStars} نجمة (معك ${state.stars})', 'Collect ${level.requiredStars} stars (you have ${state.stars})')}'),
              const SizedBox(height: 12),
              if (state.improvable.isNotEmpty) ...[
                Text(ss.t('💡 أعد إحدى هذه المراحل لتجمع نجومًا أكثر:', '💡 Replay one of these to win more stars:')),
                const SizedBox(height: 6),
                for (final l in state.improvable.take(4))
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Text(l.emoji, style: const TextStyle(fontSize: 26)),
                    title: Text(_levelTitle(context, l)),
                    subtitle: Text('${'⭐' * l.bestStars}${'☆' * (3 - l.bestStars)}'),
                    trailing: const Icon(Icons.replay_rounded),
                    onTap: () {
                      Navigator.pop(sheet);
                      context.push(Routes.speakPlay(l.id));
                    },
                  ),
              ] else
                Text(ss.t('العب المراحل المفتوحة لتجمع النجوم ⭐', 'Play the open stages to collect stars ⭐')),
            ] else ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (var s = 1; s <= 3; s++)
                    Icon(Icons.star_rounded, size: 40, color: s <= level.bestStars ? _kGold : Colors.grey.shade300),
                ],
              ),
              const SizedBox(height: 6),
              if (level.completed) ...[
                Text(ss.t('أفضل نتيجة: ${level.bestStars} ⭐ · ${level.bestPoints} نقطة', 'Best result: ${level.bestStars} ⭐ · ${level.bestPoints} points'),
                    textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
                Text(ss.t('لعبتها ${level.plays} ${level.plays == 1 ? 'مرة' : 'مرات'}', 'Played ${level.plays} time(s)'), textAlign: TextAlign.center),
                const SizedBox(height: 4),
                Text(
                  level.bestStars < 3
                      ? ss.t('تقدر تحصل على ${'⭐' * (3 - level.bestStars)} أكثر! نحفظ لك أفضل نتيجة دائمًا.',
                          'You can win ${'⭐' * (3 - level.bestStars)} more! We always keep your best result.')
                      : ss.t('ممتاز! ثلاث نجوم 🌟 العبها مرة ثانية للمتعة وللتدريب.', 'Excellent, three stars 🌟 Play again for fun and practice.'),
                  textAlign: TextAlign.center,
                ),
              ] else
                Text(ss.t('${level.words.length} كلمات · مرحلة جديدة!', '${level.words.length} words · a new stage!'), textAlign: TextAlign.center),
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: () {
                  Navigator.pop(sheet);
                  context.push(Routes.speakPlay(level.id));
                },
                icon: Icon(level.completed ? Icons.replay_rounded : Icons.play_arrow_rounded),
                label: Text(level.completed ? ss.t('العب مرة أخرى وحسّن نتيجتك', 'Play again and improve') : ss.t('ابدأ المرحلة', 'Start the stage')),
              ),
            ],
          ],
        ),
      ),
    ),
  );
}

/// Gently bounces its child (the next level to play).
class _Bouncy extends StatefulWidget {
  const _Bouncy({required this.child, required this.active});

  final Widget child;
  final bool active;

  @override
  State<_Bouncy> createState() => _BouncyState();
}

class _BouncyState extends State<_Bouncy> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    if (widget.active) _c.repeat(reverse: true);
  }

  @override
  void didUpdateWidget(_Bouncy old) {
    super.didUpdateWidget(old);
    if (widget.active && !_c.isAnimating) {
      _c.repeat(reverse: true);
    } else if (!widget.active && _c.isAnimating) {
      _c
        ..stop()
        ..reset();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.active) return widget.child;
    return AnimatedBuilder(
      animation: _c,
      builder: (_, child) => Transform.translate(offset: Offset(0, -6 * Curves.easeInOut.transform(_c.value)), child: child),
      child: widget.child,
    );
  }
}

class _NoticeCard extends StatelessWidget {
  const _NoticeCard({required this.emoji, required this.title, required this.body});

  final String emoji;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: Card(
          color: const Color(0xFFFFF4E0),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(emoji, style: const TextStyle(fontSize: 28)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF7A4B00))),
                      const SizedBox(height: 4),
                      Text(body, style: const TextStyle(color: Color(0xFF5A3A00))),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('🙈', style: TextStyle(fontSize: 56)),
              const SizedBox(height: 12),
              Text(message, textAlign: TextAlign.center, style: context.text.titleMedium),
              const SizedBox(height: 16),
              FilledButton(onPressed: onRetry, child: Text(context.ss.retry)),
            ],
          ),
        ),
      );
}

// ============================================================================
//  Play screen: one level, word by word
// ============================================================================
enum _Phase { ready, listening, success, finishing, done }

class SpeakPlayScreen extends ConsumerStatefulWidget {
  const SpeakPlayScreen({super.key, required this.levelId});

  final String levelId;

  @override
  ConsumerState<SpeakPlayScreen> createState() => _SpeakPlayScreenState();
}

class _SpeakPlayScreenState extends ConsumerState<SpeakPlayScreen> with TickerProviderStateMixin {
  static const _checker = PronunciationChecker();

  SpeakSession? _session;
  SpeakGameState? _before;
  SpeakGameState? _after;
  SpeakPlayResult? _result;
  bool _saveFailed = false;
  bool _notInstalled = false;

  _Phase _phase = _Phase.ready;
  String _heard = '';
  String? _message;
  SpeakResult? _tone;
  String? _blocking; // mic / browser problem that needs the parent
  bool _speaking = false;
  bool _showHint = false;

  StreamSubscription<SpeechEvent>? _sub;
  Timer? _softStop;
  Timer? _hardStop;
  Timer? _advance;
  Timer? _autoModel;

  late final AnimationController _pulse;
  late final AnimationController _confetti;
  late final AnimationController _shake;
  late final AnimationController _pop;
  late final SpeechEngine _engine;

  @override
  void initState() {
    super.initState();
    _engine = ref.read(speechEngineProvider);
    _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _confetti = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800));
    _shake = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    _pop = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
  }

  @override
  void dispose() {
    _softStop?.cancel();
    _hardStop?.cancel();
    _advance?.cancel();
    _autoModel?.cancel();
    _sub?.cancel();
    try {
      _engine.cancel();
      _engine.stopSpeaking();
    } catch (_) {}
    _pulse.dispose();
    _confetti.dispose();
    _shake.dispose();
    _pop.dispose();
    super.dispose();
  }

  // ---------------------------------------------------------------- audio model
  Future<void> _say({bool slow = false}) async {
    final w = _session?.current;
    if (w == null || _phase == _Phase.listening) return;
    _engine.unlockAudio();
    setState(() => _speaking = true);
    await _engine.speak(w.text, rate: slow ? 0.5 : 0.85);
    if (mounted) setState(() => _speaking = false);
  }

  // ---------------------------------------------------------------- microphone
  Future<void> _toggleMic() async {
    final session = _session;
    final word = session?.current;
    if (session == null || word == null) return;
    if (_phase == _Phase.listening) {
      _engine.stop();
      return;
    }
    if (_phase != _Phase.ready) return;

    _engine.unlockAudio();
    _engine.stopSpeaking();
    _autoModel?.cancel();
    setState(() {
      _phase = _Phase.listening;
      _speaking = false;
      _heard = '';
      _message = null;
      _tone = null;
      _blocking = null;
    });
    _pulse.repeat(reverse: true);

    var alts = <SpeechAlt>[];
    String? error;
    var early = false;
    final done = Completer<void>();
    final level = session.level;

    _sub = _engine.listen().listen(
      (e) {
        switch (e.type) {
          case SpeechEventType.partial:
          case SpeechEventType.finalResult:
            if (e.alternatives.isNotEmpty) alts = e.alternatives;
            if (mounted && alts.isNotEmpty) setState(() => _heard = alts.first.text);
            // Already right while still talking: stop now for quick feedback.
            if (!early && e.type == SpeechEventType.partial) {
              final v = _checker.check(
                  target: word.text, accepted: word.accepted, alternatives: alts, strictness: level.strictness);
              if (v.result == SpeakResult.correct) {
                early = true;
                _engine.stop();
              }
            }
          case SpeechEventType.error:
            error ??= e.error;
          case SpeechEventType.ended:
            if (!done.isCompleted) done.complete();
          case SpeechEventType.started:
          case SpeechEventType.sound:
            break;
        }
      },
      onDone: () {
        if (!done.isCompleted) done.complete();
      },
    );
    _softStop = Timer(Duration(seconds: word.isPhrase ? 10 : 7), _engine.stop);
    _hardStop = Timer(Duration(seconds: word.isPhrase ? 13 : 10), () {
      _engine.cancel();
      if (!done.isCompleted) done.complete();
    });

    await done.future;
    _softStop?.cancel();
    _hardStop?.cancel();
    await _sub?.cancel();
    _sub = null;
    if (!mounted) return;
    _pulse
      ..stop()
      ..reset();
    _evaluate(alts, error);
  }

  void _evaluate(List<SpeechAlt> alts, String? error) {
    final ss = context.ss;
    final session = _session!;
    final word = session.current!;

    if (alts.isEmpty) {
      switch (error) {
        case 'not-allowed':
          setState(() {
            _phase = _Phase.ready;
            _blocking = ss.micBlocked;
          });
          return;
        case 'service-not-allowed':
          setState(() {
            _phase = _Phase.ready;
            _blocking = ss.siriOff;
          });
          return;
        case 'not-supported' || 'language-not-supported':
          setState(() {
            _phase = _Phase.ready;
            _blocking = ss.notSupportedBody;
          });
          return;
        case 'aborted':
          setState(() => _phase = _Phase.ready);
          return;
      }
    }

    var verdict = _checker.check(
      target: word.text,
      accepted: word.accepted,
      alternatives: alts,
      strictness: session.level.strictness,
    );
    if (alts.isEmpty) {
      final reason = switch (error) {
        'network' => 'network',
        'audio-capture' => 'mic',
        _ => 'silence',
      };
      verdict = PronunciationVerdict(SpeakResult.unclear, 0, '', reason: reason);
    }

    final fb = session.register(verdict);
    unawaited(_logTry(word, verdict, fb.triesOnWord));

    switch (fb.result) {
      case SpeakResult.correct:
        _engine.playSfx(Sfx.success);
        if (fb.wordStars == 3) {
          Timer(const Duration(milliseconds: 420), () {
            if (mounted) _engine.playSfx(Sfx.star);
          });
        }
        _confetti.forward(from: 0);
        _pop.forward(from: 0);
        setState(() {
          _phase = _Phase.success;
          _tone = SpeakResult.correct;
          _showHint = false;
          _message = fb.triesOnWord == 1 ? ss.firstTrySuccess() : ss.success();
          if (fb.combo >= 3) _message = '${_message!}  ${ss.combo(fb.combo)}';
        });
        _advance = Timer(const Duration(milliseconds: 2000), _next);
      case SpeakResult.close:
      case SpeakResult.wrong:
        _engine.playSfx(Sfx.tryAgain);
        _shake.forward(from: 0);
        setState(() {
          _phase = _Phase.ready;
          _tone = fb.result;
          _showHint = fb.triesOnWord >= 2;
          _message = fb.result == SpeakResult.close ? ss.close() : ss.wrong(fb.triesOnWord);
        });
        // After a few misses, play the model slowly so the child can copy it.
        if (fb.triesOnWord >= 3 && fb.triesOnWord.isOdd) {
          _autoModel = Timer(const Duration(milliseconds: 900), () {
            if (mounted && _phase == _Phase.ready) _say(slow: true);
          });
        }
      case SpeakResult.unclear:
        setState(() {
          _phase = _Phase.ready;
          _tone = SpeakResult.unclear;
          _message = ss.unclear(verdict.reason);
        });
    }
  }

  Future<void> _logTry(SpeakWord word, PronunciationVerdict v, int tryNo) async {
    final p = ref.read(currentProfileProvider);
    final session = _session;
    if (p == null || session == null) return;
    try {
      await ref.read(speakGameRepositoryProvider).recordTry(
            profile: p,
            levelId: session.level.id,
            word: word.text,
            heard: v.heard,
            score: v.score,
            result: v.resultCode,
            tryNo: math.max(1, tryNo),
          );
    } on AuthFailure catch (e) {
      if (e.code == 'speak_not_installed' && mounted) setState(() => _notInstalled = true);
    } catch (_) {
      // a lost log line is not worth interrupting the child
    }
  }

  void _next() {
    final session = _session;
    if (session == null || !mounted) return;
    session.advance();
    if (session.finished) {
      _finish();
      return;
    }
    setState(() {
      _phase = _Phase.ready;
      _heard = '';
      _message = null;
      _tone = null;
      _showHint = false;
    });
  }

  void _skip() {
    final session = _session;
    if (session == null || !session.canSkip) return;
    _autoModel?.cancel();
    setState(() {
      session.skip();
      _heard = '';
      _message = null;
      _tone = null;
      _showHint = false;
    });
  }

  Future<void> _finish() async {
    final session = _session!;
    final p = ref.read(currentProfileProvider);
    final r = _result ?? session.result();
    setState(() {
      _result = r;
      _phase = _Phase.finishing;
      _saveFailed = false;
    });
    _engine.playSfx(Sfx.levelUp);
    _confetti.forward(from: 0);
    if (p == null) {
      setState(() {
        _saveFailed = true;
        _phase = _Phase.done;
      });
      return;
    }
    try {
      final after = await ref.read(speakGameRepositoryProvider).finishLevel(p, r);
      if (!mounted) return;
      ref.invalidate(speakGameProvider);
      setState(() {
        _after = after;
        _phase = _Phase.done;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _saveFailed = true;
        _notInstalled = e is AuthFailure && e.code == 'speak_not_installed';
        _phase = _Phase.done;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final ss = context.ss;
    if (_session == null) {
      final async = ref.watch(speakGameProvider);
      final st = async.valueOrNull;
      if (st == null) {
        return Scaffold(
          appBar: AppBar(),
          body: async.hasError
              ? _ErrorView(
                  message: async.error is AuthFailure && (async.error! as AuthFailure).code == 'speak_not_installed'
                      ? ss.notInstalled
                      : ss.loadFailed,
                  onRetry: () => ref.invalidate(speakGameProvider),
                )
              : const Center(child: CircularProgressIndicator()),
        );
      }
      final level = st.levelById(widget.levelId);
      if (level == null || !level.unlocked || level.words.isEmpty) {
        return Scaffold(appBar: AppBar(), body: EmptyState(emoji: '🔒', message: ss.locked));
      }
      _before = st;
      _session = SpeakSession(level);
    }
    final session = _session!;

    return Scaffold(
      backgroundColor: const Color(0xFFF3F6FF),
      body: Stack(
        children: [
          SafeArea(
            child: _phase == _Phase.finishing || _phase == _Phase.done ? _buildDone(context) : _buildPlay(context, session),
          ),
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _confetti,
                builder: (_, __) => _confetti.isAnimating
                    ? CustomPaint(painter: _ConfettiPainter(_confetti.value))
                    : const SizedBox.shrink(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlay(BuildContext context, SpeakSession session) {
    final ss = context.ss;
    final word = session.current!;
    final listening = _phase == _Phase.listening;
    return Column(
      children: [
        // top bar: close, progress, points
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 16, 4),
          child: Row(
            children: [
              IconButton(icon: const Icon(Icons.close_rounded, size: 30), onPressed: () => context.pop()),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: TweenAnimationBuilder<double>(
                    tween: Tween(end: session.progress),
                    duration: const Duration(milliseconds: 500),
                    builder: (_, v, __) => LinearProgressIndicator(
                      value: v,
                      minHeight: 16,
                      color: _kMint,
                      backgroundColor: const Color(0xFFDDE5F5),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              _PointsChip(points: session.points),
            ],
          ),
        ),
        if (_notInstalled) _NoticeCard(emoji: '🛠️', title: ss.title, body: ss.notInstalled),
        if (_blocking != null) _NoticeCard(emoji: '🎙️', title: ss.notSupportedTitle, body: _blocking!),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: Column(
              children: [
                Text(ss.wordOf.replaceAll('{0}', '${session.doneCount + 1}').replaceAll('{1}', '${session.total}'),
                    style: context.text.bodyMedium?.copyWith(color: Colors.blueGrey)),
                const SizedBox(height: 8),
                _MascotBubble(
                  text: _message ?? (word.isPhrase ? ss.tapToSpeakPhrase : ss.tapToSpeak),
                  tone: _tone,
                ),
                const SizedBox(height: 14),
                AnimatedBuilder(
                  animation: Listenable.merge([_shake, _pop]),
                  builder: (_, child) {
                    final dx = math.sin(_shake.value * math.pi * 6) * 10 * (1 - _shake.value);
                    final scale = 1 + 0.08 * math.sin(_pop.value * math.pi);
                    return Transform.translate(offset: Offset(dx, 0), child: Transform.scale(scale: scale, child: child));
                  },
                  child: _WordCard(
                    word: word,
                    success: _phase == _Phase.success,
                    showHint: _showHint,
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _RoundAction(
                      icon: Icons.volume_up_rounded,
                      label: ss.listen,
                      color: _kSky,
                      busy: _speaking,
                      onTap: listening ? null : () => _say(),
                    ),
                    const SizedBox(width: 18),
                    _RoundAction(
                      emoji: '🐢',
                      label: ss.slow,
                      color: _kMint,
                      onTap: listening ? null : () => _say(slow: true),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        // heard text + mic
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
          child: AnimatedOpacity(
            opacity: _heard.isEmpty ? 0 : 1,
            duration: const Duration(milliseconds: 200),
            child: Directionality(
              textDirection: TextDirection.ltr,
              child: Text('🎧 ${ss.iHeard} "$_heard"',
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: context.text.bodyLarge?.copyWith(color: Colors.blueGrey.shade700)),
            ),
          ),
        ),
        _MicButton(
          listening: listening,
          disabled: _phase == _Phase.success,
          pulse: _pulse,
          onTap: _toggleMic,
        ),
        const SizedBox(height: 8),
        Text(
          listening ? ss.listening : (_phase == _Phase.success ? '' : ss.sayIt),
          style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w800, color: listening ? _kCoral : _kPurple),
        ),
        SizedBox(
          height: 48,
          child: session.canSkip && _phase == _Phase.ready
              ? TextButton.icon(onPressed: _skip, icon: const Icon(Icons.redo_rounded), label: Text(ss.skip))
              : null,
        ),
      ],
    );
  }

  Widget _buildDone(BuildContext context) {
    final ss = context.ss;
    final r = _result!;
    final session = _session!;
    final saving = _phase == _Phase.finishing;
    final base = _after ?? _before!;
    final idx = base.levels.indexWhere((l) => l.id == session.level.id);
    final next = idx >= 0 && idx + 1 < base.levels.length ? base.levels[idx + 1] : null;
    final firstTime = (_before?.levelById(session.level.id)?.bestStars ?? 0) == 0;
    final newBadges = _after == null
        ? const <SpeakBadge>[]
        : [
            for (final b in _after!.badges)
              if (b.earned && !(_before!.badges.firstWhere((x) => x.code == b.code).earned)) b,
          ];
    final starMsg = r.stars == 3 ? ss.stars3() : (r.stars == 2 ? ss.stars2() : ss.stars1());
    // Best-result bookkeeping (the server keeps the best of every stage).
    final prevBest = _before?.levelById(session.level.id);
    final improvedStars = !firstTime && prevBest != null && r.stars > prevBest.bestStars;
    final improvedPoints = !firstTime && prevBest != null && r.points > prevBest.bestPoints;
    final after = _after;
    final newlyOpen = after == null
        ? const <SpeakLevel>[]
        : [
            for (final l in after.levels)
              if (l.unlocked && !(_before?.levelById(l.id)?.unlocked ?? false)) l,
          ];
    final starsGained = after == null || _before == null ? 0 : after.stars - _before!.stars;
    final nextLocked = after?.nextLocked;
    final missing = nextLocked == null || after == null ? 0 : (nextLocked.requiredStars - after.stars).clamp(0, 999).toInt();

    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0.3, end: 1),
              duration: const Duration(milliseconds: 700),
              curve: Curves.elasticOut,
              builder: (_, v, child) => Transform.scale(scale: v, child: child),
              child: const Text('🏆', style: TextStyle(fontSize: 96)),
            ),
            Text(ss.levelDone, style: context.text.headlineSmall?.copyWith(fontWeight: FontWeight.w900, color: _kPurple)),
            const SizedBox(height: 6),
            Text(_levelTitle(context, session.level), style: context.text.titleMedium),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var s = 1; s <= 3; s++)
                  TweenAnimationBuilder<double>(
                    tween: Tween(begin: 0, end: 1),
                    duration: Duration(milliseconds: 400 + 300 * s),
                    curve: Curves.elasticOut,
                    builder: (_, v, child) => Transform.scale(scale: v, child: child),
                    child: Icon(Icons.star_rounded, size: s == 2 ? 72 : 58, color: s <= r.stars ? _kGold : Colors.grey.shade300),
                  ),
              ],
            ),
            Text(starMsg, textAlign: TextAlign.center, style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _ResultPill(icon: '🏆', text: '+${r.points} ${ss.points}'),
                const SizedBox(width: 8),
                _ResultPill(icon: '🎯', text: '${r.firstTry}/${r.words} ${ss.firstTry}'),
              ],
            ),
            if (after != null) ...[
              const SizedBox(height: 12),
              if (improvedStars || improvedPoints)
                Text(ss.t('🎉 نتيجة جديدة أفضل! حفظناها لك', '🎉 New best result! Saved for you'),
                    style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w900, color: AppTokens.good))
              else if (!firstTime && prevBest != null)
                Text(
                  ss.t('أفضل نتيجة لك هنا: ${prevBest.bestStars} ⭐ · ${prevBest.bestPoints} نقطة. حاول مرة ثانية لتتفوّق عليها 💪',
                      'Your best here: ${prevBest.bestStars} ⭐ · ${prevBest.bestPoints} points. Try again to beat it 💪'),
                  textAlign: TextAlign.center,
                ),
              const SizedBox(height: 6),
              Text(
                ss.t('⭐ مجموع نجومك: ${after.stars}${starsGained > 0 ? ' (+$starsGained)' : ''}   ·   🏆 نقاطك: ${after.points}',
                    '⭐ Your stars: ${after.stars}${starsGained > 0 ? ' (+$starsGained)' : ''}   ·   🏆 Points: ${after.points}'),
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ],
            if (newlyOpen.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(ss.t('🔓 مراحل جديدة انفتحت لك!', '🔓 New stages are open!'),
                  style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w900, color: _kPurple)),
              const SizedBox(height: 4),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                alignment: WrapAlignment.center,
                children: [for (final l in newlyOpen) Chip(avatar: Text(l.emoji), label: Text(_levelTitle(context, l)))],
              ),
            ] else if (after != null && nextLocked != null && missing > 0 && !(next?.unlocked ?? false)) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: const Color(0xFFFFF4D6), borderRadius: BorderRadius.circular(16)),
                child: Text(
                  ss.t('باقي $missing ${missing == 1 ? 'نجمة' : 'نجوم'} لتفتح «${_levelTitle(context, nextLocked)}». أعد هذه المرحلة أو مرحلة سابقة وحسّن نتيجتك، أنت قريب! 💪',
                      '$missing more stars to open "${_levelTitle(context, nextLocked)}". Replay this or an earlier stage - you are close! 💪'),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
            if (firstTime && !_saveFailed) ...[
              const SizedBox(height: 16),
              Text(ss.newSticker, style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
              Text(session.level.emoji, style: const TextStyle(fontSize: 56)),
            ],
            if (newBadges.isNotEmpty) ...[
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [
                  for (final b in newBadges) Chip(avatar: Text(b.emoji), label: Text(ss.ar ? b.nameAr : b.name)),
                ],
              ),
            ],
            const SizedBox(height: 20),
            if (saving) ...[
              const CircularProgressIndicator(),
              const SizedBox(height: 8),
              Text(ss.saving),
            ] else if (_saveFailed) ...[
              Text(_notInstalled ? ss.notInstalled : ss.saveFailed,
                  textAlign: TextAlign.center, style: const TextStyle(color: AppTokens.bad)),
              const SizedBox(height: 8),
              FilledButton.icon(onPressed: _finish, icon: const Icon(Icons.refresh), label: Text(ss.retry)),
            ] else ...[
              if (next != null && next.unlocked)
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: () => context.pushReplacement(Routes.speakPlay(next.id)),
                    icon: Text(next.emoji, style: const TextStyle(fontSize: 22)),
                    label: Text('${ss.nextLevel}: ${_levelTitle(context, next)}', overflow: TextOverflow.ellipsis),
                  ),
                ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => context.pushReplacement(Routes.speakPlay(session.level.id)),
                  icon: const Icon(Icons.replay_rounded),
                  label: Text(r.stars < 3 ? ss.t('العب مرة ثانية واجمع نجومًا أكثر', 'Play again for more stars') : ss.playAgain),
                ),
              ),
            ],
            const SizedBox(height: 10),
            TextButton.icon(
              onPressed: () => context.pop(),
              icon: const Icon(Icons.map_outlined),
              label: Text(ss.t('خريطة المراحل', 'Stage map')),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- play widgets
class _PointsChip extends StatelessWidget {
  const _PointsChip({required this.points});

  final int points;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(color: const Color(0xFFFFF4D6), borderRadius: BorderRadius.circular(20)),
        child: TweenAnimationBuilder<double>(
          tween: Tween(end: points.toDouble()),
          duration: const Duration(milliseconds: 600),
          builder: (_, v, __) => Text('⭐ ${v.round()}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
        ),
      );
}

class _MascotBubble extends StatelessWidget {
  const _MascotBubble({required this.text, required this.tone});

  final String text;
  final SpeakResult? tone;

  @override
  Widget build(BuildContext context) {
    final (mascot, bg, fg) = switch (tone) {
      SpeakResult.correct => ('🦉', const Color(0xFFD9F7E6), const Color(0xFF12613A)),
      SpeakResult.close => ('🦉', const Color(0xFFFFF1D6), const Color(0xFF7A4B00)),
      SpeakResult.wrong => ('🦉', const Color(0xFFFFE8E0), const Color(0xFF8A2F12)),
      SpeakResult.unclear => ('🦉', const Color(0xFFE3EEFF), const Color(0xFF1B3F7A)),
      null => ('🦉', Colors.white, const Color(0xFF2B2D42)),
    };
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(mascot, style: const TextStyle(fontSize: 46)),
        const SizedBox(width: 8),
        Expanded(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
            child: Container(
              key: ValueKey(text),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: bg,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                  bottomLeft: Radius.circular(4),
                ),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 6, offset: const Offset(0, 2))],
              ),
              child: Text(text, style: TextStyle(color: fg, fontSize: 17, fontWeight: FontWeight.w700)),
            ),
          ),
        ),
      ],
    );
  }
}

class _WordCard extends StatelessWidget {
  const _WordCard({required this.word, required this.success, required this.showHint});

  final SpeakWord word;
  final bool success;
  final bool showHint;

  @override
  Widget build(BuildContext context) {
    final size = word.isPhrase ? 38.0 : (word.text.length <= 6 ? 66.0 : 52.0);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      decoration: BoxDecoration(
        color: success ? const Color(0xFFE6FAF0) : Colors.white,
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: success ? AppTokens.good : const Color(0xFFE2E8F5), width: 3),
        boxShadow: [BoxShadow(color: _kSky.withValues(alpha: 0.12), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: Column(
        children: [
          if (word.emoji.isNotEmpty) Text(word.emoji, style: const TextStyle(fontSize: 72)),
          const SizedBox(height: 6),
          Directionality(
            textDirection: TextDirection.ltr,
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                word.text,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: size,
                  fontWeight: FontWeight.w900,
                  letterSpacing: word.isPhrase ? 0.5 : 2,
                  color: success ? AppTokens.good : const Color(0xFF2B2D42),
                ),
              ),
            ),
          ),
          if (word.meaningAr.isNotEmpty) ...[
            const SizedBox(height: 6),
            Directionality(
              textDirection: TextDirection.rtl,
              child: Text(word.meaningAr, style: TextStyle(fontSize: 20, color: Colors.blueGrey.shade600, fontWeight: FontWeight.w600)),
            ),
          ],
          if (showHint && word.hint.isNotEmpty) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(color: const Color(0xFFFFF4D6), borderRadius: BorderRadius.circular(14)),
              child: Directionality(
                textDirection: TextDirection.ltr,
                child: Text('💡 ${word.hint}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, letterSpacing: 1)),
              ),
            ),
          ],
          if (success)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: const Text('✅', style: TextStyle(fontSize: 30)),
            ),
        ],
      ),
    );
  }
}

class _RoundAction extends StatelessWidget {
  const _RoundAction({this.icon, this.emoji, required this.label, required this.color, this.onTap, this.busy = false});

  final IconData? icon;
  final String? emoji;
  final String label;
  final Color color;
  final VoidCallback? onTap;
  final bool busy;

  @override
  Widget build(BuildContext context) => Opacity(
        opacity: onTap == null ? 0.4 : 1,
        child: InkWell(
          borderRadius: BorderRadius.circular(40),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(4),
            child: Column(
              children: [
                Container(
                  width: 62,
                  height: 62,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: busy ? 1 : 0.15),
                    shape: BoxShape.circle,
                  ),
                  child: emoji != null
                      ? Text(emoji!, style: const TextStyle(fontSize: 30))
                      : Icon(icon, size: 32, color: busy ? Colors.white : color),
                ),
                const SizedBox(height: 4),
                Text(label, style: TextStyle(fontWeight: FontWeight.w700, color: color)),
              ],
            ),
          ),
        ),
      );
}

class _MicButton extends StatelessWidget {
  const _MicButton({required this.listening, required this.disabled, required this.pulse, required this.onTap});

  final bool listening;
  final bool disabled;
  final Animation<double> pulse;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = listening ? _kCoral : _kPurple;
    return Semantics(
      button: true,
      label: 'microphone',
      child: GestureDetector(
        onTap: disabled ? null : onTap,
        child: SizedBox(
          width: 150,
          height: 150,
          child: AnimatedBuilder(
            animation: pulse,
            builder: (_, __) {
              final v = listening ? pulse.value : 0.0;
              return Stack(
                alignment: Alignment.center,
                children: [
                  if (listening) ...[
                    Container(
                      width: 108 + 40 * v,
                      height: 108 + 40 * v,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: color.withValues(alpha: 0.15 * (1 - v) + 0.05)),
                    ),
                    Container(
                      width: 108 + 20 * v,
                      height: 108 + 20 * v,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: color.withValues(alpha: 0.2)),
                    ),
                  ],
                  Opacity(
                    opacity: disabled ? 0.5 : 1,
                    child: Container(
                      width: 104,
                      height: 104,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: listening ? [_kCoral, const Color(0xFFFF8E53)] : [_kPurple, _kSky],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [BoxShadow(color: color.withValues(alpha: 0.45), blurRadius: 16, offset: const Offset(0, 6))],
                      ),
                      child: Icon(listening ? Icons.stop_rounded : Icons.mic_rounded, size: 54, color: Colors.white),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _ResultPill extends StatelessWidget {
  const _ResultPill({required this.icon, required this.text});

  final String icon;
  final String text;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
        child: Text('$icon $text', style: const TextStyle(fontWeight: FontWeight.w800)),
      );
}

/// Light-weight confetti: coloured bits and stars falling from the top.
class _ConfettiPainter extends CustomPainter {
  _ConfettiPainter(this.t);

  final double t;
  static final List<_Bit> _bits = List.generate(70, (i) => _Bit(math.Random(i * 7919 + 13)));

  @override
  void paint(Canvas canvas, Size size) {
    final fade = t < 0.75 ? 1.0 : (1 - (t - 0.75) / 0.25);
    for (final b in _bits) {
      final x = size.width * b.x + math.sin((t * 6 + b.phase) * math.pi) * 18 * b.sway;
      final y = -30 + (size.height * 0.9) * (t * b.speed) + 200 * t * t;
      if (y > size.height + 20) continue;
      final paint = Paint()..color = b.color.withValues(alpha: fade.clamp(0.0, 1.0).toDouble());
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(t * 8 * b.spin);
      if (b.shape == 0) {
        canvas.drawRect(Rect.fromCenter(center: Offset.zero, width: b.size, height: b.size * 0.55), paint);
      } else if (b.shape == 1) {
        canvas.drawCircle(Offset.zero, b.size * 0.4, paint);
      } else {
        canvas.drawPath(_star(b.size * 0.6), paint);
      }
      canvas.restore();
    }
  }

  static Path _star(double r) {
    final p = Path();
    for (var i = 0; i < 10; i++) {
      final rr = i.isEven ? r : r * 0.45;
      final a = -math.pi / 2 + i * math.pi / 5;
      final o = Offset(math.cos(a) * rr, math.sin(a) * rr);
      if (i == 0) {
        p.moveTo(o.dx, o.dy);
      } else {
        p.lineTo(o.dx, o.dy);
      }
    }
    return p..close();
  }

  @override
  bool shouldRepaint(_ConfettiPainter old) => old.t != t;
}

class _Bit {
  _Bit(math.Random r)
      : x = r.nextDouble(),
        speed = 0.6 + r.nextDouble() * 0.7,
        phase = r.nextDouble() * 2,
        sway = r.nextDouble(),
        spin = r.nextDouble() * 2 - 1,
        size = 8 + r.nextDouble() * 10,
        shape = r.nextInt(3),
        color = const [_kGold, _kPurple, _kSky, _kMint, _kCoral, Color(0xFFFF9F1C)][r.nextInt(6)];

  final double x;
  final double speed;
  final double phase;
  final double sway;
  final double spin;
  final double size;
  final int shape;
  final Color color;
}

// ============================================================================
//  Parent report card
// ============================================================================
class SpeakReportCard extends ConsumerWidget {
  const SpeakReportCard({super.key, required this.profileId});

  final String profileId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ss = context.ss;
    final async = ref.watch(speakGameForProvider(profileId));
    final st = async.valueOrNull;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('🎤 ${ss.title}', style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              if (async.hasError)
                Text(async.error is AuthFailure && (async.error! as AuthFailure).code == 'speak_not_installed'
                    ? ss.notInstalled
                    : ss.loadFailed)
              else if (st == null)
                const LinearProgressIndicator()
              else ...[
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _ResultPill(icon: '🏆', text: '${st.points} ${ss.points}'),
                    _ResultPill(icon: '📅', text: '${ss.today}: ${st.pointsToday}'),
                    _ResultPill(icon: '⭐', text: '${st.stars}'),
                    _ResultPill(icon: '🗣️', text: '${st.wordsMastered} ${ss.words}'),
                    _ResultPill(icon: '🧩', text: '${st.levelsDone}/${st.levels.length} ${ss.levels}'),
                    _ResultPill(icon: '🔥', text: '${st.dayStreak}'),
                  ],
                ),
                if (st.tricky.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Text(ss.ar ? 'كلمات تحتاج تدريب (آخر 14 يوماً):' : 'Words to practise (last 14 days):',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final t in st.tricky) Chip(label: Text('${t.word} ×${t.misses}')),
                    ],
                  ),
                ],
              ],
            ],
          ),
        ),
      ),
    );
  }
}
