import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../domain/account.dart';
import '../../domain/models.dart';
import '../../state/account.dart';
import '../../state/session.dart';

/// Parent's phone: choose who is learning. Profiles come from the real family.
class ProfilePickerScreen extends ConsumerWidget {
  const ProfilePickerScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final account = ref.watch(accountProvider).valueOrNull;
    final profiles = account?.profiles ?? const <LearnerProfile>[];
    return AccountScaffold(
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 24),
          if (account?.familyName != null)
            Text(account!.familyName!, textAlign: TextAlign.center, style: context.text.bodyMedium),
          Text(s.t('whoIsLearning'), textAlign: TextAlign.center, style: context.text.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 24),
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 16,
            runSpacing: 16,
            children: [
              for (final p in profiles)
                _ProfileTile(
                  profile: p,
                  onTap: () {
                    if (p.hasPin) {
                      context.push(Routes.pin(p.id));
                    } else {
                      ref.read(sessionProvider.notifier).selectProfile(p.id);
                      context.go(Routes.home);
                    }
                  },
                ),
            ],
          ),
          const SizedBox(height: 32),
          if (account?.email != null)
            Text(account!.email!, textAlign: TextAlign.center, textDirection: TextDirection.ltr, style: context.text.bodySmall),
          TextButton(
            onPressed: () => signOutThisPhone(ref),
            child: Text(s.t('signOut')),
          ),
        ],
      ),
    );
  }
}

/// Signs the parent out on this phone (other phones stay signed in).
Future<void> signOutThisPhone(WidgetRef ref) async {
  ref.read(sessionProvider.notifier).reset();
  ref.read(consentGivenProvider.notifier).state = false;
  await ref.read(accountProvider.notifier).run((r) => r.signOut());
}

class _ProfileTile extends StatelessWidget {
  const _ProfileTile({required this.profile, required this.onTap});

  final LearnerProfile profile;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = profile.isChild ? const Color(0xFFFFE8D6) : const Color(0xFFE3E9F2);
    return Semantics(
      button: true,
      label: profile.displayName,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: SizedBox(
          width: 130,
          child: Column(
            children: [
              Container(
                width: 110,
                height: 110,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(28)),
                child: Text(profile.avatarEmoji, style: const TextStyle(fontSize: 56)),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Flexible(
                    child: Text(
                      profile.displayName,
                      overflow: TextOverflow.ellipsis,
                      style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                    ),
                  ),
                  if (profile.hasPin) ...[
                    const SizedBox(width: 4),
                    Icon(Icons.lock_outline, size: 16, color: context.colors.onSurfaceVariant),
                  ],
                ],
              ),
              Text(
                profile.isChild ? '${context.s.t('grade')} ${profile.grade}' : context.s.t('adult'),
                style: context.text.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Opens a profile. The PIN is checked by the server; 5 wrong tries lock the
/// profile for 15 minutes. A profile without a PIN opens straight away.
class PinScreen extends ConsumerStatefulWidget {
  const PinScreen({super.key, required this.profileId});

  final String profileId;

  @override
  ConsumerState<PinScreen> createState() => _PinScreenState();
}

class _PinScreenState extends ConsumerState<PinScreen> {
  String _pin = '';
  bool _checking = false;
  String? _message;
  bool _opened = false;

  LearnerProfile? get _profile => ref.read(accountProvider).valueOrNull?.profileById(widget.profileId);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final p = _profile;
      if (mounted && p != null && !p.hasPin) _open();
    });
  }

  void _open() {
    if (_opened) return;
    _opened = true;
    ref.read(sessionProvider.notifier).selectProfile(widget.profileId);
    context.go(Routes.home);
  }

  Future<void> _press(String d) async {
    if (_pin.length >= 4 || _checking) return;
    setState(() {
      _pin += d;
      _message = null;
    });
    if (_pin.length < 4) return;

    setState(() => _checking = true);
    final s = context.s;
    try {
      final r = await ref.read(authRepositoryProvider).verifyPin(widget.profileId, _pin);
      if (!mounted) return;
      if (r.ok) {
        _open();
        return;
      }
      setState(() {
        _pin = '';
        _message = r.isLocked
            ? s.f('pinLocked', [TimeOfDay.fromDateTime(r.lockedUntil!).format(context)])
            : s.f('pinWrong', [r.attemptsLeft]);
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          _pin = '';
          _message = failureText(context, e);
        });
      }
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  void _delete() {
    if (_pin.isEmpty || _checking) return;
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  @override
  Widget build(BuildContext context) {
    final p = ref.watch(accountProvider).valueOrNull?.profileById(widget.profileId);
    final s = context.s;
    if (p == null) {
      return const AccountScaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (!p.hasPin) {
      return AccountScaffold(body: Center(child: Text(p.avatarEmoji, style: const TextStyle(fontSize: 64))));
    }
    return AccountScaffold(
      title: p.displayName,
      body: Column(
        children: [
          const SizedBox(height: 24),
          Text(p.avatarEmoji, style: const TextStyle(fontSize: 64)),
          const SizedBox(height: 8),
          Text(s.t('enterPin'), style: context.text.titleLarge),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 0; i < 4; i++)
                Container(
                  margin: const EdgeInsets.all(8),
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: i < _pin.length ? context.colors.primary : context.colors.surfaceContainerHighest,
                  ),
                ),
            ],
          ),
          SizedBox(
            height: 48,
            child: _checking
                ? const Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5)))
                : _message == null
                    ? null
                    : Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: Text(_message!, textAlign: TextAlign.center, style: TextStyle(color: context.colors.error)),
                      ),
          ),
          const Spacer(),
          PinPad(onDigit: _press, onDelete: _delete),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

/// 3x4 number pad, always left-to-right.
class PinPad extends StatelessWidget {
  const PinPad({super.key, required this.onDigit, required this.onDelete});

  final ValueChanged<String> onDigit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: GridView.count(
        crossAxisCount: 3,
        shrinkWrap: true,
        padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 16),
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1.4,
        physics: const NeverScrollableScrollPhysics(),
        children: [
          for (final d in ['1', '2', '3', '4', '5', '6', '7', '8', '9']) _Key(label: d, onTap: () => onDigit(d)),
          const SizedBox.shrink(),
          _Key(label: '0', onTap: () => onDigit('0')),
          _Key(icon: Icons.backspace_outlined, semantic: context.s.t('delete'), onTap: onDelete),
        ],
      ),
    );
  }
}

class _Key extends StatelessWidget {
  const _Key({this.label, this.icon, this.semantic, required this.onTap});

  final String? label;
  final IconData? icon;
  final String? semantic;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: context.colors.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Center(
          child: label != null
              ? Text(label!, style: context.text.headlineSmall)
              : Icon(icon, semanticLabel: semantic),
        ),
      ),
    );
  }
}

/// Small helper for screens that need the account (null while loading).
AccountState? accountOf(WidgetRef ref) => ref.watch(accountProvider).valueOrNull;
