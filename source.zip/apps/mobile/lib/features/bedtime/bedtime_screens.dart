import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/speech/speech_engine.dart';
import '../../data/bedtime/bedtime_repository.dart';
import '../../domain/account.dart';
import '../../domain/bedtime.dart';
import '../../state/bedtime.dart';
import '../../state/session.dart';
import '../../state/speak_game.dart';

// ============================================================================
//  Calm palettes (night = default for bedtime)
// ============================================================================
class BedtimePalette {
  const BedtimePalette({
    required this.bgTop,
    required this.bgBottom,
    required this.card,
    required this.text,
    required this.soft,
    required this.accent,
    required this.chip,
  });

  final Color bgTop;
  final Color bgBottom;
  final Color card;
  final Color text;
  final Color soft;
  final Color accent;
  final Color chip;

  static const night = BedtimePalette(
    bgTop: Color(0xFF0E1330),
    bgBottom: Color(0xFF1E2552),
    card: Color(0xFF252D5E),
    text: Color(0xFFEDEBF7),
    soft: Color(0xFFA9AED6),
    accent: Color(0xFFFFD98E),
    chip: Color(0xFF323B75),
  );

  static const day = BedtimePalette(
    bgTop: Color(0xFFFFF8EE),
    bgBottom: Color(0xFFF7E7D3),
    card: Colors.white,
    text: Color(0xFF3D3A4B),
    soft: Color(0xFF7D7890),
    accent: Color(0xFF8C7AE6),
    chip: Color(0xFFF1E9FF),
  );
}

BedtimePalette _pal(WidgetRef ref) => ref.watch(bedtimeNightProvider) ? BedtimePalette.night : BedtimePalette.day;

String _t(BuildContext c, String ar, String en) => AppStrings.of(c).isArabic ? ar : en;

String _errText(BuildContext c, Object e) {
  if (e is AuthFailure && e.code == 'bedtime_not_installed') {
    return _t(c, 'القسم يحتاج تحديث قاعدة البيانات (ملف SQL الخاص بالقصص). اطلب من الوالد تثبيته.',
        'This section needs the stories database update (SQL file). Ask a parent to install it.');
  }
  if (e is AuthFailure && e.code == 'network') {
    return _t(c, 'لا يوجد اتصال. تأكد من الإنترنت وحاول مرة أخرى.', 'No connection. Check the internet and try again.');
  }
  return _t(c, 'حدث خطأ. حاول مرة أخرى.', 'Something went wrong. Please try again.');
}

class _NightToggle extends ConsumerWidget {
  const _NightToggle();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final night = ref.watch(bedtimeNightProvider);
    return IconButton(
      tooltip: _t(context, night ? 'الوضع النهاري' : 'الوضع الليلي', night ? 'Day look' : 'Night look'),
      icon: Icon(night ? Icons.wb_sunny_outlined : Icons.nightlight_round, color: _pal(ref).accent),
      onPressed: () => ref.read(bedtimeNightProvider.notifier).state = !night,
    );
  }
}

// ============================================================================
//  Library
// ============================================================================
enum _Filter { all, favorites, prophets, hadith }

class BedtimeLibraryScreen extends ConsumerStatefulWidget {
  const BedtimeLibraryScreen({super.key});

  @override
  ConsumerState<BedtimeLibraryScreen> createState() => _BedtimeLibraryScreenState();
}

class _BedtimeLibraryScreenState extends ConsumerState<BedtimeLibraryScreen> {
  _Filter _filter = _Filter.all;
  final Set<String> _busy = {};

  Future<void> _open(String id) async {
    await context.push(Routes.bedtimeStory(id));
    if (mounted) ref.invalidate(bedtimeProvider);
  }

  Future<void> _toggleFav(BedtimeStory s) async {
    final p = ref.read(currentProfileProvider);
    if (p == null || _busy.contains(s.id)) return;
    setState(() => _busy.add(s.id));
    try {
      await ref.read(bedtimeRepositoryProvider).setFavorite(p, s.id, !s.favorite);
      if (!mounted) return;
      ref.invalidate(bedtimeProvider);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_errText(context, e))));
      }
    } finally {
      if (mounted) setState(() => _busy.remove(s.id));
    }
  }

  @override
  Widget build(BuildContext context) {
    final pal = _pal(ref);
    final async = ref.watch(bedtimeProvider);
    return Scaffold(
      backgroundColor: pal.bgTop,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: pal.text,
        elevation: 0,
        title: Text(_t(context, 'حكاية قبل النوم 🌙', 'Bedtime stories 🌙'),
            style: TextStyle(color: pal.text, fontWeight: FontWeight.w800)),
        centerTitle: true,
        actions: const [_NightToggle()],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [pal.bgTop, pal.bgBottom], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        ),
        child: async.when(
          loading: () => Center(child: CircularProgressIndicator(color: pal.accent)),
          error: (e, _) => _Message(
            pal: pal,
            emoji: '🌙',
            text: _errText(context, e),
            action: TextButton(
              onPressed: () => ref.invalidate(bedtimeProvider),
              child: Text(_t(context, 'حاول مرة أخرى', 'Try again'), style: TextStyle(color: pal.accent)),
            ),
          ),
          data: (st) {
            final list = switch (_filter) {
              _Filter.all => st.stories,
              _Filter.favorites => st.favorites,
              _Filter.prophets => st.stories.where((s) => s.isProphet).toList(),
              _Filter.hadith => st.stories.where((s) => s.isHadith).toList(),
            };
            final last = st.last == null ? null : st.byId(st.last!.storyId);
            return RefreshIndicator(
              color: pal.accent,
              onRefresh: () async {
                try {
                  await ref.refresh(bedtimeProvider.future);
                } catch (_) {}
              },
              child: LayoutBuilder(builder: (context, box) {
                final cols = box.maxWidth >= 1000 ? 3 : (box.maxWidth >= 640 ? 2 : 1);
                return CustomScrollView(
                  slivers: [
                    SliverToBoxAdapter(
                      child: Center(
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 1100),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              if (last != null)
                                _ContinueCard(
                                  pal: pal,
                                  story: last,
                                  page: st.last!.page,
                                  completed: st.last!.completed,
                                  onOpen: () => _open(last.id),
                                ),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                                child: Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children: [
                                    _FilterChip(pal: pal, label: _t(context, 'كل القصص', 'All'), selected: _filter == _Filter.all,
                                        onTap: () => setState(() => _filter = _Filter.all)),
                                    _FilterChip(pal: pal, label: _t(context, '❤️ المفضلة', '❤️ Favourites'), selected: _filter == _Filter.favorites,
                                        onTap: () => setState(() => _filter = _Filter.favorites)),
                                    _FilterChip(pal: pal, label: _t(context, '🕌 قصص الأنبياء', '🕌 Prophets'), selected: _filter == _Filter.prophets,
                                        onTap: () => setState(() => _filter = _Filter.prophets)),
                                    _FilterChip(pal: pal, label: _t(context, '🌴 من السنّة النبوية', '🌴 From the Sunnah'), selected: _filter == _Filter.hadith,
                                        onTap: () => setState(() => _filter = _Filter.hadith)),
                                  ],
                                ),
                              ),
                              if (_filter == _Filter.prophets && list.isNotEmpty)
                                _ProphetsHeader(
                                  pal: pal,
                                  count: list.length,
                                  done: list.where((s) => s.isDone).length,
                                )
                              else
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(20, 4, 20, 4),
                                  child: Text(
                                    _t(context, 'أكملتَ ${st.completedCount} من ${st.stories.length} قصة',
                                        '${st.completedCount} of ${st.stories.length} stories finished'),
                                    style: TextStyle(color: pal.soft),
                                  ),
                                ),
                              if (list.isEmpty)
                                _Message(
                                  pal: pal,
                                  emoji: _filter == _Filter.favorites ? '🤍' : '📚',
                                  text: _filter == _Filter.favorites
                                      ? _t(context, 'لا توجد قصص مفضلة بعد. اضغط ❤️ على أي قصة لتضيفها.',
                                          'No favourites yet. Tap ❤️ on a story to add it.')
                                      : _filter == _Filter.prophets
                                          ? _t(context, 'قصص الأنبياء ستظهر هنا بعد تحديث قاعدة البيانات (ملف SQL الجديد).',
                                              'Prophets stories will appear here after the database update (new SQL file).')
                                          : _t(context, 'لا توجد قصص بعد.', 'No stories yet.'),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    if (_filter == _Filter.prophets)
                      // the prophets as name cards, in order (1 = Adam ... 25 = Muhammad ﷺ)
                      SliverPadding(
                        padding: EdgeInsets.symmetric(
                            horizontal: math.max(12, (box.maxWidth - 1100) / 2 + 12), vertical: 8),
                        sliver: SliverGrid(
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: box.maxWidth >= 1000 ? 6 : (box.maxWidth >= 640 ? 4 : 3),
                            mainAxisSpacing: 10,
                            crossAxisSpacing: 10,
                            mainAxisExtent: 150,
                          ),
                          delegate: SliverChildBuilderDelegate(
                            (context, i) => _ProphetCard(
                              pal: pal,
                              number: i + 1,
                              story: list[i],
                              onOpen: () => _open(list[i].id),
                            ),
                            childCount: list.length,
                          ),
                        ),
                      )
                    else
                    SliverPadding(
                      padding: EdgeInsets.symmetric(
                          horizontal: math.max(12, (box.maxWidth - 1100) / 2 + 12), vertical: 8),
                      sliver: SliverGrid(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: cols,
                          mainAxisSpacing: 12,
                          crossAxisSpacing: 12,
                          mainAxisExtent: 128,
                        ),
                        delegate: SliverChildBuilderDelegate(
                          (context, i) => _StoryCard(
                            pal: pal,
                            story: list[i],
                            busy: _busy.contains(list[i].id),
                            onFav: () => _toggleFav(list[i]),
                            onOpen: () => _open(list[i].id),
                          ),
                          childCount: list.length,
                        ),
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(24, 8, 24, 32),
                        child: Text(
                          _t(context,
                              'قصص «من السنّة النبوية» و«قصص الأنبياء» مرويّة من مصادرها الصحيحة (القرآن الكريم والسنّة) دون إضافات، ومذكورٌ مصدرُ كلِّ قصّة في آخرها. الصور رموز فقط، ولا نرسم الأنبياء.',
                              'Sunnah and prophets stories are retold from their sources (the Quran and Sunnah) without additions; each one shows its source at the end. Pictures are symbols only; prophets are never drawn.'),
                          textAlign: TextAlign.center,
                          style: TextStyle(color: pal.soft, fontSize: 12),
                        ),
                      ),
                    ),
                  ],
                );
              }),
            );
          },
        ),
      ),
    );
  }
}

/// Title of the prophets list: what it is and how many the child finished.
class _ProphetsHeader extends StatelessWidget {
  const _ProphetsHeader({required this.pal, required this.count, required this.done});

  final BedtimePalette pal;
  final int count;
  final int done;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 6, 20, 2),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _t(context, 'الأنبياءُ المذكورون في القرآنِ الكريم ($count)، بالترتيب',
                  'The prophets named in the Quran ($count), in order'),
              style: TextStyle(color: pal.text, fontSize: 16, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: count == 0 ? 0 : done / count,
                minHeight: 8,
                color: pal.accent,
                backgroundColor: pal.chip,
              ),
            ),
            const SizedBox(height: 4),
            Text(_t(context, 'استمعتَ إلى $done من $count', '$done of $count finished'),
                style: TextStyle(color: pal.soft, fontSize: 13)),
          ],
        ),
      );
}

/// One prophet: number, symbol, name. Tapping opens the story.
class _ProphetCard extends StatelessWidget {
  const _ProphetCard({required this.pal, required this.number, required this.story, required this.onOpen});

  final BedtimePalette pal;
  final int number;
  final BedtimeStory story;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final digits = AppStrings.of(context).isArabic ? _arabicDigits('$number') : '$number';
    return Material(
      color: pal.card,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onOpen,
        child: Semantics(
          button: true,
          label: story.title,
          child: Stack(
            children: [
              PositionedDirectional(
                top: 8,
                start: 8,
                child: Container(
                  width: 26,
                  height: 26,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: pal.chip, shape: BoxShape.circle),
                  child: Text(digits, style: TextStyle(color: pal.text, fontSize: 12, fontWeight: FontWeight.w800)),
                ),
              ),
              if (story.isDone)
                PositionedDirectional(
                  top: 8,
                  end: 8,
                  child: Icon(Icons.check_circle_rounded, size: 22, color: pal.accent),
                ),
              if (story.favorite && !story.isDone)
                const PositionedDirectional(
                  top: 8,
                  end: 8,
                  child: Icon(Icons.favorite_rounded, size: 18, color: Color(0xFFFF8FA3)),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(6, 14, 6, 8),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 58,
                      height: 58,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(colors: [pal.accent.withValues(alpha: 0.35), pal.chip]),
                      ),
                      child: Text(story.emoji, style: const TextStyle(fontSize: 30)),
                    ),
                    const SizedBox(height: 8),
                    Text(story.prophetName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        textDirection: TextDirection.rtl,
                        style: TextStyle(color: pal.text, fontSize: 17, fontWeight: FontWeight.w800)),
                    Text(story.prophetHonorific,
                        maxLines: 1,
                        textAlign: TextAlign.center,
                        textDirection: TextDirection.rtl,
                        style: TextStyle(color: pal.soft, fontSize: 11)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

String _arabicDigits(String s) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  return s.split('').map((c) {
    final d = int.tryParse(c);
    return d == null ? c : ar[d];
  }).join();
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({required this.pal, required this.label, required this.selected, required this.onTap});

  final BedtimePalette pal;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: selected ? pal.accent : pal.chip,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(label,
              style: TextStyle(
                color: selected ? const Color(0xFF1B1F3B) : pal.text,
                fontWeight: FontWeight.w700,
              )),
        ),
      );
}

class _ContinueCard extends StatelessWidget {
  const _ContinueCard({required this.pal, required this.story, required this.page, required this.completed, required this.onOpen});

  final VoidCallback onOpen;
  final BedtimePalette pal;
  final BedtimeStory story;
  final int page;
  final bool completed;

  @override
  Widget build(BuildContext context) {
    final label = completed
        ? _t(context, 'آخر قصة استمعتَ إليها', 'Your last story')
        : _t(context, 'تابع قصتك من حيث توقفت', 'Continue where you stopped');
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onOpen,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: LinearGradient(colors: [pal.card, pal.chip]),
            border: Border.all(color: pal.accent.withValues(alpha: 0.35)),
          ),
          child: Row(
            children: [
              Text(story.emoji, style: const TextStyle(fontSize: 44)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label, style: TextStyle(color: pal.soft, fontSize: 13)),
                    Text(story.title,
                        textDirection: TextDirection.rtl,
                        style: TextStyle(color: pal.text, fontSize: 20, fontWeight: FontWeight.w800)),
                    if (!completed)
                      Text(_t(context, 'الصفحة ${page + 1} من ${story.pages.length}', 'Page ${page + 1} of ${story.pages.length}'),
                          style: TextStyle(color: pal.soft, fontSize: 13)),
                  ],
                ),
              ),
              Icon(completed ? Icons.replay_rounded : Icons.play_circle_fill_rounded, color: pal.accent, size: 40),
            ],
          ),
        ),
      ),
    );
  }
}

class _StoryCard extends StatelessWidget {
  const _StoryCard({required this.pal, required this.story, required this.busy, required this.onFav, required this.onOpen});

  final VoidCallback onOpen;
  final BedtimePalette pal;
  final BedtimeStory story;
  final bool busy;
  final VoidCallback onFav;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: pal.card,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onOpen,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 6, 12),
          child: Row(
            children: [
              Container(
                width: 72,
                height: 72,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [pal.accent.withValues(alpha: 0.35), pal.chip]),
                ),
                child: Text(story.emoji, style: const TextStyle(fontSize: 38)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(story.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textDirection: TextDirection.rtl,
                        style: TextStyle(color: pal.text, fontSize: 18, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        _Tag(pal: pal, text: story.valueName),
                        _Tag(pal: pal, text: _t(context, '⏱ ${story.minutes} د', '⏱ ${story.minutes} min')),
                        if (story.isHadith) _Tag(pal: pal, text: _t(context, '🌴 من السنّة', '🌴 Sunnah')),
                        if (story.isProphet) _Tag(pal: pal, text: _t(context, '🕌 قصص الأنبياء', '🕌 Prophets')),
                        if (story.isDone) _Tag(pal: pal, text: _t(context, '✓ مكتملة', '✓ Done'), strong: true),
                      ],
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: _t(context, 'المفضلة', 'Favourite'),
                onPressed: busy ? null : onFav,
                icon: Icon(story.favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    color: story.favorite ? const Color(0xFFFF8FA3) : pal.soft),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  const _Tag({required this.pal, required this.text, this.strong = false});

  final BedtimePalette pal;
  final String text;
  final bool strong;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: strong ? pal.accent.withValues(alpha: 0.25) : pal.chip,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(text, style: TextStyle(color: pal.text, fontSize: 12, fontWeight: strong ? FontWeight.w700 : FontWeight.w500)),
      );
}

class _Message extends StatelessWidget {
  const _Message({required this.pal, required this.emoji, required this.text, this.action});

  final BedtimePalette pal;
  final String emoji;
  final String text;
  final Widget? action;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(emoji, style: const TextStyle(fontSize: 52)),
              const SizedBox(height: 12),
              Text(text, textAlign: TextAlign.center, style: TextStyle(color: pal.text, fontSize: 16)),
              if (action != null) ...[const SizedBox(height: 8), action!],
            ],
          ),
        ),
      );
}

// ============================================================================
//  Story player
// ============================================================================
class BedtimeStoryScreen extends ConsumerStatefulWidget {
  const BedtimeStoryScreen({super.key, required this.storyId});

  final String storyId;

  @override
  ConsumerState<BedtimeStoryScreen> createState() => _BedtimeStoryScreenState();
}

class _BedtimeStoryScreenState extends ConsumerState<BedtimeStoryScreen> {
  late final SpeechEngine _engine;
  late final BedtimeRepository _repo;
  final PageController _pages = PageController();

  BedtimeStory? _story;
  String? _listenId;
  Object? _startError;
  bool _starting = false;

  int _page = 0;
  int _sentence = 0;
  bool _playing = false;
  int _token = 0;

  // time actually spent with the story
  int _seconds = 0;
  DateTime _lastTouch = DateTime.now();
  Timer? _ticker;
  int _savedPage = -1;
  int _savedSeconds = 0;

  // sleep timer
  int? _sleepMinutes;
  DateTime? _sleepAt;
  bool _sleeping = false;

  // end of story
  bool _ended = false;
  int? _picked;
  bool _favorite = false;
  bool _favBusy = false;
  bool _hasVoice = true;
  int _fastSpeaks = 0;

  @override
  void initState() {
    super.initState();
    _engine = ref.read(speechEngineProvider);
    _repo = ref.read(bedtimeRepositoryProvider);
    _hasVoice = _engine.ttsSupported;
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _token++;
    try {
      _engine.stopSpeaking();
      _engine.keepAwake(false);
    } catch (_) {}
    _saveProgress(force: true);
    _pages.dispose();
    super.dispose();
  }

  // ---------------------------------------------------------------- server
  Future<void> _start(BedtimeStory s) async {
    if (_starting || _listenId != null) return;
    final p = ref.read(currentProfileProvider);
    if (p == null) return;
    _starting = true;
    try {
      final l = await _repo.start(p, s.id);
      if (!mounted) return;
      setState(() {
        _listenId = l.listenId;
        _favorite = s.favorite;
        final resume = l.page.clamp(0, s.pages.length - 1).toInt();
        if (resume > 0) {
          _page = resume;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (_pages.hasClients) _pages.jumpToPage(resume);
          });
        }
      });
      // A voice for Arabic may load a moment later in some browsers.
      Future.delayed(const Duration(milliseconds: 800), () {
        if (mounted) setState(() => _hasVoice = _engine.ttsSupported && _engine.hasVoice('ar-SA'));
      });
    } catch (e) {
      if (mounted) setState(() => _startError = e);
    } finally {
      _starting = false;
    }
  }

  void _saveProgress({bool force = false}) {
    final id = _listenId;
    if (id == null) return;
    if (!force && _page == _savedPage && _seconds - _savedSeconds < 30) return;
    _savedPage = _page;
    _savedSeconds = _seconds;
    _repo.progress(id, _page, _seconds).catchError((Object _) {});
  }

  void _tick() {
    if (!mounted || _story == null || _ended || _sleeping) return;
    // voices can finish loading a little later in some browsers
    if (!_hasVoice && _fastSpeaks < 2 && _engine.ttsSupported && _engine.hasVoice('ar-SA')) {
      setState(() => _hasVoice = true);
    }
    final active = _playing || DateTime.now().difference(_lastTouch) < const Duration(seconds: 60);
    if (active) _seconds++;
    if (_sleepAt != null) {
      if (DateTime.now().isAfter(_sleepAt!)) {
        _goToSleep();
      } else {
        setState(() {}); // countdown
      }
    }
    _saveProgress();
  }

  // ---------------------------------------------------------------- narration
  Future<void> _play() async {
    final s = _story;
    if (s == null) return;
    _lastTouch = DateTime.now();
    _engine.unlockAudio();
    final my = ++_token;
    setState(() => _playing = true);
    _engine.keepAwake(true);
    for (var p = _page; p < s.pages.length; p++) {
      if (my != _token) return;
      if (p != _page) {
        setState(() {
          _page = p;
          _sentence = 0;
        });
        if (_pages.hasClients) {
          await _pages.animateToPage(p, duration: const Duration(milliseconds: 900), curve: Curves.easeInOut);
        }
        _saveProgress(force: true);
      }
      final sents = s.pages[p].sentences;
      for (var i = _sentence; i < sents.length; i++) {
        if (my != _token) return;
        setState(() => _sentence = i);
        final watch = Stopwatch()..start();
        await _engine.speak(sents[i], lang: 'ar-SA', rate: 0.78, pitch: 0.95);
        if (my != _token) return;
        // A sentence "read" in almost no time means there is no working voice:
        // stop instead of racing through the pages (and never mark it finished).
        if (watch.elapsedMilliseconds < 300) {
          if (++_fastSpeaks >= 2) {
            _pause();
            if (mounted) setState(() => _hasVoice = false);
            return;
          }
        } else {
          _fastSpeaks = 0;
        }
        await Future<void>.delayed(const Duration(milliseconds: 650));
      }
      if (my != _token) return;
      _sentence = 0;
      await Future<void>.delayed(const Duration(milliseconds: 1400));
    }
    if (my != _token || !mounted) return;
    setState(() => _playing = false);
    _engine.keepAwake(false);
    _finish();
  }

  void _pause() {
    _token++;
    _engine.stopSpeaking();
    _engine.keepAwake(false);
    _lastTouch = DateTime.now();
    if (mounted) setState(() => _playing = false);
  }

  void _goTo(int page) {
    final s = _story;
    if (s == null) return;
    final wasPlaying = _playing;
    _pause();
    final target = page.clamp(0, s.pages.length - 1).toInt();
    setState(() {
      _page = target;
      _sentence = 0;
    });
    if (_pages.hasClients) {
      _pages.animateToPage(target, duration: const Duration(milliseconds: 500), curve: Curves.easeInOut);
    }
    _saveProgress(force: true);
    if (wasPlaying) _play();
  }

  // ---------------------------------------------------------------- sleep timer
  void _setSleep(int? minutes) {
    setState(() {
      _sleepMinutes = minutes;
      _sleepAt = minutes == null ? null : DateTime.now().add(Duration(minutes: minutes));
    });
  }

  void _goToSleep() {
    _pause();
    _saveProgress(force: true);
    setState(() {
      _sleeping = true;
      _sleepAt = null;
      _sleepMinutes = null;
    });
  }

  Future<void> _pickSleep() async {
    final pal = ref.read(bedtimeNightProvider) ? BedtimePalette.night : BedtimePalette.day;
    final v = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: pal.card,
      showDragHandle: true,
      builder: (c) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_t(context, 'إيقاف الصوت تلقائيًا بعد', 'Stop the voice after'),
                style: TextStyle(color: pal.text, fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            for (final m in const [5, 10, 15, 20, 30])
              ListTile(
                leading: Icon(Icons.bedtime_outlined, color: pal.accent),
                title: Text(_t(context, '$m دقائق', '$m minutes'), style: TextStyle(color: pal.text)),
                trailing: _sleepMinutes == m ? Icon(Icons.check, color: pal.accent) : null,
                onTap: () => Navigator.pop(c, m),
              ),
            ListTile(
              leading: Icon(Icons.timer_off_outlined, color: pal.soft),
              title: Text(_t(context, 'بدون مؤقت', 'No timer'), style: TextStyle(color: pal.text)),
              onTap: () => Navigator.pop(c, 0),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (v == null || !mounted) return;
    _setSleep(v == 0 ? null : v);
  }

  String get _sleepLeft {
    final at = _sleepAt;
    if (at == null) return '';
    final d = at.difference(DateTime.now());
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  // ---------------------------------------------------------------- end
  void _finish() {
    final id = _listenId;
    setState(() => _ended = true);
    if (id != null) {
      _repo.complete(id, _seconds, null).then((_) {
        if (mounted) ref.invalidate(bedtimeProvider);
      }).catchError((Object _) {});
    }
  }

  void _answer(int i) {
    final s = _story;
    final id = _listenId;
    if (s == null || _picked == s.question.answer) return;
    final first = _picked == null;
    setState(() => _picked = i);
    // Only the first answer is saved, so it shows what the child understood.
    if (first && id != null) {
      _repo.complete(id, _seconds, i == s.question.answer).catchError((Object _) {});
    }
  }

  Future<void> _toggleFav() async {
    final p = ref.read(currentProfileProvider);
    final s = _story;
    if (p == null || s == null || _favBusy) return;
    setState(() => _favBusy = true);
    try {
      await _repo.setFavorite(p, s.id, !_favorite);
      if (!mounted) return;
      setState(() => _favorite = !_favorite);
      ref.invalidate(bedtimeProvider);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_errText(context, e))));
    } finally {
      if (mounted) setState(() => _favBusy = false);
    }
  }

  void _restart() {
    _pause();
    setState(() {
      _ended = false;
      _picked = null;
      _page = 0;
      _sentence = 0;
      _listenId = null;
    });
    if (_pages.hasClients) _pages.jumpToPage(0);
    final s = _story;
    if (s != null) _start(s);
  }

  // ---------------------------------------------------------------- build
  @override
  Widget build(BuildContext context) {
    final pal = _pal(ref);
    if (_story == null) {
      final async = ref.watch(bedtimeProvider);
      final st = async.valueOrNull;
      final s = st?.byId(widget.storyId);
      if (s == null) {
        return Scaffold(
          backgroundColor: pal.bgTop,
          appBar: AppBar(backgroundColor: Colors.transparent, foregroundColor: pal.text),
          body: async.isLoading
              ? Center(child: CircularProgressIndicator(color: pal.accent))
              : _Message(
                  pal: pal,
                  emoji: '🌙',
                  text: async.hasError ? _errText(context, async.error!) : _t(context, 'القصة غير موجودة.', 'Story not found.'),
                ),
        );
      }
      _story = s;
      WidgetsBinding.instance.addPostFrameCallback((_) => _start(s));
    }
    final s = _story!;

    return Scaffold(
      backgroundColor: pal.bgTop,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [pal.bgTop, pal.bgBottom], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Column(
                children: [
                  _topBar(context, pal, s),
                  if (_startError != null)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text(_errText(context, _startError!),
                          textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFFFB4A8))),
                    ),
                  Expanded(child: _ended ? _endView(context, pal, s) : _storyView(context, pal, s, ref.watch(bedtimeNightProvider))),
                  if (!_ended) _controls(context, pal, s),
                ],
              ),
              if (_sleeping) _sleepOverlay(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _topBar(BuildContext context, BedtimePalette pal, BedtimeStory s) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 4, 4, 0),
        child: Row(
          children: [
            IconButton(
              icon: Icon(Icons.close_rounded, color: pal.text),
              onPressed: () => context.pop(),
            ),
            Expanded(
              child: Text(s.title,
                  textAlign: TextAlign.center,
                  textDirection: TextDirection.rtl,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: pal.text, fontSize: 18, fontWeight: FontWeight.w800)),
            ),
            TextButton.icon(
              onPressed: _pickSleep,
              icon: Icon(Icons.bedtime_outlined, color: pal.accent, size: 20),
              label: Text(_sleepAt == null ? _t(context, 'مؤقت', 'Timer') : _sleepLeft,
                  style: TextStyle(color: pal.accent, fontWeight: FontWeight.w700)),
            ),
            const _NightToggle(),
          ],
        ),
      );

  Widget _storyView(BuildContext context, BedtimePalette pal, BedtimeStory s, bool night) {
    return LayoutBuilder(builder: (context, box) {
      final wide = box.maxWidth >= 760;
      // Arabic book: the next page comes from the left.
      return Directionality(
        textDirection: TextDirection.rtl,
        child: PageView.builder(
        controller: _pages,
        itemCount: s.pages.length,
        onPageChanged: (i) {
          if (i == _page) return;
          _lastTouch = DateTime.now();
          final wasPlaying = _playing;
          _pause();
          setState(() {
            _page = i;
            _sentence = 0;
          });
          _saveProgress(force: true);
          if (wasPlaying) _play();
        },
        itemBuilder: (context, i) {
          final page = s.pages[i];
          final art = _SceneArt(page: page, night: night);
          final text = _PageText(
            pal: pal,
            page: page,
            highlight: _playing && i == _page ? _sentence : -1,
          );
          final body = wide
              ? Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(flex: 5, child: art),
                    const SizedBox(width: 20),
                    Expanded(flex: 6, child: SingleChildScrollView(child: text)),
                  ],
                )
              : Column(
                  children: [
                    SizedBox(height: math.min(260, box.maxHeight * 0.36), child: art),
                    const SizedBox(height: 14),
                    Expanded(child: SingleChildScrollView(child: text)),
                  ],
                );
          return Padding(
            padding: const EdgeInsets.fromLTRB(18, 10, 18, 4),
            child: Center(
              child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1100), child: body),
            ),
          );
        },
        ),
      );
    });
  }

  Widget _controls(BuildContext context, BedtimePalette pal, BedtimeStory s) {
    final last = _page >= s.pages.length - 1;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 0; i < s.pages.length; i++)
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: i == _page ? 22 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: i == _page ? pal.accent : pal.soft.withValues(alpha: 0.4),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
            ],
          ),
          if (!_hasVoice)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                _t(context, 'لا يوجد صوت عربي على هذا الجهاز، يمكنك قراءة القصة مع طفلك.',
                    'No Arabic voice on this device - you can read the story aloud together.'),
                textAlign: TextAlign.center,
                style: TextStyle(color: pal.soft, fontSize: 12),
              ),
            ),
          const SizedBox(height: 8),
          // Laid out left-to-right on purpose: in an Arabic book the NEXT page is on the left.
          Directionality(
            textDirection: TextDirection.ltr,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                last
                    ? FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: pal.chip, foregroundColor: pal.text),
                        onPressed: () {
                          _pause();
                          _finish();
                        },
                        child: Text(_t(context, 'انتهت 🌙', 'The end 🌙')),
                      )
                    : IconButton.filledTonal(
                        iconSize: 30,
                        style: IconButton.styleFrom(backgroundColor: pal.chip, foregroundColor: pal.text),
                        tooltip: _t(context, 'الصفحة التالية', 'Next page'),
                        onPressed: () => _goTo(_page + 1),
                        icon: const Icon(Icons.chevron_left_rounded),
                      ),
                const SizedBox(width: 18),
                SizedBox(
                  width: 76,
                  height: 76,
                  child: IconButton.filled(
                    iconSize: 42,
                    style: IconButton.styleFrom(backgroundColor: pal.accent, foregroundColor: const Color(0xFF1B1F3B)),
                    tooltip: _playing ? _t(context, 'إيقاف مؤقت', 'Pause') : _t(context, 'استمع للقصة', 'Listen'),
                    onPressed: (_listenId == null && _startError == null) || (!_hasVoice && !_playing)
                        ? null
                        : (_playing ? _pause : _play),
                    icon: Icon(_playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
                  ),
                ),
                const SizedBox(width: 18),
                IconButton.filledTonal(
                  iconSize: 30,
                  style: IconButton.styleFrom(backgroundColor: pal.chip, foregroundColor: pal.text),
                  tooltip: _t(context, 'الصفحة السابقة', 'Previous page'),
                  onPressed: _page == 0 ? null : () => _goTo(_page - 1),
                  icon: const Icon(Icons.chevron_right_rounded),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _endView(BuildContext context, BedtimePalette pal, BedtimeStory s) {
    final q = s.question;
    final answered = _picked != null;
    final right = _picked == q.answer;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 640),
            child: Column(
              children: [
                const Text('🌙', style: TextStyle(fontSize: 64)),
                Text('انتهت القصة', style: TextStyle(color: pal.text, fontSize: 24, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text('تعلّمنا اليوم: ${s.valueName}', style: TextStyle(color: pal.accent, fontSize: 17)),
                if (s.showsSource) ...[
                  const SizedBox(height: 6),
                  Text('المصدر: ${s.source}', textAlign: TextAlign.center, style: TextStyle(color: pal.soft, fontSize: 12)),
                ],
                const SizedBox(height: 18),
                _EndCard(
                  pal: pal,
                  title: '💭 سؤال صغير',
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(q.question, style: TextStyle(color: pal.text, fontSize: 17, height: 1.6)),
                      const SizedBox(height: 10),
                      for (var i = 0; i < q.options.length; i++)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: OutlinedButton(
                            style: OutlinedButton.styleFrom(
                              alignment: AlignmentDirectional.centerStart,
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                              foregroundColor: pal.text,
                              backgroundColor: answered && i == _picked
                                  ? (right ? const Color(0x3348C78E) : const Color(0x22A9AED6))
                                  : null,
                              side: BorderSide(
                                  color: answered && i == _picked && right ? const Color(0xFF7BD8A8) : pal.soft.withValues(alpha: 0.5)),
                            ),
                            onPressed: right ? null : () => _answer(i),
                            child: Text(q.options[i], style: const TextStyle(fontSize: 16)),
                          ),
                        ),
                      if (answered)
                        Text(
                          right ? 'أحسنت، هذا صحيح 🌟' : 'فكّر مرة أخرى بهدوء، وتذكّر ما حدث في القصة 🙂',
                          style: TextStyle(color: right ? const Color(0xFF9BE3BF) : pal.soft, fontSize: 15),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                _EndCard(
                  pal: pal,
                  title: '🌿 نشاط هادئ',
                  child: Text(s.activity, style: TextStyle(color: pal.text, fontSize: 16, height: 1.7)),
                ),
                const SizedBox(height: 16),
                Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: pal.chip, foregroundColor: pal.text),
                      onPressed: _favBusy ? null : _toggleFav,
                      icon: Icon(_favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                          color: _favorite ? const Color(0xFFFF8FA3) : pal.text),
                      label: Text(_favorite ? 'في المفضلة' : 'أضف إلى المفضلة'),
                    ),
                    FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: pal.chip, foregroundColor: pal.text),
                      onPressed: _restart,
                      icon: const Icon(Icons.replay_rounded),
                      label: const Text('أعد القصة'),
                    ),
                    FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: pal.accent, foregroundColor: const Color(0xFF1B1F3B)),
                      onPressed: () => context.pop(),
                      icon: const Icon(Icons.menu_book_rounded),
                      label: const Text('القصص'),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text('تصبح على خير 🌙', style: TextStyle(color: pal.soft, fontSize: 16)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _sleepOverlay(BuildContext context) => Positioned.fill(
        child: GestureDetector(
          onTap: () => setState(() => _sleeping = false),
          child: Container(
            color: const Color(0xF5070A1C),
            alignment: Alignment.center,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('🌙', style: TextStyle(fontSize: 72)),
                const SizedBox(height: 12),
                const Text('تصبح على خير',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(color: Color(0xFFB8BCE0), fontSize: 26, fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Text(_t(context, 'توقّف الصوت. المس الشاشة للمتابعة.', 'The voice stopped. Touch to continue.'),
                    style: const TextStyle(color: Color(0xFF6E739C))),
              ],
            ),
          ),
        ),
      );
}

class _EndCard extends StatelessWidget {
  const _EndCard({required this.pal, required this.title, required this.child});

  final BedtimePalette pal;
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: pal.card, borderRadius: BorderRadius.circular(22)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: TextStyle(color: pal.accent, fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            child,
          ],
        ),
      );
}

/// Page text, with the sentence being read gently highlighted.
class _PageText extends StatelessWidget {
  const _PageText({required this.pal, required this.page, required this.highlight});

  final BedtimePalette pal;
  final StoryPage page;
  final int highlight;

  @override
  Widget build(BuildContext context) {
    final sents = page.sentences;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Text.rich(
        TextSpan(
          children: [
            for (var i = 0; i < sents.length; i++)
              TextSpan(
                text: '${sents[i]} ',
                style: TextStyle(
                  backgroundColor: i == highlight ? pal.accent.withValues(alpha: 0.18) : null,
                  color: pal.text,
                ),
              ),
          ],
        ),
        style: TextStyle(fontSize: MediaQuery.sizeOf(context).width >= 760 ? 24 : 21, height: 1.95, color: pal.text),
      ),
    );
  }
}

// ============================================================================
//  Calm pictures: a painted sky/landscape with the page's emojis floating gently
// ============================================================================
class _SceneArt extends StatefulWidget {
  const _SceneArt({required this.page, required this.night});

  final StoryPage page;
  final bool night;

  @override
  State<_SceneArt> createState() => _SceneArtState();
}

class _SceneArtState extends State<_SceneArt> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final scene = widget.page.scene;
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final t = Curves.easeInOut.transform(_c.value);
          return CustomPaint(
            painter: _ScenePainter(bg: widget.page.bg, night: widget.night, t: t),
            child: LayoutBuilder(builder: (context, box) {
              final size = math.min(box.maxHeight * 0.34, box.maxWidth / (scene.length + 1.2));
              return Stack(
                children: [
                  for (var i = 0; i < scene.length; i++)
                    Positioned(
                      left: box.maxWidth * (i + 1) / (scene.length + 1) - size / 2,
                      top: box.maxHeight * 0.52 - size / 2 + math.sin((t + i * 0.4) * math.pi) * 6,
                      child: Text(scene[i], style: TextStyle(fontSize: size)),
                    ),
                ],
              );
            }),
          );
        },
      ),
    );
  }
}

class _ScenePainter extends CustomPainter {
  _ScenePainter({required this.bg, required this.night, required this.t});

  final String bg;
  final bool night;
  final double t;

  static const _skies = {
    'night': [Color(0xFF141A45), Color(0xFF2C3470)],
    'dusk': [Color(0xFF3B2F6B), Color(0xFFB9789A)],
    'garden': [Color(0xFF9FD3F0), Color(0xFFE6F4FA)],
    'home': [Color(0xFFF6E3C8), Color(0xFFFBEFDD)],
    'forest': [Color(0xFF8CC7B5), Color(0xFFDDF1E8)],
    'desert': [Color(0xFFF3C98B), Color(0xFFFCE9CB)],
    'sea': [Color(0xFF7FB8E0), Color(0xFFD7ECF8)],
    'mountain': [Color(0xFFA9CBEA), Color(0xFFEAF2F8)],
    'river': [Color(0xFF9ED2E8), Color(0xFFE3F3EC)],
    'city': [Color(0xFFF2D4A8), Color(0xFFFBEEDC)],
  };

  @override
  void paint(Canvas canvas, Size size) {
    final dark = night || bg == 'night' || bg == 'dusk';
    var sky = _skies[bg] ?? _skies['night']!;
    if (night && bg != 'night' && bg != 'dusk') {
      // soften daylight scenes at night
      sky = [Color.lerp(sky[0], const Color(0xFF1B2152), 0.65)!, Color.lerp(sky[1], const Color(0xFF2C3470), 0.6)!];
    }
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..shader = LinearGradient(colors: sky, begin: Alignment.topCenter, end: Alignment.bottomCenter).createShader(rect));

    // stars and moon at night, a soft sun by day
    if (dark) {
      final star = Paint()..color = Colors.white;
      final r = math.Random(bg.hashCode);
      for (var i = 0; i < 26; i++) {
        final x = r.nextDouble() * size.width;
        final y = r.nextDouble() * size.height * 0.55;
        final tw = 0.35 + 0.65 * (0.5 + 0.5 * math.sin((t * 2 + i) * math.pi));
        star.color = Colors.white.withValues(alpha: 0.25 + 0.5 * tw);
        canvas.drawCircle(Offset(x, y), 1.1 + r.nextDouble() * 1.3, star);
      }
      final mc = Offset(size.width * 0.82, size.height * 0.2);
      canvas.drawCircle(mc, 34, Paint()..color = const Color(0x22FFE9B0));
      canvas.drawCircle(mc, 20, Paint()..color = const Color(0xFFFFE9B0));
      canvas.drawCircle(mc.translate(8, -5), 17, Paint()..color = sky[0]);
    } else {
      final sc = Offset(size.width * 0.84, size.height * 0.2);
      canvas.drawCircle(sc, 30, Paint()..color = const Color(0x33FFE08A));
      canvas.drawCircle(sc, 18, Paint()..color = const Color(0xFFFFE08A));
      final cloud = Paint()..color = Colors.white.withValues(alpha: 0.8);
      final cx = size.width * (0.2 + 0.05 * t);
      for (final o in const [Offset(0, 0), Offset(18, -8), Offset(36, 0)]) {
        canvas.drawCircle(Offset(cx + o.dx, size.height * 0.18 + o.dy), 14, cloud);
      }
    }

    Color soften(Color c) => night ? Color.lerp(c, const Color(0xFF1A2050), 0.55)! : c;

    // far shapes behind the ground: mountains, an old town, palm trees by the river
    if (bg == 'mountain') {
      final far = Paint()..color = soften(const Color(0xFF8A9BB8));
      final near = Paint()..color = soften(const Color(0xFF6E7F9E));
      canvas.drawPath(
          Path()
            ..moveTo(0, size.height * 0.8)
            ..lineTo(size.width * 0.18, size.height * 0.42)
            ..lineTo(size.width * 0.36, size.height * 0.8)
            ..close(),
          far);
      canvas.drawPath(
          Path()
            ..moveTo(size.width * 0.22, size.height * 0.8)
            ..lineTo(size.width * 0.5, size.height * 0.28)
            ..lineTo(size.width * 0.78, size.height * 0.8)
            ..close(),
          near);
      // snow cap
      canvas.drawPath(
          Path()
            ..moveTo(size.width * 0.5, size.height * 0.28)
            ..lineTo(size.width * 0.455, size.height * 0.36)
            ..lineTo(size.width * 0.545, size.height * 0.36)
            ..close(),
          Paint()..color = Colors.white.withValues(alpha: night ? 0.5 : 0.9));
      canvas.drawPath(
          Path()
            ..moveTo(size.width * 0.62, size.height * 0.8)
            ..lineTo(size.width * 0.86, size.height * 0.46)
            ..lineTo(size.width * 1.05, size.height * 0.8)
            ..close(),
          far);
    } else if (bg == 'city') {
      final wall = Paint()..color = soften(const Color(0xFFD9B98F));
      final shade = Paint()..color = soften(const Color(0xFFB8956A));
      final r = math.Random(7);
      var x = 0.0;
      while (x < size.width) {
        final w = 34 + r.nextDouble() * 30;
        final h = size.height * (0.18 + r.nextDouble() * 0.2);
        final top = size.height * 0.78 - h;
        canvas.drawRect(Rect.fromLTWH(x, top, w - 4, h + 4), r.nextBool() ? wall : shade);
        // small windows
        final win = Paint()..color = night ? const Color(0xFFFFE9A8) : const Color(0xFF8C6A45);
        canvas.drawRect(Rect.fromLTWH(x + w * 0.3, top + h * 0.25, 6, 9), win);
        if (w > 48) canvas.drawRect(Rect.fromLTWH(x + w * 0.62, top + h * 0.25, 6, 9), win);
        x += w;
      }
    } else if (bg == 'river') {
      final trunk = Paint()..color = soften(const Color(0xFF9C7448));
      final leaf = Paint()..color = soften(const Color(0xFF5FA36B));
      for (final px in [size.width * 0.1, size.width * 0.9]) {
        canvas.drawRect(Rect.fromLTWH(px - 3, size.height * 0.42, 6, size.height * 0.34), trunk);
        for (var k = 0; k < 5; k++) {
          final a = -math.pi + k * math.pi / 4;
          canvas.drawOval(
              Rect.fromCenter(
                  center: Offset(px + math.cos(a) * 16, size.height * 0.42 + math.sin(a) * 8 + 4), width: 34, height: 10),
              leaf);
        }
      }
    }

    // ground
    final ground = switch (bg) {
      'garden' || 'forest' || 'river' => const Color(0xFF7FBF7F),
      'mountain' => const Color(0xFF8DB87A),
      'city' => const Color(0xFFDDBB8A),
      'desert' => const Color(0xFFE2B36B),
      'sea' => const Color(0xFF5B9BD5),
      'home' => const Color(0xFFD9B68C),
      _ => const Color(0xFF2B3368),
    };
    final g = Paint()..color = night ? Color.lerp(ground, const Color(0xFF1A2050), 0.55)! : ground;
    final path = Path()..moveTo(0, size.height * 0.8);
    if (bg == 'sea') {
      for (var x = 0.0; x <= size.width; x += 8) {
        path.lineTo(x, size.height * 0.8 + math.sin((x / 40) + t * math.pi * 2) * 4);
      }
    } else {
      path.quadraticBezierTo(size.width * 0.3, size.height * 0.7, size.width * 0.55, size.height * 0.78);
      path.quadraticBezierTo(size.width * 0.8, size.height * 0.86, size.width, size.height * 0.74);
    }
    path
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(path, g);

    // the river: a gentle blue band with moving ripples
    if (bg == 'river') {
      final top = size.height * 0.84;
      final water = Path()..moveTo(0, top);
      for (var x = 0.0; x <= size.width; x += 8) {
        water.lineTo(x, top + math.sin((x / 36) + t * math.pi * 2) * 3);
      }
      water
        ..lineTo(size.width, size.height * 0.96)
        ..lineTo(0, size.height * 0.96)
        ..close();
      canvas.drawPath(water, Paint()..color = soften(const Color(0xFF5BA6D6)));
    }
  }

  @override
  bool shouldRepaint(_ScenePainter old) => old.t != t || old.bg != bg || old.night != night;
}
