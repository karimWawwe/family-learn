import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../core/widgets/common.dart';
import '../../domain/plan.dart';
import '../../state/session.dart';

/// Phase 6 placement test (real): a few questions from different points of each
/// course, marked on the server. Lessons the learner already knows open at once.
class PlacementIntroScreen extends ConsumerWidget {
  const PlacementIntroScreen({super.key, required this.profileId});

  final String profileId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    return AccountScaffold(
      title: s.t('placementTitle'),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text(p.avatarEmoji, textAlign: TextAlign.center, style: const TextStyle(fontSize: 64)),
          const SizedBox(height: 12),
          Text(s.t('placementBody'), style: context.text.bodyLarge, textAlign: TextAlign.center),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _Point(icon: '📝', text: s.t('placementPoint1')),
                  _Point(icon: '🔓', text: s.t('placementPoint2')),
                  _Point(icon: '🔁', text: s.t('placementPoint3')),
                ],
              ),
            ),
          ),
          const SizedBox(height: 28),
          FilledButton(
            onPressed: () => context.push(Routes.placementRun(profileId)),
            child: Text(s.t('startTest')),
          ),
          TextButton(onPressed: () => context.go(Routes.home), child: Text(s.t('placementLater'))),
        ],
      ),
    );
  }
}

class _Point extends StatelessWidget {
  const _Point({required this.icon, required this.text});

  final String icon;
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(icon, style: const TextStyle(fontSize: 20)),
            const SizedBox(width: 10),
            Expanded(child: Text(text, style: context.text.bodyMedium)),
          ],
        ),
      );
}

class PlacementResultScreen extends ConsumerWidget {
  const PlacementResultScreen({super.key, this.outcome});

  final PracticeOutcome? outcome;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final o = outcome;
    return AccountScaffold(
      title: s.t('placementResult'),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          const SizedBox(height: 16),
          const Text('🧭', textAlign: TextAlign.center, style: TextStyle(fontSize: 64)),
          if (o != null) ...[
            const SizedBox(height: 8),
            Text('${o.correct}/${o.total}', textAlign: TextAlign.center, style: context.text.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
              child: Text(s.t('placementDoneNote'), textAlign: TextAlign.center, style: context.text.bodyMedium),
            ),
            SectionTitle(s.t('startLevel')),
            for (final c in o.placements)
              Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: ListTile(
                  leading: Icon(c.placedPosition > 0 ? Icons.rocket_launch_outlined : Icons.flag_outlined,
                      color: c.placedPosition > 0 ? AppTokens.good : context.colors.primary),
                  title: Text(c.title),
                  subtitle: Text(
                    [
                      c.placedPosition > 0 ? s.f('placementSkipped', [c.placedPosition, c.lessons]) : s.t('placementFromStart'),
                      if (c.startLesson != null) '${s.t('planLessonTitle')}: ${c.startLesson}',
                    ].join('\n'),
                  ),
                  isThreeLine: c.startLesson != null,
                ),
              ),
          ] else
            EmptyState(emoji: '🧭', message: s.t('placementDoneNote')),
          Padding(
            padding: const EdgeInsets.all(16),
            child: FilledButton(onPressed: () => context.go(Routes.home), child: Text(s.t('continue'))),
          ),
          TextButton(onPressed: () => context.go(Routes.learn), child: Text(s.t('courses'))),
        ],
      ),
    );
  }
}
