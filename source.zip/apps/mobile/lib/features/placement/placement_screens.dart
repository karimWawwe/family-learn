import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/mock/mock_data.dart';
import '../../state/session.dart';

class PlacementIntroScreen extends ConsumerWidget {
  const PlacementIntroScreen({super.key, required this.profileId});

  final String profileId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final areas = p.isChild
        ? ['Vocabulary', 'Grammar', 'Reading', 'Listening', 'Speaking', 'Writing', 'Math']
        : ['General English', 'Business English', 'Sales vocabulary', 'Speaking'];
    return MockScaffold(
      title: s.t('placementTitle'),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text(p.avatarEmoji, textAlign: TextAlign.center, style: const TextStyle(fontSize: 64)),
          const SizedBox(height: 12),
          Text(s.t('placementBody'), style: context.text.bodyLarge, textAlign: TextAlign.center),
          const SizedBox(height: 20),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [for (final a in areas) Chip(label: Text(a))],
          ),
          const SizedBox(height: 28),
          FilledButton(
            onPressed: () => context.push(Routes.placementRun(profileId)),
            child: Text(s.t('startTest')),
          ),
        ],
      ),
    );
  }
}

class PlacementResultScreen extends ConsumerWidget {
  const PlacementResultScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final skills = MockData.masteryFor(p);
    final courses = MockData.coursesFor(p);
    return MockScaffold(
      title: s.t('placementResult'),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          SectionTitle(s.t('startLevel')),
          for (final c in courses)
            ListTile(
              leading: const Icon(Icons.flag_outlined),
              title: Text(c.title),
              trailing: Text(c.levelLabel, style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          SectionTitle(s.t('skills')),
          for (final sk in skills) MasteryBar(label: sk.name, value: sk.mastery),
          Padding(
            padding: const EdgeInsets.all(16),
            child: FilledButton(onPressed: () => context.go(Routes.home), child: Text(s.t('continue'))),
          ),
        ],
      ),
    );
  }
}
