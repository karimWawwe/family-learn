import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../core/widgets/common.dart';
import '../../domain/models.dart';
import '../../domain/plan.dart';
import '../../state/plan.dart';

// Phase 6: today's plan on the home screen + the result screens of a review
// session. Everything here comes from the server (daily_plan / finish_practice).

/// Opens one task of today's plan.
void openPlanTask(BuildContext context, PlanTask t) {
  switch (t.kind) {
    case PlanTaskKind.review:
      context.push(Routes.reviewRun);
    case PlanTaskKind.lesson:
      if (t.lessonId != null) {
        context.push(Routes.lesson(t.lessonId!));
      } else {
        context.go(Routes.learn);
      }
    case PlanTaskKind.speak:
      context.push(Routes.speak);
  }
}

IconData planTaskIcon(PlanTaskKind k) => switch (k) {
      PlanTaskKind.review => Icons.replay,
      PlanTaskKind.lesson => Icons.play_lesson_outlined,
      PlanTaskKind.speak => Icons.mic_none,
    };

String planTaskEmoji(PlanTaskKind k) => switch (k) {
      PlanTaskKind.review => '🔁',
      PlanTaskKind.lesson => '📘',
      PlanTaskKind.speak => '🎤',
    };

String planTaskTitle(AppStrings s, PlanTask t) => switch (t.kind) {
      PlanTaskKind.review => s.f('planReviewTitle', [t.count]),
      PlanTaskKind.lesson => s.t('planLessonTitle'),
      PlanTaskKind.speak => s.t('planSpeakTitle'),
    };

String planTaskSubtitle(AppStrings s, PlanTask t) => switch (t.kind) {
      PlanTaskKind.review => s.t('planReviewSub'),
      PlanTaskKind.lesson => [t.title, t.course].whereType<String>().where((x) => x.isNotEmpty).join(' · '),
      PlanTaskKind.speak => s.t('planSpeakSub'),
    };

/// Today's plan: progress, the tasks (done / to do) and the placement suggestion.
/// [kid] = big colourful card for children, plain list for adults.
class TodayPlanSection extends ConsumerWidget {
  const TodayPlanSection({super.key, required this.profile, required this.kid});

  final LearnerProfile profile;
  final bool kid;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final value = ref.watch(dailyPlanProvider(profile.id));
    final plan = value.valueOrNull;
    if (plan == null) {
      if (value.isLoading) {
        return const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()));
      }
      // Error (offline, or the Phase 6 database update not installed yet): stay quiet.
      return const SizedBox.shrink();
    }
    final next = plan.nextTask;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (plan.suggestPlacement) _PlacementBanner(profile: profile),
        if (kid) _KidMission(plan: plan, next: next) else _ProSummary(plan: plan),
        if (plan.tasks.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(s.t('planNoTasks'), style: context.text.bodyMedium),
          ),
        for (final t in plan.tasks) _TaskTile(task: t, kid: kid),
      ],
    );
  }
}

class _KidMission extends StatelessWidget {
  const _KidMission({required this.plan, required this.next});

  final DailyPlan plan;
  final PlanTask? next;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final onP = context.colors.onPrimary;
    final goal = plan.goalMinutes;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Card(
        color: context.colors.primary,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(s.t('todaysMission'),
                        style: context.text.titleLarge?.copyWith(color: onP, fontWeight: FontWeight.w800)),
                  ),
                  Text(plan.allDone ? '🏆' : '🎯', style: const TextStyle(fontSize: 28)),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                plan.allDone ? s.t('planAllDone') : s.f('planDone', [plan.done, plan.total]),
                style: TextStyle(color: onP, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: plan.progress,
                  minHeight: 12,
                  color: const Color(0xFFFFD166),
                  backgroundColor: onP.withValues(alpha: 0.25),
                ),
              ),
              const SizedBox(height: 6),
              Text(s.f('minutesOfGoal', [plan.minutesToday, goal]), style: TextStyle(color: onP.withValues(alpha: 0.9))),
              if (next != null) ...[
                const SizedBox(height: 14),
                FilledButton.tonal(
                  onPressed: () => openPlanTask(context, next!),
                  child: Text('${s.t('planStart')}: ${planTaskTitle(s, next!)}', overflow: TextOverflow.ellipsis),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _ProSummary extends StatelessWidget {
  const _ProSummary({required this.plan});

  final DailyPlan plan;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(s.t('todaysPlan'), style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w700))),
              Text(plan.allDone ? s.t('planAllDone') : s.f('planDone', [plan.done, plan.total]),
                  style: TextStyle(fontWeight: FontWeight.w700, color: plan.allDone ? AppTokens.good : context.colors.primary)),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: plan.progress,
              minHeight: 8,
              color: plan.allDone ? AppTokens.good : context.colors.primary,
              backgroundColor: context.colors.surfaceContainerHighest,
            ),
          ),
        ],
      ),
    );
  }
}

class _TaskTile extends StatelessWidget {
  const _TaskTile({required this.task, required this.kid});

  final PlanTask task;
  final bool kid;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final done = task.done;
    final sub = planTaskSubtitle(s, task);
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: kid ? 5 : 3),
      child: Card(
        child: ListTile(
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: kid ? 8 : 2),
          leading: CircleAvatar(
            backgroundColor: done ? AppTokens.good : context.colors.secondaryContainer,
            child: done
                ? const Icon(Icons.check, color: Colors.white)
                : (kid
                    ? Text(planTaskEmoji(task.kind), style: const TextStyle(fontSize: 20))
                    : Icon(planTaskIcon(task.kind), color: context.colors.onSecondaryContainer)),
          ),
          title: Text(
            planTaskTitle(s, task),
            style: TextStyle(
              fontWeight: FontWeight.w700,
              decoration: done ? TextDecoration.lineThrough : null,
              color: done ? context.colors.onSurfaceVariant : null,
            ),
          ),
          subtitle: sub.isEmpty ? null : Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis),
          trailing: done ? const Text('✅') : Text(s.f('minutes', [task.minutes])),
          onTap: () => openPlanTask(context, task),
        ),
      ),
    );
  }
}

class _PlacementBanner extends StatelessWidget {
  const _PlacementBanner({required this.profile});

  final LearnerProfile profile;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Card(
        color: const Color(0xFFFFF4D6),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          leading: const Text('🧭', style: TextStyle(fontSize: 30)),
          title: Text(s.t('placementTitle'), style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF5D4600))),
          subtitle: Text(s.t('placementSuggest'), style: const TextStyle(color: Color(0xFF5D4600))),
          trailing: const Icon(Icons.chevron_right, color: Color(0xFF5D4600)),
          onTap: () => context.push(Routes.placement(profile.id)),
        ),
      ),
    );
  }
}

/// Weak skills from the review box (mastery under 40% with at least 3 questions).
class WeakSkillsChips extends ConsumerWidget {
  const WeakSkillsChips({super.key, required this.profileId});

  final String profileId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final weak = ref.watch(reviewOverviewProvider(profileId)).valueOrNull?.weakSkills ?? const <SkillMasteryInfo>[];
    if (weak.isEmpty) return const SizedBox.shrink();
    final s = context.s;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SectionTitle(s.t('weakAreas')),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final w in weak.take(6))
                ActionChip(
                  avatar: const Text('💪'),
                  label: Text('${w.name} ${(w.mastery * 100).round()}%'),
                  onPressed: () => context.go(Routes.review),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

/// Mastery bars per skill (from the review box).
class SkillMasteryList extends ConsumerWidget {
  const SkillMasteryList({super.key, required this.profileId});

  final String profileId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final skills = ref.watch(reviewOverviewProvider(profileId)).valueOrNull?.skills;
    if (skills == null) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SectionTitle(s.t('skills')),
        if (skills.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(s.t('skillsMasteryEmpty'), style: context.text.bodyMedium),
          ),
        for (final sk in skills) MasteryBar(label: sk.name, value: sk.mastery),
      ],
    );
  }
}

// ---------------------------------------------------------------- review finished

class PracticeCompleteScreen extends StatelessWidget {
  const PracticeCompleteScreen({super.key, this.outcome});

  final PracticeOutcome? outcome;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final o = outcome;
    return AccountScaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(o == null || o.percent >= 70 ? '🧠' : '💪', style: const TextStyle(fontSize: 80)),
              const SizedBox(height: 12),
              Text(s.t('reviewSessionDone'), style: context.text.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
              if (o != null) ...[
                const SizedBox(height: 8),
                Semantics(
                  label: s.f('starsOf', [o.stars]),
                  child: Text('⭐' * o.stars + '☆' * (3 - o.stars), style: const TextStyle(fontSize: 32)),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(child: StatTile(label: s.t('accuracy'), value: '${o.correct}/${o.total}', icon: Icons.track_changes)),
                    Expanded(child: StatTile(label: 'XP', value: s.f('xpEarned', [o.xp]), icon: Icons.bolt, color: AppTokens.xp)),
                    Expanded(child: StatTile(label: s.t('coins'), value: '+${o.coins}', icon: Icons.monetization_on, color: AppTokens.coin)),
                  ],
                ),
                const SizedBox(height: 12),
                Text(s.t('reviewBoxNote'), textAlign: TextAlign.center, style: context.text.bodyMedium),
                if (o.wallet.streakDays > 0) ...[
                  const SizedBox(height: 8),
                  Text('🔥 ${s.f('streak', [o.wallet.streakDays])}', style: context.text.titleMedium),
                ],
              ],
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: FilledButton(onPressed: () => context.go(Routes.home), child: Text(s.t('navHome'))),
              ),
              TextButton(onPressed: () => context.go(Routes.review), child: Text(s.t('reviewToday'))),
            ],
          ),
        ),
      ),
    );
  }
}
