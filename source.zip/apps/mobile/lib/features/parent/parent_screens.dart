import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../core/widgets/common.dart';
import '../../domain/learning.dart';
import '../../domain/models.dart';
import '../../state/account.dart';
import '../../state/learning.dart';
import '../../state/session.dart';
import '../speak_game/speak_game_screens.dart';
import '../eng_unit/eng_unit_screens.dart';
import 'family_admin_screens.dart';

/// Parent-only: the router opens it only for the parent's profile on the
/// parent's account, and the database (RLS) never gives a child's phone
/// another profile's data.
/// Phase 4: the family, profiles AND study figures are REAL (from finished
/// lessons). Mastery-based review arrives in Phase 6.
class ParentDashboardScreen extends ConsumerWidget {
  const ParentDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(currentProfileProvider);
    final account = ref.watch(accountProvider).valueOrNull;
    if (p == null || account == null) return const SizedBox.shrink();
    final s = context.s;
    if (!p.isParent || !account.isParentAccount) {
      return MockScaffold(title: s.t('parentDashboard'), body: EmptyState(emoji: '🔒', message: s.t('parentsOnly')));
    }
    final children = account.children;
    final adults = account.adults;
    return AccountScaffold(
      title: s.t('parentDashboard'),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          if (children.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: FilledButton.icon(
                onPressed: () => context.push(Routes.parentFollow),
                icon: const Icon(Icons.monitor_heart_outlined),
                label: Text(s.isArabic ? 'لوحة متابعة الوالدين' : 'Parent follow-up'),
              ),
            ),
          if (children.isEmpty) EmptyState(emoji: '👶', message: s.t('noChildrenYet')),
          for (final c in children) _ChildCard(child: c),
          SectionTitle(s.t('adults')),
          for (final a in adults)
            ListTile(
              leading: Text(a.avatarEmoji, style: const TextStyle(fontSize: 28)),
              title: Text(a.displayName),
              subtitle: Text(s.t(a.hasPin ? 'pinOn' : 'pinOff')),
              trailing: const Icon(Icons.pin_outlined),
              onTap: () => context.push(Routes.setPin(a.id)),
            ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => context.push(Routes.addLearner),
            icon: const Icon(Icons.person_add_alt_1),
            label: Text(s.t('addLearner')),
          ),
        ],
      ),
    );
  }
}

String _pct(double? v) => v == null ? '–' : '${(v * 100).round()}%';

class _ChildCard extends ConsumerWidget {
  const _ChildCard({required this.child});

  final LearnerProfile child;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final async = ref.watch(reportProvider(child.id));
    final r = async.valueOrNull;
    final goal = child.dailyMinutesGoal;
    final today = r?.minutesToday ?? 0;
    final goalPct = goal == 0 ? 0.0 : (today / goal).clamp(0.0, 1.0).toDouble();
    final weak = r?.weakSkills ?? const <SkillStat>[];
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppTokens.radiusPro),
        onTap: () => context.push(Routes.childReport(child.id)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(child.avatarEmoji, style: const TextStyle(fontSize: 36)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(child.displayName, style: context.text.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                        Text('${s.t('grade')} ${child.grade} · 🔥 ${r?.streakDays ?? 0}'),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right),
                ],
              ),
              const SizedBox(height: 12),
              if (async.hasError) ErrorText(failureText(context, async.error!)),
              Text('${s.t('dailyGoal')}: ${s.f('minutesOfGoal', [today, goal])}'),
              const SizedBox(height: 6),
              LinearProgressIndicator(value: goalPct, minHeight: 8, borderRadius: BorderRadius.circular(8)),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _Mini(label: s.t('accuracy'), value: _pct(r?.week.accuracy))),
                  Expanded(child: _Mini(label: s.t('questionsSolved'), value: '${r?.week.questions ?? 0}')),
                  Expanded(child: _Mini(label: s.t('studyTime'), value: s.f('minutes', [r?.week.minutes ?? 0]))),
                ],
              ),
              if (weak.isNotEmpty) ...[
                const SizedBox(height: 10),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final w in weak)
                      Chip(
                        visualDensity: VisualDensity.compact,
                        avatar: const Icon(Icons.trending_down, size: 16, color: AppTokens.bad),
                        label: Text(w.name, textDirection: TextDirection.ltr),
                      ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _Mini extends StatelessWidget {
  const _Mini({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(value, style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
        Text(label, style: context.text.bodySmall),
      ],
    );
  }
}

enum _Range { day, week, month }

class ChildReportScreen extends ConsumerStatefulWidget {
  const ChildReportScreen({super.key, required this.profileId});

  final String profileId;

  @override
  ConsumerState<ChildReportScreen> createState() => _ChildReportScreenState();
}

class _ChildReportScreenState extends ConsumerState<ChildReportScreen> {
  _Range _range = _Range.week;
  bool _notifications = true;
  double? _goal; // while dragging
  String? _saveError;

  Future<void> _update({int? goal, bool? ai}) async {
    setState(() => _saveError = null);
    try {
      await ref.read(accountProvider.notifier).run(
            (r) => r.updateProfile(widget.profileId, dailyMinutesGoal: goal, aiEnabled: ai),
          );
    } catch (e) {
      if (mounted) setState(() => _saveError = failureText(context, e));
    } finally {
      if (mounted) setState(() => _goal = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = ref.watch(currentProfileProvider);
    final account = ref.watch(accountProvider).valueOrNull;
    if (me == null || account == null) return const SizedBox.shrink();
    final s = context.s;
    final child = account.profileById(widget.profileId);
    // Only the parent may open a child's report, and only for a child in this family.
    if (!me.isParent || !account.isParentAccount || child == null || !child.isChild) {
      return MockScaffold(title: s.t('parentDashboard'), body: EmptyState(emoji: '🔒', message: s.t('parentsOnly')));
    }
    final goal = _goal ?? child.dailyMinutesGoal.toDouble();
    final async = ref.watch(reportProvider(child.id));
    final r = async.valueOrNull;
    final range = r == null ? const RangeStats() : switch (_range) { _Range.day => r.today, _Range.week => r.week, _Range.month => r.month };
    final byDay = r?.minutesByDay ?? const [0, 0, 0, 0, 0, 0, 0];
    final maxBar = byDay.fold<int>(1, (m, v) => v > m ? v : m);

    return AccountScaffold(
      title: '${child.avatarEmoji} ${child.displayName}',
      body: RefreshIndicator(
       onRefresh: () async {
         try {
           await ref.refresh(reportProvider(child.id).future);
         } catch (_) {
           // the error is shown at the top of the list
         }
       },
       child: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          if (async.hasError)
            Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: ErrorText(failureText(context, async.error!))),
          if (async.isLoading && r == null) const LinearProgressIndicator(),
          Padding(
            padding: const EdgeInsets.all(16),
            child: SegmentedButton<_Range>(
              segments: [
                ButtonSegment(value: _Range.day, label: Text(s.t('today'))),
                ButtonSegment(value: _Range.week, label: Text(s.t('thisWeek'))),
                const ButtonSegment(value: _Range.month, label: Text('30d')),
              ],
              selected: {_range},
              onSelectionChanged: (v) => setState(() => _range = v.first),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                Expanded(child: StatTile(label: s.t('studyTime'), value: s.f('minutes', [range.minutes]), icon: Icons.timer_outlined)),
                Expanded(child: StatTile(label: s.t('questionsSolved'), value: '${range.questions}', icon: Icons.quiz_outlined)),
                Expanded(child: StatTile(label: s.t('accuracy'), value: _pct(range.accuracy), icon: Icons.track_changes)),
              ],
            ),
          ),
          SectionTitle(s.t('studyTime')),
          SizedBox(
            height: 140,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  for (var i = 0; i < byDay.length; i++)
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text('${byDay[i]}', style: context.text.labelSmall),
                          const SizedBox(height: 4),
                          Container(
                            height: 90 * byDay[i] / maxBar,
                            margin: const EdgeInsets.symmetric(horizontal: 6),
                            decoration: BoxDecoration(
                              color: byDay[i] >= child.dailyMinutesGoal && byDay[i] > 0 ? AppTokens.good : context.colors.primary,
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(i == byDay.length - 1 ? s.t('today') : '-${byDay.length - 1 - i}', style: context.text.labelSmall),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
          SectionTitle(s.t('courseProgress')),
          if (r != null && r.courses.isEmpty) ListTile(dense: true, title: Text(s.t('noDataYet'))),
          for (final c in r?.courses ?? const <CourseProgress>[]) _CourseProgressTile(c: c),
          SectionTitle(s.t('skills')),
          if ((r?.skills ?? const []).isEmpty) ListTile(dense: true, title: Text(s.t('noDataYet'))),
          for (final sk in r?.skills ?? const <SkillStat>[])
            MasteryBar(label: '${sk.name}${sk.isWeak ? '  ⚠' : ''} (${sk.answers})', value: sk.accuracy),
          SectionTitle(s.t('topicsToReview')),
          if ((r?.toReview ?? const []).isEmpty) ListTile(dense: true, title: Text(s.t('noDataYet'))),
          for (final t in r?.toReview ?? const <String>[])
            ListTile(dense: true, leading: const Icon(Icons.replay), title: Text(t, textDirection: TextDirection.ltr)),
          SpeakReportCard(profileId: child.id),
          EngUnitReportCard(profileId: child.id),
          SectionTitle(s.t('learningHistory')),
          if ((r?.history ?? const []).isEmpty) ListTile(dense: true, title: Text(s.t('noDataYet'))),
          for (final h in r?.history ?? const <HistoryEntry>[])
            ListTile(
              dense: true,
              leading: const Icon(Icons.history),
              title: Text(h.lesson, textDirection: TextDirection.ltr),
              subtitle: Text(MaterialLocalizations.of(context).formatShortDate(h.finishedAt)),
              trailing: Text('${h.correct}/${h.total}', style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          SectionTitle(s.f('childSettings', [child.displayName])),
          ListTile(
            title: Text(s.t('dailyGoal')),
            subtitle: Slider(
              value: goal.clamp(10, 60).toDouble(),
              min: 10,
              max: 60,
              divisions: 10,
              label: s.f('minutes', [goal.round()]),
              onChanged: (v) => setState(() => _goal = v),
              onChangeEnd: (v) => _update(goal: v.round()),
            ),
            trailing: Text(s.f('minutes', [goal.round()])),
          ),
          SwitchListTile(value: child.aiEnabled, onChanged: (v) => _update(ai: v), title: Text(s.t('aiEnabled'))),
          if (_saveError != null) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: ErrorText(_saveError)),
          ListTile(
            leading: const Icon(Icons.pin_outlined),
            title: Text(s.t('profilePin')),
            subtitle: Text(s.t(child.hasPin ? 'pinOn' : 'pinOff')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push(Routes.setPin(child.id)),
          ),
          LinkedPhonesSection(profileId: child.id, onLink: () => context.push(Routes.linkDevice(child.id))),
          // Notifications arrive in Phase 12; this switch is not saved yet.
          SwitchListTile(value: _notifications, onChanged: (v) => setState(() => _notifications = v), title: Text(s.t('notifications'))),
          ListTile(
            leading: const Icon(Icons.forum_outlined),
            title: Text(s.t('aiLogs')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push(Routes.aiLogs(child.id)),
          ),
          const PendingNote('reportNote'),
        ],
       ),
      ),
    );
  }
}

/// One course in the child report: % of lessons done, score, last activity; tap for details.
class _CourseProgressTile extends StatelessWidget {
  const _CourseProgressTile({required this.c});

  final CourseProgress c;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final date = MaterialLocalizations.of(context);
    final pct = (c.completion * 100).round();
    final info = [
      s.f('lessonsOf', [c.lessonsDone, c.lessonsTotal]),
      if (c.score != null) '${s.t('scoreLabel')} ${_pct(c.score)}',
      if (c.lastActivity != null) '${s.t('lastActivity')}: ${date.formatShortDate(c.lastActivity!)}',
      if (!c.started) s.t('notStarted'),
    ].join(' · ');
    Widget chips(String label, List<String> items, Color color) => Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: context.text.labelLarge?.copyWith(color: color, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Wrap(spacing: 6, runSpacing: 6, children: [
                for (final i in items)
                  Chip(
                    label: Text(i),
                    visualDensity: VisualDensity.compact,
                    side: BorderSide(color: color.withValues(alpha: 0.4)),
                  ),
              ]),
            ],
          ),
        );
    return ExpansionTile(
      tilePadding: const EdgeInsets.symmetric(horizontal: 16),
      childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      expandedCrossAxisAlignment: CrossAxisAlignment.start,
      title: Row(
        children: [
          Expanded(child: Text(c.title, maxLines: 2, overflow: TextOverflow.ellipsis)),
          const SizedBox(width: 8),
          Text('$pct%', style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: c.completion,
              minHeight: 8,
              color: c.completion >= 1 ? AppTokens.good : null,
            ),
          ),
          const SizedBox(height: 4),
          Text(info, style: context.text.bodySmall),
        ],
      ),
      children: [
        if (c.nextLesson != null)
          ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.play_circle_outline),
            title: Text(s.t('courseNextLesson')),
            subtitle: Text(c.nextLesson!),
          ),
        if (c.tests.isNotEmpty) ...[
          Text(s.t('recentResults'), style: context.text.labelLarge?.copyWith(fontWeight: FontWeight.w700)),
          for (final t in c.tests)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text(t.lesson),
              subtitle: Text(date.formatShortDate(t.finishedAt)),
              trailing: Text('${t.correct}/${t.total}', style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
        ],
        if (c.strong.isNotEmpty) chips('💪 ${s.t('strengths')}', c.strong, AppTokens.good),
        if (c.weak.isNotEmpty) chips('⚠ ${s.t('needsWork')}', c.weak, AppTokens.warn),
        if (c.toReview.isNotEmpty) chips('🔁 ${s.t('reviewItems')}', c.toReview, AppTokens.bad),
        if (!c.started) Text(s.t('notStarted'), style: context.text.bodySmall),
      ],
    );
  }
}
