import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../core/widgets/common.dart';
import '../../domain/account.dart';
import '../../state/account.dart';
import '../onboarding/learner_form.dart';
import '../profiles/profile_screens.dart';

// Parent-only screens (the router only opens them for the parent's profile,
// and the database refuses these actions from anyone else).

/// Children's phones linked to the family (parent only).
final linkedDevicesProvider = FutureProvider.autoDispose<List<LinkedDevice>>(
  (ref) {
    ref.watch(accountProvider); // reload when the family changes
    return ref.read(authRepositoryProvider).linkedDevices();
  },
);

// ---------------------------------------------------------------- link a child's phone

class LinkDeviceScreen extends ConsumerStatefulWidget {
  const LinkDeviceScreen({super.key, required this.profileId});

  final String profileId;

  @override
  ConsumerState<LinkDeviceScreen> createState() => _LinkDeviceScreenState();
}

class _LinkDeviceScreenState extends ConsumerState<LinkDeviceScreen> {
  PairingCode? _code;
  String? _error;
  bool _loading = true;
  bool _linked = false;
  Timer? _tick;
  Timer? _poll;
  Set<String> _devicesBefore = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _newCode();
    });
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    _poll?.cancel();
    super.dispose();
  }

  Future<void> _newCode() async {
    final repo = ref.read(authRepositoryProvider);
    setState(() {
      _loading = true;
      _error = null;
      _linked = false;
    });
    try {
      final before = await repo.linkedDevices();
      final code = await repo.createPairingCode(widget.profileId);
      if (!mounted) return;
      setState(() {
        _devicesBefore = {for (final d in before) d.userId};
        _code = code;
      });
      _startPolling();
    } catch (e) {
      if (mounted) setState(() => _error = failureText(context, e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  /// Watches for the child's phone to use the code.
  void _startPolling() {
    _poll?.cancel();
    _poll = Timer.periodic(const Duration(seconds: 4), (_) async {
      if (!mounted || _linked) return;
      try {
        final now = await ref.read(authRepositoryProvider).linkedDevices();
        final fresh = now.any((d) => d.profileId == widget.profileId && !_devicesBefore.contains(d.userId));
        if (fresh && mounted) {
          _poll?.cancel();
          setState(() => _linked = true);
          ref.invalidate(linkedDevicesProvider);
        }
      } catch (_) {
        // keep waiting; the code screen still works
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final child = ref.watch(accountProvider).valueOrNull?.profileById(widget.profileId);
    final code = _code;
    final left = code == null ? Duration.zero : code.expiresAt.difference(DateTime.now());
    final expired = code != null && left.isNegative;
    final mmss = '${left.inMinutes.clamp(0, 99)}:${(left.inSeconds % 60).clamp(0, 59).toString().padLeft(2, '0')}';

    return AccountScaffold(
      title: s.f('linkPhoneOf', [child?.displayName ?? '']),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          if (_linked) ...[
            const Icon(Icons.check_circle, size: 72, color: AppTokens.good),
            const SizedBox(height: 12),
            Text(s.f('phoneLinked', [child?.displayName ?? '']), textAlign: TextAlign.center, style: context.text.titleLarge),
            const SizedBox(height: 24),
            FilledButton(onPressed: () => context.pop(), child: Text(s.t('done'))),
          ] else ...[
            Text(s.f('linkSteps', [child?.displayName ?? '']), style: context.text.bodyLarge),
            const SizedBox(height: 24),
            if (_loading && code == null) const Center(child: CircularProgressIndicator()),
            if (code != null)
              Semantics(
                label: s.t('linkCode'),
                value: code.code.split('').join(' '),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  decoration: BoxDecoration(
                    color: context.colors.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(
                    expired ? '— — — — — —' : code.code,
                    textAlign: TextAlign.center,
                    textDirection: TextDirection.ltr,
                    style: context.text.displaySmall?.copyWith(
                      letterSpacing: 10,
                      fontWeight: FontWeight.w800,
                      fontFeatures: const [FontFeature.tabularFigures()],
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 12),
            if (code != null)
              Text(
                expired ? s.t('codeExpired') : s.f('codeValidFor', [mmss]),
                textAlign: TextAlign.center,
                style: context.text.bodyMedium?.copyWith(color: expired ? AppTokens.bad : null),
              ),
            if (code != null && !expired) ...[
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
                  const SizedBox(width: 8),
                  Text(s.t('waitingForPhone'), style: context.text.bodySmall),
                ],
              ),
            ],
            ErrorText(_error),
            const SizedBox(height: 20),
            OutlinedButton.icon(
              onPressed: _loading ? null : _newCode,
              icon: const Icon(Icons.refresh),
              label: Text(s.t('newCode')),
            ),
          ],
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- set / remove a PIN

class SetPinScreen extends ConsumerStatefulWidget {
  const SetPinScreen({super.key, required this.profileId});

  final String profileId;

  @override
  ConsumerState<SetPinScreen> createState() => _SetPinScreenState();
}

class _SetPinScreenState extends ConsumerState<SetPinScreen> {
  String _first = '';
  String _pin = '';
  bool _confirming = false;
  bool _saving = false;
  String? _message;

  Future<void> _save(String? pin) async {
    setState(() {
      _saving = true;
      _message = null;
    });
    try {
      await ref.read(accountProvider.notifier).run((r) => r.setPin(widget.profileId, pin));
      if (!mounted) return;
      final s = context.s;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t(pin == null ? 'pinRemoved' : 'pinSaved'))));
      context.pop();
    } catch (e) {
      if (mounted) {
        setState(() {
          _message = failureText(context, e);
          _saving = false;
        });
      }
    }
  }

  void _digit(String d) {
    if (_saving || _pin.length >= 4) return;
    setState(() {
      _pin += d;
      _message = null;
    });
    if (_pin.length < 4) return;
    if (!_confirming) {
      setState(() {
        _first = _pin;
        _pin = '';
        _confirming = true;
      });
    } else if (_pin == _first) {
      _save(_pin);
    } else {
      setState(() {
        _pin = '';
        _first = '';
        _confirming = false;
        _message = context.s.t('pinMismatch');
      });
    }
  }

  void _delete() {
    if (_pin.isEmpty || _saving) return;
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = ref.watch(accountProvider).valueOrNull?.profileById(widget.profileId);
    if (p == null) return const AccountScaffold(body: SizedBox.shrink());
    return AccountScaffold(
      title: s.f('pinFor', [p.displayName]),
      body: Column(
        children: [
          const SizedBox(height: 24),
          Text(p.avatarEmoji, style: const TextStyle(fontSize: 56)),
          const SizedBox(height: 8),
          Text(s.t(_confirming ? 'pinConfirm' : 'pinChoose'), style: context.text.titleLarge),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Text(s.t('pinExplain'), textAlign: TextAlign.center, style: context.text.bodySmall),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 0; i < 4; i++)
                Container(
                  margin: const EdgeInsets.all(8),
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: i < _pin.length ? context.colors.primary : context.colors.surfaceContainerHighest,
                  ),
                ),
            ],
          ),
          if (_message != null) Text(_message!, style: TextStyle(color: context.colors.error)),
          if (_saving) const Padding(padding: EdgeInsets.all(8), child: CircularProgressIndicator()),
          const Spacer(),
          PinPad(onDigit: _digit, onDelete: _delete),
          if (p.hasPin)
            TextButton.icon(
              onPressed: _saving ? null : () => _save(null),
              icon: const Icon(Icons.lock_open),
              label: Text(s.t('removePin')),
            ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- add a learner later

class AddLearnerScreen extends ConsumerStatefulWidget {
  const AddLearnerScreen({super.key});

  @override
  ConsumerState<AddLearnerScreen> createState() => _AddLearnerScreenState();
}

class _AddLearnerScreenState extends ConsumerState<AddLearnerScreen> with BusyForm<AddLearnerScreen> {
  final _form = GlobalKey<FormState>();
  final _draft = LearnerDraft();

  @override
  void dispose() {
    _draft.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    final learner = _draft.toNewLearner();
    await guard(() async {
      await ref.read(accountProvider.notifier).run((r) => r.addProfile(learner));
      if (mounted) context.pop();
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AccountScaffold(
      title: s.t('addLearner'),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            LearnerCard(draft: _draft, onChanged: () => setState(() {})),
            ErrorText(error),
            const SizedBox(height: 16),
            BusyButton(label: s.t('save'), busy: busy, onPressed: _submit),
          ],
        ),
      ),
    );
  }
}

/// "Phones" section for one child on the child report: linked phones + unlink.
class LinkedPhonesSection extends ConsumerWidget {
  const LinkedPhonesSection({super.key, required this.profileId, required this.onLink});

  final String profileId;
  final VoidCallback onLink;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final devices = ref.watch(linkedDevicesProvider);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SectionTitle(s.t('phones')),
        devices.when(
          loading: () => const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())),
          error: (e, _) => Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: ErrorText(failureText(context, e))),
          data: (all) {
            final mine = all.where((d) => d.profileId == profileId).toList();
            if (mine.isEmpty) {
              return ListTile(leading: const Icon(Icons.phonelink_off), title: Text(s.t('noPhoneLinked')));
            }
            return Column(
              children: [
                for (final d in mine)
                  ListTile(
                    leading: const Icon(Icons.smartphone),
                    title: Text(d.deviceName ?? s.t('childPhone')),
                    subtitle: Text(s.f('lastSeen', [MaterialLocalizations.of(context).formatShortDate(d.lastSeenAt)])),
                    trailing: TextButton(
                      onPressed: () => _confirmUnlink(context, ref, d),
                      child: Text(s.t('unlink')),
                    ),
                  ),
              ],
            );
          },
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: OutlinedButton.icon(onPressed: onLink, icon: const Icon(Icons.qr_code_2), label: Text(s.t('linkPhone'))),
        ),
      ],
    );
  }

  Future<void> _confirmUnlink(BuildContext context, WidgetRef ref, LinkedDevice d) async {
    final s = context.s;
    final yes = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(s.t('unlinkTitle')),
        content: Text(s.t('unlinkBody')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(s.t('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(s.t('unlink'))),
        ],
      ),
    );
    if (yes != true) return;
    try {
      await ref.read(authRepositoryProvider).unlinkDevice(d.userId);
      ref.invalidate(linkedDevicesProvider);
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(failureText(context, e))));
      }
    }
  }
}
