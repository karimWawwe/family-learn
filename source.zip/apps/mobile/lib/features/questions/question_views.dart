import 'package:flutter/material.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/text_dir.dart';
import '../../core/theme/app_theme.dart';
import '../../domain/questions.dart';

/// Renders any question type. New types = a new Question subclass + a case
/// here + a grader in learning_core. Unknown types never crash the lesson.
///
/// [onAnswer] receives the learner's current answer (null = not answered yet).
/// [locked] is true after "Check" so the answer can't change.
class QuestionView extends StatelessWidget {
  const QuestionView({super.key, required this.question, required this.onAnswer, required this.locked});

  final Question question;
  final ValueChanged<Object?> onAnswer;
  final bool locked;

  @override
  Widget build(BuildContext context) {
    final q = question;
    final Widget body = switch (q) {
      final MultipleChoiceQuestion m => _Choices(key: ValueKey(q.id), options: m.options, onAnswer: onAnswer, locked: locked),
      TrueFalseQuestion() => _TrueFalse(key: ValueKey(q.id), onAnswer: onAnswer, locked: locked),
      final FillBlankQuestion f => _FillBlank(key: ValueKey(q.id), before: f.before, after: f.after, onAnswer: onAnswer, locked: locked),
      final MatchingQuestion m => _Matching(key: ValueKey(q.id), question: m, onAnswer: onAnswer, locked: locked),
      final OrderingQuestion o => _Ordering(key: ValueKey(q.id), question: o, onAnswer: onAnswer, locked: locked),
      final DragDropQuestion d => _DragDrop(key: ValueKey(q.id), question: d, onAnswer: onAnswer, locked: locked),
      TypingQuestion() => _Typing(key: ValueKey(q.id), onAnswer: onAnswer, locked: locked),
      final ListeningQuestion l => _Listening(key: ValueKey(q.id), question: l, onAnswer: onAnswer, locked: locked),
      final SpeakingQuestion sp => _Speaking(key: ValueKey(q.id), question: sp, onAnswer: onAnswer),
      final ReadingQuestion r => _Reading(key: ValueKey(q.id), question: r, onAnswer: onAnswer, locked: locked),
      WordProblemQuestion() => _Typing(key: ValueKey(q.id), onAnswer: onAnswer, locked: locked, numeric: true),
    };

    return Directionality(
      textDirection: contentDir(q.prompt),
      child: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(q.prompt, style: context.text.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 20),
        body,
      ],
    ),
    );
  }
}

// ------------------------------------------------------------ multiple choice
class _Choices extends StatefulWidget {
  const _Choices({super.key, required this.options, required this.onAnswer, required this.locked});

  final List<String> options;
  final ValueChanged<Object?> onAnswer;
  final bool locked;

  @override
  State<_Choices> createState() => _ChoicesState();
}

class _ChoicesState extends State<_Choices> {
  int? _selected;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        for (var i = 0; i < widget.options.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _OptionButton(
              label: widget.options[i],
              selected: _selected == i,
              onTap: widget.locked
                  ? null
                  : () {
                      setState(() => _selected = i);
                      widget.onAnswer(i);
                    },
            ),
          ),
      ],
    );
  }
}

class _OptionButton extends StatelessWidget {
  const _OptionButton({required this.label, required this.selected, required this.onTap});

  final String label;
  final bool selected;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton(
        onPressed: onTap,
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          alignment: AlignmentDirectional.centerStart,
          backgroundColor: selected ? c.primaryContainer : null,
          side: BorderSide(color: selected ? c.primary : c.outlineVariant, width: selected ? 2 : 1),
        ),
        child: Text(label, style: context.text.titleMedium),
      ),
    );
  }
}

// ------------------------------------------------------------ true / false
class _TrueFalse extends StatefulWidget {
  const _TrueFalse({super.key, required this.onAnswer, required this.locked});

  final ValueChanged<Object?> onAnswer;
  final bool locked;

  @override
  State<_TrueFalse> createState() => _TrueFalseState();
}

class _TrueFalseState extends State<_TrueFalse> {
  bool? _value;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    Widget btn(bool v, String label, IconData icon) => Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: _OptionButton(
              label: label,
              selected: _value == v,
              onTap: widget.locked
                  ? null
                  : () {
                      setState(() => _value = v);
                      widget.onAnswer(v);
                    },
            ),
          ),
        );
    return Row(children: [btn(true, s.t('true'), Icons.check), btn(false, s.t('false'), Icons.close)]);
  }
}

// ------------------------------------------------------------ fill in the blank
class _FillBlank extends StatelessWidget {
  const _FillBlank({super.key, required this.before, required this.after, required this.onAnswer, required this.locked});

  final String before;
  final String after;
  final ValueChanged<Object?> onAnswer;
  final bool locked;

  @override
  Widget build(BuildContext context) {
    // Sentences follow the content's direction (set by QuestionView).
    return Directionality(
      textDirection: Directionality.of(context),
      child: Wrap(
        crossAxisAlignment: WrapCrossAlignment.center,
        runSpacing: 8,
        children: [
          Text(before, style: context.text.titleMedium),
          SizedBox(
            width: 140,
            child: TextField(
              enabled: !locked,
              textAlign: TextAlign.center,
              autocorrect: false,
              onChanged: (v) => onAnswer(v.trim().isEmpty ? null : v),
              decoration: const InputDecoration(isDense: true),
            ),
          ),
          Text(after, style: context.text.titleMedium),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------ typing / word problem
class _Typing extends StatelessWidget {
  const _Typing({super.key, required this.onAnswer, required this.locked, this.numeric = false});

  final ValueChanged<Object?> onAnswer;
  final bool locked;
  final bool numeric;

  @override
  Widget build(BuildContext context) {
    return TextField(
      enabled: !locked,
      autocorrect: false,
      textDirection: Directionality.of(context),
      keyboardType: numeric ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
      style: context.text.titleLarge,
      decoration: InputDecoration(hintText: context.s.t('typeAnswer')),
      onChanged: (v) => onAnswer(v.trim().isEmpty ? null : v),
    );
  }
}

// ------------------------------------------------------------ matching
class _Matching extends StatefulWidget {
  const _Matching({super.key, required this.question, required this.onAnswer, required this.locked});

  final MatchingQuestion question;
  final ValueChanged<Object?> onAnswer;
  final bool locked;

  @override
  State<_Matching> createState() => _MatchingState();
}

class _MatchingState extends State<_Matching> {
  late final List<int> _rightOrder; // shuffled indexes into question.right
  final Map<int, int> _pairs = {}; // left index -> original right index
  int? _pickedLeft;

  @override
  void initState() {
    super.initState();
    _rightOrder = List<int>.generate(widget.question.right.length, (i) => i).reversed.toList();
  }

  void _tapRight(int rightIdx) {
    if (widget.locked || _pickedLeft == null) return;
    setState(() {
      _pairs.removeWhere((_, v) => v == rightIdx);
      _pairs[_pickedLeft!] = rightIdx;
      _pickedLeft = null;
    });
    widget.onAnswer(_pairs.length == widget.question.left.length ? Map<int, int>.of(_pairs) : null);
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    final c = context.colors;
    const palette = [Color(0xFFBDE0FE), Color(0xFFFFD6A5), Color(0xFFCAFFBF), Color(0xFFFFC6FF), Color(0xFFFDFFB6)];
    Color? colorFor(int left) => _pairs.containsKey(left) ? palette[left % palette.length] : null;
    Color? colorForRight(int right) {
      for (final e in _pairs.entries) {
        if (e.value == right) return palette[e.key % palette.length];
      }
      return null;
    }

    return Column(
      children: [
        Text(context.s.t('tapPairs'), style: context.text.bodySmall),
        const SizedBox(height: 8),
        Directionality(
          textDirection: Directionality.of(context),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  children: [
                    for (var i = 0; i < q.left.length; i++)
                      _MatchCell(
                        label: q.left[i],
                        color: _pickedLeft == i ? c.primaryContainer : colorFor(i),
                        onTap: widget.locked ? null : () => setState(() => _pickedLeft = i),
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  children: [
                    for (final r in _rightOrder)
                      _MatchCell(label: q.right[r], color: colorForRight(r), onTap: widget.locked ? null : () => _tapRight(r)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _MatchCell extends StatelessWidget {
  const _MatchCell({required this.label, required this.color, required this.onTap});

  final String label;
  final Color? color;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: color ?? context.colors.surface,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Container(
            width: double.infinity,
            constraints: const BoxConstraints(minHeight: 56),
            alignment: Alignment.center,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: context.colors.outlineVariant),
            ),
            child: Text(label, textAlign: TextAlign.center, style: context.text.titleMedium),
          ),
        ),
      ),
    );
  }
}

// ------------------------------------------------------------ ordering
class _Ordering extends StatefulWidget {
  const _Ordering({super.key, required this.question, required this.onAnswer, required this.locked});

  final OrderingQuestion question;
  final ValueChanged<Object?> onAnswer;
  final bool locked;

  @override
  State<_Ordering> createState() => _OrderingState();
}

class _OrderingState extends State<_Ordering> {
  late List<String> _items;

  @override
  void initState() {
    super.initState();
    // Deterministic shuffle for Phase 2 (real shuffling with a seed in Phase 5).
    final list = List<String>.of(widget.question.correctOrder);
    _items = [...list.skip(1), list.first];
    WidgetsBinding.instance.addPostFrameCallback((_) => widget.onAnswer(List<String>.of(_items)));
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(context.s.t('dragToOrder'), style: context.text.bodySmall),
        const SizedBox(height: 8),
        Directionality(
          textDirection: Directionality.of(context),
          child: ReorderableListView(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            buildDefaultDragHandles: !widget.locked,
            onReorder: (oldIndex, newIndex) {
              if (widget.locked) return;
              setState(() {
                if (newIndex > oldIndex) newIndex -= 1;
                final item = _items.removeAt(oldIndex);
                _items.insert(newIndex, item);
              });
              widget.onAnswer(List<String>.of(_items));
            },
            children: [
              for (var i = 0; i < _items.length; i++)
                Card(
                  key: ValueKey(_items[i]),
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    leading: CircleAvatar(radius: 14, child: Text('${i + 1}')),
                    title: Text(_items[i]),
                    trailing: widget.locked ? null : const Icon(Icons.drag_handle),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

// ------------------------------------------------------------ drag & drop
class _DragDrop extends StatefulWidget {
  const _DragDrop({super.key, required this.question, required this.onAnswer, required this.locked});

  final DragDropQuestion question;
  final ValueChanged<Object?> onAnswer;
  final bool locked;

  @override
  State<_DragDrop> createState() => _DragDropState();
}

class _DragDropState extends State<_DragDrop> {
  String? _placed;

  void _place(String token) {
    if (widget.locked) return;
    setState(() => _placed = token);
    widget.onAnswer(token);
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    final c = context.colors;
    return Directionality(
      textDirection: Directionality.of(context),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Text(q.before, style: context.text.titleMedium),
              DragTarget<String>(
                onAcceptWithDetails: (d) => _place(d.data),
                builder: (context, candidates, _) => Container(
                  constraints: const BoxConstraints(minWidth: 110, minHeight: 44),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: candidates.isNotEmpty ? c.primaryContainer : c.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: c.primary, width: 1.5),
                  ),
                  child: Text(_placed ?? context.s.t('dragHere'),
                      style: _placed == null ? context.text.bodySmall : context.text.titleMedium),
                ),
              ),
              Text(q.after, style: context.text.titleMedium),
            ],
          ),
          const SizedBox(height: 24),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              for (final t in q.tokens)
                Draggable<String>(
                  data: t,
                  maxSimultaneousDrags: widget.locked ? 0 : 1,
                  feedback: Material(color: Colors.transparent, child: _Token(label: t, lifted: true)),
                  childWhenDragging: Opacity(opacity: 0.3, child: _Token(label: t)),
                  // Tapping also places the word (easier for small hands and for accessibility).
                  child: GestureDetector(onTap: () => _place(t), child: _Token(label: t)),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Token extends StatelessWidget {
  const _Token({required this.label, this.lifted = false});

  final String label;
  final bool lifted;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: context.colors.secondaryContainer,
        borderRadius: BorderRadius.circular(12),
        boxShadow: lifted ? const [BoxShadow(blurRadius: 8, color: Colors.black26)] : null,
      ),
      child: Text(label, style: context.text.titleMedium),
    );
  }
}

// ------------------------------------------------------------ listening
class _Listening extends StatelessWidget {
  const _Listening({super.key, required this.question, required this.onAnswer, required this.locked});

  final ListeningQuestion question;
  final ValueChanged<Object?> onAnswer;
  final bool locked;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Center(
          child: FilledButton.icon(
            // Phase 9: plays the cached TTS / recorded audio file.
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('🔊 "${question.audioText}"  (MOCK - audio in Phase 9)')),
            ),
            icon: const Icon(Icons.volume_up),
            label: Text(context.s.t('tapToListen')),
          ),
        ),
        const SizedBox(height: 20),
        _Choices(options: question.options, onAnswer: onAnswer, locked: locked),
      ],
    );
  }
}

// ------------------------------------------------------------ speaking
class _Speaking extends StatefulWidget {
  const _Speaking({super.key, required this.question, required this.onAnswer});

  final SpeakingQuestion question;
  final ValueChanged<Object?> onAnswer;

  @override
  State<_Speaking> createState() => _SpeakingState();
}

class _SpeakingState extends State<_Speaking> {
  bool _recording = false;
  bool _recorded = false;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Column(
      children: [
        Text(s.t('tapToSpeak'), style: context.text.bodyMedium),
        const SizedBox(height: 8),
        Text(widget.question.targetText,
            textAlign: TextAlign.center,
            textDirection: Directionality.of(context),
            style: context.text.headlineSmall?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 24),
        GestureDetector(
          onTap: () {
            setState(() {
              if (_recording) {
                _recording = false;
                _recorded = true;
                widget.onAnswer('recorded');
              } else {
                _recording = true;
              }
            });
          },
          child: CircleAvatar(
            radius: 44,
            backgroundColor: _recording ? AppTokens.bad : context.colors.primary,
            child: Icon(_recording ? Icons.stop : Icons.mic, size: 40, color: Colors.white),
          ),
        ),
        const SizedBox(height: 12),
        if (_recorded) const Icon(Icons.check_circle, color: AppTokens.good),
        Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Text(s.t('speakingPending'), textAlign: TextAlign.center, style: context.text.bodySmall),
        ),
      ],
    );
  }
}

// ------------------------------------------------------------ reading
class _Reading extends StatelessWidget {
  const _Reading({super.key, required this.question, required this.onAnswer, required this.locked});

  final ReadingQuestion question;
  final ValueChanged<Object?> onAnswer;
  final bool locked;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(context.s.t('readPassage'), style: context.text.bodySmall),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text(question.passage, textDirection: contentDir(question.passage), style: context.text.bodyLarge?.copyWith(height: 1.5)),
          ),
        ),
        const SizedBox(height: 16),
        _Choices(options: question.options, onAnswer: onAnswer, locked: locked),
      ],
    );
  }
}

/// Human-readable correct answer, shown after a wrong attempt.
String correctAnswerText(Question q) => switch (q) {
      final MultipleChoiceQuestion m => m.options[m.correctIndex],
      final TrueFalseQuestion t => t.answer ? 'True' : 'False',
      final FillBlankQuestion f => f.accepted.first,
      final MatchingQuestion m => [for (var i = 0; i < m.left.length; i++) '${m.left[i]} = ${m.right[i]}'].join(', '),
      final OrderingQuestion o => o.correctOrder.join(' > '),
      final DragDropQuestion d => d.correctToken,
      final TypingQuestion t => t.accepted.first,
      final ListeningQuestion l => l.options[l.correctIndex],
      final SpeakingQuestion sp => sp.targetText,
      final ReadingQuestion r => r.options[r.correctIndex],
      final WordProblemQuestion w => '${w.answer}${w.unit == null ? '' : ' ${w.unit}'}',
    };
