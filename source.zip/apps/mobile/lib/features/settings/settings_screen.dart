import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/widgets/common.dart';
import '../../state/account.dart';
import '../../state/session.dart';
import '../profiles/profile_screens.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final session = ref.watch(sessionProvider);
    final account = ref.watch(accountProvider).valueOrNull;
    final email = account?.email;
    final isAr = s.isArabic;
    return MockScaffold(
      title: s.t('settings'),
      body: ListView(
        children: [
          SectionTitle(s.t('language')),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'en', label: Text('English')),
                ButtonSegment(value: 'ar', label: Text('العربية')),
              ],
              selected: {isAr ? 'ar' : 'en'},
              onSelectionChanged: (v) => ref.read(sessionProvider.notifier).setLocale(Locale(v.first)),
            ),
          ),
          SwitchListTile(
            title: const Text('Dark mode'),
            value: session.themeMode == ThemeMode.dark,
            onChanged: (v) => ref.read(sessionProvider.notifier).setThemeMode(v ? ThemeMode.dark : ThemeMode.light),
          ),
          SectionTitle(s.t('downloads')),
          const ListTile(leading: Icon(Icons.download_done), title: Text('Current unit + next unit'), subtitle: Text('Auto on Wi-Fi · 48 MB (MOCK)')),
          const ListTile(leading: Icon(Icons.storage_outlined), title: Text('Storage limit'), trailing: Text('500 MB')),
          SectionTitle(s.t('notifications')),
          const ListTile(leading: Icon(Icons.notifications_none), title: Text('Daily mission'), trailing: Text('17:00')),
          const ListTile(leading: Icon(Icons.bedtime_outlined), title: Text('Quiet hours'), trailing: Text('20:00 - 07:00')),
          SectionTitle(s.t('privacy')),
          const ListTile(leading: Icon(Icons.file_download_outlined), title: Text('Export my data')),
          const ListTile(leading: Icon(Icons.delete_outline), title: Text('Delete profile data')),
          const PendingNote('uiOnly'),
          const Divider(),
          SectionTitle(s.t('account')),
          if (account != null && account.isChildDevice) ...[
            ListTile(
              leading: const Icon(Icons.family_restroom),
              title: Text(s.f('linkedToFamily', [account.familyName ?? ''])),
              subtitle: Text(s.t('childPhoneNote')),
            ),
          ] else ...[
            if (email != null)
              ListTile(
                leading: const Icon(Icons.alternate_email),
                title: Text(email, textDirection: TextDirection.ltr),
                subtitle: Text(account?.familyName ?? ''),
              ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: Text(s.t('signOut')),
              onTap: () async {
                await signOutThisPhone(ref);
                if (context.mounted) context.go(Routes.welcome);
              },
            ),
          ],
          ListTile(leading: const Icon(Icons.info_outline), title: Text(s.t('about')), subtitle: const Text('v0.4.0 · Phase 4 (learning)')),
        ],
      ),
    );
  }
}
