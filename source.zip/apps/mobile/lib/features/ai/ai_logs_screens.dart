import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../core/widgets/common.dart';
import '../../state/account.dart';
import '../../state/ai.dart';
import 'roleplay_screens.dart' show FeedbackView;
import 'tutor_chat_screen.dart' show ChatList;

// Parent only (the router keeps /parent/* away from children's phones):
// every AI conversation of a child, the safety flags, and the family's AI spend.

class AiLogsScreen extends ConsumerWidget {
  const AiLogsScreen({super.key, required this.profileId});

  final String profileId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final child = ref.watch(accountProvider).valueOrNull?.profileById(profileId);
    final status = ref.watch(aiStatusProvider(profileId)).valueOrNull;
    final list = ref.watch(aiHistoryProvider(profileId));
    final date = MaterialLocalizations.of(context);
    return AccountScaffold(
      title: '${s.t('aiLogs')}${child == null ? '' : ' · ${child.displayName}'}',
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(aiStatusProvider(profileId));
          try {
            await ref.refresh(aiHistoryProvider(profileId).future);
          } catch (_) {/* shown below */}
        },
        child: ListView(
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            if (status != null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  children: [
                    Expanded(
                      child: StatTile(
                        label: s.t('aiToday'),
                        value: '${status.usedToday}/${status.dailyLimit}',
                        icon: Icons.chat_bubble_outline,
                      ),
                    ),
                    Expanded(
                      child: StatTile(
                        label: s.t('aiMonthSpend'),
                        value: '\$${status.monthCost.toStringAsFixed(2)} / \$${status.monthlyBudget.toStringAsFixed(0)}',
                        icon: Icons.account_balance_wallet_outlined,
                      ),
                    ),
                  ],
                ),
              ),
            if (status != null && !status.enabled)
              ListTile(leading: const Icon(Icons.block, color: AppTokens.warn), title: Text(s.t('err_ai_disabled'))),
            ...list.when(
              loading: () => [const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()))],
              error: (e, _) => [Padding(padding: const EdgeInsets.all(16), child: ErrorText(failureText(context, e)))],
              data: (items) => items.isEmpty
                  ? [EmptyState(emoji: '🤖', message: s.t('aiNoChatsYet'))]
                  : [
                      for (final c in items)
                        ListTile(
                          leading: Text(c.kind == 'tutor' ? '🤖' : '💬', style: const TextStyle(fontSize: 24)),
                          title: Row(
                            children: [
                              Expanded(child: Text(c.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
                              if (c.flagged) const Text(' ⚠️'),
                            ],
                          ),
                          subtitle: Text(
                            [
                              '${date.formatShortDate(c.lastAt)} ${date.formatTimeOfDay(TimeOfDay.fromDateTime(c.lastAt))}',
                              s.f('aiMessagesCount', [c.messages]),
                              if (c.preview != null) '“${c.preview}”',
                            ].join(' · '),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => context.push(Routes.aiLogConversation(c.id)),
                        ),
                    ],
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(s.t('aiLogsNote'), style: context.text.bodySmall?.copyWith(color: context.colors.outline)),
            ),
          ],
        ),
      ),
    );
  }
}

class AiLogConversationScreen extends ConsumerWidget {
  const AiLogConversationScreen({super.key, required this.conversationId});

  final String conversationId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final async = ref.watch(aiConversationProvider(conversationId));
    return async.when(
      loading: () => const AccountScaffold(title: '', body: Center(child: CircularProgressIndicator())),
      error: (e, _) => AccountScaffold(title: '', body: Center(child: ErrorText(failureText(context, e)))),
      data: (c) => DefaultTabController(
        length: c.feedback == null ? 1 : 2,
        child: AccountScaffold(
          title: c.title,
          body: Column(
            children: [
              if (c.flagged)
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: AppTokens.bad.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(10)),
                  child: Text(s.t('aiFlaggedNote')),
                ),
              if (c.feedback != null)
                TabBar(tabs: [Tab(text: s.t('aiConversation')), Tab(text: s.t('feedback'))]),
              Expanded(
                child: c.feedback == null
                    ? ChatList(messages: c.messages, showFlags: true)
                    : TabBarView(children: [
                        ChatList(messages: c.messages, showFlags: true),
                        FeedbackView(feedback: c.feedback!, lang: (c.scenario ?? '').contains('_fr_') ? 'fr' : 'en'),
                      ]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
