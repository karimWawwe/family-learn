import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/text_dir.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../domain/ai.dart';
import '../../state/ai.dart';
import '../../state/session.dart';

/// AI tutor chat (Phase 8): real answers from Claude through the Edge Function "ai-chat".
/// Opened from the menu (free questions) or from a wrong answer in a lesson ([questionId]):
/// then the tutor knows the question, the book's explanation and the learner's answer.
/// Before the learner answers, the tutor only gives hints (the server never sends it the answer).
class TutorChatScreen extends ConsumerStatefulWidget {
  const TutorChatScreen({super.key, this.questionId, this.lessonId});

  final String? questionId;
  final String? lessonId;

  @override
  ConsumerState<TutorChatScreen> createState() => _TutorChatScreenState();
}

class _TutorChatScreenState extends ConsumerState<TutorChatScreen> {
  final _messages = <AiChatMessage>[];
  final _controller = TextEditingController();
  final _scroll = ScrollController();
  String? _conversationId;
  bool _busy = false;
  String? _error;
  int? _remaining;

  @override
  void dispose() {
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send([String? preset]) async {
    final p = ref.read(currentProfileProvider);
    final text = (preset ?? _controller.text).trim();
    if (p == null || text.isEmpty || _busy) return;
    setState(() {
      _messages.add(AiChatMessage(fromLearner: true, text: text));
      _busy = true;
      _error = null;
    });
    _controller.clear();
    _toEnd();
    try {
      final r = await ref.read(aiRepositoryProvider).askTutor(
            p.id,
            text,
            conversationId: _conversationId,
            questionId: _conversationId == null ? widget.questionId : null,
            lessonId: _conversationId == null ? widget.lessonId : null,
          );
      if (!mounted) return;
      setState(() {
        _conversationId = r.conversationId;
        _messages.add(AiChatMessage(fromLearner: false, text: r.text ?? '…', flagged: r.flagged));
        _remaining = r.remainingToday;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = failureText(context, e);
        // the message was not answered: put it back so the learner can send it again
        _messages.removeLast();
        _controller.text = text;
      });
    } finally {
      if (mounted) setState(() => _busy = false);
      _toEnd();
    }
  }

  void _toEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  void _newChat() => setState(() {
        _messages.clear();
        _conversationId = null;
        _error = null;
      });

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final status = ref.watch(aiStatusProvider(p.id)).valueOrNull;
    final remaining = _remaining ?? status?.remainingToday;
    final aboutQuestion = widget.questionId != null;
    final suggestions = widget.questionId != null
        ? [s.t('aiAskWhyWrong'), s.t('aiAskHint'), s.t('aiAskExample')]
        : [s.t('aiAskExplainLesson'), s.t('aiAskQuiz'), s.t('aiAskWord')];

    return AccountScaffold(
      title: '🤖 ${s.t('aiTutor')}',
      actions: [
        if (_messages.isNotEmpty)
          IconButton(tooltip: s.t('aiNewChat'), icon: const Icon(Icons.add_comment_outlined), onPressed: _busy ? null : _newChat),
      ],
      body: Column(
        children: [
          if (status != null && !status.enabled)
            _Note(text: s.t('err_ai_disabled'), color: AppTokens.warn)
          else if (aboutQuestion)
            _Note(text: s.t('aiAboutQuestion'), color: context.colors.primary),
          Expanded(
            child: _messages.isEmpty
                ? ListView(
                    padding: const EdgeInsets.all(20),
                    children: [
                      const SizedBox(height: 24),
                      const Text('🤖', textAlign: TextAlign.center, style: TextStyle(fontSize: 56)),
                      const SizedBox(height: 8),
                      Text(s.t('aiTutorHello'), textAlign: TextAlign.center, style: context.text.titleMedium),
                      const SizedBox(height: 20),
                      for (final q in suggestions)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: OutlinedButton(onPressed: _busy ? null : () => _send(q), child: Text(q, textAlign: TextAlign.center)),
                        ),
                    ],
                  )
                : ChatList(messages: _messages, controller: _scroll, typing: _busy),
          ),
          if (_error != null) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: ErrorText(_error)),
          if (remaining != null && status != null && status.dailyLimit > 0)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(s.f('aiRemaining', [remaining, status.dailyLimit]),
                  style: context.text.labelSmall?.copyWith(color: context.colors.outline)),
            ),
          ChatInput(controller: _controller, hintKey: 'askTutor', onSend: _busy ? null : _send),
        ],
      ),
    );
  }
}

class _Note extends StatelessWidget {
  const _Note({required this.text, required this.color});
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(color: color.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(10)),
        child: Text(text, style: context.text.bodySmall),
      );
}

/// Chat bubbles. Each bubble follows its own text direction (Arabic / English / French).
class ChatList extends StatelessWidget {
  const ChatList({super.key, required this.messages, this.controller, this.typing = false, this.showFlags = false});

  final List<AiChatMessage> messages;
  final ScrollController? controller;
  final bool typing;

  /// Parent log: mark the messages the safety check flagged.
  final bool showFlags;

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return ListView.builder(
      controller: controller,
      padding: const EdgeInsets.all(12),
      itemCount: messages.length + (typing ? 1 : 0),
      itemBuilder: (context, i) {
        if (i == messages.length) {
          return Align(
            alignment: AlignmentDirectional.centerStart,
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 4),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(color: c.surfaceContainerHighest, borderRadius: BorderRadius.circular(16)),
              child: const SizedBox(width: 36, child: LinearProgressIndicator(minHeight: 3)),
            ),
          );
        }
        final m = messages[i];
        return Align(
          alignment: m.fromLearner ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
          child: Container(
            constraints: BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width * 0.82),
            margin: const EdgeInsets.symmetric(vertical: 4),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: m.fromLearner ? c.primary : c.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(16),
              border: showFlags && m.flagged ? Border.all(color: AppTokens.bad, width: 2) : null,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                if (showFlags && m.flagged) const Text('⚠️', style: TextStyle(fontSize: 12)),
                SelectableText(
                  m.text,
                  textDirection: contentDir(m.text),
                  style: TextStyle(color: m.fromLearner ? c.onPrimary : c.onSurface, height: 1.35),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class ChatInput extends StatelessWidget {
  const ChatInput({super.key, required this.controller, required this.hintKey, required this.onSend, this.onMic, this.listening = false});

  final TextEditingController controller;
  final String hintKey;

  /// null = disabled (waiting for the answer)
  final VoidCallback? onSend;
  final VoidCallback? onMic;
  final bool listening;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
        child: Row(
          children: [
            if (onMic != null)
              IconButton(
                onPressed: onMic,
                icon: Icon(listening ? Icons.mic : Icons.mic_none, color: listening ? AppTokens.bad : null),
              ),
            Expanded(
              child: TextField(
                controller: controller,
                minLines: 1,
                maxLines: 4,
                maxLength: 600,
                textInputAction: TextInputAction.send,
                decoration: InputDecoration(hintText: context.s.t(hintKey), isDense: true, counterText: ''),
                onSubmitted: (_) => onSend?.call(),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: onSend, icon: const Icon(Icons.send)),
          ],
        ),
      ),
    );
  }
}
