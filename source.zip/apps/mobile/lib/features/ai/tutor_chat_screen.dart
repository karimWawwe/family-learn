import 'package:flutter/material.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/mock/mock_data.dart';
import '../../domain/models.dart';

/// AI tutor chat UI. Phase 2: MOCK replies only.
/// Phase 8: messages go to the AI Gateway (never directly to a provider);
/// children's messages pass the Child Safety Layer before and after the model.
class TutorChatScreen extends StatefulWidget {
  const TutorChatScreen({super.key});

  @override
  State<TutorChatScreen> createState() => _TutorChatScreenState();
}

class _TutorChatScreenState extends State<TutorChatScreen> {
  final _messages = <ChatMessage>[...MockData.tutorChat];
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _send() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _messages.add(ChatMessage(fromLearner: true, text: text));
      _messages.add(const ChatMessage(fromLearner: false, text: '(MOCK) The AI tutor will answer here in Phase 8, using this lesson\'s content.'));
    });
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return MockScaffold(
      title: s.t('aiTutor'),
      body: Column(
        children: [
          const PendingNote('aiPending'),
          Expanded(child: ChatList(messages: _messages)),
          ChatInput(controller: _controller, hintKey: 'askTutor', onSend: _send),
        ],
      ),
    );
  }
}

class ChatList extends StatelessWidget {
  const ChatList({super.key, required this.messages});

  final List<ChatMessage> messages;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: messages.length,
      itemBuilder: (context, i) {
        final m = messages[i];
        final c = context.colors;
        return Align(
          alignment: m.fromLearner ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
          child: Container(
            constraints: BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width * 0.8),
            margin: const EdgeInsets.symmetric(vertical: 4),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: m.fromLearner ? c.primary : c.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              m.text,
              textDirection: TextDirection.ltr,
              style: TextStyle(color: m.fromLearner ? c.onPrimary : c.onSurface),
            ),
          ),
        );
      },
    );
  }
}

class ChatInput extends StatelessWidget {
  const ChatInput({super.key, required this.controller, required this.hintKey, required this.onSend, this.onMic});

  final TextEditingController controller;
  final String hintKey;
  final VoidCallback onSend;
  final VoidCallback? onMic;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
        child: Row(
          children: [
            if (onMic != null) IconButton(onPressed: onMic, icon: const Icon(Icons.mic_none)),
            Expanded(
              child: TextField(
                controller: controller,
                textDirection: TextDirection.ltr,
                decoration: InputDecoration(hintText: context.s.t(hintKey), isDense: true),
                onSubmitted: (_) => onSend(),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: onSend, icon: const Icon(Icons.send)),
          ],
        ),
      ),
    );
  }
}
