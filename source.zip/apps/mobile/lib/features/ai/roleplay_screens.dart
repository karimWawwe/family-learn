import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/speech/speech_engine.dart';
import '../../core/text_dir.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../core/widgets/common.dart';
import '../../domain/ai.dart';
import '../../state/ai.dart';
import '../../state/session.dart';
import '../../state/speak_game.dart' show speechEngineProvider;
import '../learn/lesson_intro_view.dart' show speakText;
import 'tutor_chat_screen.dart';

// Role-play conversations (Phase 8): the AI plays a character, the learner reaches a goal,
// feedback at the end. Scenarios come from the server and depend on the profile
// (Kareem: business English; Omar: grade-6 English + French; Yassin: grade-3 English + French).

String _speechLang(String lang) => lang == 'fr' ? 'fr-FR' : 'en-US';
String _flag(String lang) => lang == 'fr' ? '🇫🇷' : '🇬🇧';

class RoleplayLibraryScreen extends ConsumerWidget {
  const RoleplayLibraryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final list = ref.watch(aiScenariosProvider(p.id));
    return AccountScaffold(
      title: s.t('roleplay'),
      body: list.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Padding(padding: const EdgeInsets.all(24), child: ErrorText(failureText(context, e)))),
        data: (items) => items.isEmpty
            ? EmptyState(emoji: '💬', message: s.t('aiNoScenarios'))
            : ListView(
                padding: const EdgeInsets.only(bottom: 24),
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                    child: Text(s.t('roleplayIntro'), style: context.text.bodyMedium),
                  ),
                  for (final sc in items)
                    Card(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      child: ListTile(
                        leading: Text(sc.emoji, style: const TextStyle(fontSize: 30)),
                        title: Text('${s.isArabic ? sc.titleAr : sc.title}  ${_flag(sc.lang)}',
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text('🎯 ${sc.goal}', textDirection: contentDir(sc.goal)),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => context.push(Routes.roleplayScenario(sc.code), extra: sc),
                      ),
                    ),
                ],
              ),
      ),
    );
  }
}

/// No corrections during the conversation (by design): feedback comes at the end.
class RoleplayConversationScreen extends ConsumerStatefulWidget {
  const RoleplayConversationScreen({super.key, required this.code, this.scenario});

  final String code;
  final AiScenario? scenario;

  @override
  ConsumerState<RoleplayConversationScreen> createState() => _RoleplayConversationScreenState();
}

class _RoleplayConversationScreenState extends ConsumerState<RoleplayConversationScreen> {
  final _messages = <AiChatMessage>[];
  final _controller = TextEditingController();
  final _scroll = ScrollController();
  AiScenario? _sc;
  String? _conversationId;
  bool _busy = false;
  bool _listening = false;
  String? _error;
  StreamSubscription<SpeechEvent>? _mic;
  Timer? _micTimer;

  @override
  void initState() {
    super.initState();
    _sc = widget.scenario;
    WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  @override
  void dispose() {
    _micTimer?.cancel();
    _mic?.cancel();
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }

  String get _lang => _sc?.lang ?? 'en';

  Future<void> _start() async {
    final p = ref.read(currentProfileProvider);
    if (p == null) return;
    if (_sc == null) {
      try {
        final all = await ref.read(aiRepositoryProvider).scenarios(p.id);
        for (final x in all) {
          if (x.code == widget.code) _sc = x;
        }
      } catch (_) {/* shown below */}
      if (mounted) setState(() {});
    }
    await _call(null);
  }

  Future<void> _call(String? text) async {
    final p = ref.read(currentProfileProvider);
    if (p == null || _busy) return;
    setState(() {
      _busy = true;
      _error = null;
      if (text != null) _messages.add(AiChatMessage(fromLearner: true, text: text));
    });
    _toEnd();
    try {
      final r = await ref.read(aiRepositoryProvider).roleplay(
            p.id,
            conversationId: _conversationId,
            scenario: _conversationId == null ? widget.code : null,
            message: text,
          );
      if (!mounted) return;
      setState(() {
        _conversationId = r.conversationId;
        _messages.add(AiChatMessage(fromLearner: false, text: r.text ?? '…', flagged: r.flagged));
      });
    } catch (e) {
      if (mounted) setState(() => _error = failureText(context, e));
    } finally {
      if (mounted) setState(() => _busy = false);
      _toEnd();
    }
  }

  void _send() {
    final t = _controller.text.trim();
    if (t.isEmpty) return;
    _controller.clear();
    _call(t);
  }

  void _toEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  /// Speak instead of typing: the words heard go into the text box (the learner can fix them).
  Future<void> _micTap() async {
    final engine = ref.read(speechEngineProvider);
    engine.unlockAudio();
    if (_listening) {
      engine.stop();
      return;
    }
    if (!engine.recognitionSupported) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(context.s.t('micNotSupported'))));
      return;
    }
    engine.stopSpeaking();
    setState(() => _listening = true);
    final before = _controller.text.trim();
    await _mic?.cancel();
    _micTimer?.cancel();
    _mic = engine.listen(lang: _speechLang(_lang), continuous: true).listen((e) {
      if ((e.type == SpeechEventType.partial || e.type == SpeechEventType.finalResult) && e.alternatives.isNotEmpty) {
        _controller.text = [before, e.alternatives.first.text.trim()].where((x) => x.isNotEmpty).join(' ');
      }
      if (e.type == SpeechEventType.error && (e.error == 'not-allowed' || e.error == 'service-not-allowed') && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(context.s.t('micDenied'))));
      }
      if (e.type == SpeechEventType.ended && mounted) setState(() => _listening = false);
    }, onDone: () {
      if (mounted) setState(() => _listening = false);
    });
    _micTimer = Timer(const Duration(seconds: 15), engine.stop);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final sc = _sc;
    final engine = ref.watch(speechEngineProvider);
    final learnerTurns = _messages.where((m) => m.fromLearner).length;
    final last = _messages.lastWhere((m) => !m.fromLearner, orElse: () => const AiChatMessage(fromLearner: false, text: ''));
    return AccountScaffold(
      title: sc == null ? s.t('roleplay') : '${sc.emoji} ${s.isArabic ? sc.titleAr : sc.title}',
      actions: [
        TextButton(
          onPressed: _conversationId == null || learnerTurns < 2 || _busy
              ? null
              : () => context.pushReplacement(Routes.roleplayFeedback(widget.code, _conversationId!)),
          child: Text(s.t('endConversation')),
        ),
      ],
      body: Column(
        children: [
          if (sc != null)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              color: context.colors.surfaceContainerHighest,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${_flag(sc.lang)}  ${sc.persona}', textDirection: contentDir(sc.persona)),
                  Text('🎯 ${sc.goal}', textDirection: contentDir(sc.goal), style: const TextStyle(fontWeight: FontWeight.w700)),
                  if (learnerTurns < 2)
                    Text(s.t('roleplayHowTo'), style: context.text.bodySmall?.copyWith(color: context.colors.outline)),
                ],
              ),
            ),
          Expanded(child: ChatList(messages: _messages, controller: _scroll, typing: _busy)),
          if (last.text.isNotEmpty && !_busy)
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: TextButton.icon(
                  onPressed: () => speakText(context, engine, last.text, _speechLang(_lang)),
                  icon: const Icon(Icons.volume_up_outlined, size: 18),
                  label: Text(s.t('listenAudio')),
                ),
              ),
            ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  ErrorText(_error),
                  if (_conversationId == null)
                    TextButton(onPressed: _busy ? null : () => _call(null), child: Text(s.t('tryAgain'))),
                ],
              ),
            ),
          ChatInput(
            controller: _controller,
            hintKey: 'typeOrSpeak',
            onSend: _busy || _conversationId == null ? null : _send,
            onMic: _conversationId == null ? null : _micTap,
            listening: _listening,
          ),
        ],
      ),
    );
  }
}

class RoleplayFeedbackScreen extends ConsumerStatefulWidget {
  const RoleplayFeedbackScreen({super.key, required this.code, required this.conversationId});

  final String code;
  final String? conversationId;

  @override
  ConsumerState<RoleplayFeedbackScreen> createState() => _RoleplayFeedbackScreenState();
}

class _RoleplayFeedbackScreenState extends ConsumerState<RoleplayFeedbackScreen> {
  AiFeedback? _f;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final p = ref.read(currentProfileProvider);
    final id = widget.conversationId;
    if (p == null) return;
    if (id == null) {
      setState(() => _error = context.s.t('err_not_found'));
      return;
    }
    setState(() => _error = null);
    try {
      final f = await ref.read(aiRepositoryProvider).roleplayFeedback(p.id, id);
      if (mounted) setState(() => _f = f);
    } catch (e) {
      if (mounted) setState(() => _error = failureText(context, e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final f = _f;
    final lang = widget.code.contains('_fr_') ? 'fr' : 'en';
    return AccountScaffold(
      title: s.t('feedback'),
      body: f == null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: _error == null
                    ? Column(mainAxisSize: MainAxisSize.min, children: [
                        const CircularProgressIndicator(),
                        const SizedBox(height: 12),
                        Text(s.t('aiPreparingFeedback')),
                      ])
                    : Column(mainAxisSize: MainAxisSize.min, children: [
                        ErrorText(_error),
                        TextButton(onPressed: _load, child: Text(s.t('tryAgain'))),
                      ]),
              ),
            )
          : FeedbackView(feedback: f, lang: lang, onDone: () => context.go(Routes.home)),
    );
  }
}

/// The end-of-conversation feedback (also shown read-only in the parent's log).
class FeedbackView extends ConsumerWidget {
  const FeedbackView({super.key, required this.feedback, required this.lang, this.onDone});

  final AiFeedback feedback;
  final String lang;
  final VoidCallback? onDone;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = context.s;
    final engine = ref.watch(speechEngineProvider);
    final f = feedback;
    Widget fix(String from, String to) => ListTile(
          dense: true,
          title: Text(from, textDirection: contentDir(from), style: const TextStyle(decoration: TextDecoration.lineThrough, color: AppTokens.bad)),
          subtitle: Text(to, textDirection: contentDir(to), style: const TextStyle(color: AppTokens.good, fontWeight: FontWeight.w700)),
          trailing: IconButton(
            icon: const Icon(Icons.volume_up_outlined),
            onPressed: () => speakText(context, engine, to, _speechLang(lang)),
          ),
        );
    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Text(f.goalReached ? '🏆' : '💪', style: const TextStyle(fontSize: 40)),
              const SizedBox(width: 12),
              Expanded(
                child: Text(f.goalReached ? s.t('aiGoalReached') : s.t('aiGoalAlmost'),
                    style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
              ),
            ],
          ),
        ),
        SectionTitle(s.t('summary')),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(f.summary, textDirection: contentDir(f.summary), style: context.text.bodyLarge),
        ),
        if (f.grammar.isNotEmpty) ...[SectionTitle(s.t('grammarFixes')), for (final g in f.grammar) fix(g.$1, g.$2)],
        if (f.betterWords.isNotEmpty) ...[SectionTitle(s.t('betterWords')), for (final b in f.betterWords) fix(b.$1, b.$2)],
        if (f.phrases.isNotEmpty) ...[
          SectionTitle(s.t('naturalPhrases')),
          for (final ph in f.phrases)
            ListTile(
              dense: true,
              leading: const Icon(Icons.format_quote),
              title: Text(ph, textDirection: contentDir(ph)),
              trailing: IconButton(
                icon: const Icon(Icons.volume_up_outlined),
                onPressed: () => speakText(context, engine, ph, _speechLang(lang)),
              ),
            ),
        ],
        if (f.newWords.isNotEmpty) ...[
          SectionTitle(s.t('aiNewWords')),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(spacing: 8, runSpacing: 8, children: [for (final w in f.newWords) Chip(label: Text(w))]),
          ),
        ],
        if (onDone != null)
          Padding(
            padding: const EdgeInsets.all(16),
            child: FilledButton(onPressed: onDone, child: Text(s.t('done'))),
          ),
      ],
    );
  }
}
