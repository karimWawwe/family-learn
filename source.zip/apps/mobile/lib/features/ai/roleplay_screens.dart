import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/mock/mock_data.dart';
import '../../domain/models.dart';
import 'tutor_chat_screen.dart';

RoleplayScenario _scenario(String code) =>
    MockData.scenarios.firstWhere((x) => x.code == code, orElse: () => MockData.scenarios.first);

class RoleplayLibraryScreen extends StatelessWidget {
  const RoleplayLibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return MockScaffold(
      title: s.t('roleplay'),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          Padding(padding: const EdgeInsets.all(16), child: Text(s.t('roleplayBody'))),
          for (final sc in MockData.scenarios)
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: ListTile(
                leading: Text(sc.emoji, style: const TextStyle(fontSize: 28)),
                title: Text(sc.title, textDirection: TextDirection.ltr),
                subtitle: Text('${sc.persona} - ${sc.goal}', textDirection: TextDirection.ltr),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.push(Routes.roleplayScenario(sc.code)),
              ),
            ),
        ],
      ),
    );
  }
}

/// No corrections during the conversation (by design): feedback comes at the end.
class RoleplayConversationScreen extends StatefulWidget {
  const RoleplayConversationScreen({super.key, required this.code});

  final String code;

  @override
  State<RoleplayConversationScreen> createState() => _RoleplayConversationScreenState();
}

class _RoleplayConversationScreenState extends State<RoleplayConversationScreen> {
  final _messages = <ChatMessage>[...MockData.roleplayTranscript];
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _send() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _messages.add(ChatMessage(fromLearner: true, text: text));
      _messages.add(const ChatMessage(fromLearner: false, text: '(MOCK) Thank you. What else can you offer me?'));
    });
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final sc = _scenario(widget.code);
    return MockScaffold(
      title: sc.title,
      actions: [
        TextButton(
          onPressed: () => context.pushReplacement(Routes.roleplayFeedback(sc.code)),
          child: Text(s.t('endConversation')),
        ),
      ],
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            color: context.colors.surfaceContainerHighest,
            child: Text('${sc.emoji}  ${sc.persona}\n🎯 ${sc.goal}', textDirection: TextDirection.ltr),
          ),
          Expanded(child: ChatList(messages: _messages)),
          ChatInput(
            controller: _controller,
            hintKey: 'typeOrSpeak',
            onSend: _send,
            onMic: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('speakingPending')))),
          ),
        ],
      ),
    );
  }
}

class RoleplayFeedbackScreen extends StatelessWidget {
  const RoleplayFeedbackScreen({super.key, required this.code});

  final String code;

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final sc = _scenario(code);
    Widget fix(String from, String to) => ListTile(
          dense: true,
          title: Text(from, textDirection: TextDirection.ltr, style: const TextStyle(decoration: TextDecoration.lineThrough, color: AppTokens.bad)),
          subtitle: Text(to, textDirection: TextDirection.ltr, style: const TextStyle(color: AppTokens.good, fontWeight: FontWeight.w700)),
        );
    return MockScaffold(
      title: '${s.t('feedback')}: ${sc.title}',
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          SectionTitle(s.t('summary')),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              '(MOCK) You stayed calm, apologised and offered a solution. Next time, name the solution first and use future tense for promises.',
              textDirection: TextDirection.ltr,
            ),
          ),
          SectionTitle(s.t('grammarFixes')),
          for (final g in MockData.feedbackGrammar) fix(g.$1, g.$2),
          SectionTitle(s.t('betterWords')),
          for (final b in MockData.feedbackBetterWords) fix(b.$1, b.$2),
          SectionTitle(s.t('naturalPhrases')),
          for (final ph in MockData.feedbackPhrases)
            ListTile(dense: true, leading: const Icon(Icons.format_quote), title: Text(ph, textDirection: TextDirection.ltr)),
          SectionTitle(s.t('pronunciation')),
          for (final pr in MockData.feedbackPronunciation) MasteryBar(label: pr.$1, value: pr.$2),
          SectionTitle(s.t('newWords')),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(spacing: 8, children: [for (final w in MockData.feedbackNewWords) Chip(label: Text(w))]),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: FilledButton(onPressed: () => context.go(Routes.home), child: Text(s.t('done'))),
          ),
        ],
      ),
    );
  }
}
