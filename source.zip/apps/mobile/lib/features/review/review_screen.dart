import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/widgets/common.dart';
import '../../data/mock/mock_data.dart';
import '../../domain/models.dart';
import '../../state/session.dart';

/// Review Today: only what is due, ordered by priority (lowest mastery first
/// in Phase 2; the full priority formula lands with learning_core in Phase 6).
class ReviewTodayScreen extends ConsumerWidget {
  const ReviewTodayScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final s = context.s;
    final items = MockData.reviewFor(p);

    return MockScaffold(
      title: s.t('reviewToday'),
      body: items.isEmpty
          ? EmptyState(emoji: '🌟', message: s.t('reviewEmpty'))
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: items.length,
                    itemBuilder: (context, i) {
                      final it = items[i];
                      final (String reasonKey, IconData icon) = switch (it.reason) {
                        ReviewReason.due => ('reasonDue', Icons.event_available),
                        ReviewReason.weak => ('reasonWeak', Icons.trending_down),
                        ReviewReason.recentError => ('reasonError', Icons.error_outline),
                      };
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: masteryColor(it.mastery).withValues(alpha: 0.15),
                          child: Icon(icon, color: masteryColor(it.mastery)),
                        ),
                        title: Text(it.title, textDirection: TextDirection.ltr),
                        subtitle: Text(s.t(reasonKey)),
                        trailing: Text('${(it.mastery * 100).round()}%',
                            style: TextStyle(fontWeight: FontWeight.w700, color: masteryColor(it.mastery))),
                        onTap: it.kind == 'word' ? () => context.push(Routes.word(it.title)) : null,
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      // Real spaced review arrives in Phase 6; until then practise from the course map.
                      onPressed: () => context.go(Routes.learn),
                      icon: const Icon(Icons.play_arrow),
                      label: Text('${s.t('startReview')} (${items.length})'),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
