import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/text_dir.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/account_widgets.dart';
import '../../core/widgets/common.dart';
import '../../domain/plan.dart';
import '../../state/plan.dart';
import '../../state/session.dart';
import '../learn/learn_screens.dart';
import '../plan/plan_widgets.dart';

/// Review Today (Phase 6, real): what the review box says is due, weakest
/// first, and mastery per skill. "Start review" opens a server-marked session.
class ReviewTodayScreen extends ConsumerWidget {
  const ReviewTodayScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final s = context.s;
    final value = ref.watch(reviewOverviewProvider(p.id));

    return AccountScaffold(
      title: s.t('reviewToday'),
      body: AsyncBody<ReviewOverview>(
        value: value,
        onRetry: () => ref.invalidate(reviewOverviewProvider(p.id)),
        data: (o) => RefreshIndicator(
          onRefresh: () async {
            try {
              await ref.refresh(reviewOverviewProvider(p.id).future);
            } catch (_) {
              // shown by AsyncBody
            }
          },
          child: ListView(
            padding: const EdgeInsets.only(bottom: 24),
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
                child: Row(
                  children: [
                    Expanded(child: StatTile(label: s.t('dueToday'), value: '${o.dueToday}', icon: Icons.event_available, color: o.dueToday > 0 ? AppTokens.warn : AppTokens.good)),
                    Expanded(child: StatTile(label: s.t('dueTomorrow'), value: '${o.dueTomorrow}', icon: Icons.schedule)),
                    Expanded(child: StatTile(label: s.t('mastered'), value: '${o.mastered}', icon: Icons.workspace_premium_outlined, color: AppTokens.good)),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Text(s.t('reviewBoxNote'), style: context.text.bodySmall),
              ),
              if (o.dueToday > 0)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                  child: FilledButton.icon(
                    onPressed: () => context.push(Routes.reviewRun),
                    icon: const Icon(Icons.play_arrow),
                    label: Text('${s.t('startReview')} (${o.dueToday > 10 ? 10 : o.dueToday})'),
                  ),
                )
              else
                EmptyState(emoji: o.reviewedToday ? '🏆' : '🌟', message: s.t('reviewEmpty')),
              if (o.items.isNotEmpty) SectionTitle(s.t('reasonDue')),
              for (final it in o.items)
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: masteryColor(it.strength).withValues(alpha: 0.15),
                    child: Icon(it.lastResult == false ? Icons.error_outline : Icons.event_available, color: masteryColor(it.strength)),
                  ),
                  title: Text(it.prompt, maxLines: 2, overflow: TextOverflow.ellipsis, textDirection: contentDir(it.prompt)),
                  subtitle: Text(it.lastResult == false ? '${it.skill} · ${s.t('reasonError')}' : it.skill),
                  trailing: Text(s.f('reviewBox', [it.box > 5 ? 5 : it.box]),
                      style: TextStyle(fontWeight: FontWeight.w700, color: masteryColor(it.strength))),
                ),
              SkillMasteryList(profileId: p.id),
            ],
          ),
        ),
      ),
    );
  }
}
