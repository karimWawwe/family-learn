import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart' hide TextDirection;

import '../../core/l10n/app_strings.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/common.dart';
import '../../data/mock/mock_data.dart';
import '../../domain/models.dart';
import '../../state/session.dart';

class VocabularyScreen extends ConsumerStatefulWidget {
  const VocabularyScreen({super.key});

  @override
  ConsumerState<VocabularyScreen> createState() => _VocabularyScreenState();
}

class _VocabularyScreenState extends ConsumerState<VocabularyScreen> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final s = context.s;
    final all = MockData.vocabFor(p);
    final q = _query.trim().toLowerCase();
    final words = q.isEmpty
        ? all
        : all.where((v) => v.word.toLowerCase().contains(q) || v.meaningAr.contains(q)).toList();

    return MockScaffold(
      title: s.t('vocabulary'),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: s.t('search')),
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          Expanded(
            child: ListView.separated(
              itemCount: words.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final v = words[i];
                return ListTile(
                  title: Text(v.word, textDirection: TextDirection.ltr, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(s.isArabic ? v.meaningAr : v.meaningEn),
                  trailing: Text('${(v.mastery * 100).round()}%',
                      style: TextStyle(color: masteryColor(v.mastery), fontWeight: FontWeight.w700)),
                  onTap: () => context.push(Routes.word(v.word)),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class WordDetailScreen extends ConsumerWidget {
  const WordDetailScreen({super.key, required this.word});

  final String word;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(currentProfileProvider);
    if (p == null) return const SizedBox.shrink();
    final s = context.s;
    final list = MockData.vocabFor(p).where((v) => v.word == word).toList();
    if (list.isEmpty) {
      return MockScaffold(title: word, body: EmptyState(emoji: '🔎', message: word));
    }
    final VocabItem v = list.first;
    final df = DateFormat.yMMMd(s.locale.languageCode);

    return MockScaffold(
      title: v.word,
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(v.word, textDirection: TextDirection.ltr,
                            style: context.text.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
                      ),
                      IconButton.filledTonal(
                        tooltip: 'Pronunciation (Phase 9)',
                        onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('🔊 ${v.word} ${v.ipa}  (MOCK - audio in Phase 9)')),
                        ),
                        icon: const Icon(Icons.volume_up),
                      ),
                    ],
                  ),
                  Text(v.ipa, textDirection: TextDirection.ltr, style: context.text.titleMedium?.copyWith(color: context.colors.onSurfaceVariant)),
                  const SizedBox(height: 12),
                  Text(s.t('meaning'), style: context.text.labelLarge),
                  Text(v.meaningEn, textDirection: TextDirection.ltr),
                  Text(v.meaningAr, textDirection: TextDirection.rtl),
                  const SizedBox(height: 12),
                  Text(s.t('example'), style: context.text.labelLarge),
                  Text(v.example, textDirection: TextDirection.ltr, style: const TextStyle(fontStyle: FontStyle.italic)),
                ],
              ),
            ),
          ),
          MasteryBar(label: s.t('mastery'), value: v.mastery),
          ListTile(title: Text(s.t('difficulty')), trailing: Text('${'●' * v.difficulty}${'○' * (5 - v.difficulty)}')),
          ListTile(title: Text(s.t('errors')), trailing: Text('${v.errors}')),
          ListTile(title: Text(s.t('lastReview')), trailing: Text(v.lastReview == null ? s.t('never') : df.format(v.lastReview!))),
          ListTile(title: Text(s.t('nextReview')), trailing: Text(df.format(v.nextReview))),
          ListTile(title: const Text('Domain'), trailing: Chip(label: Text(v.domain))),
        ],
      ),
    );
  }
}
