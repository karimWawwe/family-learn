import 'package:flutter/material.dart';

import '../../domain/models.dart';

/// Design tokens shared by both experiences.
class AppTokens {
  static const radiusKid = 24.0;
  static const radiusPro = 12.0;
  static const gap = 16.0;

  // Semantic colors (same meaning in both themes)
  static const good = Color(0xFF1E9E5A);
  static const warn = Color(0xFFE39B1B);
  static const bad = Color(0xFFD64545);
  static const xp = Color(0xFF7C4DFF);
  static const coin = Color(0xFFF2B400);
}

/// Two themes, one set of screens:
///  - kid: playful, larger type and touch targets, rounded shapes.
///  - pro: calm, dense, professional.
class AppTheme {
  static ThemeData forMode(UiMode mode, {Brightness brightness = Brightness.light}) =>
      mode == UiMode.kid ? kid(brightness) : pro(brightness);

  static ThemeData kid(Brightness b) {
    final scheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF3A86FF),
      secondary: const Color(0xFFFF8C42),
      tertiary: const Color(0xFF2EC4B6),
      brightness: b,
    );
    final base = ThemeData(colorScheme: scheme, useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: b == Brightness.light ? const Color(0xFFF4F8FF) : scheme.surface,
      // base.textTheme has no font sizes yet (they are added later by Theme.of),
      // so merge in the size geometry before scaling, otherwise apply() asserts.
      textTheme: base.typography.englishLike.merge(base.textTheme).apply(fontSizeFactor: 1.12),
      cardTheme: CardThemeData(
        elevation: 0,
        color: scheme.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppTokens.radiusKid)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(64, 56),
          textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppTokens.radiusKid)),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(64, 52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppTokens.radiusKid)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppTokens.radiusKid)),
      ),
      navigationBarTheme: const NavigationBarThemeData(height: 72),
    );
  }

  static ThemeData pro(Brightness b) {
    final scheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF1F3A5F),
      secondary: const Color(0xFFB08D57),
      brightness: b,
    );
    final base = ThemeData(colorScheme: scheme, useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: b == Brightness.light ? const Color(0xFFF6F7F9) : scheme.surface,
      cardTheme: CardThemeData(
        elevation: 0,
        color: scheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppTokens.radiusPro),
          side: BorderSide(color: scheme.outlineVariant),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(64, 48),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppTokens.radiusPro)),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(64, 48),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppTokens.radiusPro)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppTokens.radiusPro)),
      ),
    );
  }
}

extension ThemeX on BuildContext {
  ThemeData get theme => Theme.of(this);
  ColorScheme get colors => Theme.of(this).colorScheme;
  TextTheme get text => Theme.of(this).textTheme;
}
