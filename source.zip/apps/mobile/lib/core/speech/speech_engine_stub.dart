import 'speech_engine.dart';

/// Used outside the browser (tests, and native builds until a native
/// speech plugin is added).
SpeechEngine createEngine() => UnsupportedSpeechEngine();

class UnsupportedSpeechEngine implements SpeechEngine {
  @override
  bool get recognitionSupported => false;

  @override
  bool get ttsSupported => false;

  @override
  Stream<SpeechEvent> listen({String lang = 'en-US'}) => Stream.fromIterable(const [
        SpeechEvent(SpeechEventType.error, error: 'not-supported'),
        SpeechEvent(SpeechEventType.ended),
      ]);

  @override
  void stop() {}

  @override
  void cancel() {}

  @override
  Future<void> speak(String text, {String lang = 'en-US', double rate = 0.85, double pitch = 1.05}) async {}

  @override
  bool hasVoice(String lang) => false;

  @override
  void keepAwake(bool on) {}

  @override
  void stopSpeaking() {}

  @override
  void playSfx(Sfx sfx) {}

  @override
  void unlockAudio() {}
}
