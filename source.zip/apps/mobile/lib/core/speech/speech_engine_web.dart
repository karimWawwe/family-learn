import 'dart:async';
import 'dart:convert';
import 'dart:js_interop';

import 'speech_engine.dart';

/// Talks to `window.flSpeech` (web/speech_bridge.js).
SpeechEngine createEngine() => WebSpeechEngine();

@JS('flSpeech')
external _Bridge? get _bridge;

extension type _Bridge._(JSObject _) implements JSObject {
  external bool recognitionSupported();
  external bool ttsSupported();
  external void start(String lang, JSFunction onEvent, bool continuous);
  external void stop();
  external void abort();
  external void speak(String text, String lang, double rate, double pitch, JSFunction onEnd);
  external bool hasVoice(String lang);
  external void keepAwake(bool on);
  external void cancelSpeak();
  external void sfx(String kind);
  external void unlock();
}

class WebSpeechEngine implements SpeechEngine {
  StreamController<SpeechEvent>? _current;

  _Bridge? get _b {
    try {
      return _bridge;
    } catch (_) {
      return null;
    }
  }

  @override
  bool get recognitionSupported {
    try {
      return _b?.recognitionSupported() ?? false;
    } catch (_) {
      return false;
    }
  }

  @override
  bool get ttsSupported {
    try {
      return _b?.ttsSupported() ?? false;
    } catch (_) {
      return false;
    }
  }

  @override
  Stream<SpeechEvent> listen({String lang = 'en-US', bool continuous = false}) {
    _closeCurrent();
    final c = StreamController<SpeechEvent>();
    _current = c;
    final b = _b;
    if (b == null || !recognitionSupported) {
      c.add(const SpeechEvent(SpeechEventType.error, error: 'not-supported'));
      c.add(const SpeechEvent(SpeechEventType.ended));
      c.close();
      return c.stream;
    }

    void onEvent(JSString type, JSString data) {
      if (c.isClosed) return;
      final t = type.toDart;
      final d = data.toDart;
      switch (t) {
        case 'start':
          c.add(const SpeechEvent(SpeechEventType.started));
        case 'sound':
          c.add(const SpeechEvent(SpeechEventType.sound));
        case 'result':
          final m = jsonDecode(d) as Map<String, dynamic>;
          final alts = [
            for (final a in (m['alts'] as List? ?? const []))
              SpeechAlt('${(a as Map)['t'] ?? ''}', ((a['c'] as num?) ?? 0).toDouble()),
          ];
          c.add(SpeechEvent(m['final'] == true ? SpeechEventType.finalResult : SpeechEventType.partial,
              alternatives: alts));
        case 'error':
          c.add(SpeechEvent(SpeechEventType.error, error: d.isEmpty ? 'unknown' : d));
        case 'end':
          c.add(const SpeechEvent(SpeechEventType.ended));
          c.close();
          if (identical(_current, c)) _current = null;
      }
    }

    try {
      b.start(lang, onEvent.toJS, continuous);
    } catch (e) {
      c.add(SpeechEvent(SpeechEventType.error, error: 'start-failed'));
      c.add(const SpeechEvent(SpeechEventType.ended));
      c.close();
    }
    return c.stream;
  }

  void _closeCurrent() {
    final c = _current;
    _current = null;
    if (c != null && !c.isClosed) {
      try {
        _b?.abort();
      } catch (_) {}
      c.add(const SpeechEvent(SpeechEventType.ended));
      c.close();
    }
  }

  @override
  void stop() {
    try {
      _b?.stop();
    } catch (_) {}
  }

  @override
  void cancel() => _closeCurrent();

  @override
  Future<void> speak(String text, {String lang = 'en-US', double rate = 0.85, double pitch = 1.05}) {
    final b = _b;
    if (b == null || !ttsSupported) return Future.value();
    final done = Completer<void>();
    void onEnd() {
      if (!done.isCompleted) done.complete();
    }

    try {
      b.speak(text, lang, rate, pitch, onEnd.toJS);
    } catch (_) {
      onEnd();
    }
    // Safety net: some browsers never fire "end".
    final ms = 2500 + text.length * 160 ~/ (rate <= 0 ? 1 : rate);
    return done.future.timeout(Duration(milliseconds: ms), onTimeout: () {});
  }

  @override
  bool hasVoice(String lang) {
    try {
      return _b?.hasVoice(lang) ?? false;
    } catch (_) {
      return false;
    }
  }

  @override
  void keepAwake(bool on) {
    try {
      _b?.keepAwake(on);
    } catch (_) {}
  }

  @override
  void stopSpeaking() {
    try {
      _b?.cancelSpeak();
    } catch (_) {}
  }

  @override
  void playSfx(Sfx sfx) {
    try {
      _b?.sfx(sfx.name);
    } catch (_) {}
  }

  @override
  void unlockAudio() {
    try {
      _b?.unlock();
    } catch (_) {}
  }
}
