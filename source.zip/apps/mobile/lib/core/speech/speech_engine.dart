import '../../features/speak_game/pronunciation.dart';
import 'speech_engine_stub.dart' if (dart.library.js_interop) 'speech_engine_web.dart' as impl;

export '../../features/speak_game/pronunciation.dart' show SpeechAlt;

/// What happens while the microphone is open.
enum SpeechEventType {
  /// The browser started listening (the mic is really open).
  started,

  /// Some sound / speech was detected.
  sound,

  /// Words so far (not final yet).
  partial,

  /// The recogniser's final words for this attempt.
  finalResult,

  /// Something went wrong; see [SpeechEvent.error].
  error,

  /// Listening stopped (always the last event).
  ended,
}

class SpeechEvent {
  const SpeechEvent(this.type, {this.alternatives = const [], this.error});

  final SpeechEventType type;
  final List<SpeechAlt> alternatives;

  /// Web Speech API error code: no-speech, audio-capture, not-allowed,
  /// service-not-allowed, network, aborted, language-not-supported ...
  final String? error;
}

enum Sfx { success, star, tryAgain, levelUp, tap, start }

/// Microphone speech recognition + text-to-speech + little sound effects.
/// On the web (the app today) it uses the browser's Web Speech API through
/// web/speech_bridge.js. Elsewhere it reports "not supported".
abstract class SpeechEngine {
  bool get recognitionSupported;
  bool get ttsSupported;

  /// Opens the microphone for ONE attempt (only ever called from a tap).
  /// With [continuous] the browser keeps listening through short pauses and
  /// the caller stops it ([stop]) after a silence. The stream always ends with
  /// [SpeechEventType.ended].
  Stream<SpeechEvent> listen({String lang = 'en-US', bool continuous = false});

  /// Stop listening and deliver what was heard so far.
  void stop();

  /// Stop listening and throw away the result.
  void cancel();

  /// Reads [text] aloud. Completes when finished (or after a safety timeout).
  Future<void> speak(String text, {String lang = 'en-US', double rate = 0.85, double pitch = 1.05});

  /// True when the device has a voice for [lang] (e.g. 'ar-SA').
  bool hasVoice(String lang);

  /// Keep the screen on (story playing) or let it sleep again.
  void keepAwake(bool on);

  void stopSpeaking();

  void playSfx(Sfx sfx);

  /// Call from a tap: lets iOS play sounds later.
  void unlockAudio();
}

SpeechEngine createSpeechEngine() => impl.createEngine();
