/// Build-time settings, passed with:
///   flutter run --dart-define-from-file=env.json
/// (copy env.example.json to env.json and paste your Supabase values).
///
/// Without them the app runs in DEMO mode (in memory, nothing is saved).
class Env {
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');

  /// The "anon public" (or "publishable") key. It is safe inside the app:
  /// every table is protected by Row Level Security.
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  static bool get hasSupabase => supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;
}
