import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/ai/roleplay_screens.dart';
import '../../features/ai/tutor_chat_screen.dart';
import '../../features/home/home_screen.dart';
import '../../features/learn/learn_screens.dart';
import '../../features/onboarding/onboarding_screens.dart';
import '../../features/parent/family_admin_screens.dart';
import '../../features/parent/parent_screens.dart';
import '../../features/placement/placement_screens.dart';
import '../../features/profiles/profile_screens.dart';
import '../../features/progress/progress_screens.dart';
import '../../features/review/review_screen.dart';
import '../../features/settings/settings_screen.dart';
import '../../features/speak_game/speak_game_screens.dart';
import '../../features/shell/main_shell.dart';
import '../../features/vocab/vocab_screens.dart';
import '../../domain/account.dart';
import '../../domain/learning.dart';
import '../../state/account.dart';
import '../../state/session.dart';

class Routes {
  static const splash = '/';
  static const startupError = '/offline';
  static const welcome = '/welcome';
  static const signIn = '/sign-in';
  static const signUp = '/sign-up';
  static const verifyEmail = '/verify-email';
  static const forgotPassword = '/forgot-password';
  static const childDeviceLink = '/child-phone';
  static const consent = '/consent';
  static const createFamily = '/create-family';
  static const profiles = '/profiles';
  static const home = '/home';
  static const learn = '/learn';
  static const review = '/review';
  static const progress = '/progress';
  static const more = '/more';
  static const vocab = '/vocab';
  static const tutor = '/tutor';
  static const roleplay = '/roleplay';
  static const achievements = '/achievements';
  static const shop = '/shop';
  static const parent = '/parent';
  static const settings = '/settings';
  static const placementResult = '/placement-result';
  static const lessonComplete = '/lesson-complete';
  static const speak = '/speak';

  static String pin(String profileId) => '/pin/$profileId';
  static String placement(String profileId) => '/placement/$profileId';
  static String lesson(String lessonId) => '/lesson/$lessonId';
  static String speakPlay(String levelId) => '/speak/play/${Uri.encodeComponent(levelId)}';
  static String placementRun(String profileId) => '/placement/$profileId/run';
  static String word(String word) => '/word/${Uri.encodeComponent(word)}';
  static String roleplayScenario(String code) => '/roleplay/$code';
  static String roleplayFeedback(String code) => '/roleplay/$code/feedback';
  static String childReport(String profileId) => '/parent/child/$profileId';
  static String linkDevice(String profileId) => '/parent/link/$profileId';
  static String setPin(String profileId) => '/parent/pin/$profileId';
  static const addLearner = '/parent/add';
  static String verifyEmailFor(String email) => '$verifyEmail?email=${Uri.encodeQueryComponent(email)}';

  /// Reachable without an account.
  static const _public = {welcome, signIn, signUp, verifyEmail, forgotPassword, childDeviceLink};

  /// Reachable after e-mail confirmation, before the family exists.
  static const _familySetup = {consent, createFamily};
}

/// Where the app must go, given the account and the open profile.
/// Returns null to stay. Pure function so it can be unit-tested.
String? redirectFor({
  required String path,
  required AsyncValue<AccountState> account,
  required String? openProfileId,
  required bool openProfileExists,
  required bool openProfileIsParent,
}) {
  final a = account.valueOrNull;
  if (a == null) {
    if (account.hasError) return path == Routes.startupError ? null : Routes.startupError;
    return path == Routes.splash ? null : Routes.splash;
  }
  final isPublic = Routes._public.contains(path);
  final isSetup = Routes._familySetup.contains(path);
  final isBoot = path == Routes.splash || path == Routes.startupError;

  switch (a.stage) {
    case AccountStage.signedOut:
      return isPublic ? null : Routes.welcome;
    case AccountStage.needsFamily:
      return isSetup ? null : Routes.consent;
    case AccountStage.ready:
      break;
  }

  final hasProfile = openProfileId != null && openProfileExists;

  if (a.isChildDevice) {
    final mine = a.deviceProfileId!;
    final pinPath = Routes.pin(mine);
    // A child's phone only ever opens its own profile.
    if (!hasProfile || openProfileId != mine) return path == pinPath ? null : pinPath;
    final blocked = isPublic ||
        isSetup ||
        isBoot ||
        path == Routes.profiles ||
        path.startsWith('/pin/') ||
        path.startsWith(Routes.parent);
    return blocked ? Routes.home : null;
  }

  // Parent account
  final chooser = path == Routes.profiles || path.startsWith('/pin/');
  if (isPublic || isSetup || isBoot) return hasProfile ? Routes.home : Routes.profiles;
  if (!hasProfile) return chooser ? null : Routes.profiles;
  if (path.startsWith(Routes.parent) && !openProfileIsParent) return Routes.home;
  return null;
}

final _rootKey = GlobalKey<NavigatorState>(debugLabel: 'root');

final routerProvider = Provider<GoRouter>((ref) {
  final refresh = ValueNotifier<int>(0);
  ref.listen(sessionProvider, (_, __) => refresh.value++);
  ref.listen(accountProvider, (_, __) => refresh.value++);
  ref.onDispose(refresh.dispose);

  return GoRouter(
    navigatorKey: _rootKey,
    initialLocation: Routes.splash,
    refreshListenable: refresh,
    redirect: (context, state) {
      final openId = ref.read(sessionProvider).profileId;
      final open = ref.read(currentProfileProvider);
      return redirectFor(
        path: state.uri.path,
        account: ref.read(accountProvider),
        openProfileId: openId,
        openProfileExists: open != null,
        openProfileIsParent: open?.isParent ?? false,
      );
    },
    routes: [
      GoRoute(path: Routes.splash, builder: (_, __) => const SplashScreen()),
      GoRoute(path: Routes.startupError, builder: (_, __) => const StartupErrorScreen()),
      GoRoute(path: Routes.welcome, builder: (_, __) => const WelcomeScreen()),
      GoRoute(path: Routes.signIn, builder: (_, __) => const SignInScreen()),
      GoRoute(path: Routes.signUp, builder: (_, __) => const SignUpScreen()),
      GoRoute(
        path: Routes.verifyEmail,
        builder: (_, st) => VerifyEmailScreen(email: st.uri.queryParameters['email'] ?? ''),
      ),
      GoRoute(path: Routes.forgotPassword, builder: (_, __) => const ForgotPasswordScreen()),
      GoRoute(path: Routes.childDeviceLink, builder: (_, __) => const ChildDeviceLinkScreen()),
      GoRoute(path: Routes.consent, builder: (_, __) => const ConsentScreen()),
      GoRoute(path: Routes.createFamily, builder: (_, __) => const CreateFamilyScreen()),
      GoRoute(path: Routes.profiles, builder: (_, __) => const ProfilePickerScreen()),
      GoRoute(path: '/pin/:id', builder: (_, st) => PinScreen(profileId: st.pathParameters['id']!)),
      GoRoute(path: '/placement/:id', builder: (_, st) => PlacementIntroScreen(profileId: st.pathParameters['id']!)),
      GoRoute(
        path: '/placement/:id/run',
        builder: (_, st) => const LessonPlayerScreen(lessonId: 'placement', isPlacement: true),
      ),
      GoRoute(path: Routes.placementResult, builder: (_, __) => const PlacementResultScreen()),
      StatefulShellRoute.indexedStack(
        builder: (context, state, shell) => MainShell(shell: shell),
        branches: [
          StatefulShellBranch(routes: [GoRoute(path: Routes.home, builder: (_, __) => const HomeScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: Routes.learn, builder: (_, __) => const CourseMapScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: Routes.review, builder: (_, __) => const ReviewTodayScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: Routes.progress, builder: (_, __) => const ProgressScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: Routes.more, builder: (_, __) => const MoreScreen())]),
        ],
      ),
      GoRoute(path: '/lesson/:id', builder: (_, st) => LessonPlayerScreen(lessonId: st.pathParameters['id']!)),
      GoRoute(
        path: Routes.lessonComplete,
        builder: (_, st) => LessonCompleteScreen(outcome: st.extra is LessonOutcome ? st.extra! as LessonOutcome : null),
      ),
      GoRoute(path: Routes.speak, builder: (_, __) => const SpeakGameHomeScreen()),
      GoRoute(
        path: '/speak/play/:level',
        builder: (_, st) => SpeakPlayScreen(key: ValueKey(st.uri.toString()), levelId: st.pathParameters['level']!),
      ),
      GoRoute(path: Routes.vocab, builder: (_, __) => const VocabularyScreen()),
      GoRoute(path: '/word/:word', builder: (_, st) => WordDetailScreen(word: st.pathParameters['word']!)),
      GoRoute(path: Routes.tutor, builder: (_, __) => const TutorChatScreen()),
      GoRoute(path: Routes.roleplay, builder: (_, __) => const RoleplayLibraryScreen()),
      GoRoute(path: '/roleplay/:code', builder: (_, st) => RoleplayConversationScreen(code: st.pathParameters['code']!)),
      GoRoute(path: '/roleplay/:code/feedback', builder: (_, st) => RoleplayFeedbackScreen(code: st.pathParameters['code']!)),
      GoRoute(path: Routes.achievements, builder: (_, __) => const AchievementsScreen()),
      GoRoute(path: Routes.shop, builder: (_, __) => const ShopScreen()),
      GoRoute(path: Routes.parent, builder: (_, __) => const ParentDashboardScreen()),
      GoRoute(path: '/parent/child/:id', builder: (_, st) => ChildReportScreen(profileId: st.pathParameters['id']!)),
      GoRoute(path: '/parent/link/:id', builder: (_, st) => LinkDeviceScreen(profileId: st.pathParameters['id']!)),
      GoRoute(path: '/parent/pin/:id', builder: (_, st) => SetPinScreen(profileId: st.pathParameters['id']!)),
      GoRoute(path: Routes.addLearner, builder: (_, __) => const AddLearnerScreen()),
      GoRoute(path: Routes.settings, builder: (_, __) => const SettingsScreen()),
    ],
  );
});
