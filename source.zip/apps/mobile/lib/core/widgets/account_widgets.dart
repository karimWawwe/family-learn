import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/account.dart';
import '../../state/account.dart';
import '../l10n/app_strings.dart';
import '../theme/app_theme.dart';
import 'common.dart';

/// Scaffold for screens that use REAL account data (Phase 3).
/// No MOCK strip; in demo mode (no Supabase keys) a DEMO strip is shown instead.
class AccountScaffold extends ConsumerWidget {
  const AccountScaffold({super.key, this.title, required this.body, this.actions});

  final String? title;
  final Widget body;
  final List<Widget>? actions;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final demo = ref.watch(authRepositoryProvider).isDemo;
    return MockScaffold(
      title: title,
      actions: actions,
      showBanner: demo,
      bannerKey: 'demoMode',
      body: body,
    );
  }
}

/// Text for an error thrown by the account backend.
String failureText(BuildContext context, Object error) =>
    context.s.t(error is AuthFailure ? error.messageKey : 'err_unknown');

class ErrorText extends StatelessWidget {
  const ErrorText(this.message, {super.key});

  final String? message;

  @override
  Widget build(BuildContext context) {
    if (message == null) return const SizedBox.shrink();
    return Semantics(
      liveRegion: true,
      child: Container(
        margin: const EdgeInsets.only(top: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppTokens.bad.withValues(alpha: 0.10),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            const Icon(Icons.error_outline, color: AppTokens.bad),
            const SizedBox(width: 8),
            Expanded(child: Text(message!, style: const TextStyle(color: AppTokens.bad, fontWeight: FontWeight.w600))),
          ],
        ),
      ),
    );
  }
}

/// Filled button that shows a spinner and ignores taps while [busy].
class BusyButton extends StatelessWidget {
  const BusyButton({super.key, required this.label, required this.busy, required this.onPressed});

  final String label;
  final bool busy;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return FilledButton(
      onPressed: busy ? null : onPressed,
      child: busy
          ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5))
          : Text(label),
    );
  }
}

/// Mixin for forms that call the backend: one action at a time, error shown inline.
mixin BusyForm<T extends StatefulWidget> on State<T> {
  bool busy = false;
  String? error;

  Future<void> guard(Future<void> Function() action) async {
    if (busy) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await action();
    } catch (e) {
      if (mounted) setState(() => error = failureText(context, e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }
}
