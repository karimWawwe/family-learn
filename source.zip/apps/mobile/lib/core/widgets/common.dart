import 'package:flutter/material.dart';

import '../l10n/app_strings.dart';
import '../theme/app_theme.dart';

/// Strip shown on every screen that uses MOCK DATA, so no preview is ever
/// mistaken for real learning data.
class MockBanner extends StatelessWidget {
  const MockBanner({super.key, this.messageKey = 'mockData'});

  final String messageKey;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'mock data banner',
      child: Container(
        width: double.infinity,
        color: const Color(0xFFFFF3CD),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: Row(
          children: [
            const Icon(Icons.science_outlined, size: 16, color: Color(0xFF7A5B00)),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                context.s.t(messageKey),
                style: const TextStyle(fontSize: 12, color: Color(0xFF7A5B00), fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Scaffold with the MOCK DATA strip under the app bar.
class MockScaffold extends StatelessWidget {
  const MockScaffold({
    super.key,
    this.title,
    required this.body,
    this.actions,
    this.bottom,
    this.floatingActionButton,
    this.showBanner = true,
    this.bannerKey = 'mockData',
  });

  final String? title;
  final Widget body;
  final List<Widget>? actions;
  final Widget? bottom;
  final Widget? floatingActionButton;
  final bool showBanner;
  final String bannerKey;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: title == null ? null : AppBar(title: Text(title!), actions: actions),
      floatingActionButton: floatingActionButton,
      bottomNavigationBar: bottom,
      body: SafeArea(
        top: title == null,
        child: Column(
          children: [
            if (showBanner) MockBanner(messageKey: bannerKey),
            Expanded(child: body),
          ],
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key, this.trailing});

  final String text;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
      child: Row(
        children: [
          Expanded(child: Text(text, style: context.text.titleMedium?.copyWith(fontWeight: FontWeight.w700))),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

class StatTile extends StatelessWidget {
  const StatTile({super.key, required this.label, required this.value, this.icon, this.color});

  final String label;
  final String value;
  final IconData? icon;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (icon != null) Icon(icon, color: color ?? context.colors.primary),
            if (icon != null) const SizedBox(height: 6),
            Text(value, style: context.text.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(label, style: context.text.bodySmall?.copyWith(color: context.colors.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }
}

Color masteryColor(double m) => m >= 0.8
    ? AppTokens.good
    : m >= 0.5
        ? AppTokens.warn
        : AppTokens.bad;

class MasteryBar extends StatelessWidget {
  const MasteryBar({super.key, required this.label, required this.value});

  final String label;
  final double value;

  @override
  Widget build(BuildContext context) {
    final pct = (value * 100).round();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label)),
              Text('$pct%', style: TextStyle(fontWeight: FontWeight.w700, color: masteryColor(value))),
            ],
          ),
          const SizedBox(height: 4),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: value.clamp(0.0, 1.0).toDouble(),
              minHeight: 8,
              color: masteryColor(value),
              backgroundColor: context.colors.surfaceContainerHighest,
            ),
          ),
        ],
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.emoji, required this.message});

  final String emoji;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 56)),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center, style: context.text.titleMedium),
          ],
        ),
      ),
    );
  }
}

/// Small grey note used where a feature needs a later phase (AI, speech, auth).
class PendingNote extends StatelessWidget {
  const PendingNote(this.messageKey, {super.key});

  final String messageKey;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: context.colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline, color: context.colors.onSurfaceVariant),
          const SizedBox(width: 8),
          Expanded(child: Text(context.s.t(messageKey), style: context.text.bodySmall)),
        ],
      ),
    );
  }
}
