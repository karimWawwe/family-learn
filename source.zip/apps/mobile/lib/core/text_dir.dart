import 'package:flutter/widgets.dart';

final _arabic = RegExp(r'[؀-ۿݐ-ݿࢠ-ࣿﭐ-﷿ﹰ-﻿]');

/// True when [text] contains Arabic letters.
bool hasArabic(String? text) => text != null && _arabic.hasMatch(text);

/// Lesson content can be English (LTR) or Arabic (RTL, e.g. Arabic language,
/// religion and social studies courses). The layout follows the content, not
/// the app language.
TextDirection contentDir(String? text) => hasArabic(text) ? TextDirection.rtl : TextDirection.ltr;
