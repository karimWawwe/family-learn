import 'dart:async';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../../domain/account.dart';
import '../../domain/math_games.dart';
import '../../domain/models.dart';

/// Math games progress, separate for every profile.
///  * [SupabaseMathRepository] - real, saved (math_state / math_finish).
///  * [DemoMathRepository]     - in memory (DEMO mode and tests), same rules.
/// Throws AuthFailure: not_found, lesson_locked, network, math_not_installed, unknown.
abstract class MathRepository {
  Future<MathState> load(LearnerProfile profile);
  Future<MathState> finish(LearnerProfile profile, MathRoundResult r);
}

MathState mathStateFromJson(Map<String, dynamic> j) {
  int i(Object? v) => (v as num?)?.toInt() ?? 0;
  return MathState(
    levels: {
      for (final l in (j['levels'] as List? ?? const []).cast<Map>())
        '${l['game']}|${l['level']}': MathBest(
          bestStars: i(l['best_stars']),
          bestPoints: i(l['best_points']),
          bestCorrect: i(l['best_correct']),
          total: i(l['total']),
          plays: i(l['plays']),
        ),
    },
    points: i(j['points']),
    stars: i(j['stars']),
    rounds: i(j['rounds']),
  );
}

final _levelRe = {
  MathGame.times: RegExp(r'^(t([1-9]|1[0-2])|mixed)-(easy|medium|hard)$'),
  MathGame.clock: RegExp(r'^clock-[1-5]$'),
};

class SupabaseMathRepository implements MathRepository {
  SupabaseMathRepository(this._client);

  final SupabaseClient _client;

  Future<Object?> _rpc(String fn, Map<String, dynamic> params) async {
    try {
      return await _client.rpc(fn, params: params).timeout(const Duration(seconds: 20));
    } on PostgrestException catch (e) {
      if (e.code == 'PGRST202' || e.message.contains('Could not find the function')) {
        throw AuthFailure('math_not_installed', e.message);
      }
      throw AuthFailure(AuthFailure.known.contains(e.message) || e.message == 'lesson_locked' ? e.message : 'unknown', e.message);
    } on TimeoutException {
      throw const AuthFailure('network');
    } catch (e) {
      if (e is AuthFailure) rethrow;
      final s = e.toString();
      if (s.contains('SocketException') || s.contains('ClientException') || s.contains('Failed to fetch') || s.contains('XMLHttpRequest')) {
        throw const AuthFailure('network');
      }
      throw AuthFailure('unknown', s);
    }
  }

  @override
  Future<MathState> load(LearnerProfile profile) async =>
      mathStateFromJson(Map<String, dynamic>.from(await _rpc('math_state', {'p_profile': profile.id}) as Map));

  @override
  Future<MathState> finish(LearnerProfile profile, MathRoundResult r) async =>
      mathStateFromJson(Map<String, dynamic>.from(await _rpc('math_finish', {
        'p_profile': profile.id,
        'p_game': r.game.name,
        'p_level': r.level,
        'p_correct': r.correct,
        'p_total': r.total,
        'p_stars': r.stars,
        'p_points': r.points,
        'p_seconds': r.seconds,
      }) as Map));
}

class DemoMathRepository implements MathRepository {
  final Map<String, List<MathRoundResult>> _plays = {};

  @override
  Future<MathState> load(LearnerProfile profile) async {
    final mine = _plays[profile.id] ?? const <MathRoundResult>[];
    final byLevel = <String, List<MathRoundResult>>{};
    for (final p in mine) {
      byLevel.putIfAbsent('${p.game.name}|${p.level}', () => []).add(p);
    }
    final levels = <String, MathBest>{
      for (final e in byLevel.entries)
        e.key: MathBest(
          bestStars: e.value.map((p) => p.stars).reduce((a, b) => a > b ? a : b),
          bestPoints: e.value.map((p) => p.points).reduce((a, b) => a > b ? a : b),
          bestCorrect: e.value.map((p) => p.correct).reduce((a, b) => a > b ? a : b),
          total: e.value.first.total,
          plays: e.value.length,
        ),
    };
    return MathState(
      levels: levels,
      points: levels.values.fold(0, (s, b) => s + b.bestPoints),
      stars: levels.values.fold(0, (s, b) => s + b.bestStars),
      rounds: mine.length,
    );
  }

  @override
  Future<MathState> finish(LearnerProfile profile, MathRoundResult r) async {
    if (!_levelRe[r.game]!.hasMatch(r.level) || r.total < 1 || r.total > 30) throw const AuthFailure('not_found');
    final before = await load(profile);
    if (r.game == MathGame.clock && !before.clockOpen(int.parse(r.level.substring(6)))) {
      throw const AuthFailure('lesson_locked');
    }
    _plays.putIfAbsent(profile.id, () => []).add(MathRoundResult(
          game: r.game,
          level: r.level,
          correct: r.correct.clamp(0, r.total).toInt(),
          total: r.total,
          stars: r.stars.clamp(1, 3).toInt(),
          points: r.points.clamp(0, r.total * 20 + 30).toInt(),
          seconds: r.seconds.clamp(0, 3600).toInt(),
        ));
    return load(profile);
  }
}
