import 'dart:async';
import 'dart:math';

import '../../domain/account.dart';
import '../../domain/models.dart';
import '../mock/mock_data.dart';
import 'auth_repository.dart';

/// In-memory stand-in for Supabase, with the SAME rules as the SQL:
/// parent-only actions, 4-digit PINs with a 15-minute lock after 5 wrong tries,
/// one-time 6-digit link codes valid 10 minutes, 5 code tries per 15 minutes.
///
/// Used by the tests, and by the app when it is started without Supabase keys
/// (a "DEMO" strip is shown; nothing is saved when the app closes).
/// In demo mode the e-mail code is always [demoEmailCode].
class DemoAuthRepository implements AuthRepository {
  DemoAuthRepository({DateTime Function()? clock, Random? random})
      : _now = clock ?? DateTime.now,
        _random = random ?? Random();

  /// A ready-made family (parent kareem@demo.app / password123, PINs: Omar 1234).
  factory DemoAuthRepository.seeded({DateTime Function()? clock}) {
    final r = DemoAuthRepository(clock: clock, random: Random(7));
    final parent = r._newUser(email: 'kareem@demo.app', password: 'password123', confirmed: true);
    final fam = _Family(id: 'fam-demo', name: 'Junaid', createdBy: parent.id);
    r._families[fam.id] = fam;
    final kareem = r._insertProfile(fam.id, const NewLearner(displayName: 'Kareem', kind: ProfileKind.adult), parent: true);
    r._members[parent.id] = _Member(userId: parent.id, familyId: fam.id, role: DeviceRole.parent, profileId: kareem.id, at: r._now());
    final omar = r._insertProfile(fam.id,
        const NewLearner(displayName: 'Omar', kind: ProfileKind.child, grade: 6, avatarEmoji: '🦁'));
    r._insertProfile(fam.id,
        const NewLearner(displayName: 'Yassin', kind: ProfileKind.child, grade: 3, uiLocale: 'ar', avatarEmoji: '🐼'));
    r._secrets[omar.id] = _Secret(pin: '1234');
    r._rows[omar.id] = r._rows[omar.id]!.copyWith(hasPin: true);
    return r;
  }

  static const demoEmailCode = '123456';
  static const _maxPinTries = 5;

  final DateTime Function() _now;
  final Random _random;
  final _changes = StreamController<void>.broadcast();

  final _users = <String, _User>{}; // by id
  final _families = <String, _Family>{};
  final _rows = <String, LearnerProfile>{}; // profiles by id, insertion order kept
  final _profileFamily = <String, String>{};
  final _members = <String, _Member>{}; // by user id
  final _secrets = <String, _Secret>{};
  final _codes = <_Code>[];
  final _attempts = <_Attempt>[];
  String? _currentUserId;
  int _seq = 0;

  _User? get _me => _currentUserId == null ? null : _users[_currentUserId];
  _Member? get _myMember => _currentUserId == null ? null : _members[_currentUserId];

  @override
  bool get isDemo => true;

  @override
  Stream<void> get changes => _changes.stream;

  void _emit() => _changes.add(null);

  String _id(String prefix) => '$prefix-${++_seq}';

  _User _newUser({String? email, String? password, bool confirmed = false, bool anonymous = false}) {
    final u = _User(id: _id('user'), email: email, password: password, confirmed: confirmed, anonymous: anonymous);
    _users[u.id] = u;
    return u;
  }

  // ------------------------------------------------------------ load

  @override
  Future<AccountState> load() async {
    final me = _me;
    if (me == null) return const AccountState.signedOut();
    final m = _myMember;
    if (m == null) {
      return me.anonymous ? const AccountState.signedOut() : AccountState.needsFamily(email: me.email);
    }
    final visible = _rows.values.where((p) {
      if (_profileFamily[p.id] != m.familyId) return false;
      return m.role == DeviceRole.parent || p.id == m.profileId;
    }).toList();
    return AccountState.ready(
      role: m.role,
      familyId: m.familyId,
      familyName: _families[m.familyId]!.name,
      profiles: visible,
      email: me.anonymous ? null : me.email,
      deviceProfileId: m.role == DeviceRole.childDevice ? m.profileId : null,
    );
  }

  // ------------------------------------------------------------ parent account

  _User? _byEmail(String email) {
    final e = email.trim().toLowerCase();
    for (final u in _users.values) {
      if (u.email == e) return u;
    }
    return null;
  }

  @override
  Future<void> signUp({required String email, required String password}) async {
    final e = email.trim().toLowerCase();
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(e)) throw const AuthFailure('invalid_email');
    if (password.length < 8) throw const AuthFailure('weak_password');
    if (_byEmail(e) != null) throw const AuthFailure('user_exists');
    _newUser(email: e, password: password);
  }

  @override
  Future<void> verifySignUpCode({required String email, required String code}) async {
    final u = _byEmail(email);
    if (u == null || code.trim() != demoEmailCode) throw const AuthFailure('invalid_code');
    u.confirmed = true;
    _currentUserId = u.id;
    _emit();
  }

  @override
  Future<void> resendSignUpCode({required String email}) async {}

  @override
  Future<void> signIn({required String email, required String password}) async {
    final u = _byEmail(email);
    if (u == null || u.password != password) throw const AuthFailure('invalid_credentials');
    if (!u.confirmed) throw const AuthFailure('email_not_confirmed');
    _currentUserId = u.id;
    _emit();
  }

  @override
  Future<void> sendPasswordReset({required String email}) async {}

  @override
  Future<void> resetPassword({required String email, required String code, required String newPassword}) async {
    final u = _byEmail(email);
    if (u == null || code.trim() != demoEmailCode) throw const AuthFailure('invalid_code');
    if (newPassword.length < 8) throw const AuthFailure('weak_password');
    u.password = newPassword;
    u.confirmed = true;
    _currentUserId = u.id;
    _emit();
  }

  @override
  Future<void> signOut() async {
    _currentUserId = null;
    _emit();
  }

  // ------------------------------------------------------------ family

  String _requireParent() {
    final m = _myMember;
    if (m == null || m.role != DeviceRole.parent) throw const AuthFailure('parent_only');
    return m.familyId;
  }

  LearnerProfile _insertProfile(String familyId, NewLearner l, {bool parent = false}) {
    if (l.displayName.trim().isEmpty || l.displayName.trim().length > 40) throw const AuthFailure('invalid_profile');
    if (l.kind == ProfileKind.child && l.grade == null) throw const AuthFailure('grade_required');
    if (_profileFamily.values.where((f) => f == familyId).length >= 10) throw const AuthFailure('too_many_profiles');
    final child = l.kind == ProfileKind.child;
    final p = LearnerProfile(
      id: _id('profile'),
      displayName: l.displayName.trim(),
      kind: l.kind,
      role: parent ? FamilyRole.parent : FamilyRole.member,
      uiMode: child ? UiMode.kid : UiMode.pro,
      uiLocale: l.uiLocale,
      avatarEmoji: l.avatarEmoji ?? (parent ? '🧑‍💼' : child ? '🦁' : '🙂'),
      dailyMinutesGoal: child ? 20 : 30,
      grade: child ? l.grade : null,
      trackIds: MockData.tracksFor(l.kind, l.grade),
    );
    _rows[p.id] = p;
    _profileFamily[p.id] = familyId;
    return p;
  }

  @override
  Future<void> createFamily(NewFamily f) async {
    final me = _me;
    if (me == null) throw const AuthFailure('unknown', 'not_signed_in');
    if (me.anonymous) throw const AuthFailure('unknown', 'parent_account_required');
    if (_myMember != null) throw const AuthFailure('already_in_family');
    if (f.familyName.trim().isEmpty || f.parentName.trim().isEmpty) throw const AuthFailure('invalid_family');
    for (final l in f.learners) {
      if (l.displayName.trim().isEmpty) throw const AuthFailure('invalid_profile');
      if (l.kind == ProfileKind.child && l.grade == null) throw const AuthFailure('grade_required');
    }
    final fam = _Family(id: _id('family'), name: f.familyName.trim(), createdBy: me.id);
    _families[fam.id] = fam;
    final parent = _insertProfile(
        fam.id, NewLearner(displayName: f.parentName, kind: ProfileKind.adult, uiLocale: f.parentLocale),
        parent: true);
    _members[me.id] = _Member(userId: me.id, familyId: fam.id, role: DeviceRole.parent, profileId: parent.id, at: _now());
    for (final l in f.learners) {
      _insertProfile(fam.id, l);
    }
  }

  @override
  Future<void> addProfile(NewLearner learner) async {
    _insertProfile(_requireParent(), learner);
  }

  String _ownProfile(String familyId, String profileId) {
    if (_profileFamily[profileId] != familyId) throw const AuthFailure('not_found');
    return profileId;
  }

  @override
  Future<void> deleteProfile(String profileId) async {
    final fam = _requireParent();
    _ownProfile(fam, profileId);
    if (_rows[profileId]!.isParent) throw const AuthFailure('not_found');
    _rows.remove(profileId);
    _profileFamily.remove(profileId);
    _secrets.remove(profileId);
    _members.removeWhere((_, m) => m.profileId == profileId && m.role == DeviceRole.childDevice);
  }

  @override
  Future<void> updateProfile(String profileId, {int? dailyMinutesGoal, bool? aiEnabled, String? uiLocale}) async {
    final fam = _requireParent();
    _ownProfile(fam, profileId);
    _rows[profileId] = _rows[profileId]!.copyWith(
      dailyMinutesGoal: dailyMinutesGoal,
      aiEnabled: aiEnabled,
      uiLocale: uiLocale,
    );
  }

  @override
  Future<void> setPin(String profileId, String? pin) async {
    final fam = _requireParent();
    _ownProfile(fam, profileId);
    if (pin != null && !RegExp(r'^[0-9]{4}$').hasMatch(pin)) throw const AuthFailure('invalid_pin');
    _secrets[profileId] = _Secret(pin: pin);
    _rows[profileId] = _rows[profileId]!.copyWith(hasPin: pin != null);
  }

  @override
  Future<PinCheck> verifyPin(String profileId, String pin) async {
    final m = _myMember;
    if (m == null ||
        _profileFamily[profileId] != m.familyId ||
        !(m.role == DeviceRole.parent || m.profileId == profileId)) {
      throw const AuthFailure('not_found');
    }
    final s = _secrets[profileId];
    if (s == null || s.pin == null) return const PinCheck(ok: true, attemptsLeft: _maxPinTries);
    final now = _now();
    if (s.lockedUntil != null && s.lockedUntil!.isAfter(now)) {
      return PinCheck(ok: false, attemptsLeft: 0, lockedUntil: s.lockedUntil);
    }
    if (pin == s.pin) {
      s
        ..failed = 0
        ..lockedUntil = null;
      return const PinCheck(ok: true, attemptsLeft: _maxPinTries);
    }
    s.failed++;
    if (s.failed >= _maxPinTries) {
      s
        ..failed = 0
        ..lockedUntil = now.add(const Duration(minutes: 15));
      return PinCheck(ok: false, attemptsLeft: 0, lockedUntil: s.lockedUntil);
    }
    s.lockedUntil = null;
    return PinCheck(ok: false, attemptsLeft: _maxPinTries - s.failed);
  }

  @override
  Future<PairingCode> createPairingCode(String profileId) async {
    final fam = _requireParent();
    _ownProfile(fam, profileId);
    if (!_rows[profileId]!.isChild) throw const AuthFailure('not_found');
    final now = _now();
    _codes.removeWhere((c) => (c.profileId == profileId && c.usedAt == null) || c.expiresAt.isBefore(now.subtract(const Duration(days: 1))));
    String code;
    do {
      code = _random.nextInt(1000000).toString().padLeft(6, '0');
    } while (_codes.any((c) => c.code == code && c.usedAt == null && c.expiresAt.isAfter(now)));
    final c = _Code(code: code, familyId: fam, profileId: profileId, expiresAt: now.add(const Duration(minutes: 10)));
    _codes.add(c);
    return PairingCode(code: code, expiresAt: c.expiresAt);
  }

  @override
  Future<List<LinkedDevice>> linkedDevices() async {
    final fam = _requireParent();
    return [
      for (final m in _members.values)
        if (m.familyId == fam && m.role == DeviceRole.childDevice)
          LinkedDevice(userId: m.userId, profileId: m.profileId!, deviceName: m.deviceName, linkedAt: m.at, lastSeenAt: m.lastSeen),
    ];
  }

  @override
  Future<void> unlinkDevice(String userId) async {
    final fam = _requireParent();
    final m = _members[userId];
    if (m == null || m.familyId != fam || m.role != DeviceRole.childDevice) throw const AuthFailure('not_found');
    _members.remove(userId);
  }

  @override
  Future<void> touch() async {
    _myMember?.lastSeen = _now();
  }

  // ------------------------------------------------------------ child's phone

  @override
  Future<void> linkThisDevice({required String code, String? deviceName}) async {
    var me = _me;
    if (me != null && !me.anonymous) {
      _currentUserId = null;
      me = null;
    }
    if (me == null) {
      me = _newUser(anonymous: true);
      _currentUserId = me.id;
      _emit();
    }
    if (_members.containsKey(me.id)) throw const AuthFailure('already_linked');

    final now = _now();
    final uid = me.id;
    final mine = _attempts.where((a) => a.userId == uid && a.at.isAfter(now.subtract(const Duration(minutes: 15)))).length;
    final failedAll = _attempts.where((a) => !a.success && a.at.isAfter(now.subtract(const Duration(minutes: 10)))).length;
    if (mine >= 5 || failedAll >= 100) throw const AuthFailure('too_many_attempts');

    _Code? match;
    for (final c in _codes) {
      if (c.code == code.trim() && c.usedAt == null && c.expiresAt.isAfter(now)) match = c;
    }
    if (match == null) {
      _attempts.add(_Attempt(uid, false, now));
      throw const AuthFailure('invalid_code');
    }
    match.usedAt = now;
    _attempts.add(_Attempt(uid, true, now));
    _members[uid] = _Member(
      userId: uid,
      familyId: match.familyId,
      role: DeviceRole.childDevice,
      profileId: match.profileId,
      deviceName: deviceName,
      at: now,
    );
    _emit();
  }

  // ------------------------------------------------------------ for DemoLearningRepository

  /// The profile if the signed-in user may use it (same rule as app.can_use_profile).
  LearnerProfile? usableProfile(String profileId) {
    final m = _myMember;
    if (m == null || _profileFamily[profileId] != m.familyId) return null;
    if (m.role != DeviceRole.parent && m.profileId != profileId) return null;
    return _rows[profileId];
  }

  bool get isParentSignedIn => _myMember?.role == DeviceRole.parent;

  String? get currentUserId => _currentUserId;

  // ------------------------------------------------------------ test helpers

  /// Signs in as the seeded parent without going through the UI.
  Future<void> debugSignInParent() => signIn(email: 'kareem@demo.app', password: 'password123');

  String debugProfileId(String displayName) => _rows.values.firstWhere((p) => p.displayName == displayName).id;
}

class _User {
  _User({required this.id, this.email, this.password, this.confirmed = false, this.anonymous = false});
  final String id;
  final String? email;
  String? password;
  bool confirmed;
  final bool anonymous;
}

class _Family {
  _Family({required this.id, required this.name, required this.createdBy});
  final String id;
  final String name;
  final String createdBy;
}

class _Member {
  _Member({
    required this.userId,
    required this.familyId,
    required this.role,
    required this.at,
    this.profileId,
    this.deviceName,
  }) : lastSeen = at;
  final String userId;
  final String familyId;
  final DeviceRole role;
  final String? profileId;
  final String? deviceName;
  final DateTime at;
  DateTime lastSeen;
}

class _Secret {
  _Secret({this.pin});
  final String? pin;
  int failed = 0;
  DateTime? lockedUntil;
}

class _Code {
  _Code({required this.code, required this.familyId, required this.profileId, required this.expiresAt});
  final String code;
  final String familyId;
  final String profileId;
  final DateTime expiresAt;
  DateTime? usedAt;
}

class _Attempt {
  _Attempt(this.userId, this.success, this.at);
  final String userId;
  final bool success;
  final DateTime at;
}
