import '../../domain/account.dart';

/// Everything the app needs from the account backend.
///
/// Two implementations:
///  * [SupabaseAuthRepository] - the real one (Supabase Auth + Postgres RLS).
///  * [DemoAuthRepository]     - in memory, used by tests and when the app is
///                               started without Supabase keys.
///
/// All methods throw [AuthFailure] with a short code on failure.
abstract class AuthRepository {
  /// True for the in-memory demo (nothing leaves the phone, nothing is kept).
  bool get isDemo;

  /// Fires whenever the signed-in user changes (sign in, sign out, token lost).
  Stream<void> get changes;

  /// Reads who is signed in on this device and what they may see.
  Future<AccountState> load();

  // ------------------------------------------------------------ parent account
  /// Creates the account. Supabase then e-mails a 6-digit confirmation code.
  Future<void> signUp({required String email, required String password});
  Future<void> verifySignUpCode({required String email, required String code});
  Future<void> resendSignUpCode({required String email});
  Future<void> signIn({required String email, required String password});
  Future<void> sendPasswordReset({required String email});
  Future<void> resetPassword({required String email, required String code, required String newPassword});
  Future<void> signOut();

  // ------------------------------------------------------------ family (parent only)
  Future<void> createFamily(NewFamily family);
  Future<void> addProfile(NewLearner learner);
  Future<void> deleteProfile(String profileId);
  Future<void> updateProfile(String profileId, {int? dailyMinutesGoal, bool? aiEnabled, String? uiLocale});
  Future<void> setPin(String profileId, String? pin);
  Future<PairingCode> createPairingCode(String profileId);
  Future<List<LinkedDevice>> linkedDevices();
  Future<void> unlinkDevice(String userId);

  // ------------------------------------------------------------ any member
  Future<PinCheck> verifyPin(String profileId, String pin);

  /// Updates "last seen" for this device (shown to the parent).
  Future<void> touch();

  // ------------------------------------------------------------ child's phone
  /// Signs this phone in (anonymously) and links it with the parent's code.
  Future<void> linkThisDevice({required String code, String? deviceName});
}
