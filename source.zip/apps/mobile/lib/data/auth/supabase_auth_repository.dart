import 'dart:async';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../../domain/account.dart';
import 'auth_repository.dart';
import 'profile_row.dart';

/// Real accounts: Supabase Auth (email + password, email codes, anonymous
/// sign-in for children's phones) and the Phase 3 SQL functions.
/// Security is enforced in the database (RLS), not here.
class SupabaseAuthRepository implements AuthRepository {
  SupabaseAuthRepository(this._client) {
    // Token refreshes are ignored; only a change of user matters to the app.
    _authSub = _client.auth.onAuthStateChange.listen(
      (s) {
        if (s.event == AuthChangeEvent.signedIn || s.event == AuthChangeEvent.signedOut) _changes.add(null);
      },
      onError: (Object _) => _changes.add(null),
    );
  }

  final SupabaseClient _client;
  final _changes = StreamController<void>.broadcast();
  // ignore: unused_field
  late final StreamSubscription<AuthState> _authSub;

  GoTrueClient get _auth => _client.auth;

  @override
  bool get isDemo => false;

  @override
  Stream<void> get changes => _changes.stream;

  @override
  Future<AccountState> load() => _guard(() async {
        final user = _auth.currentUser;
        if (user == null) return const AccountState.signedOut();

        final ctx = Map<String, dynamic>.from(await _client.rpc('my_context') as Map);
        final role = ctx['role'] as String?;
        if (role == null) {
          // A child's phone that is not (or no longer) linked stays "signed out"
          // but keeps its anonymous session so it can try a code again.
          if (user.isAnonymous) return const AccountState.signedOut();
          return AccountState.needsFamily(email: user.email);
        }

        final rows = await _client.from('profiles').select().order('created_at', ascending: true);
        return AccountState.ready(
          role: role == 'parent' ? DeviceRole.parent : DeviceRole.childDevice,
          familyId: ctx['family_id'] as String,
          familyName: (ctx['family_name'] as String?) ?? '',
          email: user.isAnonymous ? null : user.email,
          deviceProfileId: role == 'child_device' ? (ctx['profile_id'] as String?) : null,
          profiles: [for (final r in rows) profileFromRow(r)],
        );
      });

  // ------------------------------------------------------------ parent account

  @override
  Future<void> signUp({required String email, required String password}) => _guard(() async {
        final res = await _auth.signUp(email: email.trim(), password: password);
        // With "Confirm email" on, Supabase answers an existing address with a
        // user that has no identities (so nobody can probe which emails exist).
        final ids = res.user?.identities;
        if (res.user != null && ids != null && ids.isEmpty) throw const AuthFailure('user_exists');
      });

  @override
  Future<void> verifySignUpCode({required String email, required String code}) => _guard(() async {
        await _auth.verifyOTP(type: OtpType.email, email: email.trim(), token: code.trim());
      });

  @override
  Future<void> resendSignUpCode({required String email}) => _guard(() async {
        await _auth.resend(type: OtpType.signup, email: email.trim());
      });

  @override
  Future<void> signIn({required String email, required String password}) => _guard(() async {
        await _auth.signInWithPassword(email: email.trim(), password: password);
      });

  @override
  Future<void> sendPasswordReset({required String email}) => _guard(() async {
        await _auth.resetPasswordForEmail(email.trim());
      });

  @override
  Future<void> resetPassword({required String email, required String code, required String newPassword}) =>
      _guard(() async {
        await _auth.verifyOTP(type: OtpType.recovery, email: email.trim(), token: code.trim());
        try {
          await _auth.updateUser(UserAttributes(password: newPassword));
        } on AuthException catch (e) {
          if (e.code != 'same_password') rethrow; // same password is fine: they are signed in
        }
      });

  @override
  Future<void> signOut() => _guard(() => _auth.signOut());

  // ------------------------------------------------------------ family

  @override
  Future<void> createFamily(NewFamily f) => _guard(() async {
        await _client.rpc('create_family', params: {
          'p_family_name': f.familyName.trim(),
          'p_parent_name': f.parentName.trim(),
          'p_parent_locale': f.parentLocale,
          'p_consent_version': f.consentVersion,
          'p_learners': [for (final l in f.learners) l.toJson()],
        });
      });

  @override
  Future<void> addProfile(NewLearner learner) =>
      _guard(() => _client.rpc('add_profile', params: {'p_profile': learner.toJson()}));

  @override
  Future<void> deleteProfile(String profileId) =>
      _guard(() => _client.rpc('delete_profile', params: {'p_profile_id': profileId}));

  @override
  Future<void> updateProfile(String profileId, {int? dailyMinutesGoal, bool? aiEnabled, String? uiLocale}) =>
      _guard(() async {
        final values = <String, Object>{
          if (dailyMinutesGoal != null) 'daily_minutes_goal': dailyMinutesGoal,
          if (aiEnabled != null) 'ai_enabled': aiEnabled,
          if (uiLocale != null) 'ui_locale': uiLocale,
        };
        if (values.isEmpty) return;
        await _client.from('profiles').update(values).eq('id', profileId);
      });

  @override
  Future<void> setPin(String profileId, String? pin) =>
      _guard(() => _client.rpc('set_profile_pin', params: {'p_profile_id': profileId, 'p_pin': pin}));

  @override
  Future<PairingCode> createPairingCode(String profileId) => _guard(() async {
        final j = Map<String, dynamic>.from(
            await _client.rpc('create_pairing_code', params: {'p_profile_id': profileId}) as Map);
        return PairingCode(
          code: j['code'] as String,
          expiresAt: DateTime.parse(j['expires_at'] as String).toLocal(),
        );
      });

  @override
  Future<List<LinkedDevice>> linkedDevices() => _guard(() async {
        final rows = await _client
            .from('family_members')
            .select('user_id, profile_id, device_name, created_at, last_seen_at')
            .eq('role', 'child_device')
            .order('created_at', ascending: true);
        return [for (final r in rows) linkedDeviceFromRow(r)];
      });

  @override
  Future<void> unlinkDevice(String userId) =>
      _guard(() => _client.rpc('unlink_device', params: {'p_user_id': userId}));

  // ------------------------------------------------------------ any member

  @override
  Future<PinCheck> verifyPin(String profileId, String pin) => _guard(() async {
        final j = await _client.rpc('verify_profile_pin', params: {'p_profile_id': profileId, 'p_pin': pin});
        return pinCheckFromJson(Map<String, dynamic>.from(j as Map));
      });

  @override
  Future<void> touch() async {
    try {
      await _client.rpc('touch_device');
    } catch (_) {
      // "last seen" is best effort
    }
  }

  // ------------------------------------------------------------ child's phone

  @override
  Future<void> linkThisDevice({required String code, String? deviceName}) => _guard(() async {
        final current = _auth.currentUser;
        if (current != null && !current.isAnonymous) await _auth.signOut();
        if (_auth.currentUser == null) await _auth.signInAnonymously();

        final j = Map<String, dynamic>.from(await _client.rpc('redeem_pairing_code', params: {
          'p_code': code.trim(),
          'p_device_name': deviceName,
        }) as Map);
        if (j['ok'] != true) throw AuthFailure((j['error'] as String?) ?? 'invalid_code');
        _changes.add(null);
      });

  // ------------------------------------------------------------ errors

  Future<T> _guard<T>(Future<T> Function() body) async {
    try {
      return await body();
    } on AuthFailure {
      rethrow;
    } on AuthException catch (e) {
      throw _fromAuth(e);
    } on PostgrestException catch (e) {
      throw _fromDb(e);
    } on TimeoutException {
      throw const AuthFailure('network');
    } catch (e) {
      final s = e.toString();
      if (s.contains('SocketException') || s.contains('Failed host lookup') || s.contains('ClientException') || s.contains('XMLHttpRequest') || s.contains('Failed to fetch')) {
        throw const AuthFailure('network');
      }
      throw AuthFailure('unknown', s);
    }
  }

  static AuthFailure _fromAuth(AuthException e) {
    final msg = e.message.toLowerCase();
    switch (e.code) {
      case 'invalid_credentials':
        return const AuthFailure('invalid_credentials');
      case 'email_not_confirmed':
        return const AuthFailure('email_not_confirmed');
      case 'user_already_exists':
      case 'email_exists':
        return const AuthFailure('user_exists');
      case 'weak_password':
        return const AuthFailure('weak_password');
      case 'otp_expired':
        return const AuthFailure('invalid_code');
      case 'email_address_invalid':
      case 'validation_failed':
        return const AuthFailure('invalid_email');
      case 'over_email_send_rate_limit':
      case 'over_request_rate_limit':
        return const AuthFailure('rate_limited');
      case 'anonymous_provider_disabled':
        return const AuthFailure('anonymous_disabled');
    }
    if (msg.contains('invalid login credentials')) return const AuthFailure('invalid_credentials');
    if (msg.contains('email not confirmed')) return const AuthFailure('email_not_confirmed');
    if (msg.contains('expired or is invalid')) return const AuthFailure('invalid_code');
    if (msg.contains('already registered')) return const AuthFailure('user_exists');
    if (msg.contains('socketexception') || msg.contains('failed host lookup')) return const AuthFailure('network');
    if (e.statusCode == '429') return const AuthFailure('rate_limited');
    return AuthFailure('unknown', e.message);
  }

  /// Our SQL functions raise short codes (e.g. 'parent_only') as the message.
  static AuthFailure _fromDb(PostgrestException e) {
    if (AuthFailure.known.contains(e.message)) return AuthFailure(e.message);
    if (e.message == 'consent_required') return const AuthFailure('unknown', 'consent_required');
    return AuthFailure('unknown', e.message);
  }
}
