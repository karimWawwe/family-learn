import '../../domain/account.dart';
import '../../domain/models.dart';
import '../mock/mock_data.dart';

/// Converts a row of the `profiles` table into a [LearnerProfile].
LearnerProfile profileFromRow(Map<String, dynamic> r) {
  final kind = r['kind'] == 'child' ? ProfileKind.child : ProfileKind.adult;
  final grade = (r['grade'] as num?)?.toInt();
  return LearnerProfile(
    id: r['id'] as String,
    displayName: r['display_name'] as String,
    kind: kind,
    role: r['role'] == 'parent' ? FamilyRole.parent : FamilyRole.member,
    uiMode: kind == ProfileKind.child ? UiMode.kid : UiMode.pro,
    uiLocale: (r['ui_locale'] as String?) ?? 'en',
    avatarEmoji: (r['avatar_emoji'] as String?) ?? '🙂',
    dailyMinutesGoal: (r['daily_minutes_goal'] as num?)?.toInt() ?? 20,
    grade: grade,
    birthYear: (r['birth_year'] as num?)?.toInt(),
    // Courses are MOCK DATA until the content service (Phase 5).
    trackIds: MockData.tracksFor(kind, grade),
    hasPin: r['has_pin'] == true,
    aiEnabled: r['ai_enabled'] != false,
  );
}

PinCheck pinCheckFromJson(Map<String, dynamic> j) => PinCheck(
      ok: j['ok'] == true,
      attemptsLeft: (j['attempts_left'] as num?)?.toInt() ?? 0,
      lockedUntil: j['locked_until'] == null ? null : DateTime.parse(j['locked_until'] as String).toLocal(),
    );

LinkedDevice linkedDeviceFromRow(Map<String, dynamic> r) => LinkedDevice(
      userId: r['user_id'] as String,
      profileId: r['profile_id'] as String,
      deviceName: r['device_name'] as String?,
      linkedAt: DateTime.parse(r['created_at'] as String).toLocal(),
      lastSeenAt: DateTime.parse(r['last_seen_at'] as String).toLocal(),
    );
