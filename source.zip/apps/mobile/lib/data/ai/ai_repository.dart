import 'dart:async';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../../domain/account.dart';
import '../../domain/ai.dart';

/// AI tutor + role-play + parent log.
///  * [SupabaseAiRepository] - the Edge Function "ai-chat" (Claude) and the 0015 SQL functions.
///  * [DemoAiRepository]     - DEMO mode (no Supabase): AI needs the real connection.
/// Errors are AuthFailure codes: ai_not_configured, ai_disabled, ai_daily_limit, ai_budget,
/// ai_busy, ai_key_invalid, ai_no_credit, ai_error, empty_message, message_too_long, too_short,
/// not_found, network, ai_needs_connection.
abstract class AiRepository {
  Future<AiStatus> status(String profileId);
  Future<List<AiScenario>> scenarios(String profileId);

  /// Tutor message. [questionId] / [lessonId] only for a new conversation.
  Future<AiReply> askTutor(String profileId, String message, {String? conversationId, String? questionId, String? lessonId});

  /// Role-play: no [message] and no [conversationId] = start (the AI speaks first).
  Future<AiReply> roleplay(String profileId, {String? conversationId, String? scenario, String? message});

  Future<AiFeedback> roleplayFeedback(String profileId, String conversationId);

  Future<List<AiConversationSummary>> history(String profileId);
  Future<AiConversation> conversation(String conversationId);
}

// ------------------------------------------------------------------ JSON
DateTime _date(Object? v) => DateTime.tryParse('${v ?? ''}')?.toLocal() ?? DateTime.now();
int _int(Object? v) => (v as num?)?.toInt() ?? 0;
List<(String, String)> _pairs(Object? v) => [
      for (final x in (v as List? ?? const []))
        if (x is List && x.length >= 2) ('${x[0]}', '${x[1]}'),
    ];
List<String> _strs(Object? v) => [for (final x in (v as List? ?? const [])) if ('$x'.trim().isNotEmpty) '$x'];

AiFeedback feedbackFromJson(Map<String, dynamic> j) => AiFeedback(
      summary: '${j['summary'] ?? ''}',
      goalReached: j['goal_reached'] == true,
      grammar: _pairs(j['grammar']),
      betterWords: _pairs(j['better_words']),
      phrases: _strs(j['phrases']),
      newWords: _strs(j['new_words']),
    );

AiReply replyFromJson(Map<String, dynamic> j) => AiReply(
      conversationId: '${j['conversation_id']}',
      text: j['reply'] as String?,
      feedback: j['feedback'] is Map ? feedbackFromJson(Map<String, dynamic>.from(j['feedback'] as Map)) : null,
      flagged: j['flagged'] == true,
      remainingToday: (j['remaining_today'] as num?)?.toInt(),
    );

AiStatus statusFromJson(Map<String, dynamic> j) => AiStatus(
      enabled: j['enabled'] != false,
      usedToday: _int(j['used_today']),
      dailyLimit: _int(j['daily_limit']),
      monthCost: (j['month_cost'] as num?)?.toDouble() ?? 0,
      monthlyBudget: (j['monthly_budget'] as num?)?.toDouble() ?? 0,
    );

List<AiScenario> scenariosFromJson(List<dynamic> list) => [
      for (final s in list.cast<Map>())
        AiScenario(
          code: '${s['code']}',
          lang: '${s['lang'] ?? 'en'}',
          title: '${s['title'] ?? ''}',
          titleAr: '${s['title_ar'] ?? s['title'] ?? ''}',
          persona: '${s['persona'] ?? ''}',
          goal: '${s['goal'] ?? ''}',
          emoji: '${s['emoji'] ?? '💬'}',
        ),
    ];

List<AiConversationSummary> historyFromJson(List<dynamic> list) => [
      for (final c in list.cast<Map>())
        AiConversationSummary(
          id: '${c['id']}',
          kind: '${c['kind']}',
          title: '${c['title'] ?? ''}',
          scenario: c['scenario'] as String?,
          startedAt: _date(c['started_at']),
          lastAt: _date(c['last_at']),
          messages: _int(c['messages']),
          preview: c['preview'] as String?,
          flagged: c['flagged'] == true,
          hasFeedback: c['has_feedback'] == true,
        ),
    ];

AiConversation conversationFromJson(Map<String, dynamic> j) => AiConversation(
      id: '${j['id']}',
      profileId: '${j['profile_id']}',
      kind: '${j['kind']}',
      title: '${j['title'] ?? ''}',
      scenario: j['scenario'] as String?,
      flagged: j['flagged'] == true,
      feedback: j['feedback'] is Map ? feedbackFromJson(Map<String, dynamic>.from(j['feedback'] as Map)) : null,
      messages: [
        for (final m in (j['messages'] as List? ?? const []).cast<Map>())
          AiChatMessage(fromLearner: m['role'] == 'user', text: '${m['content'] ?? ''}', flagged: m['flagged'] == true, at: _date(m['at'])),
      ],
    );

// ------------------------------------------------------------------ Supabase
class SupabaseAiRepository implements AiRepository {
  SupabaseAiRepository(this._client);

  final SupabaseClient _client;

  static const _codes = {
    'ai_not_configured', 'ai_disabled', 'ai_daily_limit', 'ai_budget', 'ai_busy', 'ai_key_invalid', 'ai_no_credit',
    'ai_error', 'empty_message', 'message_too_long', 'too_short', 'not_found', 'not_signed_in', 'bad_request',
  };

  AuthFailure _fail(String? code, [String? detail]) =>
      AuthFailure(code != null && _codes.contains(code) ? code : 'ai_error', detail);

  bool _isNetwork(Object e) {
    final s = e.toString();
    return s.contains('SocketException') || s.contains('Failed host lookup') || s.contains('ClientException') ||
        s.contains('XMLHttpRequest') || s.contains('Failed to fetch');
  }

  Future<Object?> _rpc(String fn, Map<String, dynamic> params) async {
    try {
      return await _client.rpc(fn, params: params);
    } on PostgrestException catch (e) {
      throw _fail(e.message, e.message);
    } on TimeoutException {
      throw const AuthFailure('network');
    } catch (e) {
      if (_isNetwork(e)) throw const AuthFailure('network');
      throw AuthFailure('ai_error', e.toString());
    }
  }

  Future<Map<String, dynamic>> _gateway(Map<String, dynamic> body) async {
    try {
      final r = await _client.functions.invoke('ai-chat', body: body).timeout(const Duration(seconds: 60));
      final data = r.data;
      if (data is Map && data['error'] != null) throw _fail('${data['error']}');
      if (data is! Map) throw const AuthFailure('ai_error');
      return Map<String, dynamic>.from(data);
    } on AuthFailure {
      rethrow;
    } on FunctionException catch (e) {
      final d = e.details;
      final code = d is Map ? '${d['error'] ?? ''}' : null;
      // 404 from the gateway itself = the function is not deployed yet
      if ((code == null || code.isEmpty) && e.status == 404) throw const AuthFailure('ai_not_configured');
      throw _fail(code, '${e.status} ${e.reasonPhrase ?? ''}');
    } on TimeoutException {
      throw const AuthFailure('network');
    } catch (e) {
      if (_isNetwork(e)) throw const AuthFailure('network');
      throw AuthFailure('ai_error', e.toString());
    }
  }

  Map<String, dynamic> _map(Object? v) => Map<String, dynamic>.from(v as Map);

  @override
  Future<AiStatus> status(String profileId) async => statusFromJson(_map(await _rpc('ai_status', {'p_profile': profileId})));

  @override
  Future<List<AiScenario>> scenarios(String profileId) async =>
      scenariosFromJson((await _rpc('ai_scenarios_for', {'p_profile': profileId}) as List?) ?? const []);

  @override
  Future<AiReply> askTutor(String profileId, String message, {String? conversationId, String? questionId, String? lessonId}) async =>
      replyFromJson(await _gateway({
        'profile_id': profileId,
        'kind': 'tutor',
        'conversation_id': conversationId,
        'message': message,
        'context': {
          if (questionId != null) 'question_id': questionId,
          if (questionId == null && lessonId != null) 'lesson_id': lessonId,
        },
      }));

  @override
  Future<AiReply> roleplay(String profileId, {String? conversationId, String? scenario, String? message}) async =>
      replyFromJson(await _gateway({
        'profile_id': profileId,
        'kind': 'roleplay',
        'conversation_id': conversationId,
        'message': message,
        'context': {if (scenario != null) 'scenario': scenario},
      }));

  @override
  Future<AiFeedback> roleplayFeedback(String profileId, String conversationId) async {
    final r = replyFromJson(await _gateway({'profile_id': profileId, 'kind': 'feedback', 'conversation_id': conversationId}));
    return r.feedback ?? const AiFeedback(summary: '');
  }

  @override
  Future<List<AiConversationSummary>> history(String profileId) async =>
      historyFromJson((await _rpc('ai_history', {'p_profile': profileId}) as List?) ?? const []);

  @override
  Future<AiConversation> conversation(String conversationId) async =>
      conversationFromJson(_map(await _rpc('ai_conversation', {'p_conversation': conversationId})));
}

// ------------------------------------------------------------------ demo
/// Without Supabase there is no AI: every call explains that a connection is needed.
class DemoAiRepository implements AiRepository {
  static const _no = AuthFailure('ai_needs_connection');

  @override
  Future<AiStatus> status(String profileId) async =>
      const AiStatus(enabled: true, usedToday: 0, dailyLimit: 0, monthCost: 0, monthlyBudget: 0);
  @override
  Future<List<AiScenario>> scenarios(String profileId) async => const [];
  @override
  Future<AiReply> askTutor(String profileId, String message, {String? conversationId, String? questionId, String? lessonId}) =>
      Future.error(_no);
  @override
  Future<AiReply> roleplay(String profileId, {String? conversationId, String? scenario, String? message}) => Future.error(_no);
  @override
  Future<AiFeedback> roleplayFeedback(String profileId, String conversationId) => Future.error(_no);
  @override
  Future<List<AiConversationSummary>> history(String profileId) async => const [];
  @override
  Future<AiConversation> conversation(String conversationId) => Future.error(const AuthFailure('not_found'));
}
