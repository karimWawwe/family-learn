import 'dart:async';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../../domain/account.dart';
import '../../domain/follow.dart';
import '../../domain/models.dart';
import '../bedtime/bedtime_repository.dart';

/// Parent follow report ("لوحة متابعة الوالدين").
///  * [SupabaseFollowRepository] - computed by the database from real activity.
///  * [DemoFollowRepository]     - DEMO mode: computed from the demo stories progress.
abstract class FollowRepository {
  Future<FollowReport> report(LearnerProfile child, FollowPeriod period);
}

// ---------------------------------------------------------------- JSON
int _i(Object? v) => (v as num?)?.toInt() ?? 0;
DateTime? _d(Object? v) => v == null ? null : DateTime.tryParse('$v');

RangeFigures rangeFromJson(Map? j) {
  if (j == null) return const RangeFigures();
  return RangeFigures(
    minutesLessons: _i(j['minutes_lessons']),
    minutesStories: _i(j['minutes_stories']),
    minutesSpeaking: _i(j['minutes_speaking']),
    minutesTotal: _i(j['minutes_total']),
    daysUsed: _i(j['days_used']),
    storiesListened: _i(j['stories_listened']),
    storiesCompleted: _i(j['stories_completed']),
    values: [for (final v in (j['values'] as List? ?? const [])) '$v'],
    lessonsDone: _i(j['lessons_done']),
    questions: _i(j['questions']),
    correct: _i(j['correct']),
    speakWords: _i(j['speak_words']),
    speakLevels: _i(j['speak_levels']),
    speakPoints: _i(j['speak_points']),
    minutesMath: _i(j['minutes_math']),
    mathRounds: _i(j['math_rounds']),
    mathCorrect: _i(j['math_correct']),
    mathTotal: _i(j['math_total']),
  );
}

StoryRef? storyRefFromJson(Object? v) {
  if (v is! Map) return null;
  return StoryRef(
    id: '${v['id'] ?? ''}',
    title: '${v['title'] ?? ''}',
    emoji: '${v['emoji'] ?? '🌙'}',
    value: '${v['value'] ?? ''}',
  );
}

FollowReport followFromJson(Map<String, dynamic> j) {
  final totals = (j['totals'] as Map?) ?? const {};
  final progress = (j['progress'] as Map?) ?? const {};
  final last = j['last_story'] as Map?;
  final act = j['last_activity'] as Map?;
  return FollowReport(
    period: switch ('${j['period']}') {
      'day' => FollowPeriod.day,
      'month' => FollowPeriod.month,
      _ => FollowPeriod.week,
    },
    current: rangeFromJson(j['current'] as Map?),
    previous: rangeFromJson(j['previous'] as Map?),
    byDay: [
      for (final d in (j['by_day'] as List? ?? const []).cast<Map>())
        DayMinutes(DateTime.tryParse('${d['day']}') ?? DateTime(2000), _i(d['minutes'])),
    ],
    totalMinutes: _i(totals['minutes']),
    totalDays: _i(totals['days']),
    totalStoriesListened: _i(totals['stories_listened']),
    totalStoriesCompleted: _i(totals['stories_completed']),
    distinctStories: _i(totals['distinct_stories']),
    totalLessons: _i(totals['lessons_done']),
    totalSpeakWords: _i(totals['speak_words']),
    speakLevelsDone: _i(totals['speak_levels_done']),
    progressPoints: _i(progress['points']),
    lessonXp: _i(progress['lesson_xp']),
    speakPoints: _i(progress['speak_points']),
    storyPoints: _i(progress['story_points']),
    mathPoints: _i(progress['math_points']),
    level: progress['level'] == null ? 1 : _i(progress['level']),
    intoLevel: _i(progress['into_level']),
    lastStory: storyRefFromJson(last),
    lastStoryCompleted: last?['completed'] == true,
    lastStoryAt: _d(last?['at']),
    favorites: [for (final f in (j['favorites'] as List? ?? const [])) if (storyRefFromJson(f) != null) storyRefFromJson(f)!],
    valuesAll: [
      for (final v in (j['values_all'] as List? ?? const []).cast<Map>()) ValueCount('${v['value']}', _i(v['count'])),
    ],
    topValue: j['top_value'] == null ? null : '${j['top_value']}',
    lastActivityKind: act == null ? null : '${act['kind']}',
    lastActivityTitle: act == null ? null : '${act['title']}',
    lastActivityAt: _d(act?['at']),
    suggestion: storyRefFromJson(j['suggestion']),
    trickyWords: [for (final w in (j['tricky_words'] as List? ?? const [])) '$w'],
    weakSkills: [for (final w in (j['weak_skills'] as List? ?? const [])) '$w'],
  );
}

// ---------------------------------------------------------------- Supabase
class SupabaseFollowRepository implements FollowRepository {
  SupabaseFollowRepository(this._client);

  final SupabaseClient _client;

  @override
  Future<FollowReport> report(LearnerProfile child, FollowPeriod period) async {
    try {
      final r = await _client
          .rpc('parent_follow', params: {'p_profile': child.id, 'p_period': period.name})
          .timeout(const Duration(seconds: 25));
      return followFromJson(Map<String, dynamic>.from(r as Map));
    } on PostgrestException catch (e) {
      if (e.code == 'PGRST202' || e.message.contains('Could not find the function')) {
        throw AuthFailure('bedtime_not_installed', e.message);
      }
      throw AuthFailure(AuthFailure.known.contains(e.message) ? e.message : 'unknown', e.message);
    } on TimeoutException {
      throw const AuthFailure('network');
    } catch (e) {
      if (e is AuthFailure) rethrow;
      final s = e.toString();
      if (s.contains('SocketException') || s.contains('ClientException') || s.contains('Failed to fetch') || s.contains('XMLHttpRequest')) {
        throw const AuthFailure('network');
      }
      throw AuthFailure('unknown', s);
    }
  }
}

// ---------------------------------------------------------------- Demo
/// DEMO mode only: the same report built from the in-memory stories progress
/// (lessons and the speaking game are left at zero here).
class DemoFollowRepository implements FollowRepository {
  DemoFollowRepository(this._bedtime, {DateTime Function()? clock}) : _now = clock ?? DateTime.now;

  final DemoBedtimeRepository _bedtime;
  final DateTime Function() _now;

  DateTime _day(DateTime d) => DateTime(d.year, d.month, d.day);

  RangeFigures _range(String profileId, DateTime from, DateTime to) {
    bool inR(DateTime d) => !_day(d).isBefore(from) && !_day(d).isAfter(to);
    final ls = _bedtime.listens.where((l) => l.profileId == profileId).toList();
    final started = ls.where((l) => inR(l.startedAt)).toList();
    final done = ls.where((l) => l.completedAt != null && inR(l.completedAt!)).toList();
    final secs = started.fold<int>(0, (s, l) => s + l.seconds);
    final values = <String>{
      for (final l in done) '${_bedtime.stories.firstWhere((s) => s['id'] == l.storyId)['value_name']}',
    };
    return RangeFigures(
      minutesStories: (secs / 60).round(),
      minutesTotal: (secs / 60).ceil(),
      daysUsed: {for (final l in started) _day(l.startedAt)}.length,
      storiesListened: started.length,
      storiesCompleted: done.length,
      values: values.toList(),
    );
  }

  @override
  Future<FollowReport> report(LearnerProfile child, FollowPeriod period) async {
    final n = switch (period) { FollowPeriod.day => 1, FollowPeriod.week => 7, FollowPeriod.month => 30 };
    final today = _day(_now());
    final cur = _range(child.id, today.subtract(Duration(days: n - 1)), today);
    final prev = _range(child.id, today.subtract(Duration(days: 2 * n - 1)), today.subtract(Duration(days: n)));
    final all = _range(child.id, DateTime(2000), today);
    final state = await _bedtime.load(child);
    final ls = _bedtime.listens.where((l) => l.profileId == child.id).toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    final counts = <String, int>{};
    for (final l in ls.where((l) => l.completedAt != null)) {
      final v = state.byId(l.storyId)?.valueName ?? '';
      counts[v] = (counts[v] ?? 0) + 1;
    }
    final values = counts.entries.map((e) => ValueCount(e.key, e.value)).toList()
      ..sort((a, b) => b.count.compareTo(a.count));
    final top = values.isEmpty ? null : values.first.value;
    final unfinished = state.stories.where((s) => !s.isDone).toList()
      ..sort((a, b) => (b.valueName == top ? 1 : 0).compareTo(a.valueName == top ? 1 : 0));
    final lastStory = ls.isEmpty ? null : state.byId(ls.first.storyId);
    final points = 20 * all.storiesCompleted;
    return FollowReport(
      period: period,
      current: cur,
      previous: prev,
      byDay: [
        for (var i = (n < 7 ? 7 : n) - 1; i >= 0; i--)
          DayMinutes(today.subtract(Duration(days: i)),
              _range(child.id, today.subtract(Duration(days: i)), today.subtract(Duration(days: i))).minutesTotal),
      ],
      totalMinutes: all.minutesTotal,
      totalDays: all.daysUsed,
      totalStoriesListened: all.storiesListened,
      totalStoriesCompleted: all.storiesCompleted,
      distinctStories: state.completedCount,
      progressPoints: points,
      storyPoints: points,
      level: 1 + points ~/ 500,
      intoLevel: points % 500,
      lastStory: lastStory == null
          ? null
          : StoryRef(id: lastStory.id, title: lastStory.title, emoji: lastStory.emoji, value: lastStory.valueName),
      lastStoryCompleted: ls.isNotEmpty && ls.first.completedAt != null,
      lastStoryAt: ls.isEmpty ? null : ls.first.updatedAt,
      favorites: [for (final s in state.favorites) StoryRef(id: s.id, title: s.title, emoji: s.emoji, value: s.valueName)],
      valuesAll: values,
      topValue: top,
      lastActivityKind: ls.isEmpty ? null : 'story',
      lastActivityTitle: lastStory?.title,
      lastActivityAt: ls.isEmpty ? null : ls.first.updatedAt,
      suggestion: unfinished.isEmpty
          ? null
          : StoryRef(id: unfinished.first.id, title: unfinished.first.title, emoji: unfinished.first.emoji, value: unfinished.first.valueName),
    );
  }
}
