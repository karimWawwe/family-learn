import '../../domain/learning.dart';
import '../../domain/models.dart';
import 'question_codec.dart';

// JSON (from the Supabase functions, or the demo) -> domain objects.

int _i(Object? v) => (v as num?)?.toInt() ?? 0;

LessonStatus _status(Object? s) => switch (s) {
      'done' => LessonStatus.done,
      'in_progress' => LessonStatus.inProgress,
      'available' => LessonStatus.available,
      _ => LessonStatus.locked,
    };

List<Course> coursesFromJson(List<dynamic> list) => [
      for (final c in list.cast<Map>())
        Course(
          id: c['id'] as String,
          subject: c['subject'] as String,
          title: c['title'] as String,
          levelLabel: (c['level_label'] as String?) ?? '',
          units: [
            for (final u in (c['units'] as List? ?? const []).cast<Map>())
              Unit(
                id: u['id'] as String,
                title: u['title'] as String,
                lessons: [
                  for (final l in (u['lessons'] as List? ?? const []).cast<Map>())
                    LessonSummary(
                      id: l['id'] as String,
                      title: l['title'] as String,
                      minutes: _i(l['minutes']),
                      status: _status(l['status']),
                    ),
                ],
              ),
          ],
        ),
    ];

LessonSession sessionFromJson(Map<String, dynamic> j) => LessonSession(
      attemptId: j['attempt_id'] as String,
      lessonId: j['lesson_id'] as String,
      title: (j['title'] as String?) ?? '',
      questions: [
        for (final q in (j['questions'] as List? ?? const []).cast<Map>())
          if (questionFromJson(q.cast<String, dynamic>()) case final question?) question,
      ],
    );

AnswerResult answerFromJson(Map<String, dynamic> j) => AnswerResult(
      correct: j['correct'] == true,
      correctText: (j['correct_text'] as String?) ?? '',
      explanation: j['explanation'] as String?,
    );

ProfileWallet walletFromJson(Map<String, dynamic> j) => ProfileWallet(
      xp: _i(j['xp']),
      coins: _i(j['coins']),
      stars: _i(j['stars']),
      level: j['level'] == null ? 1 : _i(j['level']),
      streakDays: _i(j['streak_days']),
      minutesToday: _i(j['minutes_today']),
      lessonsDone: _i(j['lessons_done']),
    );

LessonOutcome outcomeFromJson(Map<String, dynamic> j) => LessonOutcome(
      correct: _i(j['correct']),
      total: _i(j['total']),
      xp: _i(j['xp']),
      coins: _i(j['coins']),
      stars: _i(j['stars']),
      wallet: walletFromJson(((j['wallet'] as Map?) ?? const {}).cast<String, dynamic>()),
    );

RangeStats _range(Object? v) {
  final m = ((v as Map?) ?? const {}).cast<String, dynamic>();
  return RangeStats(
    minutes: _i(m['minutes']),
    questions: _i(m['questions']),
    correct: _i(m['correct']),
    accuracy: (m['accuracy'] as num?)?.toDouble(),
  );
}

ProfileReport reportFromJson(Map<String, dynamic> j) => ProfileReport(
      minutesByDay: [for (final v in (j['minutes_by_day'] as List? ?? const [])) _i(v)],
      today: _range(j['last_1']),
      week: _range(j['last_7']),
      month: _range(j['last_30']),
      dailyGoal: _i(j['daily_goal']),
      streakDays: _i(j['streak_days']),
      history: [
        for (final h in (j['history'] as List? ?? const []).cast<Map>())
          HistoryEntry(
            lesson: h['lesson'] as String,
            correct: _i(h['correct']),
            total: _i(h['total']),
            finishedAt: DateTime.parse(h['finished_at'] as String).toLocal(),
          ),
      ],
      skills: [
        for (final s in (j['skills'] as List? ?? const []).cast<Map>())
          SkillStat(
            code: s['code'] as String,
            name: s['name'] as String,
            answers: _i(s['answers']),
            accuracy: (s['accuracy'] as num?)?.toDouble() ?? 0,
          ),
      ],
      toReview: [for (final t in (j['to_review'] as List? ?? const [])) '$t'],
    );
