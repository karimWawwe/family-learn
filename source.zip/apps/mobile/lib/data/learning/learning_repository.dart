import '../../domain/learning.dart';
import '../../domain/models.dart';

/// Courses, lessons and progress.
///  * [SupabaseLearningRepository] - the real one (server marks every answer).
///  * [DemoLearningRepository]     - in memory, same rules, for DEMO mode and tests.
/// Methods throw AuthFailure (codes: not_found, lesson_locked, lesson_finished,
/// parent_only, network, unknown).
abstract class LearningRepository {
  /// The profile's courses with each lesson's status.
  Future<List<Course>> courseMap(String profileId);

  Future<LessonSession> startLesson(String profileId, String lessonId);

  /// [response] is already JSON-ready (see encodeResponse).
  Future<AnswerResult> submitAnswer(String attemptId, String questionId, Object? response);

  Future<LessonOutcome> finishLesson(String attemptId);

  Future<ProfileWallet> wallet(String profileId);

  /// Parent only.
  Future<ProfileReport> report(String profileId);
}
