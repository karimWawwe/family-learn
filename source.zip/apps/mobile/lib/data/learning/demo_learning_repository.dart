import 'dart:convert';
import 'dart:math' as math;

import '../../domain/account.dart';
import '../../domain/learning.dart';
import '../../domain/models.dart';
import '../auth/demo_auth_repository.dart';
import 'grader.dart';
import 'learning_json.dart';
import 'learning_repository.dart';
import 'starter_content.g.dart';

/// In-memory copy of the Phase 4 learning functions, using the SAME starter
/// content and rules as the database (see 20260926000002_phase4_learning.sql):
/// unlock order, server-side marking, XP / coins / stars, streaks, reports.
/// Used when the app runs without Supabase, and by the tests.
class DemoLearningRepository implements LearningRepository {
  DemoLearningRepository(this._auth, {DateTime Function()? clock}) : _now = clock ?? DateTime.now {
    final data = jsonDecode(starterContentJson) as Map<String, dynamic>;
    for (final s in (data['skills'] as List).cast<Map<String, dynamic>>()) {
      _skills[s['code'] as String] = s['name'] as String;
    }
    _courses = (data['courses'] as List).cast<Map<String, dynamic>>();
    _units = (data['units'] as List).cast<Map<String, dynamic>>();
    _lessons = (data['lessons'] as List).cast<Map<String, dynamic>>();
    for (final q in (data['questions'] as List).cast<Map<String, dynamic>>()) {
      _questions.putIfAbsent(q['lesson_id'] as String, () => []).add(q);
      _questionById[q['id'] as String] = q;
    }
  }

  final DemoAuthRepository _auth;
  final DateTime Function() _now;
  final _skills = <String, String>{};
  late final List<Map<String, dynamic>> _courses;
  late final List<Map<String, dynamic>> _units;
  late final List<Map<String, dynamic>> _lessons;
  final _questions = <String, List<Map<String, dynamic>>>{};
  final _questionById = <String, Map<String, dynamic>>{};
  final _attempts = <String, _Attempt>{};
  int _seq = 0;

  // ------------------------------------------------------------ rules

  LearnerProfile _profile(String id) {
    final p = _auth.usableProfile(id);
    if (p == null) throw const AuthFailure('not_found');
    return p;
  }

  List<Map<String, dynamic>> _coursesFor(LearnerProfile p) => _courses.where((c) {
        if (p.kind == ProfileKind.adult) return c['audience'] == 'adult';
        if (c['audience'] != 'child') return false;
        final g = p.grade ?? 1;
        return g >= ((c['grade_min'] as int?) ?? 1) && g <= ((c['grade_max'] as int?) ?? 12);
      }).toList();

  Iterable<_Attempt> _finished(String profileId) =>
      _attempts.values.where((a) => a.profileId == profileId && a.finishedAt != null);

  bool _done(String profileId, String lessonId) => _finished(profileId).any((a) => a.lessonId == lessonId);

  bool _unlocked(String profileId, Map<String, dynamic> lesson) {
    final pos = lesson['position'] as int;
    if (pos == 1) return true;
    final prev = _lessons.firstWhere(
      (l) => l['course_id'] == lesson['course_id'] && l['position'] == pos - 1,
      orElse: () => const {},
    );
    return prev.isNotEmpty && _done(profileId, prev['id'] as String);
  }

  static DateTime _day(DateTime t) => DateTime(t.year, t.month, t.day);

  static double _minutes(_Attempt a) =>
      a.finishedAt == null ? 0 : math.min(a.finishedAt!.difference(a.startedAt).inSeconds / 60.0, 30);

  int _streak(String profileId) {
    final days = {for (final a in _finished(profileId)) _day(a.finishedAt!)};
    if (days.isEmpty) return 0;
    final today = _day(_now());
    var d = days.reduce((a, b) => a.isAfter(b) ? a : b);
    if (d.isBefore(today.subtract(const Duration(days: 1)))) return 0;
    var n = 0;
    while (days.contains(d)) {
      n++;
      d = DateTime(d.year, d.month, d.day - 1);
    }
    return n;
  }

  // ------------------------------------------------------------ API

  @override
  Future<List<Course>> courseMap(String profileId) async {
    final p = _profile(profileId);
    final json = [
      for (final c in _coursesFor(p))
        {
          ...c,
          'units': [
            for (final u in _units.where((u) => u['course_id'] == c['id']))
              {
                'id': u['id'],
                'title': u['title'],
                'lessons': [
                  for (final l in _lessons.where((l) => l['unit_id'] == u['id']))
                    {
                      'id': l['id'],
                      'title': l['title'],
                      'minutes': l['minutes'],
                      'status': _done(profileId, l['id'] as String)
                          ? 'done'
                          : !_unlocked(profileId, l)
                              ? 'locked'
                              : _attempts.values.any((a) =>
                                      a.profileId == profileId && a.lessonId == l['id'] && a.finishedAt == null && a.answers.isNotEmpty)
                                  ? 'in_progress'
                                  : 'available',
                    },
                ],
              },
          ],
        },
    ];
    return coursesFromJson(json);
  }

  @override
  Future<LessonSession> startLesson(String profileId, String lessonId) async {
    final p = _profile(profileId);
    final courseIds = {for (final c in _coursesFor(p)) c['id']};
    final lesson = _lessons.firstWhere((l) => l['id'] == lessonId && courseIds.contains(l['course_id']), orElse: () => const {});
    if (lesson.isEmpty) throw const AuthFailure('not_found');
    if (!_unlocked(profileId, lesson)) throw const AuthFailure('lesson_locked');
    _attempts.removeWhere((_, a) => a.profileId == profileId && a.lessonId == lessonId && a.finishedAt == null && a.answers.isEmpty);

    final a = _Attempt('attempt-${++_seq}', profileId, lessonId, _now());
    _attempts[a.id] = a;
    return sessionFromJson({
      'attempt_id': a.id,
      'lesson_id': lessonId,
      'title': lesson['title'],
      'questions': [
        for (final q in _questions[lessonId] ?? const <Map<String, dynamic>>[])
          {'id': q['id'], 'type': q['type'], 'skill': q['skill'], 'prompt': q['prompt'], 'hint': q['hint'], 'payload': q['payload']},
      ],
    });
  }

  _Attempt _attempt(String attemptId) {
    final a = _attempts[attemptId];
    if (a == null || _auth.usableProfile(a.profileId) == null) throw const AuthFailure('not_found');
    return a;
  }

  @override
  Future<AnswerResult> submitAnswer(String attemptId, String questionId, Object? response) async {
    final a = _attempt(attemptId);
    if (a.finishedAt != null) throw const AuthFailure('lesson_finished');
    final q = _questionById[questionId];
    if (q == null || q['lesson_id'] != a.lessonId) throw const AuthFailure('not_found');
    final ok = a.answers.putIfAbsent(questionId, () {
      a.answeredAt[questionId] = _now();
      return gradeAnswer(q['type'] as String, (q['answer_key'] as Map).cast<String, dynamic>(), response);
    });
    return AnswerResult(correct: ok, correctText: q['correct_text'] as String, explanation: q['explanation'] as String?);
  }

  @override
  Future<LessonOutcome> finishLesson(String attemptId) async {
    final a = _attempt(attemptId);
    if (a.finishedAt == null) {
      final total = (_questions[a.lessonId] ?? const []).length;
      final right = a.answers.values.where((v) => v).length;
      final pct = total == 0 ? 0.0 : right / total;
      a
        ..finishedAt = _now()
        ..total = total
        ..correct = right
        ..xp = 10 * right + (pct >= 0.8 ? 20 : 0)
        ..coins = right + 5
        ..stars = pct >= 0.9 ? 3 : (pct >= 0.7 ? 2 : 1);
    }
    return LessonOutcome(
      correct: a.correct,
      total: a.total,
      xp: a.xp,
      coins: a.coins,
      stars: a.stars,
      wallet: await wallet(a.profileId),
    );
  }

  @override
  Future<ProfileWallet> wallet(String profileId) async {
    _profile(profileId);
    final done = _finished(profileId).toList();
    final best = <String, int>{};
    for (final a in done) {
      best[a.lessonId] = math.max(best[a.lessonId] ?? 0, a.stars);
    }
    final today = _day(_now());
    final xp = done.fold<int>(0, (t, a) => t + a.xp);
    return ProfileWallet(
      xp: xp,
      coins: done.fold<int>(0, (t, a) => t + a.coins),
      stars: best.values.fold<int>(0, (t, v) => t + v),
      level: 1 + xp ~/ 500,
      streakDays: _streak(profileId),
      minutesToday: done.where((a) => _day(a.finishedAt!) == today).fold<double>(0, (t, a) => t + _minutes(a)).ceil(),
      lessonsDone: best.length,
    );
  }

  @override
  Future<ProfileReport> report(String profileId) async {
    if (!_auth.isParentSignedIn) throw const AuthFailure('parent_only');
    final p = _profile(profileId);
    final today = _day(_now());
    final done = _finished(profileId).toList();
    final answers = <({String skill, bool ok, DateTime at})>[
      for (final a in _attempts.values.where((a) => a.profileId == profileId))
        for (final e in a.answers.entries)
          (skill: _questionById[e.key]!['skill'] as String, ok: e.value, at: a.answeredAt[e.key]!),
    ];

    RangeStats range(int days) {
      final from = DateTime(today.year, today.month, today.day - (days - 1));
      final inRange = answers.where((x) => !_day(x.at).isBefore(from)).toList();
      final right = inRange.where((x) => x.ok).length;
      return RangeStats(
        minutes: done.where((a) => !_day(a.finishedAt!).isBefore(from)).fold<double>(0, (t, a) => t + _minutes(a)).ceil(),
        questions: inRange.length,
        correct: right,
        accuracy: inRange.isEmpty ? null : right / inRange.length,
      );
    }

    final month = answers.where((x) => x.at.isAfter(_now().subtract(const Duration(days: 30))));
    final bySkill = <String, List<bool>>{};
    for (final x in month) {
      bySkill.putIfAbsent(x.skill, () => []).add(x.ok);
    }
    final skills = [
      for (final e in bySkill.entries)
        SkillStat(code: e.key, name: _skills[e.key] ?? e.key, answers: e.value.length, accuracy: e.value.where((v) => v).length / e.value.length),
    ]..sort((a, b) => a.accuracy.compareTo(b.accuracy));
    final recent = _now().subtract(const Duration(days: 7));

    final history = done.toList()..sort((a, b) => b.finishedAt!.compareTo(a.finishedAt!));
    return ProfileReport(
      minutesByDay: [
        for (var i = 6; i >= 0; i--)
          done
              .where((a) => _day(a.finishedAt!) == DateTime(today.year, today.month, today.day - i))
              .fold<double>(0, (t, a) => t + _minutes(a))
              .ceil(),
      ],
      today: range(1),
      week: range(7),
      month: range(30),
      dailyGoal: p.dailyMinutesGoal,
      streakDays: _streak(profileId),
      history: [
        for (final a in history.take(8))
          HistoryEntry(
            lesson: _lessons.firstWhere((l) => l['id'] == a.lessonId)['title'] as String,
            correct: a.correct,
            total: a.total,
            finishedAt: a.finishedAt!,
          ),
      ],
      skills: skills,
      toReview: {
        for (final x in answers.where((x) => !x.ok && x.at.isAfter(recent))) _skills[x.skill] ?? x.skill,
      }.toList(),
    );
  }
}

class _Attempt {
  _Attempt(this.id, this.profileId, this.lessonId, this.startedAt);

  final String id;
  final String profileId;
  final String lessonId;
  final DateTime startedAt;
  DateTime? finishedAt;
  int total = 0;
  int correct = 0;
  int xp = 0;
  int coins = 0;
  int stars = 0;
  final answers = <String, bool>{};
  final answeredAt = <String, DateTime>{};
}
