import 'dart:async';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../../domain/account.dart';
import '../../domain/learning.dart';
import '../../domain/models.dart';
import 'learning_json.dart';
import 'learning_repository.dart';

/// Calls the Phase 4 SQL functions (course_map, start_lesson, submit_answer,
/// finish_lesson, profile_wallet, profile_report). Access rules live in the database.
class SupabaseLearningRepository implements LearningRepository {
  SupabaseLearningRepository(this._client);

  final SupabaseClient _client;

  Future<Object?> _rpc(String fn, Map<String, dynamic> params) async {
    try {
      return await _client.rpc(fn, params: params);
    } on PostgrestException catch (e) {
      throw AuthFailure(AuthFailure.known.contains(e.message) ? e.message : 'unknown', e.message);
    } on AuthException catch (e) {
      throw AuthFailure('unknown', e.message);
    } on TimeoutException {
      throw const AuthFailure('network');
    } catch (e) {
      final s = e.toString();
      if (s.contains('SocketException') || s.contains('Failed host lookup') || s.contains('ClientException') || s.contains('XMLHttpRequest') || s.contains('Failed to fetch')) {
        throw const AuthFailure('network');
      }
      throw AuthFailure('unknown', s);
    }
  }

  Map<String, dynamic> _map(Object? v) => Map<String, dynamic>.from(v as Map);

  @override
  Future<List<Course>> courseMap(String profileId) async =>
      coursesFromJson((await _rpc('course_map', {'p_profile': profileId}) as List?) ?? const []);

  @override
  Future<LessonSession> startLesson(String profileId, String lessonId) async =>
      sessionFromJson(_map(await _rpc('start_lesson', {'p_profile': profileId, 'p_lesson': lessonId})));

  @override
  Future<AnswerResult> submitAnswer(String attemptId, String questionId, Object? response) async => answerFromJson(
      _map(await _rpc('submit_answer', {'p_attempt': attemptId, 'p_question': questionId, 'p_response': response})));

  @override
  Future<LessonOutcome> finishLesson(String attemptId) async =>
      outcomeFromJson(_map(await _rpc('finish_lesson', {'p_attempt': attemptId})));

  @override
  Future<ProfileWallet> wallet(String profileId) async =>
      walletFromJson(_map(await _rpc('profile_wallet', {'p_profile': profileId})));

  @override
  Future<ProfileReport> report(String profileId) async =>
      reportFromJson(_map(await _rpc('profile_report', {'p_profile': profileId})));
}
