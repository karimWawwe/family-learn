// The answer checker used by DEMO mode. Same rules as app.grade() in
// supabase/migrations/20260926000002_phase4_learning.sql - keep them in step.
// With Supabase connected the server always marks the answer.

String normAnswer(String? t) => (t ?? '')
    .trim()
    .toLowerCase()
    .replaceAll(RegExp(r'\s+'), ' ')
    .replaceAll(RegExp(r'[.!?]+$'), '');

/// First number in a typed answer: "300 baisa" -> 300, "0,25" -> 0.25, "20,000" -> 20000.
num? parseNumber(String? t) {
  var s = (t ?? '').replaceAllMapped(RegExp(r'(\d),(\d{3})(?!\d)'), (m) => '${m[1]}${m[2]}');
  s = s.replaceAll(',', '.');
  final m = RegExp(r'-?\d+(?:\.\d+)?|-?\.\d+').firstMatch(s);
  return m == null ? null : num.tryParse(m[0]!);
}

bool gradeAnswer(String type, Map<String, dynamic> key, Object? response) {
  if (response == null) return false;
  switch (type) {
    case 'multiple_choice':
    case 'reading':
    case 'listening':
      return response is num && response == (key['index'] as num);
    case 'true_false':
      return response is bool && response == key['value'];
    case 'fill_blank':
    case 'typing':
      if (response is! String) return false;
      final given = normAnswer(response);
      return (key['accepted'] as List).any((a) => normAnswer('$a') == given);
    case 'drag_drop':
      return response is String && response == key['token'];
    case 'word_problem':
      final v = response is num ? response : (response is String ? parseNumber(response) : null);
      return v != null && (v - (key['value'] as num)).abs() < 0.0001;
    case 'matching':
      // response: {"leftIndex": index in the right list as shown}; key.map = the right pairs.
      if (response is! Map) return false;
      final n = key['pairs'] as int;
      final map = (key['map'] as Map).cast<String, dynamic>();
      if (response.length != n) return false;
      return response.entries.every((e) {
        final want = map['${e.key}'];
        return want != null && e.value is num && e.value == want;
      });
    case 'ordering':
      if (response is! List) return false;
      final order = (key['order'] as List).map((e) => '$e').toList();
      if (response.length != order.length) return false;
      for (var i = 0; i < order.length; i++) {
        // SQL compares JSON arrays: items must be strings, not numbers.
        if (response[i] is! String || response[i] != order[i]) return false;
      }
      return true;
    case 'speaking':
      return true;
  }
  return false;
}
