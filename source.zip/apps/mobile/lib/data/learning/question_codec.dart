import '../../domain/questions.dart';

// Converts questions from the server (no answers inside) into the app's
// Question objects, and the learner's answer into JSON for the server.
//
// The answer fields of the Question classes (correctIndex, accepted, ...)
// are filled with placeholders: the phone never knows the answer. The
// server's reply (AnswerResult) says whether it was right.

List<String> _strings(Object? v) => v is List ? v.map((e) => '$e').toList() : const [];

/// Builds a Question from {id, type, skill, prompt, hint, payload}.
/// Unknown types return null (the lesson skips them instead of crashing).
Question? questionFromJson(Map<String, dynamic> j) {
  final id = j['id'] as String;
  final skill = (j['skill'] as String?) ?? '';
  final prompt = (j['prompt'] as String?) ?? '';
  final hint = j['hint'] as String?;
  final p = (j['payload'] as Map?)?.cast<String, dynamic>() ?? const <String, dynamic>{};
  switch (j['type']) {
    case 'multiple_choice':
      return MultipleChoiceQuestion(id: id, skill: skill, prompt: prompt, hint: hint, options: _strings(p['options']), correctIndex: -1);
    case 'true_false':
      return TrueFalseQuestion(id: id, skill: skill, prompt: prompt, hint: hint, answer: false);
    case 'fill_blank':
      return FillBlankQuestion(
          id: id, skill: skill, prompt: prompt, hint: hint, before: '${p['before'] ?? ''}', after: '${p['after'] ?? ''}', accepted: const []);
    case 'matching':
      return MatchingQuestion(id: id, skill: skill, prompt: prompt, hint: hint, left: _strings(p['left']), right: _strings(p['right']));
    case 'ordering':
      return OrderingQuestion(id: id, skill: skill, prompt: prompt, hint: hint, correctOrder: _strings(p['items']));
    case 'drag_drop':
      return DragDropQuestion(
        id: id,
        skill: skill,
        prompt: prompt,
        hint: hint,
        before: '${p['before'] ?? ''}',
        after: '${p['after'] ?? ''}',
        tokens: _strings(p['tokens']),
        correctToken: '',
      );
    case 'typing':
      return TypingQuestion(id: id, skill: skill, prompt: prompt, hint: hint, accepted: const []);
    case 'reading':
      return ReadingQuestion(
          id: id, skill: skill, prompt: prompt, hint: hint, passage: '${p['passage'] ?? ''}', options: _strings(p['options']), correctIndex: -1);
    case 'word_problem':
      return WordProblemQuestion(id: id, skill: skill, prompt: prompt, hint: hint, answer: 0, unit: p['unit'] as String?);
    case 'listening':
      return ListeningQuestion(
          id: id, skill: skill, prompt: prompt, hint: hint, audioText: '${p['audio_text'] ?? ''}', options: _strings(p['options']), correctIndex: -1);
    case 'speaking':
      return SpeakingQuestion(id: id, skill: skill, prompt: prompt, hint: hint, targetText: '${p['target'] ?? ''}');
  }
  return null;
}

/// The learner's answer as JSON for submit_answer.
///  choice -> index (int), true/false -> bool, text -> String,
///  matching -> {"leftIndex": rightIndex}, ordering -> [items...]
Object? encodeResponse(Object? answer) {
  if (answer is Map) {
    return {for (final e in answer.entries) '${e.key}': e.value};
  }
  if (answer is List) return answer.map((e) => '$e').toList();
  return answer;
}
