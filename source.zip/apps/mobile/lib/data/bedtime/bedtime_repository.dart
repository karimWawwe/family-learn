import 'dart:async';
import 'dart:convert';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../../domain/account.dart';
import '../../domain/bedtime.dart';
import '../../domain/models.dart';
import 'bedtime_content.g.dart';

/// Bedtime stories and each child's own listening progress.
///  * [SupabaseBedtimeRepository] - real, saved per profile.
///  * [DemoBedtimeRepository]     - in memory (DEMO mode and tests).
/// Throws AuthFailure: not_found, network, bedtime_not_installed, unknown.
abstract class BedtimeRepository {
  Future<BedtimeState> load(LearnerProfile profile);
  Future<ListenSession> start(LearnerProfile profile, String storyId);
  Future<void> progress(String listenId, int page, int seconds);
  Future<void> complete(String listenId, int seconds, bool? answerCorrect);
  Future<void> setFavorite(LearnerProfile profile, String storyId, bool on);
}

// ---------------------------------------------------------------- JSON
BedtimeStory storyFromJson(Map j) {
  final q = (j['question'] as Map?) ?? const {};
  return BedtimeStory(
    id: '${j['id']}',
    title: '${j['title'] ?? ''}',
    emoji: '${j['emoji'] ?? '🌙'}',
    valueCode: '${j['value_code'] ?? ''}',
    valueName: '${j['value_name'] ?? ''}',
    kind: '${j['kind'] ?? 'value'}',
    minutes: (j['minutes'] as num?)?.toInt() ?? 4,
    source: '${j['source'] ?? ''}',
    pages: [
      for (final p in (j['pages'] as List? ?? const []).cast<Map>())
        StoryPage(
          text: '${p['text'] ?? ''}',
          scene: [for (final e in (p['scene'] as List? ?? const [])) '$e'],
          bg: '${p['bg'] ?? 'night'}',
        ),
    ],
    question: StoryQuestion(
      question: '${q['q'] ?? ''}',
      options: [for (final o in (q['options'] as List? ?? const [])) '$o'],
      answer: (q['answer'] as num?)?.toInt() ?? 0,
    ),
    activity: '${j['activity'] ?? ''}',
    favorite: j['favorite'] == true,
    completed: (j['completed'] as num?)?.toInt() ?? 0,
    listened: (j['listened'] as num?)?.toInt() ?? 0,
  );
}

BedtimeState bedtimeStateFromJson(Map<String, dynamic> j) {
  final last = j['last'] as Map?;
  return BedtimeState(
    stories: [for (final s in (j['stories'] as List? ?? const []).cast<Map>()) storyFromJson(s)],
    last: last == null
        ? null
        : LastStory(
            storyId: '${last['story_id']}',
            page: (last['page'] as num?)?.toInt() ?? 0,
            completed: last['completed'] == true,
            at: last['at'] == null ? null : DateTime.tryParse('${last['at']}'),
          ),
  );
}

// ---------------------------------------------------------------- Supabase
class SupabaseBedtimeRepository implements BedtimeRepository {
  SupabaseBedtimeRepository(this._client);

  final SupabaseClient _client;

  Future<Object?> _rpc(String fn, Map<String, dynamic> params) async {
    try {
      return await _client.rpc(fn, params: params).timeout(const Duration(seconds: 20));
    } on PostgrestException catch (e) {
      if (e.code == 'PGRST202' || e.message.contains('Could not find the function')) {
        throw AuthFailure('bedtime_not_installed', e.message);
      }
      throw AuthFailure(AuthFailure.known.contains(e.message) ? e.message : 'unknown', e.message);
    } on TimeoutException {
      throw const AuthFailure('network');
    } catch (e) {
      if (e is AuthFailure) rethrow;
      final s = e.toString();
      if (s.contains('SocketException') || s.contains('ClientException') || s.contains('Failed to fetch') || s.contains('XMLHttpRequest')) {
        throw const AuthFailure('network');
      }
      throw AuthFailure('unknown', s);
    }
  }

  @override
  Future<BedtimeState> load(LearnerProfile profile) async =>
      bedtimeStateFromJson(Map<String, dynamic>.from(await _rpc('bedtime_state', {'p_profile': profile.id}) as Map));

  @override
  Future<ListenSession> start(LearnerProfile profile, String storyId) async {
    final m = Map<String, dynamic>.from(
        await _rpc('bedtime_start', {'p_profile': profile.id, 'p_story': storyId}) as Map);
    return ListenSession(listenId: '${m['listen_id']}', page: (m['page'] as num?)?.toInt() ?? 0);
  }

  @override
  Future<void> progress(String listenId, int page, int seconds) async {
    await _rpc('bedtime_progress', {'p_listen': listenId, 'p_page': page, 'p_seconds': seconds});
  }

  @override
  Future<void> complete(String listenId, int seconds, bool? answerCorrect) async {
    await _rpc('bedtime_complete', {'p_listen': listenId, 'p_seconds': seconds, 'p_answer_correct': answerCorrect});
  }

  @override
  Future<void> setFavorite(LearnerProfile profile, String storyId, bool on) async {
    await _rpc('bedtime_favorite', {'p_profile': profile.id, 'p_story': storyId, 'p_on': on});
  }
}

// ---------------------------------------------------------------- Demo
class DemoListen {
  DemoListen(this.id, this.profileId, this.storyId, this.startedAt) : updatedAt = startedAt;

  final String id;
  final String profileId;
  final String storyId;
  final DateTime startedAt;
  DateTime updatedAt;
  int page = 0;
  int seconds = 0;
  DateTime? completedAt;
  bool? answerCorrect;
}

class DemoBedtimeRepository implements BedtimeRepository {
  DemoBedtimeRepository({DateTime Function()? clock}) : _now = clock ?? DateTime.now;

  final DateTime Function() _now;
  late final List<Map<String, dynamic>> stories =
      (jsonDecode(bedtimeContentJson) as List).cast<Map<String, dynamic>>();
  final List<DemoListen> listens = [];
  final Map<String, Set<String>> favorites = {};
  int _seq = 0;

  @override
  Future<BedtimeState> load(LearnerProfile profile) async {
    final mine = listens.where((l) => l.profileId == profile.id).toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    final fav = favorites[profile.id] ?? const {};
    return bedtimeStateFromJson({
      'stories': [
        for (final s in stories)
          {
            ...s,
            'favorite': fav.contains(s['id']),
            'completed': mine.where((l) => l.storyId == s['id'] && l.completedAt != null).length,
            'listened': mine.where((l) => l.storyId == s['id']).length,
          },
      ],
      'last': mine.isEmpty
          ? null
          : {
              'story_id': mine.first.storyId,
              'page': mine.first.page,
              'completed': mine.first.completedAt != null,
              'at': mine.first.updatedAt.toIso8601String(),
            },
    });
  }

  DemoListen _listen(String id) =>
      listens.firstWhere((l) => l.id == id, orElse: () => throw const AuthFailure('not_found'));

  @override
  Future<ListenSession> start(LearnerProfile profile, String storyId) async {
    if (!stories.any((s) => s['id'] == storyId)) throw const AuthFailure('not_found');
    final now = _now();
    for (final l in listens.reversed) {
      if (l.profileId == profile.id &&
          l.storyId == storyId &&
          l.completedAt == null &&
          now.difference(l.updatedAt) < const Duration(hours: 12)) {
        l.updatedAt = now;
        return ListenSession(listenId: l.id, page: l.page);
      }
    }
    final l = DemoListen('listen-${++_seq}', profile.id, storyId, now);
    listens.add(l);
    return ListenSession(listenId: l.id);
  }

  @override
  Future<void> progress(String listenId, int page, int seconds) async {
    final l = _listen(listenId);
    l.page = page.clamp(0, 50).toInt();
    if (seconds > l.seconds) l.seconds = seconds.clamp(0, 7200).toInt();
    l.updatedAt = _now();
  }

  @override
  Future<void> complete(String listenId, int seconds, bool? answerCorrect) async {
    final l = _listen(listenId);
    l.completedAt ??= _now();
    if (seconds > l.seconds) l.seconds = seconds.clamp(0, 7200).toInt();
    l.answerCorrect = answerCorrect ?? l.answerCorrect;
    l.updatedAt = _now();
  }

  @override
  Future<void> setFavorite(LearnerProfile profile, String storyId, bool on) async {
    final f = favorites.putIfAbsent(profile.id, () => {});
    on ? f.add(storyId) : f.remove(storyId);
  }
}
