import 'dart:async';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../../domain/account.dart';
import '../../domain/learning.dart';
import '../../domain/plan.dart';
import '../learning/learning_json.dart';
import '../learning/learning_repository.dart';
import '../learning/question_codec.dart';

/// Phase 6: today's plan, the review box and the placement test.
///  * [SupabasePlanRepository] - real (daily_plan, review_overview, start_review,
///    start_placement, submit_practice_answer, finish_practice). The server marks
///    every answer and decides what is due.
///  * [DemoPlanRepository]     - DEMO mode / tests: a plan built from the course map,
///    nothing to review, no placement test.
/// Throws AuthFailure: not_found, lesson_finished, network, plan_not_installed, unknown.
abstract class PlanRepository {
  Future<DailyPlan> dailyPlan(String profileId);
  Future<ReviewOverview> reviewOverview(String profileId);
  Future<PracticeSession> startReview(String profileId, {int limit = 10});
  Future<PracticeSession> startPlacement(String profileId);
  Future<AnswerResult> submitAnswer(String sessionId, String questionId, Object? response);
  Future<PracticeOutcome> finish(String sessionId);
}

// ---------------------------------------------------------------- JSON

int _i(Object? v) => (v as num?)?.toInt() ?? 0;
double _d(Object? v) => (v as num?)?.toDouble() ?? 0;
Map<String, dynamic> _m(Object? v) => ((v as Map?) ?? const {}).cast<String, dynamic>();
List<Map<String, dynamic>> _l(Object? v) => [for (final e in (v as List?) ?? const []) _m(e)];

PlanTaskKind? _taskKind(Object? s) => switch (s) {
      'review' => PlanTaskKind.review,
      'lesson' => PlanTaskKind.lesson,
      'speak' => PlanTaskKind.speak,
      _ => null,
    };

DailyPlan dailyPlanFromJson(Map<String, dynamic> j) => DailyPlan(
      tasks: [
        for (final t in _l(j['tasks']))
          if (_taskKind(t['kind']) case final kind?)
            PlanTask(
              kind: kind,
              done: t['done'] == true,
              minutes: t['minutes'] == null ? 5 : _i(t['minutes']),
              count: _i(t['count']),
              lessonId: t['lesson_id'] as String?,
              title: t['title'] as String?,
              course: t['course'] as String?,
            ),
      ],
      done: _i(j['done']),
      total: _i(j['total']),
      minutesToday: _i(j['minutes_today']),
      goalMinutes: j['goal_minutes'] == null ? 20 : _i(j['goal_minutes']),
      streakDays: _i(j['streak_days']),
      dueReview: _i(j['due_review']),
      suggestPlacement: j['suggest_placement'] == true,
    );

ReviewOverview reviewOverviewFromJson(Map<String, dynamic> j) => ReviewOverview(
      dueToday: _i(j['due_today']),
      dueTomorrow: _i(j['due_tomorrow']),
      tracked: _i(j['tracked']),
      mastered: _i(j['mastered']),
      reviewedToday: j['reviewed_today'] == true,
      items: [
        for (final it in _l(j['items']))
          ReviewItemInfo(
            questionId: (it['question_id'] as String?) ?? '',
            prompt: (it['prompt'] as String?) ?? '',
            skill: (it['skill'] as String?) ?? '',
            box: it['box'] == null ? 1 : _i(it['box']),
            lastResult: it['last_result'] as bool?,
            lapses: _i(it['lapses']),
          ),
      ],
      skills: [
        for (final s in _l(j['skills']))
          SkillMasteryInfo(
            code: (s['code'] as String?) ?? '',
            name: (s['name'] as String?) ?? '',
            questions: _i(s['questions']),
            mastery: _d(s['mastery']),
          ),
      ],
    );

PracticeSession practiceSessionFromJson(Map<String, dynamic> j) => PracticeSession(
      sessionId: j['session_id'] as String?,
      kind: j['kind'] == 'placement' ? PracticeKind.placement : PracticeKind.review,
      questions: [
        for (final q in _l(j['questions']))
          if (questionFromJson(q) case final question?) question,
      ],
    );

PracticeOutcome practiceOutcomeFromJson(Map<String, dynamic> j) => PracticeOutcome(
      kind: j['kind'] == 'placement' ? PracticeKind.placement : PracticeKind.review,
      correct: _i(j['correct']),
      total: _i(j['total']),
      xp: _i(j['xp']),
      coins: _i(j['coins']),
      stars: j['stars'] == null ? 1 : _i(j['stars']),
      wallet: walletFromJson(_m(j['wallet'])),
      placements: [
        for (final p in _l(j['placements']))
          PlacementCourse(
            courseId: (p['course_id'] as String?) ?? '',
            title: (p['title'] as String?) ?? '',
            placedPosition: _i(p['placed_position']),
            lessons: _i(p['lessons']),
            startLesson: p['start_lesson'] as String?,
          ),
      ],
    );

// ---------------------------------------------------------------- Supabase

class SupabasePlanRepository implements PlanRepository {
  SupabasePlanRepository(this._client);

  final SupabaseClient _client;

  Future<Object?> _rpc(String fn, Map<String, dynamic> params) async {
    try {
      return await _client.rpc(fn, params: params).timeout(const Duration(seconds: 20));
    } on PostgrestException catch (e) {
      if (e.code == 'PGRST202' || e.message.contains('Could not find the function')) {
        throw AuthFailure('plan_not_installed', e.message);
      }
      throw AuthFailure(AuthFailure.known.contains(e.message) ? e.message : 'unknown', e.message);
    } on TimeoutException {
      throw const AuthFailure('network');
    } catch (e) {
      if (e is AuthFailure) rethrow;
      final s = e.toString();
      if (s.contains('SocketException') || s.contains('ClientException') || s.contains('Failed to fetch') || s.contains('XMLHttpRequest')) {
        throw const AuthFailure('network');
      }
      throw AuthFailure('unknown', s);
    }
  }

  @override
  Future<DailyPlan> dailyPlan(String profileId) async =>
      dailyPlanFromJson(_m(await _rpc('daily_plan', {'p_profile': profileId})));

  @override
  Future<ReviewOverview> reviewOverview(String profileId) async =>
      reviewOverviewFromJson(_m(await _rpc('review_overview', {'p_profile': profileId})));

  @override
  Future<PracticeSession> startReview(String profileId, {int limit = 10}) async =>
      practiceSessionFromJson(_m(await _rpc('start_review', {'p_profile': profileId, 'p_limit': limit})));

  @override
  Future<PracticeSession> startPlacement(String profileId) async =>
      practiceSessionFromJson(_m(await _rpc('start_placement', {'p_profile': profileId})));

  @override
  Future<AnswerResult> submitAnswer(String sessionId, String questionId, Object? response) async => answerFromJson(_m(
      await _rpc('submit_practice_answer', {'p_session': sessionId, 'p_question': questionId, 'p_response': response})));

  @override
  Future<PracticeOutcome> finish(String sessionId) async =>
      practiceOutcomeFromJson(_m(await _rpc('finish_practice', {'p_session': sessionId})));
}

// ---------------------------------------------------------------- demo

/// DEMO mode: the plan is the next lesson + the speaking game; there is no
/// review box and no placement test without the database.
class DemoPlanRepository implements PlanRepository {
  DemoPlanRepository(this._learning);

  final LearningRepository _learning;

  @override
  Future<DailyPlan> dailyPlan(String profileId) async {
    final courses = await _learning.courseMap(profileId);
    final wallet = await _learning.wallet(profileId);
    final next = nextLesson(courses);
    final tasks = <PlanTask>[
      if (next != null) PlanTask(kind: PlanTaskKind.lesson, done: false, lessonId: next.id, title: next.title, minutes: next.minutes),
      const PlanTask(kind: PlanTaskKind.speak, done: false),
    ];
    return DailyPlan(
      tasks: tasks,
      total: tasks.length,
      minutesToday: wallet.minutesToday,
      streakDays: wallet.streakDays,
    );
  }

  @override
  Future<ReviewOverview> reviewOverview(String profileId) async => const ReviewOverview();

  @override
  Future<PracticeSession> startReview(String profileId, {int limit = 10}) async =>
      const PracticeSession(sessionId: null, kind: PracticeKind.review, questions: []);

  @override
  Future<PracticeSession> startPlacement(String profileId) async => throw const AuthFailure('plan_not_installed');

  @override
  Future<AnswerResult> submitAnswer(String sessionId, String questionId, Object? response) async =>
      throw const AuthFailure('not_found');

  @override
  Future<PracticeOutcome> finish(String sessionId) async => throw const AuthFailure('not_found');
}
