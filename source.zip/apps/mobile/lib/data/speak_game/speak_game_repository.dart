import 'dart:async';
import 'dart:convert';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../../domain/account.dart';
import '../../domain/models.dart';
import '../../domain/speak_game.dart';
import 'speak_content.g.dart';

/// Levels, words and each child's own progress in the speaking game.
///  * [SupabaseSpeakGameRepository] - real, saved per profile (Phase "speak" SQL).
///  * [DemoSpeakGameRepository]     - in memory (DEMO mode and tests).
/// Throws AuthFailure: not_found, network, speak_not_installed, unknown.
abstract class SpeakGameRepository {
  Future<SpeakGameState> load(LearnerProfile profile);

  /// Logs one try (for the parent report). Unclear tries are logged too.
  Future<void> recordTry({
    required LearnerProfile profile,
    required String levelId,
    required String word,
    required String heard,
    required double score,
    required String result,
    required int tryNo,
  });

  /// Saves a finished level and returns the new totals.
  Future<SpeakGameState> finishLevel(LearnerProfile profile, SpeakPlayResult r);
}

/// Which word list fits a profile.
String speakTrackFor(LearnerProfile p) {
  if (!p.isChild) return 'adult';
  return (p.grade ?? 3) <= 4 ? 'young' : 'older';
}

// ---------------------------------------------------------------- JSON
SpeakGameState speakStateFromJson(Map<String, dynamic> j) {
  List<String> strList(Object? v) => [for (final e in (v as List? ?? const [])) '$e'];
  final levels = <SpeakLevel>[
    for (final l in (j['levels'] as List? ?? const []).cast<Map>())
      SpeakLevel(
        id: '${l['id']}',
        title: '${l['title'] ?? ''}',
        titleAr: '${l['title_ar'] ?? ''}',
        emoji: '${l['emoji'] ?? '⭐'}',
        strictness: ((l['strictness'] as num?) ?? 0.75).toDouble(),
        source: '${l['source'] ?? ''}',
        bestStars: (l['best_stars'] as num?)?.toInt() ?? 0,
        plays: (l['plays'] as num?)?.toInt() ?? 0,
        unlocked: l['unlocked'] == true,
        words: [
          for (final w in (l['words'] as List? ?? const []).cast<Map>())
            SpeakWord(
              text: '${w['text']}',
              emoji: '${w['emoji'] ?? ''}',
              meaningAr: '${w['meaning_ar'] ?? ''}',
              accepted: strList(w['accept']),
              hint: '${w['hint'] ?? ''}',
            ),
        ],
      ),
  ];
  return SpeakGameState(
    track: '${j['track'] ?? 'young'}',
    levels: levels,
    points: (j['points'] as num?)?.toInt() ?? 0,
    pointsToday: (j['points_today'] as num?)?.toInt() ?? 0,
    wordsMastered: (j['words_mastered'] as num?)?.toInt() ?? 0,
    dayStreak: (j['day_streak'] as num?)?.toInt() ?? 0,
    lastPlayed: j['last_played'] == null ? null : DateTime.tryParse('${j['last_played']}'),
    tricky: [
      for (final t in (j['tricky'] as List? ?? const []).cast<Map>())
        TrickyWord('${t['word']}', (t['misses'] as num?)?.toInt() ?? 0),
    ],
  );
}

// ---------------------------------------------------------------- Supabase
class SupabaseSpeakGameRepository implements SpeakGameRepository {
  SupabaseSpeakGameRepository(this._client);

  final SupabaseClient _client;

  Future<Object?> _rpc(String fn, Map<String, dynamic> params) async {
    try {
      return await _client.rpc(fn, params: params).timeout(const Duration(seconds: 20));
    } on PostgrestException catch (e) {
      // PGRST202 = function not found: the speaking-game SQL is not installed yet.
      if (e.code == 'PGRST202' || e.message.contains('Could not find the function')) {
        throw AuthFailure('speak_not_installed', e.message);
      }
      throw AuthFailure(AuthFailure.known.contains(e.message) ? e.message : 'unknown', e.message);
    } on TimeoutException {
      throw const AuthFailure('network');
    } catch (e) {
      if (e is AuthFailure) rethrow;
      final s = e.toString();
      if (s.contains('SocketException') || s.contains('ClientException') || s.contains('Failed to fetch') || s.contains('XMLHttpRequest')) {
        throw const AuthFailure('network');
      }
      throw AuthFailure('unknown', s);
    }
  }

  Map<String, dynamic> _map(Object? v) => Map<String, dynamic>.from(v as Map);

  @override
  Future<SpeakGameState> load(LearnerProfile profile) async =>
      speakStateFromJson(_map(await _rpc('speak_game_state', {'p_profile': profile.id})));

  @override
  Future<void> recordTry({
    required LearnerProfile profile,
    required String levelId,
    required String word,
    required String heard,
    required double score,
    required String result,
    required int tryNo,
  }) async {
    await _rpc('speak_record_attempt', {
      'p_profile': profile.id,
      'p_level': levelId,
      'p_word': word,
      'p_heard': heard.length > 200 ? heard.substring(0, 200) : heard,
      'p_score': double.parse(score.toStringAsFixed(3)),
      'p_result': result,
      'p_try': tryNo,
    });
  }

  @override
  Future<SpeakGameState> finishLevel(LearnerProfile profile, SpeakPlayResult r) async =>
      speakStateFromJson(_map(await _rpc('speak_finish_level', {
        'p_profile': profile.id,
        'p_level': r.levelId,
        'p_points': r.points,
        'p_stars': r.stars,
        'p_words': r.words,
        'p_first_try': r.firstTry,
        'p_attempts': r.attempts,
      })));
}

// ---------------------------------------------------------------- Demo
class DemoSpeakGameRepository implements SpeakGameRepository {
  DemoSpeakGameRepository({DateTime Function()? clock}) : _now = clock ?? DateTime.now;

  final DateTime Function() _now;
  late final List<Map<String, dynamic>> _levels =
      (jsonDecode(speakContentJson) as List).cast<Map<String, dynamic>>();

  // profileId -> levelId -> best stars
  final Map<String, Map<String, int>> _best = {};
  final Map<String, Map<String, int>> _plays = {};
  final Map<String, int> _points = {};
  final Map<String, Set<String>> _mastered = {};
  final Map<String, Map<String, int>> _misses = {};
  final Map<String, Map<String, int>> _pointsByDay = {};

  String _day(DateTime d) => '${d.year}-${d.month}-${d.day}';

  @override
  Future<SpeakGameState> load(LearnerProfile profile) async {
    final track = speakTrackFor(profile);
    final best = _best[profile.id] ?? const {};
    final plays = _plays[profile.id] ?? const {};
    var prevDone = true;
    final levels = <Map<String, dynamic>>[];
    for (final l in _levels.where((l) => l['track'] == track)) {
      final stars = best[l['id']] ?? 0;
      levels.add({...l, 'best_stars': stars, 'plays': plays[l['id']] ?? 0, 'unlocked': prevDone});
      prevDone = stars > 0;
    }
    final byDay = _pointsByDay[profile.id] ?? const {};
    var streak = 0;
    var d = _now();
    if (!byDay.containsKey(_day(d))) d = d.subtract(const Duration(days: 1));
    while (byDay.containsKey(_day(d))) {
      streak++;
      d = d.subtract(const Duration(days: 1));
    }
    final misses = (_misses[profile.id] ?? const <String, int>{}).entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return speakStateFromJson({
      'track': track,
      'levels': levels,
      'points': _points[profile.id] ?? 0,
      'points_today': byDay[_day(_now())] ?? 0,
      'words_mastered': (_mastered[profile.id] ?? const {}).length,
      'day_streak': streak,
      'tricky': [for (final m in misses.take(5)) {'word': m.key, 'misses': m.value}],
    });
  }

  @override
  Future<void> recordTry({
    required LearnerProfile profile,
    required String levelId,
    required String word,
    required String heard,
    required double score,
    required String result,
    required int tryNo,
  }) async {
    if (result == 'correct') {
      _mastered.putIfAbsent(profile.id, () => {}).add(word.toLowerCase());
    } else if (result != 'unclear') {
      final m = _misses.putIfAbsent(profile.id, () => {});
      m[word] = (m[word] ?? 0) + 1;
    }
  }

  @override
  Future<SpeakGameState> finishLevel(LearnerProfile profile, SpeakPlayResult r) async {
    final state = await load(profile);
    final level = state.levelById(r.levelId);
    if (level == null) throw const AuthFailure('not_found');
    if (!level.unlocked) throw const AuthFailure('lesson_locked');
    final pts = r.points.clamp(0, r.words * 30 + 50).toInt();
    final best = _best.putIfAbsent(profile.id, () => {});
    best[r.levelId] = (best[r.levelId] ?? 0) > r.stars ? best[r.levelId]! : r.stars.clamp(1, 3).toInt();
    final plays = _plays.putIfAbsent(profile.id, () => {});
    plays[r.levelId] = (plays[r.levelId] ?? 0) + 1;
    _points[profile.id] = (_points[profile.id] ?? 0) + pts;
    final byDay = _pointsByDay.putIfAbsent(profile.id, () => {});
    byDay[_day(_now())] = (byDay[_day(_now())] ?? 0) + pts;
    return load(profile);
  }
}
