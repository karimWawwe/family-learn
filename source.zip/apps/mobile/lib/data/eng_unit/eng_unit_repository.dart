import 'dart:async';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../../domain/account.dart';
import '../../domain/eng_unit.dart';
import '../../domain/models.dart';

/// English unit progress, separate for every profile.
///  * [SupabaseEngUnitRepository] - real, saved (eng_unit_state / eng_unit_log).
///  * [DemoEngUnitRepository]     - in memory (DEMO mode and tests).
abstract class EngUnitRepository {
  Future<EngUnitState> load(LearnerProfile profile);

  /// [kind]: 'answer' (with [correct] / [stars]), 'video' or 'read'.
  Future<EngUnitState> log(LearnerProfile profile, String item, String kind, {bool correct = true, int stars = 0});
}

EngUnitState engUnitStateFromJson(Map<String, dynamic> j) {
  int i(Object? v) => (v as num?)?.toInt() ?? 0;
  return EngUnitState(
    items: {
      for (final it in (j['items'] as List? ?? const []).cast<Map>())
        '${it['item']}': UnitItemStat(
          attempts: i(it['attempts']),
          wrong: i(it['wrong']),
          solved: it['solved'] == true,
          bestStars: i(it['best_stars']),
        ),
    },
    videos: {for (final v in (j['videos'] as List? ?? const [])) '$v'},
    read: j['read'] == true,
  );
}

class SupabaseEngUnitRepository implements EngUnitRepository {
  SupabaseEngUnitRepository(this._client);

  final SupabaseClient _client;

  Future<Object?> _rpc(String fn, Map<String, dynamic> params) async {
    try {
      return await _client.rpc(fn, params: params).timeout(const Duration(seconds: 20));
    } on PostgrestException catch (e) {
      if (e.code == 'PGRST202' || e.message.contains('Could not find the function')) {
        throw AuthFailure('unit_not_installed', e.message);
      }
      throw AuthFailure(AuthFailure.known.contains(e.message) ? e.message : 'unknown', e.message);
    } on TimeoutException {
      throw const AuthFailure('network');
    } catch (e) {
      if (e is AuthFailure) rethrow;
      final s = e.toString();
      if (s.contains('SocketException') || s.contains('ClientException') || s.contains('Failed to fetch') || s.contains('XMLHttpRequest')) {
        throw const AuthFailure('network');
      }
      throw AuthFailure('unknown', s);
    }
  }

  @override
  Future<EngUnitState> load(LearnerProfile profile) async => engUnitStateFromJson(
      Map<String, dynamic>.from(await _rpc('eng_unit_state', {'p_profile': profile.id, 'p_unit': engUnitCode}) as Map));

  @override
  Future<EngUnitState> log(LearnerProfile profile, String item, String kind, {bool correct = true, int stars = 0}) async =>
      engUnitStateFromJson(Map<String, dynamic>.from(await _rpc('eng_unit_log', {
        'p_profile': profile.id,
        'p_unit': engUnitCode,
        'p_item': item,
        'p_kind': kind,
        'p_correct': correct,
        'p_stars': stars,
      }) as Map));
}

class DemoEngUnitRepository implements EngUnitRepository {
  final Map<String, List<(String, String, bool, int)>> _events = {};

  @override
  Future<EngUnitState> load(LearnerProfile profile) async {
    final ev = _events[profile.id] ?? const <(String, String, bool, int)>[];
    final items = <String, UnitItemStat>{};
    for (final e in ev.where((e) => e.$2 == 'answer')) {
      final old = items[e.$1] ?? const UnitItemStat();
      items[e.$1] = UnitItemStat(
        attempts: old.attempts + 1,
        wrong: old.wrong + (e.$3 ? 0 : 1),
        solved: old.solved || e.$3,
        bestStars: e.$3 && e.$4 > old.bestStars ? e.$4 : old.bestStars,
      );
    }
    return EngUnitState(
      items: items,
      videos: {for (final e in ev.where((e) => e.$2 == 'video')) e.$1},
      read: ev.any((e) => e.$2 == 'read'),
    );
  }

  @override
  Future<EngUnitState> log(LearnerProfile profile, String item, String kind, {bool correct = true, int stars = 0}) async {
    if (!engUnitItemRe.hasMatch(item) || !const {'answer', 'video', 'read'}.contains(kind)) throw const AuthFailure('not_found');
    _events.putIfAbsent(profile.id, () => []).add((item, kind, correct, correct ? stars.clamp(1, 3).toInt() : 0));
    return load(profile);
  }
}
