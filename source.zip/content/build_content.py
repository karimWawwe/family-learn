#!/usr/bin/env python3
"""Builds the starter content into SQL (Supabase) and Dart (app demo mode + tests).

    python3 content/build_content.py

Checks every question (answer index in range, drag answer among tokens,
skills exist, ids unique) and stops with an error if anything is wrong.
"""
import json
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from starter_content import COURSES, SKILLS  # noqa: E402

SQL_OUT = os.path.join(ROOT, "supabase", "migrations", "20260926000003_phase4_starter_content.sql")
DART_OUT = os.path.join(ROOT, "apps", "mobile", "lib", "data", "learning", "starter_content.g.dart")

TYPE = {"mc": "multiple_choice", "tf": "true_false", "fill": "fill_blank", "match": "matching",
        "order": "ordering", "drag": "drag_drop", "type": "typing", "read": "reading", "word": "word_problem"}


def shuffled(items, qid):
    """Fixed shuffle per question (never the original order), so the phone
    cannot read the answer from the order of the items."""
    rnd = random.Random(qid)
    out = list(items)
    while out == list(items):
        rnd.shuffle(out)
    return out


def fmt_num(v):
    return str(int(v)) if float(v).is_integer() else str(v)


def convert(q, qid):
    t = q["t"]
    if t not in TYPE:
        raise ValueError(f"{qid}: unknown type {t}")
    if q["skill"] not in SKILLS:
        raise ValueError(f"{qid}: unknown skill {q['skill']}")
    if t in ("mc", "read"):
        opts = q["options"]
        if not 0 <= q["answer"] < len(opts) or len(set(opts)) != len(opts):
            raise ValueError(f"{qid}: bad options/answer")
        payload = {"options": opts} if t == "mc" else {"passage": q["passage"], "options": opts}
        key, text = {"index": q["answer"]}, opts[q["answer"]]
    elif t == "tf":
        if not isinstance(q["answer"], bool):
            raise ValueError(f"{qid}: tf answer must be bool")
        payload, key, text = {}, {"value": q["answer"]}, "True" if q["answer"] else "False"
    elif t in ("fill", "type"):
        acc = q["accepted"]
        if not acc:
            raise ValueError(f"{qid}: no accepted answers")
        payload = {"before": q["before"], "after": q["after"]} if t == "fill" else {}
        key, text = {"accepted": acc}, acc[0]
    elif t == "drag":
        if q["answer"] not in q["tokens"]:
            raise ValueError(f"{qid}: drag answer not in tokens")
        payload = {"before": q["before"], "after": q["after"], "tokens": q["tokens"]}
        key, text = {"token": q["answer"]}, q["answer"]
    elif t == "word":
        payload = {"unit": q.get("unit") or None}
        key = {"value": q["answer"]}
        text = (fmt_num(q["answer"]) + (" " + q["unit"] if q.get("unit") else "")).strip()
    elif t == "match":
        left, right = q["left"], q["right"]
        if len(left) != len(right) or len(left) < 2 or len(set(right)) != len(right):
            raise ValueError(f"{qid}: bad matching pairs")
        shown = shuffled(right, qid)
        # response: {"leftIndex": index in the SHOWN right list}; map = the right answer
        payload = {"left": left, "right": shown}
        key = {"pairs": len(left), "map": {str(i): shown.index(r) for i, r in enumerate(right)}}
        text = ", ".join(f"{a} = {b}" for a, b in zip(left, right))
    elif t == "order":
        order = q["order"]
        if len(order) < 2 or len(set(order)) != len(order):
            raise ValueError(f"{qid}: bad order")
        payload, key, text = {"items": shuffled(order, qid)}, {"order": order}, " > ".join(order)
    return {
        "id": qid, "type": TYPE[t], "skill": q["skill"], "prompt": q["prompt"], "hint": q.get("hint"),
        "payload": payload, "answer_key": key, "correct_text": text, "explanation": q.get("explain"),
    }


def build():
    courses, units, lessons, questions = [], [], [], []
    for ci, c in enumerate(COURSES, start=1):
        courses.append({k: c[k] for k in ("subject", "title", "audience", "grade_min", "grade_max")}
                       | {"id": c["code"], "level_label": c["level"], "position": ci})
        pos = 0
        for ui, u in enumerate(c["units"], start=1):
            uid = f"{c['code']}.u{ui}"
            units.append({"id": uid, "course_id": c["code"], "position": ui, "title": u["title"]})
            for li, l in enumerate(u["lessons"], start=1):
                pos += 1
                lid = f"{uid}.l{li}"
                lessons.append({"id": lid, "unit_id": uid, "course_id": c["code"], "position": pos,
                                "title": l["title"], "minutes": l["minutes"]})
                for qi, q in enumerate(l["questions"], start=1):
                    row = convert(q, f"{lid}.q{qi}")
                    row["lesson_id"], row["position"] = lid, qi
                    questions.append(row)
    ids = [q["id"] for q in questions]
    assert len(ids) == len(set(ids))
    skills = [{"code": k, "name": v, "subject": k.split(".")[0]} for k, v in SKILLS.items()]
    return {"skills": skills, "courses": courses, "units": units, "lessons": lessons, "questions": questions}


def lit(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace("'", "''") + "'"


def write_sql(data):
    """Compact form: one JSON document per table, loaded with jsonb_to_recordset."""
    def doc(rows):
        return lit(json.dumps(rows, ensure_ascii=False, separators=(",", ":"))) + "::jsonb"

    course_ids = ", ".join(lit(c["id"]) for c in data["courses"])
    lesson_ids = ", ".join(lit(l["id"]) for l in data["lessons"])
    out = [
        "-- ============================================================================",
        "--  Family Learn - Phase 4 starter content (GENERATED by content/build_content.py - do not edit).",
        f"--  {len(data['courses'])} courses, {len(data['lessons'])} lessons, {len(data['questions'])} questions.",
        "--  Safe to run again: it updates the starter courses (learner progress on",
        "--  lessons that still exist is kept).",
        "-- ============================================================================",
        "begin;",
        "insert into public.skills (code, name, subject)",
        f"select code, name, subject from jsonb_to_recordset({doc(data['skills'])}) as x(code text, name text, subject text)",
        "on conflict (code) do update set name = excluded.name, subject = excluded.subject;",
        "",
        "insert into public.courses (id, subject, title, level_label, audience, grade_min, grade_max, position)",
        "select id, subject, title, level_label, audience, grade_min, grade_max, position",
        f"  from jsonb_to_recordset({doc(data['courses'])})",
        "    as x(id text, subject text, title text, level_label text, audience text, grade_min smallint, grade_max smallint, position smallint)",
        "on conflict (id) do update set subject = excluded.subject, title = excluded.title, level_label = excluded.level_label,",
        "  audience = excluded.audience, grade_min = excluded.grade_min, grade_max = excluded.grade_max, position = excluded.position;",
        "",
        "insert into public.units (id, course_id, position, title)",
        f"select id, course_id, position, title from jsonb_to_recordset({doc(data['units'])}) as x(id text, course_id text, position smallint, title text)",
        "on conflict (id) do update set course_id = excluded.course_id, position = excluded.position, title = excluded.title;",
        "",
        "-- lesson positions are unique per course: move existing ones out of the way first",
        f"update public.lessons set position = position + 1000 where course_id in ({course_ids});",
        "insert into public.lessons (id, unit_id, course_id, position, title, minutes)",
        "select id, unit_id, course_id, position, title, minutes",
        f"  from jsonb_to_recordset({doc(data['lessons'])})",
        "    as x(id text, unit_id text, course_id text, position smallint, title text, minutes smallint)",
        "on conflict (id) do update set unit_id = excluded.unit_id, course_id = excluded.course_id,",
        "  position = excluded.position, title = excluded.title, minutes = excluded.minutes;",
        f"delete from public.lessons where course_id in ({course_ids}) and position > 1000;",
        "",
        f"update public.questions set position = position + 1000 where lesson_id in ({lesson_ids});",
        "insert into public.questions (id, lesson_id, position, type, skill, prompt, hint, payload, answer_key, correct_text, explanation)",
        "select id, lesson_id, position, type, skill, prompt, hint, payload, answer_key, correct_text, explanation",
        f"  from jsonb_to_recordset({doc(data['questions'])})",
        "    as x(id text, lesson_id text, position smallint, type text, skill text, prompt text, hint text,",
        "         payload jsonb, answer_key jsonb, correct_text text, explanation text)",
        "on conflict (id) do update set lesson_id = excluded.lesson_id, position = excluded.position, type = excluded.type,",
        "  skill = excluded.skill, prompt = excluded.prompt, hint = excluded.hint, payload = excluded.payload,",
        "  answer_key = excluded.answer_key, correct_text = excluded.correct_text, explanation = excluded.explanation;",
        f"delete from public.questions where lesson_id in ({lesson_ids}) and position > 1000;",
        "commit;",
    ]
    os.makedirs(os.path.dirname(SQL_OUT), exist_ok=True)
    with open(SQL_OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")


def write_dart(data):
    blob = json.dumps(data, ensure_ascii=False, indent=1)
    if "'''" in blob:
        raise ValueError("content contains ''' which breaks the Dart raw string")
    os.makedirs(os.path.dirname(DART_OUT), exist_ok=True)
    with open(DART_OUT, "w", encoding="utf-8") as f:
        f.write("// GENERATED by content/build_content.py - do not edit.\n"
                "// The same starter content as supabase/migrations/20260926000003_phase4_starter_content.sql,\n"
                "// used by the app's DEMO mode and by the tests.\n"
                "// ignore_for_file: lines_longer_than_80_chars\n\n"
                "const starterContentJson = r'''\n" + blob + "\n''';\n")


if __name__ == "__main__":
    d = build()
    write_sql(d)
    write_dart(d)
    print(f"ok: {len(d['courses'])} courses, {len(d['units'])} units, {len(d['lessons'])} lessons, "
          f"{len(d['questions'])} questions, {len(d['skills'])} skills")
