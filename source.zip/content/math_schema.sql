-- ============================================================================
--  Family Learn - math games: "جدول الضرب" (times tables) and "تعلّم الوقت" (clock)
--  + prophets stories in the existing bedtime-stories section
--  + the follow report now counts the math games too.
--
--  Needs migrations 0001-0008. Safe to run again: progress is kept.
--  Rules enforced here:
--   * a child's phone reads and writes only its own math progress;
--   * clock levels open one after another (level n needs a finished level n-1);
--   * numbers sent by the app are checked and capped.
-- ============================================================================

do $$
begin
  if to_regclass('public.math_plays') is null then
    create table public.math_plays (
      id          bigint generated always as identity primary key,
      profile_id  uuid not null references public.profiles (id) on delete cascade,
      game        text not null check (game in ('times', 'clock')),
      level       text not null,
      correct     int  not null check (correct >= 0),
      total       int  not null check (total between 1 and 30),
      stars       int  not null check (stars between 1 and 3),
      points      int  not null check (points >= 0),
      seconds     int  not null default 0 check (seconds between 0 and 3600),
      created_at  timestamptz not null default now(),
      check (correct <= total)
    );
    create index math_plays_profile on public.math_plays (profile_id, created_at desc);
    alter table public.math_plays enable row level security;
    revoke all on public.math_plays from anon, authenticated;
  end if;
end $$;

-- ---------------------------------------------------------------- helpers
create or replace function app.math_level_ok(p_game text, p_level text) returns boolean
language sql immutable set search_path = '' as $$
  select case p_game
    when 'times' then p_level ~ '^(t([1-9]|1[0-2])|mixed)-(easy|medium|hard)$'
    when 'clock' then p_level ~ '^clock-[1-5]$'
    else false end
$$;

create or replace function app.math_minutes(p_profile uuid, d1 date, d2 date, tz text) returns numeric
language sql stable security definer set search_path = '' as $$
  select coalesce(sum(seconds), 0) / 60.0 from public.math_plays
   where profile_id = p_profile and (created_at at time zone tz)::date between d1 and d2
$$;

-- Points: the best result of every game level (replays can only improve it).
create or replace function app.math_best_points(p_profile uuid) returns int
language sql stable security definer set search_path = '' as $$
  select coalesce(sum(b.best), 0)::int
    from (select max(points) best from public.math_plays where profile_id = p_profile group by game, level) b
$$;

create or replace function app.clock_level_open(p_profile uuid, p_level text) returns boolean
language sql stable security definer set search_path = '' as $$
  select p_level = 'clock-1'
      or exists (select 1 from public.math_plays
                  where profile_id = p_profile and game = 'clock'
                    and level = 'clock-' || (substring(p_level from 7)::int - 1))
$$;

revoke all on function app.math_level_ok(text, text) from public, anon;
revoke all on function app.math_minutes(uuid, date, date, text) from public, anon;
revoke all on function app.math_best_points(uuid) from public, anon;
revoke all on function app.clock_level_open(uuid, text) from public, anon;
grant execute on function app.math_level_ok(text, text) to authenticated;
grant execute on function app.math_minutes(uuid, date, date, text) to authenticated;
grant execute on function app.math_best_points(uuid) to authenticated;
grant execute on function app.clock_level_open(uuid, text) to authenticated;

-- ---------------------------------------------------------------- API (RPC)

-- Best result of every level the child played, plus totals.
create or replace function public.math_state(p_profile uuid) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
begin
  perform app.require_profile(p_profile);
  return jsonb_build_object(
    'levels', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'game', b.game, 'level', b.level, 'best_stars', b.best_stars, 'best_points', b.best_points,
               'best_correct', b.best_correct, 'total', b.total, 'plays', b.plays, 'last_at', b.last_at)
             order by b.game, b.level), '[]'::jsonb)
        from (select game, level, max(stars) best_stars, max(points) best_points, max(correct) best_correct,
                     max(total) total, count(*) plays, max(created_at) last_at
                from public.math_plays where profile_id = p_profile group by game, level) b),
    'points', app.math_best_points(p_profile),
    'stars', (select coalesce(sum(m), 0) from (select max(stars) m from public.math_plays
                                               where profile_id = p_profile group by game, level) x),
    'rounds', (select count(*) from public.math_plays where profile_id = p_profile));
end $$;

-- One round played to the end. Returns the new state.
create or replace function public.math_finish(
  p_profile uuid, p_game text, p_level text, p_correct int, p_total int, p_stars int, p_points int, p_seconds int
) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform app.require_profile(p_profile);
  if not app.math_level_ok(p_game, p_level) then perform app.fail('not_found'); end if;
  if p_game = 'clock' and not app.clock_level_open(p_profile, p_level) then perform app.fail('lesson_locked'); end if;
  if coalesce(p_total, 0) not between 1 and 30 then perform app.fail('unknown'); end if;
  if (select count(*) from public.math_plays
       where profile_id = p_profile and created_at > now() - interval '1 minute') >= 10 then
    perform app.fail('rate_limited');
  end if;
  insert into public.math_plays (profile_id, game, level, correct, total, stars, points, seconds)
  values (p_profile, p_game, p_level,
          least(greatest(coalesce(p_correct, 0), 0), p_total),
          p_total,
          least(greatest(coalesce(p_stars, 1), 1), 3),
          least(greatest(coalesce(p_points, 0), 0), p_total * 20 + 30),
          least(greatest(coalesce(p_seconds, 0), 0), 3600));
  return public.math_state(p_profile);
end $$;

revoke all on function public.math_state(uuid) from public, anon;
revoke all on function public.math_finish(uuid, text, text, int, int, int, int, int) from public, anon;
grant execute on function public.math_state(uuid) to authenticated;
grant execute on function public.math_finish(uuid, text, text, int, int, int, int, int) to authenticated;

-- ---------------------------------------------------------------- prophets stories (same section)
alter table public.bedtime_stories drop constraint if exists bedtime_stories_kind_check;
alter table public.bedtime_stories add constraint bedtime_stories_kind_check
  check (kind in ('value', 'hadith', 'prophet'));

-- ---------------------------------------------------------------- display name
-- The child's name is shown as "Yassin" (only the shown name; ids and progress stay the same).
update public.profiles set display_name = 'Yassin'
 where kind = 'child' and lower(btrim(display_name)) in ('yasen', 'yaseen', 'yassen', 'yasin', 'ياسين', 'يسين');
