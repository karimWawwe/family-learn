-- ============================================================================
--  Family Learn - Speaking game ("Say it!")
--   speak_levels -> speak_words      (content: words from the school books)
--   speak_attempts, speak_plays      (each child's own progress)
--
--  Needs Phases 3-4. Safe to run again: content is replaced, progress is kept.
--  Rules enforced here:
--   * a child's phone reads and writes only its own profile's game progress;
--   * the parent account can see every profile in the family;
--   * a level opens only after the previous level of the same track is finished;
--   * points per play are capped (the app cannot send huge numbers).
-- ============================================================================

create table if not exists public.speak_levels (
  id          text primary key,
  track       text not null check (track in ('young', 'older', 'adult')),
  sort        int  not null,
  title       text not null,
  title_ar    text not null default '',
  emoji       text not null default '⭐',
  strictness  numeric(3,2) not null default 0.75 check (strictness between 0.5 and 0.98),
  source      text not null default '',
  published   boolean not null default true
);

create table if not exists public.speak_words (
  id          bigint generated always as identity primary key,
  level_id    text not null references public.speak_levels (id) on delete cascade,
  sort        int  not null,
  text        text not null check (char_length(btrim(text)) between 1 and 80),
  emoji       text not null default '',
  meaning_ar  text not null default '',
  hint        text not null default '',
  accept      text[] not null default '{}'
);
create index if not exists speak_words_level on public.speak_words (level_id, sort);

create table if not exists public.speak_attempts (
  id          bigint generated always as identity primary key,
  profile_id  uuid not null references public.profiles (id) on delete cascade,
  level_id    text not null,
  word        text not null,
  heard       text not null default '',
  score       numeric(4,3) not null default 0,
  result      text not null check (result in ('correct', 'close', 'wrong', 'unclear')),
  try_no      int  not null default 1,
  created_at  timestamptz not null default now()
);
create index if not exists speak_attempts_profile on public.speak_attempts (profile_id, created_at desc);

create table if not exists public.speak_plays (
  id          bigint generated always as identity primary key,
  profile_id  uuid not null references public.profiles (id) on delete cascade,
  level_id    text not null references public.speak_levels (id) on delete cascade,
  points      int  not null check (points >= 0),
  stars       int  not null check (stars between 1 and 3),
  words       int  not null,
  first_try   int  not null,
  attempts    int  not null,
  created_at  timestamptz not null default now()
);
create index if not exists speak_plays_profile on public.speak_plays (profile_id, created_at desc);

-- Nothing is readable or writable directly; the app uses the functions below.
alter table public.speak_levels   enable row level security;
alter table public.speak_words    enable row level security;
alter table public.speak_attempts enable row level security;
alter table public.speak_plays    enable row level security;
revoke all on public.speak_levels, public.speak_words, public.speak_attempts, public.speak_plays from anon, authenticated;

-- ---------------------------------------------------------------- helpers
create or replace function app.speak_track(p_profile uuid) returns text
language sql stable security definer set search_path = '' as $$
  select case when p.kind <> 'child' then 'adult'
              when coalesce(p.grade, 3) <= 4 then 'young'
              else 'older' end
    from public.profiles p where p.id = p_profile
$$;

create or replace function app.speak_level_unlocked(p_profile uuid, p_level text) returns boolean
language sql stable security definer set search_path = '' as $$
  with me as (select * from public.speak_levels where id = p_level and published),
       prev as (
         select l.id from public.speak_levels l, me
          where l.track = me.track and l.published and l.sort < me.sort
          order by l.sort desc limit 1)
  select exists (select 1 from me)
     and (not exists (select 1 from prev)
          or exists (select 1 from public.speak_plays sp, prev
                      where sp.profile_id = p_profile and sp.level_id = prev.id))
$$;

revoke all on function app.speak_track(uuid) from public, anon;
revoke all on function app.speak_level_unlocked(uuid, text) from public, anon;
grant execute on function app.speak_track(uuid) to authenticated;
grant execute on function app.speak_level_unlocked(uuid, text) to authenticated;

-- ---------------------------------------------------------------- API (RPC)

-- Levels (with words) for the profile's track, its progress and totals.
create or replace function public.speak_game_state(p_profile uuid) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  v_track text;
  tz      text;
  today   date;
  v_levels jsonb;
  v_streak int := 0;
  d       date;
begin
  perform app.require_profile(p_profile);
  v_track := app.speak_track(p_profile);
  tz := app.profile_tz(p_profile);
  today := (now() at time zone tz)::date;

  select coalesce(jsonb_agg(x.j order by x.sort), '[]'::jsonb) into v_levels
    from (
      select l.sort, jsonb_build_object(
               'id', l.id, 'title', l.title, 'title_ar', l.title_ar, 'emoji', l.emoji,
               'strictness', l.strictness, 'source', l.source,
               'best_stars', coalesce((select max(stars) from public.speak_plays sp
                                        where sp.profile_id = p_profile and sp.level_id = l.id), 0),
               'plays', (select count(*) from public.speak_plays sp
                          where sp.profile_id = p_profile and sp.level_id = l.id),
               'unlocked', app.speak_level_unlocked(p_profile, l.id),
               'words', (select coalesce(jsonb_agg(jsonb_build_object(
                                  'text', w.text, 'emoji', w.emoji, 'meaning_ar', w.meaning_ar,
                                  'hint', w.hint, 'accept', to_jsonb(w.accept)) order by w.sort), '[]'::jsonb)
                           from public.speak_words w where w.level_id = l.id)) j
        from public.speak_levels l
       where l.track = v_track and l.published) x;

  -- days in a row with a finished level, ending today or yesterday
  select max((created_at at time zone tz)::date) into d from public.speak_plays where profile_id = p_profile;
  if d is not null and d >= today - 1 then
    while exists (select 1 from public.speak_plays where profile_id = p_profile
                   and (created_at at time zone tz)::date = d) loop
      v_streak := v_streak + 1;
      d := d - 1;
    end loop;
  end if;

  return jsonb_build_object(
    'track', v_track,
    'levels', v_levels,
    'points', (select coalesce(sum(points), 0) from public.speak_plays where profile_id = p_profile),
    'points_today', (select coalesce(sum(points), 0) from public.speak_plays
                      where profile_id = p_profile and (created_at at time zone tz)::date = today),
    'words_mastered', (select count(distinct lower(word)) from public.speak_attempts
                        where profile_id = p_profile and result = 'correct'),
    'day_streak', v_streak,
    'last_played', (select max(created_at) from public.speak_plays where profile_id = p_profile),
    'tricky', (select coalesce(jsonb_agg(jsonb_build_object('word', t.word, 'misses', t.n) order by t.n desc), '[]'::jsonb)
                 from (select word, count(*) n from public.speak_attempts
                        where profile_id = p_profile and result in ('close', 'wrong')
                          and created_at > now() - interval '14 days'
                        group by word order by count(*) desc limit 6) t));
end $$;

-- One try on one word (unclear tries are logged too, for the parent).
create or replace function public.speak_record_attempt(
  p_profile uuid, p_level text, p_word text, p_heard text, p_score numeric, p_result text, p_try int
) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform app.require_profile(p_profile);
  if not exists (select 1 from public.speak_words where level_id = p_level and text = p_word) then
    perform app.fail('not_found');
  end if;
  if p_result not in ('correct', 'close', 'wrong', 'unclear') then perform app.fail('unknown'); end if;
  -- simple flood guard: at most 40 tries a minute per profile
  if (select count(*) from public.speak_attempts
       where profile_id = p_profile and created_at > now() - interval '1 minute') >= 40 then
    perform app.fail('rate_limited');
  end if;
  insert into public.speak_attempts (profile_id, level_id, word, heard, score, result, try_no)
  values (p_profile, p_level, p_word, left(coalesce(p_heard, ''), 200),
          least(greatest(coalesce(p_score, 0), 0), 1), p_result, greatest(coalesce(p_try, 1), 1));
end $$;

-- A level played to the end. Returns the new state.
create or replace function public.speak_finish_level(
  p_profile uuid, p_level text, p_points int, p_stars int, p_words int, p_first_try int, p_attempts int
) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_words int;
begin
  perform app.require_profile(p_profile);
  if not exists (select 1 from public.speak_levels
                  where id = p_level and published and track = app.speak_track(p_profile)) then
    perform app.fail('not_found');
  end if;
  if not app.speak_level_unlocked(p_profile, p_level) then perform app.fail('lesson_locked'); end if;
  select count(*) into v_words from public.speak_words where level_id = p_level;
  insert into public.speak_plays (profile_id, level_id, points, stars, words, first_try, attempts)
  values (p_profile, p_level,
          least(greatest(coalesce(p_points, 0), 0), v_words * 30 + 50),
          least(greatest(coalesce(p_stars, 1), 1), 3),
          v_words,
          least(greatest(coalesce(p_first_try, 0), 0), v_words),
          greatest(coalesce(p_attempts, 0), 0));
  return public.speak_game_state(p_profile);
end $$;

revoke all on function public.speak_game_state(uuid) from public, anon;
revoke all on function public.speak_record_attempt(uuid, text, text, text, numeric, text, int) from public, anon;
revoke all on function public.speak_finish_level(uuid, text, int, int, int, int, int) from public, anon;
grant execute on function public.speak_game_state(uuid) to authenticated;
grant execute on function public.speak_record_attempt(uuid, text, text, text, numeric, text, int) to authenticated;
grant execute on function public.speak_finish_level(uuid, text, int, int, int, int, int) to authenticated;

-- ---------------------------------------------------------------- content
-- Replaced on every run (progress rows keep their level ids).
