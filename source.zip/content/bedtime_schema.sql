-- ============================================================================
--  Family Learn - "حكاية قبل النوم" (bedtime stories) + "لوحة متابعة الوالدين"
--   bedtime_stories                    (content)
--   bedtime_listens, bedtime_favorites (each child's own progress)
--   parent_follow()                    (parent report from the REAL tables:
--                                       lessons, speaking game, stories)
--
--  Needs Phases 3-4 and the speaking-game SQL (20260930000006).
--  Safe to run again: stories are replaced, progress is kept.
--  Rules enforced here:
--   * a child's phone reads and writes only its own stories progress;
--   * only the parent account can open the follow report;
--   * every number in the report is computed from saved activity.
-- ============================================================================

create table if not exists public.bedtime_stories (
  id          text primary key,
  sort        int  not null,
  title       text not null,
  emoji       text not null default '🌙',
  value_code  text not null,
  value_name  text not null,
  kind        text not null default 'value' check (kind in ('value', 'hadith')),
  minutes     int  not null default 4,
  source      text not null default '',
  min_grade   int  not null default 1,
  max_grade   int  not null default 12,
  pages       jsonb not null,
  question    jsonb not null,
  activity    text not null default '',
  published   boolean not null default true
);

create table if not exists public.bedtime_listens (
  id           uuid primary key default gen_random_uuid(),
  profile_id   uuid not null references public.profiles (id) on delete cascade,
  story_id     text not null references public.bedtime_stories (id) on delete cascade,
  started_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  last_page    int  not null default 0,
  seconds      int  not null default 0 check (seconds between 0 and 7200),
  completed_at timestamptz,
  answer_correct boolean
);
create index if not exists bedtime_listens_profile on public.bedtime_listens (profile_id, updated_at desc);

create table if not exists public.bedtime_favorites (
  profile_id  uuid not null references public.profiles (id) on delete cascade,
  story_id    text not null references public.bedtime_stories (id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (profile_id, story_id)
);

alter table public.bedtime_stories   enable row level security;
alter table public.bedtime_listens   enable row level security;
alter table public.bedtime_favorites enable row level security;
revoke all on public.bedtime_stories, public.bedtime_listens, public.bedtime_favorites from anon, authenticated;

-- ---------------------------------------------------------------- helpers
create or replace function app.bedtime_fits(p_profile uuid, s public.bedtime_stories) returns boolean
language sql stable security definer set search_path = '' as $$
  select s.published and exists (
    select 1 from public.profiles p where p.id = p_profile
       and (p.kind <> 'child' or coalesce(p.grade, 3) between s.min_grade and s.max_grade))
$$;

create or replace function app.listen_owner_ok(p_listen uuid) returns uuid
language plpgsql stable security definer set search_path = '' as $$
declare v uuid;
begin
  select profile_id into v from public.bedtime_listens where id = p_listen;
  if v is null or not app.can_use_profile(v) then perform app.fail('not_found'); end if;
  return v;
end $$;

revoke all on function app.bedtime_fits(uuid, public.bedtime_stories) from public, anon;
revoke all on function app.listen_owner_ok(uuid) from public, anon;
grant execute on function app.bedtime_fits(uuid, public.bedtime_stories) to authenticated;
grant execute on function app.listen_owner_ok(uuid) to authenticated;

-- ---------------------------------------------------------------- stories API

-- Stories for the profile, with its favourites, completions and last story.
create or replace function public.bedtime_state(p_profile uuid) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
begin
  perform app.require_profile(p_profile);
  return jsonb_build_object(
    'stories', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'id', s.id, 'title', s.title, 'emoji', s.emoji, 'value_code', s.value_code,
               'value_name', s.value_name, 'kind', s.kind, 'minutes', s.minutes, 'source', s.source,
               'pages', s.pages, 'question', s.question, 'activity', s.activity,
               'favorite', exists (select 1 from public.bedtime_favorites f
                                    where f.profile_id = p_profile and f.story_id = s.id),
               'completed', (select count(*) from public.bedtime_listens l
                              where l.profile_id = p_profile and l.story_id = s.id and l.completed_at is not null),
               'listened', (select count(*) from public.bedtime_listens l
                             where l.profile_id = p_profile and l.story_id = s.id))
             order by s.sort), '[]'::jsonb)
        from public.bedtime_stories s where app.bedtime_fits(p_profile, s)),
    'last', (
      select jsonb_build_object('story_id', l.story_id, 'page', l.last_page,
                                'completed', l.completed_at is not null, 'at', l.updated_at)
        from public.bedtime_listens l where l.profile_id = p_profile
       order by l.updated_at desc limit 1));
end $$;

-- Opens a listen. Re-opening an unfinished story within 12 hours continues it.
create or replace function public.bedtime_start(p_profile uuid, p_story text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_id uuid;
  v_page int := 0;
  s public.bedtime_stories;
begin
  perform app.require_profile(p_profile);
  select * into s from public.bedtime_stories where id = p_story;
  if s.id is null or not app.bedtime_fits(p_profile, s) then perform app.fail('not_found'); end if;
  select id, last_page into v_id, v_page from public.bedtime_listens
   where profile_id = p_profile and story_id = p_story and completed_at is null
     and updated_at > now() - interval '12 hours'
   order by updated_at desc limit 1;
  if v_id is null then
    insert into public.bedtime_listens (profile_id, story_id) values (p_profile, p_story)
    returning id into v_id;
    v_page := 0;
  else
    update public.bedtime_listens set updated_at = now() where id = v_id;
  end if;
  return jsonb_build_object('listen_id', v_id, 'page', v_page);
end $$;

-- Page reached + seconds spent so far (never goes down).
create or replace function public.bedtime_progress(p_listen uuid, p_page int, p_seconds int) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform app.listen_owner_ok(p_listen);
  update public.bedtime_listens
     set last_page = greatest(0, least(coalesce(p_page, 0), 50)),
         seconds = greatest(seconds, least(greatest(coalesce(p_seconds, 0), 0), 7200)),
         updated_at = now()
   where id = p_listen;
end $$;

-- Story finished (the end screen was reached). The answer is optional.
create or replace function public.bedtime_complete(p_listen uuid, p_seconds int, p_answer_correct boolean) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform app.listen_owner_ok(p_listen);
  update public.bedtime_listens
     set completed_at = coalesce(completed_at, now()),
         seconds = greatest(seconds, least(greatest(coalesce(p_seconds, 0), 0), 7200)),
         answer_correct = coalesce(p_answer_correct, answer_correct),
         updated_at = now()
   where id = p_listen;
end $$;

create or replace function public.bedtime_favorite(p_profile uuid, p_story text, p_on boolean) returns boolean
language plpgsql security definer set search_path = '' as $$
begin
  perform app.require_profile(p_profile);
  if not exists (select 1 from public.bedtime_stories where id = p_story) then perform app.fail('not_found'); end if;
  if p_on then
    insert into public.bedtime_favorites (profile_id, story_id) values (p_profile, p_story) on conflict do nothing;
  else
    delete from public.bedtime_favorites where profile_id = p_profile and story_id = p_story;
  end if;
  return p_on;
end $$;

-- ---------------------------------------------------------------- follow report helpers

-- Speaking-game minutes per day, estimated from the saved tries:
-- time to the next try (max 60 s), 20 s for the last try of a session.
create or replace function app.speak_minutes(p_profile uuid, d1 date, d2 date, tz text) returns numeric
language sql stable security definer set search_path = '' as $$
  select coalesce(sum(case when nxt is null or nxt - created_at > interval '5 minutes' then 20
                           else least(extract(epoch from (nxt - created_at)), 60) end), 0) / 60.0
    from (select created_at, lead(created_at) over (order by created_at) nxt
            from public.speak_attempts where profile_id = p_profile) a
   where (created_at at time zone tz)::date between d1 and d2
$$;

-- Days (in the family time zone) with any saved activity.
create or replace function app.active_days(p_profile uuid, d1 date, d2 date, tz text) returns setof date
language sql stable security definer set search_path = '' as $$
  select distinct d from (
    select (started_at at time zone tz)::date d from public.lesson_attempts where profile_id = p_profile
    union all
    select (created_at at time zone tz)::date from public.speak_attempts where profile_id = p_profile
    union all
    select (started_at at time zone tz)::date from public.bedtime_listens where profile_id = p_profile
  ) x where d between d1 and d2
$$;

-- All figures for one date range.
create or replace function app.follow_range(p_profile uuid, d1 date, d2 date, tz text) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  v_lesson numeric; v_story numeric; v_speak numeric;
  r jsonb;
begin
  select coalesce(sum(app.attempt_minutes(a)), 0) into v_lesson
    from public.lesson_attempts a
   where a.profile_id = p_profile and a.finished_at is not null
     and (a.finished_at at time zone tz)::date between d1 and d2;
  select coalesce(sum(seconds), 0) / 60.0 into v_story
    from public.bedtime_listens where profile_id = p_profile
     and (started_at at time zone tz)::date between d1 and d2;
  v_speak := app.speak_minutes(p_profile, d1, d2, tz);

  select jsonb_build_object(
    'from', d1, 'to', d2,
    'minutes_lessons', round(v_lesson),
    'minutes_stories', round(v_story),
    'minutes_speaking', round(v_speak),
    'minutes_total', ceil(v_lesson + v_story + v_speak),
    'days_used', (select count(*) from app.active_days(p_profile, d1, d2, tz)),
    'stories_listened', (select count(*) from public.bedtime_listens
                          where profile_id = p_profile and (started_at at time zone tz)::date between d1 and d2),
    'stories_completed', (select count(*) from public.bedtime_listens
                           where profile_id = p_profile and completed_at is not null
                             and (completed_at at time zone tz)::date between d1 and d2),
    'values', (select coalesce(jsonb_agg(distinct s.value_name), '[]'::jsonb)
                 from public.bedtime_listens l join public.bedtime_stories s on s.id = l.story_id
                where l.profile_id = p_profile and l.completed_at is not null
                  and (l.completed_at at time zone tz)::date between d1 and d2),
    'lessons_done', (select count(*) from public.lesson_attempts
                      where profile_id = p_profile and finished_at is not null
                        and (finished_at at time zone tz)::date between d1 and d2),
    'questions', (select count(*) from public.answers an join public.lesson_attempts a on a.id = an.attempt_id
                   where a.profile_id = p_profile and (an.answered_at at time zone tz)::date between d1 and d2),
    'correct', (select count(*) filter (where an.is_correct) from public.answers an
                  join public.lesson_attempts a on a.id = an.attempt_id
                 where a.profile_id = p_profile and (an.answered_at at time zone tz)::date between d1 and d2),
    'speak_words', (select count(distinct lower(word)) from public.speak_attempts
                     where profile_id = p_profile and result = 'correct'
                       and (created_at at time zone tz)::date between d1 and d2),
    'speak_levels', (select count(*) from public.speak_plays
                      where profile_id = p_profile and (created_at at time zone tz)::date between d1 and d2),
    'speak_points', (select coalesce(sum(points), 0) from public.speak_plays
                      where profile_id = p_profile and (created_at at time zone tz)::date between d1 and d2)
  ) into r;
  return r;
end $$;

revoke all on function app.speak_minutes(uuid, date, date, text) from public, anon;
revoke all on function app.active_days(uuid, date, date, text) from public, anon;
revoke all on function app.follow_range(uuid, date, date, text) from public, anon;
grant execute on function app.speak_minutes(uuid, date, date, text) to authenticated;
grant execute on function app.active_days(uuid, date, date, text) to authenticated;
grant execute on function app.follow_range(uuid, date, date, text) to authenticated;

-- ---------------------------------------------------------------- follow report (parent only)
-- p_period: day (today vs yesterday) | week (last 7 days vs the 7 before)
--           | month (last 30 days vs the 30 before)
create or replace function public.parent_follow(p_profile uuid, p_period text) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  tz    text;
  today date;
  n     int;
  v_xp  int;
  v_speak_pts int;
  v_stories_done int;
  v_top text;
  r     jsonb;
begin
  if not app.i_am_parent() then perform app.fail('parent_only'); end if;
  perform app.require_profile(p_profile);
  tz := app.profile_tz(p_profile);
  today := (now() at time zone tz)::date;
  n := case p_period when 'day' then 1 when 'month' then 30 else 7 end;

  select coalesce(sum(xp), 0) into v_xp from public.lesson_attempts
   where profile_id = p_profile and finished_at is not null;
  select coalesce(sum(points), 0) into v_speak_pts from public.speak_plays where profile_id = p_profile;
  select count(*) into v_stories_done from public.bedtime_listens
   where profile_id = p_profile and completed_at is not null;
  select s.value_name into v_top
    from public.bedtime_listens l join public.bedtime_stories s on s.id = l.story_id
   where l.profile_id = p_profile and l.completed_at is not null
   group by s.value_name order by count(*) desc, max(l.completed_at) desc limit 1;

  r := jsonb_build_object(
    'period', case n when 1 then 'day' when 30 then 'month' else 'week' end,
    'today', today,
    'current', app.follow_range(p_profile, today - (n - 1), today, tz),
    'previous', app.follow_range(p_profile, today - (2 * n - 1), today - n, tz),
    'by_day', (
      select jsonb_agg(jsonb_build_object(
               'day', d,
               'minutes', ceil(
                   coalesce((select sum(app.attempt_minutes(a)) from public.lesson_attempts a
                              where a.profile_id = p_profile and a.finished_at is not null
                                and (a.finished_at at time zone tz)::date = d), 0)
                 + coalesce((select sum(seconds) / 60.0 from public.bedtime_listens
                              where profile_id = p_profile and (started_at at time zone tz)::date = d), 0)
                 + app.speak_minutes(p_profile, d, d, tz))) order by d)
        from generate_series(today - (greatest(n, 7) - 1), today, interval '1 day') g(dd),
             lateral (select g.dd::date d) x),
    'totals', jsonb_build_object(
      'minutes', (app.follow_range(p_profile, '2000-01-01'::date, today, tz) ->> 'minutes_total')::int,
      'days', (select count(*) from app.active_days(p_profile, '2000-01-01'::date, today, tz)),
      'stories_listened', (select count(*) from public.bedtime_listens where profile_id = p_profile),
      'stories_completed', v_stories_done,
      'distinct_stories', (select count(distinct story_id) from public.bedtime_listens
                            where profile_id = p_profile and completed_at is not null),
      'lessons_done', (select count(distinct lesson_id) from public.lesson_attempts
                        where profile_id = p_profile and finished_at is not null),
      'speak_words', (select count(distinct lower(word)) from public.speak_attempts
                       where profile_id = p_profile and result = 'correct'),
      'speak_levels_done', (select count(distinct level_id) from public.speak_plays where profile_id = p_profile)),
    'progress', jsonb_build_object(
      'points', v_xp + v_speak_pts + 20 * v_stories_done,
      'lesson_xp', v_xp, 'speak_points', v_speak_pts, 'story_points', 20 * v_stories_done,
      'level', 1 + (v_xp + v_speak_pts + 20 * v_stories_done) / 500,
      'into_level', (v_xp + v_speak_pts + 20 * v_stories_done) % 500),
    'last_story', (
      select jsonb_build_object('id', s.id, 'title', s.title, 'emoji', s.emoji, 'value', s.value_name,
                                'completed', l.completed_at is not null, 'at', l.updated_at)
        from public.bedtime_listens l join public.bedtime_stories s on s.id = l.story_id
       where l.profile_id = p_profile order by l.updated_at desc limit 1),
    'favorites', (
      select coalesce(jsonb_agg(jsonb_build_object('id', s.id, 'title', s.title, 'emoji', s.emoji)
                                order by f.created_at desc), '[]'::jsonb)
        from public.bedtime_favorites f join public.bedtime_stories s on s.id = f.story_id
       where f.profile_id = p_profile),
    'values_all', (
      select coalesce(jsonb_agg(jsonb_build_object('value', v.value_name, 'count', v.n) order by v.n desc), '[]'::jsonb)
        from (select s.value_name, count(*) n
                from public.bedtime_listens l join public.bedtime_stories s on s.id = l.story_id
               where l.profile_id = p_profile and l.completed_at is not null
               group by s.value_name) v),
    'top_value', v_top,
    'last_activity', (
      select jsonb_build_object('kind', x.kind, 'title', x.title, 'at', x.at)
        from (
          select 'lesson' kind, le.title, a.finished_at at
            from public.lesson_attempts a join public.lessons le on le.id = a.lesson_id
           where a.profile_id = p_profile and a.finished_at is not null
          union all
          select 'speak', sl.title, sa.created_at
            from public.speak_attempts sa join public.speak_levels sl on sl.id = sa.level_id
           where sa.profile_id = p_profile
          union all
          select 'story', s.title, coalesce(l.completed_at, l.updated_at)
            from public.bedtime_listens l join public.bedtime_stories s on s.id = l.story_id
           where l.profile_id = p_profile
        ) x order by x.at desc limit 1),
    -- a story to suggest: not finished yet; same value as the favourite theme first,
    -- then a value the child has not met yet, then any unfinished story.
    'suggestion', (
      select jsonb_build_object('id', s.id, 'title', s.title, 'emoji', s.emoji, 'value', s.value_name)
        from public.bedtime_stories s
       where app.bedtime_fits(p_profile, s)
         and not exists (select 1 from public.bedtime_listens l
                          where l.profile_id = p_profile and l.story_id = s.id and l.completed_at is not null)
       order by (s.value_name = v_top) desc nulls last,
                exists (select 1 from public.bedtime_listens l2 join public.bedtime_stories s2 on s2.id = l2.story_id
                         where l2.profile_id = p_profile and l2.completed_at is not null
                           and s2.value_name = s.value_name),
                s.sort
       limit 1),
    'tricky_words', (
      select coalesce(jsonb_agg(t.word), '[]'::jsonb)
        from (select word from public.speak_attempts
               where profile_id = p_profile and result in ('close', 'wrong')
                 and created_at > now() - interval '14 days'
               group by word order by count(*) desc limit 3) t),
    'weak_skills', (
      select coalesce(jsonb_agg(w.name), '[]'::jsonb)
        from (select sk.name
                from public.answers an
                join public.lesson_attempts a on a.id = an.attempt_id
                join public.questions q on q.id = an.question_id
                join public.skills sk on sk.code = q.skill
               where a.profile_id = p_profile and an.answered_at > now() - interval '30 days'
               group by sk.name
              having count(*) >= 3 and avg(case when an.is_correct then 1.0 else 0 end) < 0.6
               order by avg(case when an.is_correct then 1.0 else 0 end) limit 2) w)
  );
  return r;
end $$;

revoke all on function public.bedtime_state(uuid) from public, anon;
revoke all on function public.bedtime_start(uuid, text) from public, anon;
revoke all on function public.bedtime_progress(uuid, int, int) from public, anon;
revoke all on function public.bedtime_complete(uuid, int, boolean) from public, anon;
revoke all on function public.bedtime_favorite(uuid, text, boolean) from public, anon;
revoke all on function public.parent_follow(uuid, text) from public, anon;
grant execute on function public.bedtime_state(uuid) to authenticated;
grant execute on function public.bedtime_start(uuid, text) to authenticated;
grant execute on function public.bedtime_progress(uuid, int, int) to authenticated;
grant execute on function public.bedtime_complete(uuid, int, boolean) to authenticated;
grant execute on function public.bedtime_favorite(uuid, text, boolean) to authenticated;
grant execute on function public.parent_follow(uuid, text) to authenticated;

-- ---------------------------------------------------------------- content
-- Replaced on every run (progress rows keep their story ids).
