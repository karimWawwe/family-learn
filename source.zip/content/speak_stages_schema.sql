-- ============================================================================
--  Family Learn - Speaking game: STAGES
--   * many more stages, easy -> hard (content at the end of this file);
--   * a stage opens when the stage before it is finished AND the child has
--     collected enough stars in total (required_stars);
--   * once a stage is open it stays open (speak_unlocks), it is never locked again;
--   * every stage can be replayed; the BEST stars and BEST points of each stage count.
--
--  Needs 20260930000006_speak_game.sql. Safe to run again: progress is kept.
-- ============================================================================

alter table public.speak_levels add column if not exists required_stars int not null default 0;

-- Stages already open for each child are remembered here.
do $$
begin
  if to_regclass('public.speak_unlocks') is null then
    create table public.speak_unlocks (
      profile_id  uuid not null references public.profiles (id) on delete cascade,
      level_id    text not null references public.speak_levels (id) on delete cascade,
      unlocked_at timestamptz not null default now(),
      primary key (profile_id, level_id)
    );
    alter table public.speak_unlocks enable row level security;
    revoke all on public.speak_unlocks from anon, authenticated;

    -- First install only: keep every stage that was already open under the old
    -- rule (played stages, the stage right after each played one, and the first).
    insert into public.speak_unlocks (profile_id, level_id)
    select distinct x.profile_id, x.level_id from (
      select sp.profile_id, sp.level_id from public.speak_plays sp
      union
      select sp.profile_id, nxt.id
        from public.speak_plays sp
        join public.speak_levels cur on cur.id = sp.level_id
        join lateral (select l.id from public.speak_levels l
                       where l.track = cur.track and l.published and l.sort > cur.sort
                       order by l.sort limit 1) nxt on true
    ) x
    on conflict do nothing;
  end if;
end $$;

-- ---------------------------------------------------------------- helpers
-- Stars of a profile in its track: the best result of every published stage.
create or replace function app.speak_total_stars(p_profile uuid) returns int
language sql stable security definer set search_path = '' as $$
  select coalesce(sum(b.best), 0)::int
    from (select max(sp.stars) best
            from public.speak_plays sp
            join public.speak_levels l on l.id = sp.level_id
           where sp.profile_id = p_profile and l.published and l.track = app.speak_track(p_profile)
           group by sp.level_id) b
$$;

-- Points: the best result of every stage (replaying can only improve it).
create or replace function app.speak_best_points(p_profile uuid) returns int
language sql stable security definer set search_path = '' as $$
  select coalesce(sum(b.best), 0)::int
    from (select max(points) best from public.speak_plays
           where profile_id = p_profile group by level_id) b
$$;

create or replace function app.speak_level_unlocked(p_profile uuid, p_level text) returns boolean
language sql stable security definer set search_path = '' as $$
  with me as (select * from public.speak_levels where id = p_level and published),
       prev as (
         select l.id from public.speak_levels l, me
          where l.track = me.track and l.published and l.sort < me.sort
          order by l.sort desc limit 1)
  select exists (select 1 from me)
     and (
       exists (select 1 from public.speak_unlocks u where u.profile_id = p_profile and u.level_id = p_level)
       or (
         (not exists (select 1 from prev)
          or exists (select 1 from public.speak_plays sp, prev
                      where sp.profile_id = p_profile and sp.level_id = prev.id))
         and app.speak_total_stars(p_profile) >= (select required_stars from me)))
$$;

revoke all on function app.speak_total_stars(uuid) from public, anon;
revoke all on function app.speak_best_points(uuid) from public, anon;
grant execute on function app.speak_total_stars(uuid) to authenticated;
grant execute on function app.speak_best_points(uuid) to authenticated;

-- ---------------------------------------------------------------- API (RPC)

-- Stages (with words) of the profile's track: best stars/points, plays, open or not,
-- stars needed; totals. Newly opened stages are remembered so they stay open.
create or replace function public.speak_game_state(p_profile uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare
  v_track text;
  tz      text;
  today   date;
  v_levels jsonb;
  v_streak int := 0;
  v_stars int;
  d       date;
begin
  perform app.require_profile(p_profile);
  v_track := app.speak_track(p_profile);
  tz := app.profile_tz(p_profile);
  today := (now() at time zone tz)::date;
  v_stars := app.speak_total_stars(p_profile);

  -- remember every stage that is open now (it will never be locked again)
  insert into public.speak_unlocks (profile_id, level_id)
  select p_profile, l.id from public.speak_levels l
   where l.track = v_track and l.published and app.speak_level_unlocked(p_profile, l.id)
  on conflict do nothing;

  select coalesce(jsonb_agg(x.j order by x.sort), '[]'::jsonb) into v_levels
    from (
      select l.sort, jsonb_build_object(
               'id', l.id, 'title', l.title, 'title_ar', l.title_ar, 'emoji', l.emoji,
               'strictness', l.strictness, 'source', l.source, 'required_stars', l.required_stars,
               'best_stars', coalesce((select max(stars) from public.speak_plays sp
                                        where sp.profile_id = p_profile and sp.level_id = l.id), 0),
               'best_points', coalesce((select max(points) from public.speak_plays sp
                                         where sp.profile_id = p_profile and sp.level_id = l.id), 0),
               'plays', (select count(*) from public.speak_plays sp
                          where sp.profile_id = p_profile and sp.level_id = l.id),
               'unlocked', exists (select 1 from public.speak_unlocks u
                                    where u.profile_id = p_profile and u.level_id = l.id),
               'words', (select coalesce(jsonb_agg(jsonb_build_object(
                                  'text', w.text, 'emoji', w.emoji, 'meaning_ar', w.meaning_ar,
                                  'hint', w.hint, 'accept', to_jsonb(w.accept)) order by w.sort), '[]'::jsonb)
                           from public.speak_words w where w.level_id = l.id)) j
        from public.speak_levels l
       where l.track = v_track and l.published) x;

  select max((created_at at time zone tz)::date) into d from public.speak_plays where profile_id = p_profile;
  if d is not null and d >= today - 1 then
    while exists (select 1 from public.speak_plays where profile_id = p_profile
                   and (created_at at time zone tz)::date = d) loop
      v_streak := v_streak + 1;
      d := d - 1;
    end loop;
  end if;

  return jsonb_build_object(
    'track', v_track,
    'levels', v_levels,
    'stars', v_stars,
    'points', app.speak_best_points(p_profile),
    'points_today', (select coalesce(sum(points), 0) from public.speak_plays
                      where profile_id = p_profile and (created_at at time zone tz)::date = today),
    'words_mastered', (select count(distinct lower(word)) from public.speak_attempts
                        where profile_id = p_profile and result = 'correct'),
    'day_streak', v_streak,
    'last_played', (select max(created_at) from public.speak_plays where profile_id = p_profile),
    'tricky', (select coalesce(jsonb_agg(jsonb_build_object('word', t.word, 'misses', t.n) order by t.n desc), '[]'::jsonb)
                 from (select word, count(*) n from public.speak_attempts
                        where profile_id = p_profile and result in ('close', 'wrong')
                          and created_at > now() - interval '14 days'
                        group by word order by count(*) desc limit 6) t));
end $$;

-- A stage played to the end (first time or a replay). Returns the new state.
create or replace function public.speak_finish_level(
  p_profile uuid, p_level text, p_points int, p_stars int, p_words int, p_first_try int, p_attempts int
) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_words int;
begin
  perform app.require_profile(p_profile);
  if not exists (select 1 from public.speak_levels
                  where id = p_level and published and track = app.speak_track(p_profile)) then
    perform app.fail('not_found');
  end if;
  if not app.speak_level_unlocked(p_profile, p_level) then perform app.fail('lesson_locked'); end if;
  select count(*) into v_words from public.speak_words where level_id = p_level;
  insert into public.speak_plays (profile_id, level_id, points, stars, words, first_try, attempts)
  values (p_profile, p_level,
          least(greatest(coalesce(p_points, 0), 0), v_words * 30 + 50),
          least(greatest(coalesce(p_stars, 1), 1), 3),
          v_words,
          least(greatest(coalesce(p_first_try, 0), 0), v_words),
          greatest(coalesce(p_attempts, 0), 0));
  return public.speak_game_state(p_profile);
end $$;

revoke all on function public.speak_game_state(uuid) from public, anon;
revoke all on function public.speak_finish_level(uuid, text, int, int, int, int, int) from public, anon;
grant execute on function public.speak_game_state(uuid) to authenticated;
grant execute on function public.speak_finish_level(uuid, text, int, int, int, int, int) to authenticated;
