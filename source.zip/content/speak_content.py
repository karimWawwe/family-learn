# -*- coding: utf-8 -*-
"""
Family Learn - speaking game ("Say it!") word levels.

The words come from the family's school books (see book_content.py):
  young  = English Primary 3 Term 2 + Math Primary 3  (Yassin, grades 1-4)
  older  = English Primary 6 Term 2 + Math Primary 6  (Omar, grade 5+)
  adult  = Everyday English 1                         (Kareem)

Build:  python3 content/build_speak.py
  -> supabase/migrations/20260930000006_speak_game.sql
  -> apps/mobile/lib/data/speak_game/speak_content.g.dart (demo mode + tests)

Word fields:  text, emoji, ar (Arabic meaning), hint (syllables), accept (sound-alikes)
strictness:   minimum pronunciation score for "correct" (0.78 lenient .. 0.95 strict).
              Magic-e uses 0.93 so "cap" is NOT accepted for "cape".
"""


def w(text, emoji="", ar="", hint="", accept=()):
    return {"text": text, "emoji": emoji, "meaning_ar": ar, "hint": hint, "accept": list(accept)}


LEVELS = [
    # ============================================================ young (Yassin)
    {"id": "y1-sounds", "track": "young", "title": "Sounds: st, sl, tr, gr", "title_ar": "أصوات: st, sl, tr, gr",
     "emoji": "🚂", "strictness": 0.8, "source": "English P3 - Unit 1: Sounds sl, st, gr, tr",
     "words": [
         w("stop", "🛑", "قِف"), w("star", "⭐", "نجمة"), w("step", "👣", "خطوة"),
         w("slow", "🐢", "بطيء"), w("sleep", "😴", "ينام"), w("train", "🚆", "قطار"),
         w("truck", "🚚", "شاحنة", accept=["trucks"]), w("green", "🟢", "أخضر"),
     ]},
    {"id": "y2-safety", "track": "young", "title": "Safety", "title_ar": "السلامة",
     "emoji": "⛑️", "strictness": 0.8, "source": "English P3 - Unit 1: Safety",
     "words": [
         w("helmet", "⛑️", "خوذة", "hel-met"), w("careful", "⚠️", "حذِر", "care-ful"),
         w("sign", "🪧", "إشارة", accept=["sine"]), w("stranger", "🧍", "شخص غريب", "stran-ger"),
         w("ambulance", "🚑", "سيارة إسعاف", "am-bu-lance"), w("seat belt", "🚗", "حزام الأمان", "seat - belt", ["seatbelt"]),
         w("dangerous", "⚡", "خطير", "dan-ger-ous"), w("emergency", "🚨", "طوارئ", "e-mer-gen-cy"),
     ]},
    {"id": "y3-food", "track": "young", "title": "Food and health", "title_ar": "الطعام والصحة",
     "emoji": "🍎", "strictness": 0.8, "source": "English P3 - Unit 2: Food and Health",
     "words": [
         w("apple", "🍎", "تفاحة", "ap-ple"), w("milk", "🥛", "حليب"), w("rice", "🍚", "أرز"),
         w("water", "💧", "ماء", "wa-ter"), w("breakfast", "🍳", "الفطور", "break-fast"),
         w("lunch", "🥪", "الغداء"), w("dinner", "🍽️", "العشاء", "din-ner"),
         w("vegetables", "🥦", "خضروات", "veg-e-ta-bles", ["vegetable"]),
     ]},
    {"id": "y4-magic-e", "track": "young", "title": "Magic e: cap or cape?", "title_ar": "حرف e السحري",
     "emoji": "🪄", "strictness": 0.93, "source": "English P3 - Unit 3: Magic e",
     "words": [
         w("cap", "🧢", "قبعة"), w("cape", "🦸", "عباءة", "c-a-pe (a says its name)"),
         w("hop", "🐇", "يقفز"), w("hope", "🙏", "أمل", "h-o-pe (o says its name)"),
         w("kit", "🧰", "عُدّة"), w("kite", "🪁", "طائرة ورقية", "k-i-te (i says its name)"),
         w("cub", "🐻", "شبل / صغير الدب", accept=["cubs"]), w("cube", "🧊", "مكعب", "c-u-be (u says its name)"),
     ]},
    {"id": "y5-heroes", "track": "young", "title": "Heroes around us", "title_ar": "أبطال حولنا",
     "emoji": "🚒", "strictness": 0.8, "source": "English P3 - Unit 3: Heroes Around Us",
     "words": [
         w("firefighter", "👩‍🚒", "رجل إطفاء", "fire-fight-er", ["fire fighter", "firefighters"]),
         w("pilot", "👨‍✈️", "طيار", "pi-lot"), w("teacher", "👩‍🏫", "معلم", "tea-cher"),
         w("chef", "👨‍🍳", "طاهٍ", accept=["shef"]), w("brave", "🦁", "شجاع"),
         w("ladder", "🪜", "سلّم", "lad-der"), w("medal", "🏅", "ميدالية", "med-al", ["metal"]),
         w("uniform", "🦺", "زي موحد", "u-ni-form"),
     ]},
    {"id": "y6-tech", "track": "young", "title": "Technology", "title_ar": "التكنولوجيا",
     "emoji": "🤖", "strictness": 0.8, "source": "English P3 - Unit 4: Living with Technology",
     "words": [
         w("phone", "📱", "هاتف"), w("robot", "🤖", "روبوت", "ro-bot"), w("camera", "📷", "كاميرا", "cam-er-a"),
         w("tablet", "📲", "جهاز لوحي", "tab-let"), w("screen", "🖥️", "شاشة"),
         w("keyboard", "⌨️", "لوحة المفاتيح", "key-board", ["key board"]),
         w("button", "🔘", "زر", "but-ton"), w("password", "🔑", "كلمة المرور", "pass-word", ["pass word"]),
     ]},
    {"id": "y7-animals", "track": "young", "title": "Animals and habitats", "title_ar": "الحيوانات وبيئاتها",
     "emoji": "🐪", "strictness": 0.8, "source": "English P3 - Unit 5: Animals and Habitats",
     "words": [
         w("camel", "🐪", "جمل", "cam-el"), w("monkey", "🐒", "قرد", "mon-key"), w("fish", "🐟", "سمكة"),
         w("owl", "🦉", "بومة"), w("polar bear", "🐻‍❄️", "دب قطبي", "po-lar bear", ["polarbear"]),
         w("feathers", "🪶", "ريش", "feath-ers", ["feather"]), w("fur", "🧸", "فرو", accept=["fir"]),
         w("claws", "🐾", "مخالب", accept=["claw", "clause"]),
     ]},
    {"id": "y8-actions", "track": "young", "title": "I can... (action words)", "title_ar": "أستطيع... (أفعال)",
     "emoji": "🤸", "strictness": 0.8, "source": "English P3 - Unit 5: can / can't",
     "words": [
         w("fly", "🕊️", "يطير"), w("jump", "🦘", "يقفز"), w("crawl", "🐛", "يزحف"),
         w("swim", "🏊", "يسبح"), w("climb", "🧗", "يتسلق", accept=["clime"]), w("run", "🏃", "يجري"),
     ]},
    {"id": "y9-feelings", "track": "young", "title": "Feelings (story)", "title_ar": "المشاعر (القصة)",
     "emoji": "😊", "strictness": 0.8, "source": "English P3 - Unit 6: The Honest Choice",
     "words": [
         w("happy", "😀", "سعيد", "hap-py"), w("angry", "😠", "غاضب", "an-gry"), w("sleepy", "😴", "نعسان", "sleep-y"),
         w("nervous", "😬", "متوتر", "ner-vous"), w("honest", "🤝", "صادق", "hon-est (h is silent)"),
         w("whisper", "🤫", "يهمس", "whis-per"),
     ]},
    {"id": "y10-math", "track": "young", "title": "Math words", "title_ar": "كلمات الرياضيات",
     "emoji": "➗", "strictness": 0.8, "source": "Math P3 - Chapters 1-10",
     "words": [
         w("multiply", "✖️", "يضرب", "mul-ti-ply"), w("divide", "➗", "يقسم", "di-vide"),
         w("hour", "⏰", "ساعة", "our (h is silent)", ["our"]), w("minute", "⏱️", "دقيقة", "min-ute", ["minutes"]),
         w("remainder", "🧮", "الباقي", "re-main-der"),
         w("kilometre", "🛣️", "كيلومتر", "ki-lo-me-tre", ["kilometer", "kilometers", "kilometres"]),
         w("graph", "📊", "رسم بياني", accept=["graf"]),
         w("ten thousand", "🔟", "عشرة آلاف", accept=["10000"]),
     ]},
    {"id": "y11-sentences", "track": "young", "title": "Short sentences", "title_ar": "جمل قصيرة",
     "emoji": "💬", "strictness": 0.8, "source": "English P3 - Units 1, 2, 6",
     "words": [
         w("Be careful", "⚠️", "كن حذراً"), w("Don't run", "🚫🏃", "لا تجرِ", accept=["do not run"]),
         w("Wait here", "✋", "انتظر هنا"), w("I did it myself", "💪", "فعلتها بنفسي"),
         w("I can jump", "🦘", "أستطيع أن أقفز"), w("Always tell the truth", "🤝", "قل الحقيقة دائماً"),
     ]},

    # ============================================================ older (Omar)
    {"id": "o1-art", "track": "older", "title": "Celebrating creativity", "title_ar": "الاحتفاء بالإبداع",
     "emoji": "🎨", "strictness": 0.84, "source": "English P6 - Unit 1: Celebrating Creativity",
     "words": [
         w("canvas", "🖼️", "قماش الرسم", "can-vas", ["canvass"]), w("gallery", "🏛️", "معرض", "gal-le-ry"),
         w("sketch", "✏️", "رسم تخطيطي"), w("mural", "🧱", "لوحة جدارية", "mu-ral"),
         w("palette", "🎨", "لوحة الألوان", "pal-ette", ["pallet"]), w("sculpture", "🗿", "منحوتة", "sculp-ture"),
         w("sculptor", "🧑‍🎨", "نحّات", "sculp-tor"), w("masterpiece", "🌟", "تحفة فنية", "mas-ter-piece", ["master piece"]),
     ]},
    {"id": "o2-inventions", "track": "older", "title": "Wonderful inventions", "title_ar": "اختراعات رائعة",
     "emoji": "💡", "strictness": 0.84, "source": "English P6 - Unit 2: Wonderful Inventions",
     "words": [
         w("gadget", "📟", "أداة / جهاز صغير", "gad-get"), w("fabric", "🧵", "قماش", "fab-ric"),
         w("thread", "🪡", "خيط"), w("blueprint", "📐", "مخطط", "blue-print", ["blue print"]),
         w("accurate", "🎯", "دقيق", "ac-cu-rate"), w("assemble", "🔧", "يُجمِّع", "as-sem-ble"),
         w("rebuild", "🏗️", "يعيد البناء", "re-build", ["re build"]), w("unhappy", "🙁", "غير سعيد", "un-hap-py"),
     ]},
    {"id": "o3-egypt", "track": "older", "title": "Hidden gems of Egypt", "title_ar": "كنوز مصر الخفية",
     "emoji": "🏺", "strictness": 0.84, "source": "English P6 - Unit 3: Hidden Gems of Egypt",
     "words": [
         w("mummy", "🧟", "مومياء", "mum-my"), w("monument", "🗿", "أثر / نُصب", "mon-u-ment"),
         w("chamber", "🚪", "حجرة", "cham-ber"), w("ruler", "👑", "حاكم", "rul-er"),
         w("discover", "🔍", "يكتشف", "dis-cov-er"), w("restore", "🛠️", "يرمّم", "re-store"),
         w("craftsman", "🔨", "حِرفي", "crafts-man", ["craftsmen"]),
         w("archaeologist", "⛏️", "عالم آثار", "ar-chae-ol-o-gist", ["archeologist"]),
     ]},
    {"id": "o4-industry", "track": "older", "title": "Egypt on the move", "title_ar": "مصر تتحرك",
     "emoji": "🏭", "strictness": 0.84, "source": "English P6 - Unit 4: Egypt on the Move",
     "words": [
         w("steel", "🔩", "فولاذ", accept=["steal"]), w("textile", "🧶", "نسيج", "tex-tile"),
         w("highway", "🛣️", "طريق سريع", "high-way", ["high way"]), w("border", "🗺️", "حدود", "bor-der", ["boarder"]),
         w("innovation", "🚀", "ابتكار", "in-no-va-tion"), w("manufacture", "🏭", "يصنّع", "man-u-fac-ture"),
         w("infrastructure", "🌉", "البنية التحتية", "in-fra-struc-ture"),
         w("self-reliant", "💪", "معتمد على نفسه", "self - re-li-ant", ["self reliant"]),
     ]},
    {"id": "o5-transport", "track": "older", "title": "Smart transportation", "title_ar": "النقل الذكي",
     "emoji": "🚝", "strictness": 0.84, "source": "English P6 - Unit 5: Smart Transportation",
     "words": [
         w("monorail", "🚝", "قطار أحادي", "mon-o-rail", ["mono rail"]), w("escalator", "🛗", "سلم متحرك", "es-ca-la-tor"),
         w("ticket machine", "🎫", "آلة التذاكر", "tick-et ma-chine"), w("pollution", "🏭", "تلوث", "pol-lu-tion"),
         w("digital", "💻", "رقمي", "dig-i-tal"), w("renewable", "♻️", "متجدد", "re-new-a-ble"),
         w("eco-friendly", "🌱", "صديق للبيئة", "e-co friend-ly", ["eco friendly"]),
         w("self-driving", "🚘", "ذاتي القيادة", "self driv-ing", ["self driving"]),
     ]},
    {"id": "o6-library", "track": "older", "title": "The library that time forgot", "title_ar": "المكتبة المنسية",
     "emoji": "📚", "strictness": 0.84, "source": "English P6 - Unit 6: The Library That Time Forgot",
     "words": [
         w("library", "📚", "مكتبة", "li-brar-y"), w("treasure", "💰", "كنز", "trea-sure"),
         w("fountain", "⛲", "نافورة", "foun-tain"), w("rusty", "🔧", "صدئ", "rust-y"),
         w("clogged", "🚱", "مسدود", accept=["clogs"]), w("creaked", "🚪", "صرّ / أصدر صريراً", accept=["creeked"]),
         w("stacks", "📚", "أكوام", accept=["stax"]), w("mayor", "🎩", "عمدة", accept=["mare", "mayer"]),
     ]},
    {"id": "o7-math", "track": "older", "title": "Math words", "title_ar": "كلمات الرياضيات",
     "emoji": "📐", "strictness": 0.84, "source": "Math P6 - Units 8-13",
     "words": [
         w("fraction", "½", "كسر", "frac-tion"), w("decimal", "🔢", "عدد عشري", "dec-i-mal"),
         w("ratio", "⚖️", "نسبة", "ra-ti-o"), w("percent", "💯", "نسبة مئوية", "per-cent", ["per cent"]),
         w("unit rate", "🏷️", "معدل الوحدة", "u-nit rate"), w("coordinates", "📍", "إحداثيات", "co-or-di-nates", ["coordinate"]),
         w("polygon", "🔷", "مضلع", "pol-y-gon"), w("volume", "🧊", "الحجم", "vol-ume"),
     ]},
    {"id": "o8-sentences", "track": "older", "title": "Grammar sentences", "title_ar": "جمل القواعد",
     "emoji": "💬", "strictness": 0.8, "source": "English P6 - Units 1-6 (grammar)",
     "words": [
         w("Have you been to Aswan", "🏝️", "هل زرت أسوان؟"),
         w("We used to travel by train", "🚆", "كنا نسافر بالقطار"),
         w("If it rains we will stay at home", "🌧️", "إذا أمطرت سنبقى في البيت", accept=["if it rains we'll stay at home"]),
         w("She was walking when it started to rain", "🚶‍♀️", "كانت تمشي عندما بدأ المطر"),
         w("The man who painted this is famous", "🧑‍🎨", "الرجل الذي رسم هذه مشهور"),
         w("Neither Ali nor Sara was late", "⏰", "لا علي ولا سارة تأخرا"),
     ]},

    # ============================================================ adult (Kareem)
    {"id": "a1-words", "track": "adult", "title": "Everyday English words", "title_ar": "كلمات الإنجليزية اليومية",
     "emoji": "💼", "strictness": 0.86, "source": "Everyday English 1",
     "words": [
         w("formal", "👔", "رسمي"), w("informal", "👕", "غير رسمي"), w("opinion", "💭", "رأي"),
         w("discussion", "🗣️", "نقاش"), w("paragraph", "📄", "فقرة"), w("punctuation", "❗", "علامات الترقيم"),
         w("spelling", "🔤", "التهجئة"), w("summary", "📝", "ملخص"),
     ]},
    {"id": "a2-phrases", "track": "adult", "title": "Useful phrases", "title_ar": "عبارات مفيدة",
     "emoji": "🤝", "strictness": 0.82, "source": "Everyday English 1 - Speaking, Writing",
     "words": [
         w("Thank you for your email", "📧", "شكراً على بريدك"),
         w("Could you please send me the details", "📨", "هل يمكنك إرسال التفاصيل من فضلك؟"),
         w("In my opinion", "💭", "في رأيي"),
         w("I agree with you", "👍", "أتفق معك"),
         w("I would like to ask about the price", "💬", "أود أن أسأل عن السعر", accept=["i'd like to ask about the price"]),
         w("Best regards", "✍️", "مع أطيب التحيات"),
     ]},
]


# ===========================================================================
# More stages (added with the stage system). Explicit "sort" values place them
# between the first stages so difficulty grows step by step; the first stages
# keep their ids and places, so saved progress is kept.
# ===========================================================================
def S(id, track, sort, title, title_ar, emoji, words, strictness=0.8, source=""):
    return {"id": id, "track": track, "sort": sort, "title": title, "title_ar": title_ar, "emoji": emoji,
            "strictness": strictness, "source": source, "words": words}


LEVELS += [
    # ------------------------------------------------------------------ young (Yassin)
    S("y1b-colors", "young", 13, "Colours", "الألوان", "🎨", [
        w("red", "🔴", "أحمر", accept=["read"]), w("blue", "🔵", "أزرق", accept=["blew"]), w("green", "🟢", "أخضر"),
        w("yellow", "🟡", "أصفر"), w("pink", "🩷", "وردي"), w("orange", "🟠", "برتقالي")], 0.78, "Everyday words"),
    S("y1c-numbers", "young", 16, "Numbers 1-6", "الأرقام 1-6", "🔢", [
        w("one", "1️⃣", "واحد", accept=["won", "1"]), w("two", "2️⃣", "اثنان", accept=["to", "too", "2"]),
        w("three", "3️⃣", "ثلاثة", accept=["3"]), w("four", "4️⃣", "أربعة", accept=["for", "fore", "4"]),
        w("five", "5️⃣", "خمسة", accept=["5"]), w("six", "6️⃣", "ستة", accept=["6"])], 0.78, "Math P3"),
    S("y2b-body", "young", 23, "My body", "جسمي", "🧒", [
        w("head", "🙆", "رأس"), w("hand", "✋", "يد"), w("eye", "👁️", "عين", accept=["i", "aye"]),
        w("nose", "👃", "أنف", accept=["knows"]), w("ear", "👂", "أذن"), w("foot", "🦶", "قدم")], 0.8, "Everyday words"),
    S("y2c-short-a", "young", 26, "Short a: cat, hat", "صوت a القصير", "🐈", [
        w("cat", "🐈", "قطة"), w("hat", "👒", "قبعة"), w("bat", "🦇", "خفاش"), w("map", "🗺️", "خريطة"),
        w("bag", "👜", "حقيبة"), w("jam", "🍓", "مربى")], 0.82, "English P3 - Phonics"),
    S("y3b-healthy", "young", 33, "Healthy food", "طعام صحي", "🥕", [
        w("fruit", "🍇", "فاكهة"), w("juice", "🧃", "عصير"), w("egg", "🥚", "بيضة"), w("bread", "🍞", "خبز"),
        w("cheese", "🧀", "جبن"), w("carrot", "🥕", "جزر", "car-rot")], 0.8, "English P3 - Unit 2"),
    S("y3c-long-e", "young", 36, "Long e: ee, ea", "صوت e الطويل", "🐝", [
        w("tree", "🌳", "شجرة"), w("bee", "🐝", "نحلة", accept=["b", "be"]), w("sea", "🌊", "بحر", accept=["see", "c"]),
        w("leaf", "🍃", "ورقة شجر"), w("sheep", "🐑", "خروف"), w("teeth", "🦷", "أسنان")], 0.84, "English P3 - Unit 2: long e"),
    S("y4b-magic-e2", "young", 43, "Magic e: tap or tape?", "حرف e السحري 2", "✨", [
        w("pin", "📌", "دبوس"), w("pine", "🌲", "صنوبر", "p-i-ne (i says its name)"),
        w("tap", "🚰", "صنبور"), w("tape", "📼", "شريط", "t-a-pe (a says its name)"),
        w("not", "🚫", "ليس", accept=["knot"]), w("note", "📝", "ملاحظة", "n-o-te (o says its name)")], 0.93, "English P3 - Unit 3: Magic e"),
    S("y4c-sequence", "young", 46, "First, then, finally", "أولًا ثم أخيرًا", "🔢", [
        w("first", "1️⃣", "أولًا"), w("then", "➡️", "ثم"), w("next", "⏭️", "بعد ذلك"), w("finally", "🏁", "أخيرًا", "fi-nal-ly"),
        w("before", "⬅️", "قبل", "be-fore"), w("after", "➡️", "بعد", "af-ter")], 0.8, "English P3 - Unit 3"),
    S("y5b-jobs", "young", 53, "Jobs", "المهن", "👩‍⚕️", [
        w("doctor", "👨‍⚕️", "طبيب", "doc-tor"), w("nurse", "👩‍⚕️", "ممرضة"), w("farmer", "👨‍🌾", "مزارع", "farm-er"),
        w("driver", "🚕", "سائق", "driv-er"), w("dentist", "🦷", "طبيب أسنان", "den-tist"),
        w("police officer", "👮", "شرطي", "po-lice of-fi-cer")], 0.8, "English P3 - Unit 3"),
    S("y5c-places", "young", 56, "Places in town", "أماكن في المدينة", "🏫", [
        w("school", "🏫", "مدرسة"), w("hospital", "🏥", "مستشفى", "hos-pi-tal"), w("park", "🏞️", "حديقة"),
        w("shop", "🏪", "متجر"), w("house", "🏠", "بيت"), w("mosque", "🕌", "مسجد", accept=["mosk"])], 0.8, "Everyday words"),
    S("y6b-tech2", "young", 63, "More technology", "تكنولوجيا أكثر", "💻", [
        w("computer", "💻", "حاسوب", "com-pu-ter"), w("internet", "🌐", "الإنترنت", "in-ter-net"),
        w("message", "💬", "رسالة", "mes-sage"), w("video", "🎬", "فيديو", "vid-e-o"), w("drone", "🛸", "طائرة مسيّرة"),
        w("charger", "🔌", "شاحن", "char-ger")], 0.8, "English P3 - Unit 4"),
    S("y6c-short-o-u", "young", 66, "Short o and u", "صوت o و u القصير", "🐶", [
        w("dog", "🐶", "كلب"), w("box", "📦", "صندوق"), w("sun", "☀️", "شمس", accept=["son"]), w("bus", "🚌", "حافلة"),
        w("cup", "☕", "كوب"), w("duck", "🦆", "بطة")], 0.82, "English P3 - Phonics"),
    S("y7b-habitats", "young", 73, "Where animals live", "أين تعيش الحيوانات", "🌍", [
        w("desert", "🏜️", "صحراء", "des-ert"), w("ocean", "🌊", "محيط", "o-cean"), w("forest", "🌲", "غابة", "for-est"),
        w("jungle", "🌴", "أدغال", "jun-gle"), w("river", "🏞️", "نهر", "riv-er"), w("nest", "🪺", "عش")], 0.8, "English P3 - Unit 5"),
    S("y7c-farm", "young", 76, "On the farm", "في المزرعة", "🐐", [
        w("goat", "🐐", "ماعز"), w("horse", "🐴", "حصان"), w("hen", "🐔", "دجاجة"), w("rabbit", "🐇", "أرنب", "rab-bit"),
        w("donkey", "🫏", "حمار", "don-key"), w("cow", "🐄", "بقرة")], 0.8, "Everyday words"),
    S("y8b-actions2", "young", 83, "More action words", "أفعال أكثر", "✏️", [
        w("read", "📖", "يقرأ", accept=["reed", "red"]), w("write", "✍️", "يكتب", accept=["right", "rite"]),
        w("draw", "🖍️", "يرسم"), w("sing", "🎤", "يغني"), w("dance", "💃", "يرقص"), w("cook", "🍳", "يطبخ")], 0.8, "Everyday words"),
    S("y8c-can-sentences", "young", 86, "What can they do?", "ماذا يستطيعون؟", "🐦", [
        w("I can swim", "🏊", "أستطيع السباحة"), w("A bird can fly", "🐦", "الطائر يستطيع الطيران"),
        w("A fish can't walk", "🐟", "السمكة لا تستطيع المشي", accept=["a fish cannot walk"]),
        w("I can read", "📖", "أستطيع القراءة"), w("A monkey can climb", "🐒", "القرد يستطيع التسلق")], 0.8, "English P3 - Unit 5: can / can't"),
    S("y9b-feelings2", "young", 93, "How do you feel?", "كيف تشعر؟", "🥱", [
        w("tired", "🥱", "متعب"), w("hungry", "😋", "جائع", "hun-gry"), w("excited", "🤩", "متحمس", "ex-cit-ed"),
        w("proud", "😊", "فخور"), w("bored", "😐", "ملول", accept=["board"]), w("scared", "😨", "خائف")], 0.8, "English P3 - Unit 6"),
    S("y9c-weather", "young", 96, "Weather", "الطقس", "🌦️", [
        w("sunny", "☀️", "مشمس", "sun-ny"), w("rainy", "🌧️", "ممطر", "rain-y"), w("windy", "🌬️", "عاصف", "wind-y"),
        w("cloudy", "☁️", "غائم", "cloud-y"), w("hot", "🥵", "حار"), w("cold", "🥶", "بارد")], 0.8, "Everyday words"),
    S("y10b-math2", "young", 103, "Math words 2", "كلمات الرياضيات 2", "➕", [
        w("plus", "➕", "زائد"), w("minus", "➖", "ناقص", "mi-nus"), w("equals", "🟰", "يساوي", "e-quals", ["equal"]),
        w("twenty", "2️⃣0️⃣", "عشرون", accept=["20"]), w("hundred", "💯", "مئة", accept=["100", "one hundred"]),
        w("half", "🌓", "نصف")], 0.8, "Math P3"),
    S("y10c-time", "young", 106, "Telling the time", "الوقت", "⏰", [
        w("o'clock", "🕒", "الساعة (تمامًا)", accept=["oclock", "o clock"]), w("morning", "🌅", "صباح", "morn-ing"),
        w("evening", "🌆", "مساء", "eve-ning"), w("today", "📅", "اليوم", "to-day"), w("tomorrow", "🗓️", "غدًا", "to-mor-row"),
        w("week", "📆", "أسبوع", accept=["weak"])], 0.8, "Math P3 - Time"),
    S("y11b-talk", "young", 113, "Let's talk", "لنتحدث", "🗣️", [
        w("Good morning", "🌅", "صباح الخير"), w("Thank you very much", "🙏", "شكرًا جزيلًا"), w("How are you", "👋", "كيف حالك؟"),
        w("I am fine", "😊", "أنا بخير", accept=["i'm fine"]), w("What is your name", "📛", "ما اسمك؟", accept=["what's your name"]),
        w("See you tomorrow", "👋", "أراك غدًا")], 0.8, "Everyday English"),
    S("y11c-future", "young", 116, "I will...", "سوف...", "🔮", [
        w("I will help my mom", "🤝", "سأساعد أمي", accept=["i will help my mum", "i'll help my mom"]),
        w("It will rain tomorrow", "🌧️", "ستمطر غدًا"), w("I will read a book", "📖", "سأقرأ كتابًا", accept=["i'll read a book"]),
        w("We will go to the park", "🏞️", "سنذهب إلى الحديقة", accept=["we'll go to the park"]),
        w("I will be kind", "💛", "سأكون لطيفًا", accept=["i'll be kind"])], 0.8, "English P3 - Unit 4: will"),
    S("y12-review", "young", 120, "Big review", "مراجعة كبيرة", "🏆", [
        w("helmet", "⛑️", "خوذة", "hel-met"), w("breakfast", "🍳", "الفطور", "break-fast"),
        w("firefighter", "👩‍🚒", "رجل إطفاء", "fire-fight-er", ["fire fighter"]), w("keyboard", "⌨️", "لوحة المفاتيح", "key-board"),
        w("camel", "🐪", "جمل", "cam-el"), w("remainder", "🧮", "الباقي", "re-main-der")], 0.84, "Review of all stages"),

    # ------------------------------------------------------------------ older (Omar)
    S("o0-warmup", "older", 5, "Warm up", "إحماء", "🙌", [
        w("school", "🏫", "مدرسة"), w("friend", "🤝", "صديق"), w("family", "👨‍👩‍👦", "عائلة", "fam-i-ly"),
        w("teacher", "👩‍🏫", "معلم", "tea-cher"), w("weekend", "🎉", "عطلة نهاية الأسبوع", "week-end"),
        w("homework", "📝", "واجب منزلي", "home-work")], 0.8, "Everyday words"),
    S("o0b-days-months", "older", 7, "Days and months", "الأيام والشهور", "🗓️", [
        w("Monday", "📅", "الاثنين"), w("Wednesday", "📅", "الأربعاء", "wens-day"), w("Thursday", "📅", "الخميس", "thurs-day"),
        w("February", "❄️", "فبراير", "feb-ru-ar-y"), w("August", "☀️", "أغسطس", "au-gust"), w("December", "🎄", "ديسمبر", "de-cem-ber")],
      0.82, "Everyday words"),
    S("o1b-art2", "older", 13, "Art words 2", "كلمات الفن 2", "🖌️", [
        w("artist", "🧑‍🎨", "فنان", "art-ist"), w("painting", "🖼️", "لوحة", "paint-ing"),
        w("colourful", "🌈", "ملوّن", "col-our-ful", ["colorful"]), w("exhibition", "🏛️", "معرض", "ex-hi-bi-tion"),
        w("portrait", "🖼️", "صورة شخصية", "por-trait"), w("statue", "🗽", "تمثال", "stat-ue")], 0.84, "English P6 - Unit 1"),
    S("o1c-both-either", "older", 16, "Both, either, neither", "كلاهما، إمّا، لا هذا ولا ذاك", "⚖️", [
        w("Both Omar and Ali like art", "🎨", "عمر وعلي كلاهما يحبان الفن"),
        w("You can either walk or run", "🏃", "يمكنك إمّا أن تمشي أو تجري"),
        w("Neither the tea nor the milk is hot", "☕", "لا الشاي ولا الحليب ساخن"),
        w("I like both drawing and music", "🎵", "أحب الرسم والموسيقى كليهما"),
        w("Either Sara or Mona will help", "🤝", "إمّا سارة أو منى ستساعد")], 0.8, "English P6 - Unit 1: grammar"),
    S("o2b-inventions2", "older", 23, "Inventors", "المخترعون", "⚙️", [
        w("inventor", "👨‍🔬", "مخترع", "in-ven-tor"), w("invention", "💡", "اختراع", "in-ven-tion"),
        w("machine", "⚙️", "آلة", "ma-chine"), w("electricity", "⚡", "كهرباء", "e-lec-tric-i-ty"),
        w("telephone", "☎️", "هاتف", "tel-e-phone"), w("engine", "🚂", "محرك", "en-gine")], 0.84, "English P6 - Unit 2"),
    S("o2c-prefixes", "older", 26, "Prefixes re- and un-", "البادئات re و un", "🔁", [
        w("redo", "🔁", "يعيد العمل", "re-do", ["re do"]), w("rewrite", "✍️", "يعيد الكتابة", "re-write", ["re write"]),
        w("unlock", "🔓", "يفتح القفل", "un-lock"), w("unkind", "😠", "غير لطيف", "un-kind"),
        w("retell", "🗣️", "يعيد الحكي", "re-tell", ["re tell"]), w("unfair", "⚖️", "غير عادل", "un-fair")], 0.84, "English P6 - Unit 2: prefixes"),
    S("o3b-egypt2", "older", 33, "Ancient Egypt", "مصر القديمة", "🔺", [
        w("pyramid", "🔺", "هرم", "pyr-a-mid"), w("temple", "🏛️", "معبد", "tem-ple"), w("pharaoh", "👑", "فرعون", "phar-aoh", ["pharoah"]),
        w("tomb", "⚱️", "مقبرة", "toom (b is silent)"), w("ancient", "📜", "قديم", "an-cient"), w("papyrus", "📜", "ورق البردي", "pa-py-rus")],
      0.84, "English P6 - Unit 3"),
    S("o3c-present-perfect", "older", 36, "Have you ever...?", "هل سبق لك...؟", "✅", [
        w("I have visited Luxor", "🏛️", "لقد زرت الأقصر", accept=["i've visited luxor"]),
        w("She has finished her homework", "📝", "لقد أنهت واجبها", accept=["she's finished her homework"]),
        w("Have you ever seen the pyramids", "🔺", "هل رأيت الأهرامات من قبل؟"),
        w("They have discovered a tomb", "⚱️", "لقد اكتشفوا مقبرة", accept=["they've discovered a tomb"]),
        w("We have never been to Aswan", "🏝️", "لم نذهب إلى أسوان أبدًا", accept=["we've never been to aswan"])], 0.8, "English P6 - Unit 3: present perfect"),
    S("o4b-industry2", "older", 43, "Factories", "المصانع", "🏭", [
        w("factory", "🏭", "مصنع", "fac-to-ry"), w("product", "📦", "منتج", "prod-uct"), w("export", "🚢", "يصدّر", "ex-port"),
        w("cotton", "☁️", "قطن", "cot-ton"), w("engineer", "👷", "مهندس", "en-gi-neer"), w("technology", "🤖", "تكنولوجيا", "tech-nol-o-gy")],
      0.84, "English P6 - Unit 4"),
    S("o4c-used-to", "older", 46, "Used to", "كان يفعل (used to)", "⏳", [
        w("I used to play in the garden", "🌳", "كنت ألعب في الحديقة"),
        w("We didn't use to have a car", "🚗", "لم تكن لدينا سيارة", accept=["we did not use to have a car"]),
        w("Did you use to live here", "🏠", "هل كنت تعيش هنا؟"),
        w("My grandfather used to farm", "👴", "كان جدي يزرع"),
        w("People used to write letters", "✉️", "كان الناس يكتبون الرسائل")], 0.8, "English P6 - Unit 4: used to"),
    S("o5b-transport2", "older", 53, "Getting around", "التنقل", "🚉", [
        w("passenger", "🧳", "راكب", "pas-sen-ger"), w("platform", "🚉", "رصيف القطار", "plat-form"),
        w("traffic", "🚦", "حركة المرور", "traf-fic"), w("station", "🚏", "محطة", "sta-tion"),
        w("electric car", "🔋", "سيارة كهربائية", "e-lec-tric car"), w("underground", "🚇", "مترو الأنفاق", "un-der-ground")],
      0.84, "English P6 - Unit 5"),
    S("o5c-conditional", "older", 56, "If... will...", "إذا... سوف...", "🔀", [
        w("If you study you will pass", "📚", "إذا ذاكرت ستنجح", accept=["if you study you'll pass"]),
        w("If it is sunny we will swim", "☀️", "إذا كان الجو مشمسًا سنسبح", accept=["if it's sunny we'll swim"]),
        w("If I have time I will call you", "📞", "إذا كان لدي وقت سأتصل بك", accept=["if i have time i'll call you"]),
        w("You will be late if you don't hurry", "⏰", "ستتأخر إذا لم تسرع", accept=["you'll be late if you don't hurry"]),
        w("If we recycle we will save energy", "♻️", "إذا أعدنا التدوير سنوفّر الطاقة", accept=["if we recycle we'll save energy"])],
      0.8, "English P6 - Unit 5: first conditional"),
    S("o6b-library2", "older", 63, "In the library", "في المكتبة", "📖", [
        w("librarian", "🧑‍🏫", "أمين المكتبة", "li-brar-i-an"), w("shelf", "🗄️", "رف"), w("novel", "📕", "رواية", "nov-el"),
        w("author", "✍️", "مؤلف", "au-thor"), w("dusty", "🌫️", "مغبّر", "dust-y"), w("mysterious", "🕵️", "غامض", "mys-te-ri-ous")],
      0.84, "English P6 - Unit 6"),
    S("o6c-past-continuous", "older", 66, "I was doing...", "كنت أفعل...", "🎬", [
        w("I was reading when the phone rang", "📞", "كنت أقرأ عندما رنّ الهاتف"),
        w("They were playing football", "⚽", "كانوا يلعبون كرة القدم"),
        w("What were you doing yesterday", "❓", "ماذا كنت تفعل أمس؟"),
        w("It was raining all day", "🌧️", "كانت تمطر طوال اليوم")], 0.8, "English P6 - Unit 6: past continuous"),
    S("o7b-fractions", "older", 73, "Fractions", "الكسور", "🍕", [
        w("numerator", "🔝", "البسط", "nu-mer-a-tor"), w("denominator", "⬇️", "المقام", "de-nom-i-na-tor"),
        w("equivalent", "🟰", "مكافئ", "e-quiv-a-lent"), w("divisible", "➗", "قابل للقسمة", "di-vis-i-ble"),
        w("perimeter", "📏", "المحيط", "pe-rim-e-ter"), w("area", "⬛", "المساحة", "ar-e-a")], 0.84, "Math P6"),
    S("o7c-geometry", "older", 76, "Shapes", "الأشكال", "📐", [
        w("triangle", "🔺", "مثلث", "tri-an-gle"), w("rectangle", "▭", "مستطيل", "rec-tan-gle"),
        w("parallelogram", "▱", "متوازي أضلاع", "par-al-lel-o-gram"), w("angle", "📐", "زاوية", "an-gle"),
        w("diagonal", "⟋", "قطر", "di-ag-o-nal"), w("cube", "🧊", "مكعب")], 0.84, "Math P6 - Geometry"),
    S("o9-science", "older", 83, "Science", "العلوم", "🔬", [
        w("planet", "🪐", "كوكب", "plan-et"), w("energy", "⚡", "طاقة", "en-er-gy"), w("oxygen", "🫧", "أكسجين", "ox-y-gen"),
        w("volcano", "🌋", "بركان", "vol-ca-no"), w("environment", "🌍", "البيئة", "en-vi-ron-ment"),
        w("temperature", "🌡️", "درجة الحرارة", "tem-per-a-ture")], 0.84, "Science words"),
    S("o9b-tricky", "older", 86, "Tricky spellings", "كلمات صعبة النطق", "🧩", [
        w("vegetable", "🥦", "خضار", "veg-ta-ble", ["vegetables"]), w("island", "🏝️", "جزيرة", "eye-land (s is silent)"),
        w("knowledge", "🧠", "معرفة", "nol-edge (k is silent)"), w("answer", "💬", "إجابة", "an-ser (w is silent)"),
        w("through", "➡️", "عبر", "throo", ["threw"]), w("enough", "✋", "يكفي", "e-nuff")], 0.84, "Silent letters"),
    S("o10-review", "older", 90, "Big review", "مراجعة كبيرة", "🏆", [
        w("masterpiece", "🌟", "تحفة فنية", "mas-ter-piece"), w("archaeologist", "⛏️", "عالم آثار", "ar-chae-ol-o-gist", ["archeologist"]),
        w("infrastructure", "🌉", "البنية التحتية", "in-fra-struc-ture"), w("escalator", "🛗", "سلم متحرك", "es-ca-la-tor"),
        w("fraction", "½", "كسر", "frac-tion"), w("pendulum", "🕰️", "بندول", "pen-du-lum")], 0.86, "Review of all stages"),
    S("o10b-long-sentences", "older", 93, "Long sentences", "جمل طويلة", "📜", [
        w("Libraries help people learn new things every day", "📚", "المكتبات تساعد الناس على تعلّم أشياء جديدة كل يوم"),
        w("Clean energy is good for our planet", "🌍", "الطاقة النظيفة مفيدة لكوكبنا"),
        w("My favourite subject at school is science", "🔬", "مادتي المفضلة في المدرسة هي العلوم", accept=["my favorite subject at school is science"]),
        w("I would like to visit the Egyptian Museum", "🏛️", "أودّ زيارة المتحف المصري", accept=["i'd like to visit the egyptian museum"])],
      0.8, "English P6 - Review"),

    # ------------------------------------------------------------------ adult (Kareem)
    S("a3-perfume", "adult", 30, "Perfume shop words", "كلمات متجر العطور", "🧴", [
        w("fragrance", "🌸", "عطر / رائحة", "fra-grance"), w("perfume", "🧴", "عطر", "per-fume"), w("customer", "🧑", "زبون", "cus-tom-er"),
        w("discount", "🏷️", "خصم", "dis-count"), w("delivery", "🚚", "توصيل", "de-liv-er-y"), w("invoice", "🧾", "فاتورة", "in-voice")],
      0.86, "Business English"),
    S("a4-shop-phrases", "adult", 40, "Talking to customers", "الحديث مع الزبائن", "💬", [
        w("How can I help you", "🙋", "كيف أستطيع مساعدتك؟"), w("This fragrance lasts all day", "⏳", "هذا العطر يدوم طوال اليوم"),
        w("Would you like to try it", "🧴", "هل تحب أن تجرّبه؟"), w("We have a special offer today", "🏷️", "لدينا عرض خاص اليوم"),
        w("Thank you for shopping with us", "🛍️", "شكرًا لتسوّقك معنا")], 0.82, "Business English"),
    S("a5-meetings", "adult", 50, "Meeting words", "كلمات الاجتماعات", "📊", [
        w("agenda", "📋", "جدول الأعمال", "a-gen-da"), w("target", "🎯", "الهدف", "tar-get"), w("sales", "💰", "المبيعات", accept=["sails"]),
        w("report", "📈", "تقرير", "re-port"), w("deadline", "⏰", "الموعد النهائي", "dead-line"), w("budget", "💵", "الميزانية", "budg-et")],
      0.86, "Business English"),
    S("a6-meeting-phrases", "adult", 60, "In the sales meeting", "في اجتماع المبيعات", "🤝", [
        w("Let's review the monthly sales", "📊", "لنراجع المبيعات الشهرية", accept=["let us review the monthly sales"]),
        w("We exceeded our target", "🎯", "تجاوزنا هدفنا"), w("Could we schedule a meeting", "📅", "هل يمكننا تحديد موعد اجتماع؟"),
        w("I will send the report today", "📨", "سأرسل التقرير اليوم", accept=["i'll send the report today"])], 0.82, "Business English"),
]
