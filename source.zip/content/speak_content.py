# -*- coding: utf-8 -*-
"""
Family Learn - speaking game ("Say it!") word levels.

The words come from the family's school books (see book_content.py):
  young  = English Primary 3 Term 2 + Math Primary 3  (Yassin, grades 1-4)
  older  = English Primary 6 Term 2 + Math Primary 6  (Omar, grade 5+)
  adult  = Everyday English 1                         (Kareem)

Build:  python3 content/build_speak.py
  -> supabase/migrations/20260930000006_speak_game.sql
  -> apps/mobile/lib/data/speak_game/speak_content.g.dart (demo mode + tests)

Word fields:  text, emoji, ar (Arabic meaning), hint (syllables), accept (sound-alikes)
strictness:   minimum pronunciation score for "correct" (0.78 lenient .. 0.95 strict).
              Magic-e uses 0.93 so "cap" is NOT accepted for "cape".
"""


def w(text, emoji="", ar="", hint="", accept=()):
    return {"text": text, "emoji": emoji, "meaning_ar": ar, "hint": hint, "accept": list(accept)}


LEVELS = [
    # ============================================================ young (Yassin)
    {"id": "y1-sounds", "track": "young", "title": "Sounds: st, sl, tr, gr", "title_ar": "أصوات: st, sl, tr, gr",
     "emoji": "🚂", "strictness": 0.8, "source": "English P3 - Unit 1: Sounds sl, st, gr, tr",
     "words": [
         w("stop", "🛑", "قِف"), w("star", "⭐", "نجمة"), w("step", "👣", "خطوة"),
         w("slow", "🐢", "بطيء"), w("sleep", "😴", "ينام"), w("train", "🚆", "قطار"),
         w("truck", "🚚", "شاحنة", accept=["trucks"]), w("green", "🟢", "أخضر"),
     ]},
    {"id": "y2-safety", "track": "young", "title": "Safety", "title_ar": "السلامة",
     "emoji": "⛑️", "strictness": 0.8, "source": "English P3 - Unit 1: Safety",
     "words": [
         w("helmet", "⛑️", "خوذة", "hel-met"), w("careful", "⚠️", "حذِر", "care-ful"),
         w("sign", "🪧", "إشارة", accept=["sine"]), w("stranger", "🧍", "شخص غريب", "stran-ger"),
         w("ambulance", "🚑", "سيارة إسعاف", "am-bu-lance"), w("seat belt", "🚗", "حزام الأمان", "seat - belt", ["seatbelt"]),
         w("dangerous", "⚡", "خطير", "dan-ger-ous"), w("emergency", "🚨", "طوارئ", "e-mer-gen-cy"),
     ]},
    {"id": "y3-food", "track": "young", "title": "Food and health", "title_ar": "الطعام والصحة",
     "emoji": "🍎", "strictness": 0.8, "source": "English P3 - Unit 2: Food and Health",
     "words": [
         w("apple", "🍎", "تفاحة", "ap-ple"), w("milk", "🥛", "حليب"), w("rice", "🍚", "أرز"),
         w("water", "💧", "ماء", "wa-ter"), w("breakfast", "🍳", "الفطور", "break-fast"),
         w("lunch", "🥪", "الغداء"), w("dinner", "🍽️", "العشاء", "din-ner"),
         w("vegetables", "🥦", "خضروات", "veg-e-ta-bles", ["vegetable"]),
     ]},
    {"id": "y4-magic-e", "track": "young", "title": "Magic e: cap or cape?", "title_ar": "حرف e السحري",
     "emoji": "🪄", "strictness": 0.93, "source": "English P3 - Unit 3: Magic e",
     "words": [
         w("cap", "🧢", "قبعة"), w("cape", "🦸", "عباءة", "c-a-pe (a says its name)"),
         w("hop", "🐇", "يقفز"), w("hope", "🙏", "أمل", "h-o-pe (o says its name)"),
         w("kit", "🧰", "عُدّة"), w("kite", "🪁", "طائرة ورقية", "k-i-te (i says its name)"),
         w("cub", "🐻", "شبل / صغير الدب", accept=["cubs"]), w("cube", "🧊", "مكعب", "c-u-be (u says its name)"),
     ]},
    {"id": "y5-heroes", "track": "young", "title": "Heroes around us", "title_ar": "أبطال حولنا",
     "emoji": "🚒", "strictness": 0.8, "source": "English P3 - Unit 3: Heroes Around Us",
     "words": [
         w("firefighter", "👩‍🚒", "رجل إطفاء", "fire-fight-er", ["fire fighter", "firefighters"]),
         w("pilot", "👨‍✈️", "طيار", "pi-lot"), w("teacher", "👩‍🏫", "معلم", "tea-cher"),
         w("chef", "👨‍🍳", "طاهٍ", accept=["shef"]), w("brave", "🦁", "شجاع"),
         w("ladder", "🪜", "سلّم", "lad-der"), w("medal", "🏅", "ميدالية", "med-al", ["metal"]),
         w("uniform", "🦺", "زي موحد", "u-ni-form"),
     ]},
    {"id": "y6-tech", "track": "young", "title": "Technology", "title_ar": "التكنولوجيا",
     "emoji": "🤖", "strictness": 0.8, "source": "English P3 - Unit 4: Living with Technology",
     "words": [
         w("phone", "📱", "هاتف"), w("robot", "🤖", "روبوت", "ro-bot"), w("camera", "📷", "كاميرا", "cam-er-a"),
         w("tablet", "📲", "جهاز لوحي", "tab-let"), w("screen", "🖥️", "شاشة"),
         w("keyboard", "⌨️", "لوحة المفاتيح", "key-board", ["key board"]),
         w("button", "🔘", "زر", "but-ton"), w("password", "🔑", "كلمة المرور", "pass-word", ["pass word"]),
     ]},
    {"id": "y7-animals", "track": "young", "title": "Animals and habitats", "title_ar": "الحيوانات وبيئاتها",
     "emoji": "🐪", "strictness": 0.8, "source": "English P3 - Unit 5: Animals and Habitats",
     "words": [
         w("camel", "🐪", "جمل", "cam-el"), w("monkey", "🐒", "قرد", "mon-key"), w("fish", "🐟", "سمكة"),
         w("owl", "🦉", "بومة"), w("polar bear", "🐻‍❄️", "دب قطبي", "po-lar bear", ["polarbear"]),
         w("feathers", "🪶", "ريش", "feath-ers", ["feather"]), w("fur", "🧸", "فرو", accept=["fir"]),
         w("claws", "🐾", "مخالب", accept=["claw", "clause"]),
     ]},
    {"id": "y8-actions", "track": "young", "title": "I can... (action words)", "title_ar": "أستطيع... (أفعال)",
     "emoji": "🤸", "strictness": 0.8, "source": "English P3 - Unit 5: can / can't",
     "words": [
         w("fly", "🕊️", "يطير"), w("jump", "🦘", "يقفز"), w("crawl", "🐛", "يزحف"),
         w("swim", "🏊", "يسبح"), w("climb", "🧗", "يتسلق", accept=["clime"]), w("run", "🏃", "يجري"),
     ]},
    {"id": "y9-feelings", "track": "young", "title": "Feelings (story)", "title_ar": "المشاعر (القصة)",
     "emoji": "😊", "strictness": 0.8, "source": "English P3 - Unit 6: The Honest Choice",
     "words": [
         w("happy", "😀", "سعيد", "hap-py"), w("angry", "😠", "غاضب", "an-gry"), w("sleepy", "😴", "نعسان", "sleep-y"),
         w("nervous", "😬", "متوتر", "ner-vous"), w("honest", "🤝", "صادق", "hon-est (h is silent)"),
         w("whisper", "🤫", "يهمس", "whis-per"),
     ]},
    {"id": "y10-math", "track": "young", "title": "Math words", "title_ar": "كلمات الرياضيات",
     "emoji": "➗", "strictness": 0.8, "source": "Math P3 - Chapters 1-10",
     "words": [
         w("multiply", "✖️", "يضرب", "mul-ti-ply"), w("divide", "➗", "يقسم", "di-vide"),
         w("hour", "⏰", "ساعة", "our (h is silent)", ["our"]), w("minute", "⏱️", "دقيقة", "min-ute", ["minutes"]),
         w("remainder", "🧮", "الباقي", "re-main-der"),
         w("kilometre", "🛣️", "كيلومتر", "ki-lo-me-tre", ["kilometer", "kilometers", "kilometres"]),
         w("graph", "📊", "رسم بياني", accept=["graf"]),
         w("ten thousand", "🔟", "عشرة آلاف", accept=["10000"]),
     ]},
    {"id": "y11-sentences", "track": "young", "title": "Short sentences", "title_ar": "جمل قصيرة",
     "emoji": "💬", "strictness": 0.8, "source": "English P3 - Units 1, 2, 6",
     "words": [
         w("Be careful", "⚠️", "كن حذراً"), w("Don't run", "🚫🏃", "لا تجرِ", accept=["do not run"]),
         w("Wait here", "✋", "انتظر هنا"), w("I did it myself", "💪", "فعلتها بنفسي"),
         w("I can jump", "🦘", "أستطيع أن أقفز"), w("Always tell the truth", "🤝", "قل الحقيقة دائماً"),
     ]},

    # ============================================================ older (Omar)
    {"id": "o1-art", "track": "older", "title": "Celebrating creativity", "title_ar": "الاحتفاء بالإبداع",
     "emoji": "🎨", "strictness": 0.84, "source": "English P6 - Unit 1: Celebrating Creativity",
     "words": [
         w("canvas", "🖼️", "قماش الرسم", "can-vas", ["canvass"]), w("gallery", "🏛️", "معرض", "gal-le-ry"),
         w("sketch", "✏️", "رسم تخطيطي"), w("mural", "🧱", "لوحة جدارية", "mu-ral"),
         w("palette", "🎨", "لوحة الألوان", "pal-ette", ["pallet"]), w("sculpture", "🗿", "منحوتة", "sculp-ture"),
         w("sculptor", "🧑‍🎨", "نحّات", "sculp-tor"), w("masterpiece", "🌟", "تحفة فنية", "mas-ter-piece", ["master piece"]),
     ]},
    {"id": "o2-inventions", "track": "older", "title": "Wonderful inventions", "title_ar": "اختراعات رائعة",
     "emoji": "💡", "strictness": 0.84, "source": "English P6 - Unit 2: Wonderful Inventions",
     "words": [
         w("gadget", "📟", "أداة / جهاز صغير", "gad-get"), w("fabric", "🧵", "قماش", "fab-ric"),
         w("thread", "🪡", "خيط"), w("blueprint", "📐", "مخطط", "blue-print", ["blue print"]),
         w("accurate", "🎯", "دقيق", "ac-cu-rate"), w("assemble", "🔧", "يُجمِّع", "as-sem-ble"),
         w("rebuild", "🏗️", "يعيد البناء", "re-build", ["re build"]), w("unhappy", "🙁", "غير سعيد", "un-hap-py"),
     ]},
    {"id": "o3-egypt", "track": "older", "title": "Hidden gems of Egypt", "title_ar": "كنوز مصر الخفية",
     "emoji": "🏺", "strictness": 0.84, "source": "English P6 - Unit 3: Hidden Gems of Egypt",
     "words": [
         w("mummy", "🧟", "مومياء", "mum-my"), w("monument", "🗿", "أثر / نُصب", "mon-u-ment"),
         w("chamber", "🚪", "حجرة", "cham-ber"), w("ruler", "👑", "حاكم", "rul-er"),
         w("discover", "🔍", "يكتشف", "dis-cov-er"), w("restore", "🛠️", "يرمّم", "re-store"),
         w("craftsman", "🔨", "حِرفي", "crafts-man", ["craftsmen"]),
         w("archaeologist", "⛏️", "عالم آثار", "ar-chae-ol-o-gist", ["archeologist"]),
     ]},
    {"id": "o4-industry", "track": "older", "title": "Egypt on the move", "title_ar": "مصر تتحرك",
     "emoji": "🏭", "strictness": 0.84, "source": "English P6 - Unit 4: Egypt on the Move",
     "words": [
         w("steel", "🔩", "فولاذ", accept=["steal"]), w("textile", "🧶", "نسيج", "tex-tile"),
         w("highway", "🛣️", "طريق سريع", "high-way", ["high way"]), w("border", "🗺️", "حدود", "bor-der", ["boarder"]),
         w("innovation", "🚀", "ابتكار", "in-no-va-tion"), w("manufacture", "🏭", "يصنّع", "man-u-fac-ture"),
         w("infrastructure", "🌉", "البنية التحتية", "in-fra-struc-ture"),
         w("self-reliant", "💪", "معتمد على نفسه", "self - re-li-ant", ["self reliant"]),
     ]},
    {"id": "o5-transport", "track": "older", "title": "Smart transportation", "title_ar": "النقل الذكي",
     "emoji": "🚝", "strictness": 0.84, "source": "English P6 - Unit 5: Smart Transportation",
     "words": [
         w("monorail", "🚝", "قطار أحادي", "mon-o-rail", ["mono rail"]), w("escalator", "🛗", "سلم متحرك", "es-ca-la-tor"),
         w("ticket machine", "🎫", "آلة التذاكر", "tick-et ma-chine"), w("pollution", "🏭", "تلوث", "pol-lu-tion"),
         w("digital", "💻", "رقمي", "dig-i-tal"), w("renewable", "♻️", "متجدد", "re-new-a-ble"),
         w("eco-friendly", "🌱", "صديق للبيئة", "e-co friend-ly", ["eco friendly"]),
         w("self-driving", "🚘", "ذاتي القيادة", "self driv-ing", ["self driving"]),
     ]},
    {"id": "o6-library", "track": "older", "title": "The library that time forgot", "title_ar": "المكتبة المنسية",
     "emoji": "📚", "strictness": 0.84, "source": "English P6 - Unit 6: The Library That Time Forgot",
     "words": [
         w("library", "📚", "مكتبة", "li-brar-y"), w("treasure", "💰", "كنز", "trea-sure"),
         w("fountain", "⛲", "نافورة", "foun-tain"), w("rusty", "🔧", "صدئ", "rust-y"),
         w("clogged", "🚱", "مسدود", accept=["clogs"]), w("creaked", "🚪", "صرّ / أصدر صريراً", accept=["creeked"]),
         w("stacks", "📚", "أكوام", accept=["stax"]), w("mayor", "🎩", "عمدة", accept=["mare", "mayer"]),
     ]},
    {"id": "o7-math", "track": "older", "title": "Math words", "title_ar": "كلمات الرياضيات",
     "emoji": "📐", "strictness": 0.84, "source": "Math P6 - Units 8-13",
     "words": [
         w("fraction", "½", "كسر", "frac-tion"), w("decimal", "🔢", "عدد عشري", "dec-i-mal"),
         w("ratio", "⚖️", "نسبة", "ra-ti-o"), w("percent", "💯", "نسبة مئوية", "per-cent", ["per cent"]),
         w("unit rate", "🏷️", "معدل الوحدة", "u-nit rate"), w("coordinates", "📍", "إحداثيات", "co-or-di-nates", ["coordinate"]),
         w("polygon", "🔷", "مضلع", "pol-y-gon"), w("volume", "🧊", "الحجم", "vol-ume"),
     ]},
    {"id": "o8-sentences", "track": "older", "title": "Grammar sentences", "title_ar": "جمل القواعد",
     "emoji": "💬", "strictness": 0.8, "source": "English P6 - Units 1-6 (grammar)",
     "words": [
         w("Have you been to Aswan", "🏝️", "هل زرت أسوان؟"),
         w("We used to travel by train", "🚆", "كنا نسافر بالقطار"),
         w("If it rains we will stay at home", "🌧️", "إذا أمطرت سنبقى في البيت", accept=["if it rains we'll stay at home"]),
         w("She was walking when it started to rain", "🚶‍♀️", "كانت تمشي عندما بدأ المطر"),
         w("The man who painted this is famous", "🧑‍🎨", "الرجل الذي رسم هذه مشهور"),
         w("Neither Ali nor Sara was late", "⏰", "لا علي ولا سارة تأخرا"),
     ]},

    # ============================================================ adult (Kareem)
    {"id": "a1-words", "track": "adult", "title": "Everyday English words", "title_ar": "كلمات الإنجليزية اليومية",
     "emoji": "💼", "strictness": 0.86, "source": "Everyday English 1",
     "words": [
         w("formal", "👔", "رسمي"), w("informal", "👕", "غير رسمي"), w("opinion", "💭", "رأي"),
         w("discussion", "🗣️", "نقاش"), w("paragraph", "📄", "فقرة"), w("punctuation", "❗", "علامات الترقيم"),
         w("spelling", "🔤", "التهجئة"), w("summary", "📝", "ملخص"),
     ]},
    {"id": "a2-phrases", "track": "adult", "title": "Useful phrases", "title_ar": "عبارات مفيدة",
     "emoji": "🤝", "strictness": 0.82, "source": "Everyday English 1 - Speaking, Writing",
     "words": [
         w("Thank you for your email", "📧", "شكراً على بريدك"),
         w("Could you please send me the details", "📨", "هل يمكنك إرسال التفاصيل من فضلك؟"),
         w("In my opinion", "💭", "في رأيي"),
         w("I agree with you", "👍", "أتفق معك"),
         w("I would like to ask about the price", "💬", "أود أن أسأل عن السعر", accept=["i'd like to ask about the price"]),
         w("Best regards", "✍️", "مع أطيب التحيات"),
     ]},
]
