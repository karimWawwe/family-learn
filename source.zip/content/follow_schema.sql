-- ============================================================================
--  Parent follow report (latest version): lessons + speaking game + stories
--  + math games (times tables, clock). Generated into the newest migration.
-- ============================================================================

-- ---------------------------------------------------------------- follow report helpers

-- Speaking-game minutes per day, estimated from the saved tries:
-- time to the next try (max 60 s), 20 s for the last try of a session.
create or replace function app.speak_minutes(p_profile uuid, d1 date, d2 date, tz text) returns numeric
language sql stable security definer set search_path = '' as $$
  select coalesce(sum(case when nxt is null or nxt - created_at > interval '5 minutes' then 20
                           else least(extract(epoch from (nxt - created_at)), 60) end), 0) / 60.0
    from (select created_at, lead(created_at) over (order by created_at) nxt
            from public.speak_attempts where profile_id = p_profile) a
   where (created_at at time zone tz)::date between d1 and d2
$$;

-- Days (in the family time zone) with any saved activity.
create or replace function app.active_days(p_profile uuid, d1 date, d2 date, tz text) returns setof date
language sql stable security definer set search_path = '' as $$
  select distinct d from (
    select (started_at at time zone tz)::date d from public.lesson_attempts where profile_id = p_profile
    union all
    select (created_at at time zone tz)::date from public.speak_attempts where profile_id = p_profile
    union all
    select (started_at at time zone tz)::date from public.bedtime_listens where profile_id = p_profile
    union all
    select (created_at at time zone tz)::date from public.math_plays where profile_id = p_profile
  ) x where d between d1 and d2
$$;

-- All figures for one date range.
create or replace function app.follow_range(p_profile uuid, d1 date, d2 date, tz text) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  v_lesson numeric; v_story numeric; v_speak numeric; v_math numeric;
  r jsonb;
begin
  select coalesce(sum(app.attempt_minutes(a)), 0) into v_lesson
    from public.lesson_attempts a
   where a.profile_id = p_profile and a.finished_at is not null
     and (a.finished_at at time zone tz)::date between d1 and d2;
  select coalesce(sum(seconds), 0) / 60.0 into v_story
    from public.bedtime_listens where profile_id = p_profile
     and (started_at at time zone tz)::date between d1 and d2;
  v_speak := app.speak_minutes(p_profile, d1, d2, tz);
  v_math := app.math_minutes(p_profile, d1, d2, tz);

  select jsonb_build_object(
    'from', d1, 'to', d2,
    'minutes_lessons', round(v_lesson),
    'minutes_stories', round(v_story),
    'minutes_speaking', round(v_speak),
    'minutes_math', round(v_math),
    'minutes_total', ceil(v_lesson + v_story + v_speak + v_math),
    'math_rounds', (select count(*) from public.math_plays
                     where profile_id = p_profile and (created_at at time zone tz)::date between d1 and d2),
    'math_correct', (select coalesce(sum(correct), 0) from public.math_plays
                      where profile_id = p_profile and (created_at at time zone tz)::date between d1 and d2),
    'math_total', (select coalesce(sum(total), 0) from public.math_plays
                    where profile_id = p_profile and (created_at at time zone tz)::date between d1 and d2),
    'days_used', (select count(*) from app.active_days(p_profile, d1, d2, tz)),
    'stories_listened', (select count(*) from public.bedtime_listens
                          where profile_id = p_profile and (started_at at time zone tz)::date between d1 and d2),
    'stories_completed', (select count(*) from public.bedtime_listens
                           where profile_id = p_profile and completed_at is not null
                             and (completed_at at time zone tz)::date between d1 and d2),
    'values', (select coalesce(jsonb_agg(distinct s.value_name), '[]'::jsonb)
                 from public.bedtime_listens l join public.bedtime_stories s on s.id = l.story_id
                where l.profile_id = p_profile and l.completed_at is not null
                  and (l.completed_at at time zone tz)::date between d1 and d2),
    'lessons_done', (select count(*) from public.lesson_attempts
                      where profile_id = p_profile and finished_at is not null
                        and (finished_at at time zone tz)::date between d1 and d2),
    'questions', (select count(*) from public.answers an join public.lesson_attempts a on a.id = an.attempt_id
                   where a.profile_id = p_profile and (an.answered_at at time zone tz)::date between d1 and d2),
    'correct', (select count(*) filter (where an.is_correct) from public.answers an
                  join public.lesson_attempts a on a.id = an.attempt_id
                 where a.profile_id = p_profile and (an.answered_at at time zone tz)::date between d1 and d2),
    'speak_words', (select count(distinct lower(word)) from public.speak_attempts
                     where profile_id = p_profile and result = 'correct'
                       and (created_at at time zone tz)::date between d1 and d2),
    'speak_levels', (select count(*) from public.speak_plays
                      where profile_id = p_profile and (created_at at time zone tz)::date between d1 and d2),
    'speak_points', (select coalesce(sum(points), 0) from public.speak_plays
                      where profile_id = p_profile and (created_at at time zone tz)::date between d1 and d2)
  ) into r;
  return r;
end $$;

revoke all on function app.speak_minutes(uuid, date, date, text) from public, anon;
revoke all on function app.active_days(uuid, date, date, text) from public, anon;
revoke all on function app.follow_range(uuid, date, date, text) from public, anon;
grant execute on function app.speak_minutes(uuid, date, date, text) to authenticated;
grant execute on function app.active_days(uuid, date, date, text) to authenticated;
grant execute on function app.follow_range(uuid, date, date, text) to authenticated;

-- ---------------------------------------------------------------- follow report (parent only)
-- p_period: day (today vs yesterday) | week (last 7 days vs the 7 before)
--           | month (last 30 days vs the 30 before)
create or replace function public.parent_follow(p_profile uuid, p_period text) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare
  tz    text;
  today date;
  n     int;
  v_xp  int;
  v_speak_pts int;
  v_math_pts int;
  v_stories_done int;
  v_top text;
  r     jsonb;
begin
  if not app.i_am_parent() then perform app.fail('parent_only'); end if;
  perform app.require_profile(p_profile);
  tz := app.profile_tz(p_profile);
  today := (now() at time zone tz)::date;
  n := case p_period when 'day' then 1 when 'month' then 30 else 7 end;

  select coalesce(sum(xp), 0) into v_xp from public.lesson_attempts
   where profile_id = p_profile and finished_at is not null;
  -- best result of each speaking stage (replays improve it, they don't add up)
  v_speak_pts := app.speak_best_points(p_profile);
  v_math_pts := app.math_best_points(p_profile);
  select count(*) into v_stories_done from public.bedtime_listens
   where profile_id = p_profile and completed_at is not null;
  select s.value_name into v_top
    from public.bedtime_listens l join public.bedtime_stories s on s.id = l.story_id
   where l.profile_id = p_profile and l.completed_at is not null
   group by s.value_name order by count(*) desc, max(l.completed_at) desc limit 1;

  r := jsonb_build_object(
    'period', case n when 1 then 'day' when 30 then 'month' else 'week' end,
    'today', today,
    'current', app.follow_range(p_profile, today - (n - 1), today, tz),
    'previous', app.follow_range(p_profile, today - (2 * n - 1), today - n, tz),
    'by_day', (
      select jsonb_agg(jsonb_build_object(
               'day', d,
               'minutes', ceil(
                   coalesce((select sum(app.attempt_minutes(a)) from public.lesson_attempts a
                              where a.profile_id = p_profile and a.finished_at is not null
                                and (a.finished_at at time zone tz)::date = d), 0)
                 + coalesce((select sum(seconds) / 60.0 from public.bedtime_listens
                              where profile_id = p_profile and (started_at at time zone tz)::date = d), 0)
                 + app.speak_minutes(p_profile, d, d, tz)
                 + app.math_minutes(p_profile, d, d, tz))) order by d)
        from generate_series(today - (greatest(n, 7) - 1), today, interval '1 day') g(dd),
             lateral (select g.dd::date d) x),
    'totals', jsonb_build_object(
      'minutes', (app.follow_range(p_profile, '2000-01-01'::date, today, tz) ->> 'minutes_total')::int,
      'days', (select count(*) from app.active_days(p_profile, '2000-01-01'::date, today, tz)),
      'stories_listened', (select count(*) from public.bedtime_listens where profile_id = p_profile),
      'stories_completed', v_stories_done,
      'distinct_stories', (select count(distinct story_id) from public.bedtime_listens
                            where profile_id = p_profile and completed_at is not null),
      'lessons_done', (select count(distinct lesson_id) from public.lesson_attempts
                        where profile_id = p_profile and finished_at is not null),
      'speak_words', (select count(distinct lower(word)) from public.speak_attempts
                       where profile_id = p_profile and result = 'correct'),
      'speak_levels_done', (select count(distinct level_id) from public.speak_plays where profile_id = p_profile)),
    'progress', jsonb_build_object(
      'points', v_xp + v_speak_pts + v_math_pts + 20 * v_stories_done,
      'lesson_xp', v_xp, 'speak_points', v_speak_pts, 'math_points', v_math_pts, 'story_points', 20 * v_stories_done,
      'level', 1 + (v_xp + v_speak_pts + v_math_pts + 20 * v_stories_done) / 500,
      'into_level', (v_xp + v_speak_pts + v_math_pts + 20 * v_stories_done) % 500),
    'last_story', (
      select jsonb_build_object('id', s.id, 'title', s.title, 'emoji', s.emoji, 'value', s.value_name,
                                'completed', l.completed_at is not null, 'at', l.updated_at)
        from public.bedtime_listens l join public.bedtime_stories s on s.id = l.story_id
       where l.profile_id = p_profile order by l.updated_at desc limit 1),
    'favorites', (
      select coalesce(jsonb_agg(jsonb_build_object('id', s.id, 'title', s.title, 'emoji', s.emoji)
                                order by f.created_at desc), '[]'::jsonb)
        from public.bedtime_favorites f join public.bedtime_stories s on s.id = f.story_id
       where f.profile_id = p_profile),
    'values_all', (
      select coalesce(jsonb_agg(jsonb_build_object('value', v.value_name, 'count', v.n) order by v.n desc), '[]'::jsonb)
        from (select s.value_name, count(*) n
                from public.bedtime_listens l join public.bedtime_stories s on s.id = l.story_id
               where l.profile_id = p_profile and l.completed_at is not null
               group by s.value_name) v),
    'top_value', v_top,
    'last_activity', (
      select jsonb_build_object('kind', x.kind, 'title', x.title, 'at', x.at)
        from (
          select 'lesson' kind, le.title, a.finished_at at
            from public.lesson_attempts a join public.lessons le on le.id = a.lesson_id
           where a.profile_id = p_profile and a.finished_at is not null
          union all
          select 'speak', sl.title, sa.created_at
            from public.speak_attempts sa join public.speak_levels sl on sl.id = sa.level_id
           where sa.profile_id = p_profile
          union all
          select 'story', s.title, coalesce(l.completed_at, l.updated_at)
            from public.bedtime_listens l join public.bedtime_stories s on s.id = l.story_id
           where l.profile_id = p_profile
          union all
          select 'math', case mp.game when 'times' then 'جدول الضرب' else 'تعلّم الوقت' end, mp.created_at
            from public.math_plays mp
           where mp.profile_id = p_profile
        ) x order by x.at desc limit 1),
    -- a story to suggest: not finished yet; same value as the favourite theme first,
    -- then a value the child has not met yet, then any unfinished story.
    'suggestion', (
      select jsonb_build_object('id', s.id, 'title', s.title, 'emoji', s.emoji, 'value', s.value_name)
        from public.bedtime_stories s
       where app.bedtime_fits(p_profile, s)
         and not exists (select 1 from public.bedtime_listens l
                          where l.profile_id = p_profile and l.story_id = s.id and l.completed_at is not null)
       order by (s.value_name = v_top) desc nulls last,
                exists (select 1 from public.bedtime_listens l2 join public.bedtime_stories s2 on s2.id = l2.story_id
                         where l2.profile_id = p_profile and l2.completed_at is not null
                           and s2.value_name = s.value_name),
                s.sort
       limit 1),
    'tricky_words', (
      select coalesce(jsonb_agg(t.word), '[]'::jsonb)
        from (select word from public.speak_attempts
               where profile_id = p_profile and result in ('close', 'wrong')
                 and created_at > now() - interval '14 days'
               group by word order by count(*) desc limit 3) t),
    'weak_skills', (
      select coalesce(jsonb_agg(w.name), '[]'::jsonb)
        from (select sk.name
                from public.answers an
                join public.lesson_attempts a on a.id = an.attempt_id
                join public.questions q on q.id = an.question_id
                join public.skills sk on sk.code = q.skill
               where a.profile_id = p_profile and an.answered_at > now() - interval '30 days'
               group by sk.name
              having count(*) >= 3 and avg(case when an.is_correct then 1.0 else 0 end) < 0.6
               order by avg(case when an.is_correct then 1.0 else 0 end) limit 2) w)
  );
  return r;
end $$;

revoke all on function public.parent_follow(uuid, text) from public, anon;
grant execute on function public.parent_follow(uuid, text) to authenticated;
