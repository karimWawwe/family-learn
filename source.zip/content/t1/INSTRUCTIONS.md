# Task: turn one Egyptian MoE school book (Term 1, 2026/2027) into app lessons

You build ONE Python module for the "Family Learn" kids' learning app, from ONE school book.
The book's pages are JPEG images: /home/claude/books/<key>/p001.jpg ... (look at them with the Read tool).
English books can also be OCR'd quickly: `tesseract /home/claude/books/<key>/p030.jpg - -l eng 2>/dev/null`.
(No Arabic OCR is installed: read Arabic pages visually with the Read tool.)

## Steps
1. Find the table of contents (first ~10 pages) and list the units and lessons of the book.
2. Read the lesson pages (skim; you don't need every exercise page) to learn what each lesson teaches:
   vocabulary, rules, facts, values, grammar points, worked methods.
3. Write `/home/claude/fl/src/content/t1/<key>.py` (format below).
4. Run `cd /home/claude/fl/src/content && python3 t1/validate.py <key>` until it prints OK.
5. Reply with: the course outline (units -> lessons with question counts) and any book pages you could not read.

## Coverage
- Follow the book's own order: one app *unit* per book unit (or per big theme/chapter),
  one app *lesson* per book lesson (merge very small ones, split very big ones). Cover the WHOLE term-1 book.
- 5-8 questions per lesson (validator allows 4-10). Mix types.
- Lesson `minutes`: 6-10.

## Accuracy rules (very important)
- Questions must test exactly what THIS book teaches at this grade, with ONE clearly correct answer
  and plausible wrong options. Never invent facts. If unsure of a fact, leave that question out.
- Write ORIGINAL practice questions on the book's topics. Do not copy the book's passages, stories or
  exercises word for word (single words, terms, names, short rules are fine).
- Religion books: never invent or paraphrase a Quran verse or hadith as a quote. You may quote a short
  verse / hadith ONLY if it is printed in the book and you copy it exactly; otherwise ask about meaning,
  values, rulings, stories and facts taught in the lesson. Be respectful (ﷺ after the Prophet's name,
  رضي الله عنه/عنها for companions where the book uses it).
- Arabic-language content: write correct Modern Standard Arabic for kids, add tashkeel only where it
  removes ambiguity (e.g. grammar questions). Keep sentences short for the grade.

## Module format
```python
# -*- coding: utf-8 -*-
"""<Book name> - <Grade>, Term 1 (Egypt MoE 2026/2027). Original practice questions on the book's lessons."""

SKILLS = {
    "<prefix>.<code>": "<short skill name in the course language>",   # 6-20 skills, each used at least once
}

COURSE = {
    "code": "<course code>", "subject": "<subject>", "audience": "child",
    "grade_min": <g>, "grade_max": <g>,
    "title": "<title>", "level": "<level label>",
    "units": [
        {"title": "<unit title>", "lessons": [
            {"title": "<lesson title>", "minutes": 8, "questions": [
                {"t": "mc", "skill": "...", "prompt": "...", "options": ["a", "b", "c", "d"], "answer": 1,
                 "explain": "optional: why (shown after answering)", "hint": "optional"},
                {"t": "tf", "skill": "...", "prompt": "a statement", "answer": False, "explain": "..."},
                {"t": "match", "skill": "...", "prompt": "...", "left": ["a", "b", "c"], "right": ["1", "2", "3"]},  # 3-5 pairs, left[i] matches right[i], right items unique
                {"t": "order", "skill": "...", "prompt": "...", "order": ["first", "second", "third"]},  # 3-6 items, correct order
                {"t": "drag", "skill": "...", "prompt": "...", "before": "text before the gap ", "after": " text after",
                 "tokens": ["right", "wrong1", "wrong2"], "answer": "right"},
                {"t": "read", "skill": "...", "prompt": "question about the passage", "passage": "short ORIGINAL passage",
                 "options": [...], "answer": 0},
                # English/Math courses only:
                {"t": "fill", "skill": "...", "prompt": "...", "before": "...", "after": "...", "accepted": ["answer", "alt spelling"]},
                {"t": "word", "skill": "...", "prompt": "a word problem", "answer": 42, "unit": "cm"},  # numeric answer
            ]},
        ]},
    ],
}
```
Rules the validator checks: options unique, answer index in range, tf answer is bool, drag answer is in tokens,
match pairs 2+ with unique right side, every skill used, Arabic courses (arabic/religion/social) may only use
mc, tf, match, order, drag, read. Use `False`/`True` (Python booleans). The file must be valid Python
(watch quotes inside strings — use double quotes outside and avoid unescaped double quotes inside).

## Language
- English and Math courses: prompts/options in English (simple, for the grade). Add a short Arabic gloss in
  `hint` or `explain` for hard words, like: "explain": "A helmet keeps your head safe. (خوذة)".
- Arabic, Religion, Social Studies courses: everything in Arabic.
