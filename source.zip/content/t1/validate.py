#!/usr/bin/env python3
"""Checks one Term-1 book module:  python3 content/t1/validate.py ar3

Each module (content/t1/<key>.py) defines:
  SKILLS = {"<prefix>.<code>": "Skill name", ...}
  COURSE = {"code", "subject", "audience", "grade_min", "grade_max", "title", "level", "units": [...]}
Same question format as content/book_content.py.
"""
import importlib
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
import build_content as bc  # noqa: E402

ARABIC_OK = {"mc", "tf", "match", "order", "drag", "read"}
SUBJECTS = {"english", "math", "arabic", "religion", "social"}


def check(key):
    m = importlib.import_module(key)
    bc.SKILLS = m.SKILLS
    c = m.COURSE
    assert c["subject"] in SUBJECTS, c["subject"]
    for k in ("code", "title", "level", "grade_min", "grade_max", "audience", "units"):
        assert k in c, k
    n_l = n_q = 0
    for ui, u in enumerate(c["units"], 1):
        assert u["title"] and u["lessons"], f"unit {ui} empty"
        for li, l in enumerate(u["lessons"], 1):
            n_l += 1
            qs = l["questions"]
            assert 4 <= len(qs) <= 10, f"{u['title']} / {l['title']}: {len(qs)} questions (need 4-10)"
            assert isinstance(l.get("minutes"), int)
            for qi, q in enumerate(qs, 1):
                qid = f"{c['code']}.u{ui}.l{li}.q{qi}"
                bc.convert(q, qid)
                if c["subject"] in ("arabic", "religion", "social"):
                    assert q["t"] in ARABIC_OK, f"{qid}: type {q['t']} not allowed for Arabic content"
                n_q += 1
    used = {q["skill"] for u in c["units"] for l in u["lessons"] for q in l["questions"]}
    unused = set(m.SKILLS) - used
    assert not unused, f"unused skills: {unused}"
    print(f"OK {key}: {len(c['units'])} units, {n_l} lessons, {n_q} questions")


if __name__ == "__main__":
    for k in sys.argv[1:]:
        check(k)
