# -*- coding: utf-8 -*-
"""English Student Book - Primary 3, Term 1 (Egypt MoE 2026/2027). Original practice questions on the book's lessons."""

SKILLS = {
    "eng3t1.greet": "Greetings and introductions",
    "eng3t1.class": "Classroom rules and phrases",
    "eng3t1.describe": "Describing people",
    "eng3t1.tobe": "Verb to be: am / is / are",
    "eng3t1.routine": "Daily routines",
    "eng3t1.presimple": "Present simple (he/she/it + s)",
    "eng3t1.family": "Family members",
    "eng3t1.possess": "my / his / her",
    "eng3t1.jobs": "Jobs",
    "eng3t1.celebr": "Celebrations and traditions",
    "eng3t1.places": "Places and landmarks",
    "eng3t1.prep": "Prepositions of place",
    "eng3t1.punct": "Capital letters and punctuation",
    "eng3t1.past": "Past simple",
    "eng3t1.feel": "Emotions",
    "eng3t1.team": "Teamwork, chores and action verbs",
    "eng3t1.goals": "Goals and success",
    "eng3t1.prescont": "Present continuous",
    "eng3t1.phonics": "Phonics",
    "eng3t1.reading": "Reading comprehension",
}

P = "eng3t1."


def mc(skill, prompt, options, answer, explain=None, hint=None):
    q = {"t": "mc", "skill": P + skill, "prompt": prompt, "options": options, "answer": answer}
    if explain:
        q["explain"] = explain
    if hint:
        q["hint"] = hint
    return q


def tf(skill, prompt, answer, explain=None):
    q = {"t": "tf", "skill": P + skill, "prompt": prompt, "answer": answer}
    if explain:
        q["explain"] = explain
    return q


def match(skill, prompt, left, right):
    return {"t": "match", "skill": P + skill, "prompt": prompt, "left": left, "right": right}


def order(skill, prompt, items):
    return {"t": "order", "skill": P + skill, "prompt": prompt, "order": items}


def drag(skill, prompt, before, after, tokens, answer, explain=None):
    q = {"t": "drag", "skill": P + skill, "prompt": prompt, "before": before, "after": after,
         "tokens": tokens, "answer": answer}
    if explain:
        q["explain"] = explain
    return q


def fill(skill, prompt, before, after, accepted, hint=None):
    q = {"t": "fill", "skill": P + skill, "prompt": prompt, "before": before, "after": after,
         "accepted": accepted}
    if hint:
        q["hint"] = hint
    return q


def read(skill, prompt, passage, options, answer, explain=None):
    q = {"t": "read", "skill": P + skill, "prompt": prompt, "passage": passage,
         "options": options, "answer": answer}
    if explain:
        q["explain"] = explain
    return q


def word(skill, prompt, answer, unit=None):
    q = {"t": "word", "skill": P + skill, "prompt": prompt, "answer": answer}
    if unit:
        q["unit"] = unit
    return q


def lesson(title, questions, minutes=8):
    return {"title": title, "minutes": minutes, "questions": questions}


# ---------------------------------------------------------------- Unit 1
U1 = {"title": "Unit 1: Let's Learn Together!", "lessons": [
    lesson("Greetings and Introductions", [
        mc("greet", "It is 8 o'clock in the morning. You meet your teacher. What do you say?",
           ["Good morning!", "Goodbye!", "See you later!", "Good night!"], 0,
           "We say \"Good morning\" in the morning. (صباح الخير)"),
        mc("greet", "Your friend asks: \"How are you?\" What is the best answer?",
           ["I am 8 years old.", "I am fine, thank you.", "My name is Ali.", "I am from Egypt."], 1,
           "\"How are you?\" asks how you feel. (كيف حالك؟)"),
        match("greet", "Match each phrase to when we use it.",
              ["Nice to meet you.", "See you later!", "How are you?", "Good morning!"],
              ["When you meet someone new", "When you say goodbye", "When you check on someone",
               "When you meet in the morning"]),
        drag("greet", "Complete the sentence.", "I am 8 ", " old.", ["years", "name", "fine"], "years"),
        fill("greet", "Write the missing word.", "My ", " is Adam.", ["name"],
             hint="We say this to tell people what we are called. (اسم)"),
        order("greet", "Put the dialog in order.",
              ["Hello! What's your name?", "My name is Hana.", "Nice to meet you, Hana!",
               "Nice to meet you too!"]),
        tf("greet", "\"Goodbye!\" is what we say when we leave.", True, "Goodbye = مع السلامة"),
    ]),
    lesson("Classroom Rules", [
        mc("class", "You want to answer the teacher's question. What should you do?",
           ["Shout the answer", "Raise your hand", "Run to the board", "Close your book"], 1,
           "Raise your hand = ارفع يدك"),
        mc("class", "When the teacher talks, you should ...",
           ["listen carefully", "stand up", "eat", "shout"], 0, "Listen carefully = استمع جيدًا"),
        mc("class", "You need to use the bathroom. What do you say?",
           ["Can I draw?", "Is it break time?", "May I go to the bathroom?", "Sit down."], 2,
           "We ask for permission politely with \"May I ...?\""),
        tf("class", "\"Don't shout\" is a good classroom rule.", True),
        tf("class", "We should throw papers on the classroom floor.", False,
           "Keep your classroom clean! (حافظ على نظافة فصلك)"),
        match("class", "Match the action to the rule.",
              ["A boy is running in class.", "A girl is shouting.", "There is paper on the floor.",
               "A boy takes his friend's pencil."],
              ["Sit down.", "Don't shout.", "Keep your classroom clean.", "Be kind."]),
        mc("phonics", "Which word starts with \"wh\"?", ["whale", "tale", "sale", "hall"], 0,
           "\"wh\" says /w/: what, when, where, whale, white."),
        drag("phonics", "Choose the question word.", "", " is your name?",
             ["What", "Where", "When"], "What"),
        fill("phonics", "Write the missing letters.", "My shirt is ", "ite.", ["wh"],
             hint="White = أبيض"),
    ]),
    lesson("Describing People", [
        match("describe", "Match the word to its meaning.",
              ["funny", "shy", "helpful", "tall"],
              ["makes people laugh", "quiet and doesn't talk a lot", "helps others",
               "high in height"]),
        mc("describe", "Ola always says \"please\" and \"thank you\". She is ...",
           ["polite", "angry", "short", "tired"], 0, "Polite = مؤدب"),
        mc("describe", "Ramy can reach the top shelf. He is ...", ["short", "tall", "shy", "funny"], 1,
           "Tall = طويل"),
        mc("describe", "Which words describe how someone looks?",
           ["curly hair, brown eyes", "funny, polite", "friendly, helpful", "shy, kind"], 0,
           "Hair and eyes are about looks. Funny or kind is about personality."),
        tf("describe", "\"Straight hair\" is the opposite of \"curly hair\".", True,
           "Curly = مجعد, straight = ناعم/مفرود"),
        drag("describe", "Complete the sentence.", "He says hello to everyone. He is ", ".",
             ["friendly", "shy", "short"], "friendly"),
        read("reading", "What does Hoda look like?",
             "This is my cousin Hoda. She has short black hair and big brown eyes. She is kind. "
             "She shares her crayons with everyone in class.",
             ["She has short black hair.", "She has long curly hair.", "She has blue eyes.",
              "She is very tall."], 0),
        read("reading", "Why is Hoda kind?",
             "This is my cousin Hoda. She has short black hair and big brown eyes. She is kind. "
             "She shares her crayons with everyone in class.",
             ["She tells jokes.", "She shares her crayons.", "She runs fast.", "She is quiet."], 1),
    ]),
    lesson("Verb To Be", [
        mc("tobe", "I ___ eight years old.", ["is", "are", "am", "be"], 2, "I → am"),
        mc("tobe", "She ___ my sister.", ["am", "is", "are", "be"], 1, "He / She / It → is"),
        mc("tobe", "We ___ in the classroom.", ["am", "is", "are", "be"], 2, "We / You / They → are"),
        match("tobe", "Match the subject with the right verb.", ["I", "He", "They"], ["am", "is", "are"]),
        drag("tobe", "Choose the right word.", "You ", " very kind.", ["are", "is", "am"], "are"),
        fill("tobe", "Write am, is or are.", "It ", " a cat.", ["is"]),
        order("tobe", "Put the words in order to make a sentence.", ["He", "is", "from", "Egypt."]),
        tf("tobe", "\"They is my friends.\" is a correct sentence.", False,
           "Correct: They are my friends."),
    ]),
    lesson("Daily Routines", [
        order("routine", "Put the day in order.",
              ["wake up", "have breakfast", "go to school", "do my homework", "go to sleep"]),
        match("routine", "Match the routine to its meaning.",
              ["wake up", "get dressed", "make my bed", "do my homework"],
              ["stop sleeping", "put on clothes", "tidy the sheets on my bed", "do schoolwork at home"]),
        mc("routine", "What do you use to brush your teeth?",
           ["a toothbrush", "a pillow", "a pencil", "a ball"], 0, "Toothbrush = فرشاة أسنان"),
        drag("routine", "Complete the sentence.", "After school, I do my ", ".",
             ["homework", "bed", "breakfast"], "homework"),
        read("reading", "What time does Karim wake up?",
             "I am Karim. I wake up at 6:30 every day. I wash my face and have breakfast with my "
             "sister. Then we go to school by bus. In the evening, I read a story and go to sleep.",
             ["6:30", "7:00", "8:00", "9:30"], 0),
        read("reading", "How does Karim go to school?",
             "I am Karim. I wake up at 6:30 every day. I wash my face and have breakfast with my "
             "sister. Then we go to school by bus. In the evening, I read a story and go to sleep.",
             ["by car", "on foot", "by bus", "by train"], 2),
        tf("routine", "We have breakfast in the evening.", False, "Breakfast is the morning meal. (الفطور)"),
    ]),
    lesson("Present Simple for Routines", [
        mc("presimple", "He ___ football every day.", ["play", "plays", "playing", "is play"], 1,
           "With he / she / it we add -s: plays."),
        mc("presimple", "They ___ to school every day.", ["go", "goes", "going", "is go"], 0,
           "With I / you / we / they there is no -s."),
        mc("presimple", "She ___ her teeth every morning.", ["brush", "brushs", "brushes", "brushing"], 2,
           "Verbs ending in ch, sh, x, ss, o take -es: brushes."),
        mc("presimple", "My brother ___ hard at school.", ["study", "studys", "studies", "studyes"], 2,
           "Consonant + y → change y to i and add -es: studies."),
        drag("presimple", "Choose the right verb.", "Judy ", " breakfast at 8 o'clock.",
             ["eats", "eat", "eating"], "eats"),
        fill("presimple", "Write the verb with he/she.", "Mariam ", " TV in the evening. (watch)",
             ["watches"], hint="watch → watches"),
        tf("presimple", "\"I wakes up at 7 a.m.\" is correct.", False, "Correct: I wake up at 7 a.m."),
        mc("presimple", "Which sentence is correct?",
           ["He go to school.", "He goes to school.", "He going to school.", "He gos to school."], 1),
    ]),
]}

# ---------------------------------------------------------------- Unit 2
U2 = {"title": "Unit 2: My Family and I", "lessons": [
    lesson("Meet My Family", [
        match("family", "Match the family word to its meaning.",
              ["aunt", "uncle", "cousin", "grandmother"],
              ["your mom's or dad's sister", "your mom's or dad's brother", "a child of your aunt or uncle",
               "your mom's or dad's mother"]),
        mc("family", "My father's father is my ...", ["uncle", "brother", "grandfather", "cousin"], 2,
           "Grandfather = جد"),
        mc("family", "Which one is NOT a family member?", ["sister", "mother", "hospital", "uncle"], 2),
        tf("family", "My mother's sister is my aunt.", True, "Aunt = خالة / عمة"),
        drag("family", "Complete the sentence.", "My ", " is a girl. She is my mom's daughter.",
             ["sister", "brother", "uncle"], "sister"),
        fill("family", "Write the family word.", "My dad's brother is my ", ".", ["uncle"],
             hint="عم"),
    ]),
    lesson("Possessive Words: my, his, her", [
        mc("possess", "Nader has a book. ___ book is new.", ["Her", "His", "My", "Your"], 1,
           "Nader is a boy → his"),
        mc("possess", "Amira has a kite. ___ kite is red.", ["His", "Her", "My", "Our"], 1,
           "Amira is a girl → her"),
        mc("possess", "I have a pet. ___ pet is a rabbit.", ["My", "His", "Her", "Their"], 0, "I → my"),
        match("possess", "Match the person with the right word.", ["I", "Omar", "Laila"], ["my", "his", "her"]),
        drag("possess", "Choose the right word.", "This is Laila. ", " dress is pink.",
             ["Her", "His", "My"], "Her"),
        order("possess", "Put the words in order.", ["My", "sister", "is", "kind."]),
        tf("possess", "\"Dina has a cat. His cat is cute.\" is correct.", False,
           "Dina is a girl, so we say: Her cat is cute."),
    ]),
    lesson("Family Traditions and Celebrations", [
        match("celebr", "Match the celebration to what we do or remember.",
              ["Sham El-Nessim", "6th of October", "Mother's Day"],
              ["We go to gardens and eat salted fish.", "We remember the brave Egyptian soldiers.",
               "We give our mothers presents."]),
        mc("celebr", "On which day do many Egyptian families go to the garden and eat salted fish?",
           ["Sham El-Nessim", "6th of October", "Mother's Day", "Eid Al-Fitr"], 0),
        mc("celebr", "Which day reminds us how brave the Egyptian soldiers are?",
           ["Mother's Day", "6th of October", "Sham El-Nessim", "New Year"], 1),
        tf("celebr", "Eid Al-Fitr comes after Ramadan.", True, "عيد الفطر يأتي بعد شهر رمضان"),
        read("reading", "What does Salma's family do on Eid Al-Fitr?",
             "On Eid Al-Fitr, Salma wears new clothes. She visits her grandmother with her family. "
             "They eat cookies together, and Salma is very happy.",
             ["They visit her grandmother.", "They go to the zoo.", "They swim in the sea.",
              "They stay at school."], 0),
        mc("phonics", "Which word has \"x\" making the /gz/ sound like in \"exam\"?",
           ["exit", "box", "fox", "six"], 0, "exam, exit, example, exist → /gz/"),
        fill("phonics", "Write the missing letter.", "I have an e", "am today.", ["x"]),
    ]),
    lesson("My Family Helps Me Grow", [
        read("reading", "Who helps Nada with her homework?",
             "My name is Nada. My mother cooks us food every day. My big brother helps me with my "
             "homework. My grandfather tells me stories at night. My family helps me grow.",
             ["her mother", "her brother", "her grandfather", "her teacher"], 1),
        read("reading", "What does Nada's grandfather do?",
             "My name is Nada. My mother cooks us food every day. My big brother helps me with my "
             "homework. My grandfather tells me stories at night. My family helps me grow.",
             ["He cooks food.", "He drives her to school.", "He tells her stories.", "He plays football."], 2),
        tf("family", "Our family helps us grow and learn.", True),
        drag("family", "Complete the sentence.", "My grandmother ", " me a story.",
             ["reads", "eats", "sleeps"], "reads"),
        mc("phonics", "In which word does \"ph\" sound like /f/?", ["phone", "pen", "hat", "top"], 0,
           "ph = /f/: phone, photo, elephant, graph, alphabet."),
        fill("phonics", "Write the missing letters.", "We saw a big ele", "ant at the zoo.", ["ph"]),
        match("phonics", "Match the riddle to the word.",
              ["You use me to call a friend.", "I am a big grey animal with a long trunk.",
               "A, B, C ... all the letters."],
              ["phone", "elephant", "alphabet"]),
    ]),
    lesson("Jobs in My Family", [
        match("jobs", "Match the job to what the person does.",
              ["doctor", "pilot", "farmer", "baker", "teacher"],
              ["helps sick people", "flies a plane", "grows vegetables", "makes bread", "helps students learn"]),
        mc("jobs", "Who flies the airplane?", ["a pilot", "a baker", "a farmer", "a doctor"], 0,
           "Pilot = طيار"),
        mc("jobs", "My uncle makes delicious bread. He is a ...", ["teacher", "baker", "pilot", "doctor"], 1,
           "Baker = خباز"),
        drag("jobs", "Complete the sentence.", "My aunt works at a hospital. She is a ", ".",
             ["doctor", "farmer", "pilot"], "doctor"),
        fill("jobs", "Write the job.", "A ", " works at a school and helps students learn.", ["teacher"]),
        order("jobs", "Put the words in order.", ["He", "wants", "to", "be", "a", "doctor."]),
        tf("jobs", "A farmer works on a farm.", True, "Farmer = مزارع"),
    ]),
]}

# ---------------------------------------------------------------- Unit 3
U3 = {"title": "Unit 3: New Adventures", "lessons": [
    lesson("Places Around Me", [
        match("places", "Where do you go?",
              ["to buy food", "to read books", "to take a train", "to see old things"],
              ["supermarket", "library", "train station", "museum"]),
        mc("places", "Where do you play with your friends?", ["park", "library", "train station", "museum"], 0),
        mc("places", "Where do you live?", ["house", "supermarket", "museum", "zoo"], 0),
        read("reading", "Where did Tarek go first?",
             "On Friday, Tarek and his dad left home early. First, they went to the park to play. "
             "Then, they bought fruit at the supermarket. After lunch, they visited the museum.",
             ["the museum", "the park", "the supermarket", "the library"], 1),
        read("reading", "What did they buy?",
             "On Friday, Tarek and his dad left home early. First, they went to the park to play. "
             "Then, they bought fruit at the supermarket. After lunch, they visited the museum.",
             ["books", "toys", "fruit", "tickets"], 2),
        fill("places", "Write the place.", "We borrow books from the ", ".", ["library"],
             hint="مكتبة"),
        mc("phonics", "Which word ends with a double consonant?", ["buzz", "bus", "cat", "pen"], 0,
           "Short words with a short vowel often end in ff, ll, ss, zz: buzz, bell, miss, off."),
        fill("phonics", "Write the missing letters.", "The be", " rings at school.", ["ll"]),
    ]),
    lesson("Egypt's Landmarks", [
        match("places", "Match the landmark to its city.",
              ["The Pyramids", "Alexandria Library", "Cairo Tower"],
              ["Giza", "Alexandria", "Cairo"]),
        mc("places", "Where can you read many books in Alexandria?",
           ["Alexandria Library", "Cairo Tower", "The Pyramids", "The zoo"], 0),
        tf("places", "The Pyramids are in Giza.", True, "الأهرامات في الجيزة"),
        read("reading", "Where did Ziad go first?",
             "Ziad visited the Cairo Tower with his family. They saw the whole city from the top. "
             "Next, they went to the Pyramids of Giza and rode a camel. Ziad loved his trip.",
             ["the Pyramids", "Cairo Tower", "Alexandria Library", "a museum"], 1),
        read("reading", "What did Ziad ride?",
             "Ziad visited the Cairo Tower with his family. They saw the whole city from the top. "
             "Next, they went to the Pyramids of Giza and rode a camel. Ziad loved his trip.",
             ["a horse", "a bike", "a camel", "a train"], 2),
        mc("phonics", "Which word has \"ck\" making the /k/ sound?", ["duck", "dog", "pen", "sun"], 0,
           "ck = /k/ at the end of a word: duck, sock, back, neck, truck."),
        fill("phonics", "Write the missing letters.", "A big tru", " is on the road.", ["ck"]),
    ]),
    lesson("Capital Letters and Punctuation", [
        mc("punct", "Which sentence is written correctly?",
           ["we went to the park.", "We went to the park.", "We went to the park?", "we went to the park"], 1,
           "Start with a capital letter and end with a period (.)."),
        mc("punct", "Which mark ends this question: \"Where is the library\"",
           [".", "?", ",", "!"], 1, "Questions end with a question mark (?)."),
        drag("punct", "Choose the right mark.", "I saw the Pyramids with my family", "",
             [".", "?"], "."),
        drag("punct", "Choose the right mark.", "Did you visit the Cairo Tower", "", ["?", "."], "?"),
        tf("punct", "Names of people, like Sara, start with a capital letter.", True),
        mc("punct", "Which sentence is correct?",
           ["is the shop open today?", "Is the shop open today.", "Is the shop open today?",
            "is the shop open today"], 2),
    ]),
    lesson("Prepositions of Place", [
        match("prep", "Match the word to its meaning.",
              ["in", "on", "under", "between", "behind"],
              ["inside something", "on top of something", "beneath something", "in the middle of two things",
               "at the back of something"]),
        mc("prep", "The cat is inside the box. The cat is ___ the box.", ["on", "in", "under", "behind"], 1),
        mc("prep", "The ball is beneath the table. The ball is ___ the table.",
           ["on", "under", "between", "in"], 1, "Under = تحت"),
        mc("prep", "Sara sits in the middle of Ali and Omar. She is ___ them.",
           ["between", "behind", "on", "under"], 0, "Between = بين"),
        drag("prep", "Choose the right word.", "The dog is ", " of the door, so I can see it.",
             ["in front", "under", "in"], "in front", ),
        tf("prep", "\"Next to\" means beside.", True, "Next to = بجانب"),
        read("prep", "Where did Hany find his ball?",
             "Hany lost his ball. He looked under the bed, but it was not there. He looked behind the "
             "door. Then he found it on the chair next to the window.",
             ["under the bed", "behind the door", "on the chair", "in the box"], 2),
    ]),
    lesson("A School Trip (Past Simple)", [
        mc("past", "Yesterday, I ___ to school.", ["walk", "walked", "walks", "walking"], 1,
           "Past: add -ed → walked."),
        mc("past", "What is the past of \"live\"?", ["lived", "liveed", "lives", "living"], 0,
           "Verbs ending in -e add only -d."),
        match("past", "Match the verb to its past form.",
              ["play", "jump", "dance", "clean"], ["played", "jumped", "danced", "cleaned"]),
        fill("past", "Write the past of the verb.", "My grandma ", " a cake last week. (bake)", ["baked"]),
        read("reading", "How did the class go to the farm?",
             "Last Sunday, our class visited a farm. We went by train. We saw cows, ducks and sheep. "
             "The ticket was 15 pounds. We ate cheese sandwiches and drank milk.",
             ["by bus", "by train", "by car", "on foot"], 1),
        word("reading", "Last Sunday, a class visited a farm. One ticket was 15 pounds. How much did 2 tickets cost?",
             30, "pounds"),
        tf("past", "\"Last week, we visit the zoo.\" is correct.", False, "Correct: we visited the zoo."),
    ]),
    lesson("Review: Units 1, 2 and 3", [
        mc("jobs", "A ___ grows vegetables.", ["farmer", "pilot", "doctor", "baker"], 0),
        mc("family", "Which word is the odd one out?", ["Mother", "Brother", "Uncle", "Hospital"], 3,
           "Hospital is a place, not a family member."),
        mc("tobe", "He ___ a pilot.", ["are", "am", "is", "be"], 2),
        mc("possess", "I have a bag. ___ bag is blue.", ["My", "Her", "His", "Your"], 0, "I → my"),
        mc("prep", "The book is on top of the table. The book is ___ the table.",
           ["on", "between", "under", "behind"], 0),
        match("phonics", "Match the sound to a word.", ["wh", "ph", "ck", "ss"],
              ["whale", "photo", "truck", "miss"]),
        order("places", "Put the words in order.", ["The", "supermarket", "is", "near", "my", "house."]),
    ]),
]}

# ---------------------------------------------------------------- Unit 4
U4 = {"title": "Unit 4: Let's Tell Stories!", "lessons": [
    lesson("How We Feel", [
        match("feel", "Match the feeling to the face.",
              ["happy", "sad", "angry", "scared", "tired"],
              ["big smile", "tears", "red face, shouting", "eyes wide open, hiding", "yawning"]),
        mc("feel", "Lina got a new bike for her birthday. She feels ...", ["sad", "excited", "bored", "angry"], 1,
           "Excited = متحمس"),
        mc("feel", "There is nothing to do. Ahmed feels ...", ["bored", "excited", "happy", "proud"], 0,
           "Bored = يشعر بالملل"),
        mc("feel", "Mai doesn't want to speak in front of the class. She feels ...",
           ["shy", "angry", "tired", "excited"], 0, "Shy = خجول"),
        drag("feel", "Complete the sentence.", "I played all day. Now I am ", ".",
             ["tired", "excited", "shy"], "tired"),
        tf("feel", "\"Scared\" means afraid.", True, "Scared = خائف"),
    ]),
    lesson("Adam and Omar in the Garden", [
        read("reading", "What was the problem?",
             "Hassan and Nour were in the garden. They heard a little bird crying. The bird was stuck "
             "in a tree. Hassan held the branch, and Nour helped the bird out. Then the bird flew away. "
             "They felt happy and proud.",
             ["A cat was lost.", "A bird was stuck in a tree.", "It was raining.", "They lost a ball."], 1),
        read("reading", "How did Hassan and Nour feel at the end?",
             "Hassan and Nour were in the garden. They heard a little bird crying. The bird was stuck "
             "in a tree. Hassan held the branch, and Nour helped the bird out. Then the bird flew away. "
             "They felt happy and proud.",
             ["sad and tired", "angry", "happy and proud", "bored"], 2),
        mc("past", "What is the past of \"go\"?", ["goed", "went", "goes", "gone"], 1,
           "Irregular verbs don't take -ed. go → went"),
        match("past", "Match the irregular verb to its past form.",
              ["is", "are", "see", "eat", "have"], ["was", "were", "saw", "ate", "had"]),
        mc("past", "Adam and Omar ___ playing in the garden when they heard a cat.", ["are", "were", "was", "is"], 1,
           "Adam and Omar = they → were"),
        order("reading", "Put the linking words in order.", ["First,", "Then,", "After that,", "Finally,"]),
        mc("phonics", "In which word does \"c\" make a hard /k/ sound?", ["cat", "city", "nice", "face"], 0,
           "Hard c before a, o, u: cat, cold, cup."),
    ]),
    lesson("A Helping Hand", [
        match("past", "Match the verb to its past form.", ["draw", "fall", "help", "go"],
              ["drew", "fell", "helped", "went"]),
        mc("past", "Yesterday, Sara ___ a picture with her pencil.", ["draw", "drew", "draws", "drawing"], 1, "draw → drew"),
        drag("team", "Choose the linking word.", "She was hurt, ", " her friend helped her.",
             ["but", "because", "or"], "but", "\"But\" shows something different. (لكن)"),
        drag("team", "Choose the linking word.", "Sara played on the swings. ", " she fell.",
             ["Then", "Because", "Or"], "Then", "\"Then\" tells what happens next. (ثم)"),
        mc("phonics", "In which word does \"c\" make a soft /s/ sound?", ["city", "cup", "coat", "cold"], 0,
           "Soft c before e, i, y: city, face, nice, pencil."),
        fill("phonics", "Write the missing letter.", "I like ri", "e with chicken.", ["c"]),
        tf("phonics", "In the word \"face\", the letter c sounds like /s/.", True),
    ]),
    lesson("A Big Win", [
        read("feel", "How did Mostafa feel before the race?",
             "Mostafa was nervous before his first swimming race. He was worried about being slow. "
             "But he swam fast and came first. He felt proud, and his family cheered.",
             ["nervous", "bored", "angry", "sleepy"], 0, "Nervous = متوتر"),
        read("feel", "How did Mostafa feel after he won?",
             "Mostafa was nervous before his first swimming race. He was worried about being slow. "
             "But he swam fast and came first. He felt proud, and his family cheered.",
             ["sad", "proud", "scared", "shy"], 1, "Proud = فخور"),
        mc("past", "His team ___ the game yesterday.", ["win", "won", "wins", "winning"], 1, "win → won"),
        mc("past", "In the match last Friday, he ___ a goal.", ["score", "scored", "scores", "scoring"], 1),
        mc("past", "After the match yesterday, he ___ proud.", ["feel", "felt", "feels", "feeled"], 1, "feel → felt"),
        drag("feel", "Choose the linking word.", "Omar was nervous ", " the match started.",
             ["when", "but", "or"], "when"),
        mc("punct", "Which sentence is written correctly?",
           ["omar scored a goal.", "Omar scored a goal.", "Omar scored a goal?", "omar scored a goal"], 1),
    ]),
]}

# ---------------------------------------------------------------- Unit 5
U5 = {"title": "Unit 5: Together Is Better", "lessons": [
    lesson("Teamwork and Chores", [
        match("team", "Match the word to its meaning.",
              ["share", "donate", "plant", "cheer", "tidy up"],
              ["give part of something to someone", "give things to help people", "put a seed into the ground",
               "shout to support someone", "make a place neat"]),
        mc("team", "Ahmed gives his old clothes to people who need them. He ___ clothes.",
           ["donates", "wins", "cheers", "plants"], 0, "Donate = يتبرع"),
        mc("team", "Sara gives some of her food to her sister. She ___ her food.",
           ["shares", "plants", "wins", "fixes"], 0, "Share = يشارك"),
        read("reading", "What do the children do first?",
             "Hala and Tamer help their dad on Saturday. First, they tidy up their bedroom. Then, they "
             "wash the dishes together. Dad smiles and says, \"Great teamwork!\"",
             ["They wash the dishes.", "They tidy up their bedroom.", "They go shopping.",
              "They watch TV."], 1),
        read("reading", "What does Dad say?",
             "Hala and Tamer help their dad on Saturday. First, they tidy up their bedroom. Then, they "
             "wash the dishes together. Dad smiles and says, \"Great teamwork!\"",
             ["Try again!", "Great teamwork!", "Go to bed!", "It's messy!"], 1),
        tf("team", "Chores are jobs we do at home, like cleaning.", True, "Chores = الأعمال المنزلية"),
    ]),
    lesson("Teamwork at School", [
        mc("team", "Which word is an action verb?", ["help", "happy", "tall", "blue"], 0,
           "Action verbs show what someone does."),
        mc("team", "They ___ the broken chair in class.", ["fix", "agree", "cry", "sleep"], 0, "Fix = يصلح"),
        mc("team", "We ___ the trip before the holiday.", ["plan", "fix", "jump", "cry"], 0,
           "Plan = يخطط"),
        drag("team", "Choose the action verb.", "Mariam ", " a book in the library.",
             ["finds", "agrees", "cries"], "finds"),
        mc("phonics", "Which word has a hard \"g\" like in \"game\"?", ["dog", "giraffe", "page", "huge"], 0,
           "Hard g before a, o, u or at the end: game, go, dog, gum."),
        fill("phonics", "Write the missing letter.", "The ", "um is sweet.", ["g"]),
        tf("team", "When we work as a team, we share ideas.", True),
    ]),
    lesson("Teamwork in Sports", [
        read("reading", "Who scored the goal?",
             "Nader and his friends played basketball. At first, everyone wanted the ball. Then the "
             "coach said, \"Pass the ball!\" Nader passed to Hazem, and Hazem scored. Everyone cheered.",
             ["Nader", "the coach", "Hazem", "nobody"], 2),
        read("reading", "What did the coach say?",
             "Nader and his friends played basketball. At first, everyone wanted the ball. Then the "
             "coach said, \"Pass the ball!\" Nader passed to Hazem, and Hazem scored. Everyone cheered.",
             ["Pass the ball!", "Go home!", "Run fast!", "Sit down!"], 0),
        order("reading", "Put the story in order.",
              ["Omar and his friends played football.", "The coach said, \"Work as a team!\"",
               "They passed the ball to each other.", "Karim scored a goal.", "Everyone cheered."]),
        mc("phonics", "Which word has a soft \"g\" like in \"giraffe\"?", ["Egypt", "game", "goat", "good"], 0,
           "Soft g before e, i, y: giraffe, Egypt, page, huge."),
        fill("phonics", "Write the missing letter.", "Open your book on pa", "e 10.", ["g"]),
        mc("punct", "Where do we put a comma?",
           ["Then, we played.", "Then we, played.", "Then we played,", ",Then we played."], 0,
           "We put a comma after First, Then, Finally."),
    ]),
    lesson("I Help My Community", [
        match("team", "Match the action to the place.",
              ["plant trees", "donate books", "clean the street"],
              ["in the garden", "to the library", "in the neighborhood"]),
        read("reading", "What do Rana and Adel plant?",
             "Rana and Adel want to help their town. First, they clean the street. Then, they plant "
             "flowers near the school. After that, they donate toys to children. Everyone is happy.",
             ["trees", "flowers", "vegetables", "grass"], 1),
        read("reading", "What do they donate?",
             "Rana and Adel want to help their town. First, they clean the street. Then, they plant "
             "flowers near the school. After that, they donate toys to children. Everyone is happy.",
             ["books", "clothes", "toys", "food"], 2),
        drag("team", "Complete the sentence.", "We can ", " flowers in the park.",
             ["plant", "eat", "sleep"], "plant"),
        tf("team", "Helping your community means only helping yourself.", False,
           "Community = المجتمع. We help other people too."),
        mc("punct", "Which sentence is correct?",
           ["first they clean the street.", "First, they clean the street.", "First they, clean the street",
            "first, they clean the street?"], 1),
    ]),
]}

# ---------------------------------------------------------------- Unit 6
U6 = {"title": "Unit 6: Dare to Dream", "lessons": [
    lesson("My Goal, My Dream", [
        match("goals", "Match the word to its meaning.",
              ["goal", "plan", "practice", "celebrate", "success"],
              ["something you want to achieve", "a way to get something done", "do something again and again",
               "show happiness for something good", "doing well and reaching your goal"]),
        mc("goals", "Karim wants to be a doctor one day. This is his ...", ["goal", "chore", "bed", "exam"], 0,
           "Goal = هدف"),
        mc("goals", "Nour ___ hard to be a great swimmer.", ["tries", "sleeps", "cries", "shouts"], 0,
           "Try = يحاول"),
        drag("goals", "Complete the sentence.", "Mariam ", " passing the exam with a party.",
             ["celebrates", "forgets", "breaks"], "celebrates"),
        read("reading", "What is Hamza doing now?",
             "Hamza wants to be a good runner. He is training every morning. Now, he is running in a "
             "race with his friends. He is feeling very proud.",
             ["He is sleeping.", "He is running in a race.", "He is reading.", "He is eating."], 1),
        mc("prescont", "Which sentence is in the present continuous?",
           ["He is scoring a goal.", "He scored a goal.", "He scores goals.", "He score a goal."], 0,
           "Present continuous = am / is / are + verb-ing. It shows what is happening now."),
    ]),
    lesson("A Day to Remember (Present Continuous)", [
        mc("prescont", "I ___ trying to be a better student.", ["am", "is", "are", "be"], 0),
        mc("prescont", "The boys ___ celebrating.", ["is", "am", "are", "was"], 2),
        mc("prescont", "Look! The cat ___ on the chair.", ["jumps", "jumped", "is jumping", "jump"], 2,
           "\"Look!\" means it is happening now."),
        fill("prescont", "Complete with the -ing form.", "Mai is ", " the dog gently. (touch)",
             ["touching"]),
        drag("prescont", "Choose the right verb.", "Now, she ", " her lunch.",
             ["is eating", "ate", "eats"], "is eating"),
        mc("phonics", "Which word starts with the cluster \"spl\"?", ["splash", "spring", "street", "screen"], 0,
           "Three-consonant clusters: spr, spl, str, scr."),
        match("phonics", "Match the start to the word.", ["spr", "spl", "str", "scr"],
              ["spring", "splash", "street", "screen"]),
        fill("phonics", "Write the missing cluster.", "We watch cartoons on the ", "een.", ["scr"]),
    ]),
    lesson("Practice Brings Success", [
        read("reading", "What is Dalia learning?",
             "Dalia is learning how to swim. She is practicing every day after school. First, she is "
             "holding the side of the pool. Then, she is kicking her legs. Now, she is swimming alone!",
             ["to ride a bike", "to swim", "to draw", "to cook"], 1),
        read("reading", "What is Dalia doing now?",
             "Dalia is learning how to swim. She is practicing every day after school. First, she is "
             "holding the side of the pool. Then, she is kicking her legs. Now, she is swimming alone!",
             ["holding the side of the pool", "kicking her legs", "swimming alone", "sleeping"], 2),
        order("reading", "Put Mona's steps in order.",
              ["She is holding the bike and walking with it.", "She is pushing her feet on the pedals.",
               "She is riding around the garden path.", "She is feeling proud."]),
        tf("goals", "Practice helps us reach our goals.", True, "التدريب يساعدنا على تحقيق أهدافنا"),
        mc("prescont", "Which verb is in the present continuous?", ["is practicing", "practiced", "practice", "practices"], 0),
    ]),
    lesson("I Did It!", [
        read("reading", "How did Rania feel on the day of the exam?",
             "Rania studied hard for her English exam. On the exam day, she felt nervous. She answered "
             "all the questions. Later, she got full marks! She celebrated with her family at home.",
             ["nervous", "bored", "angry", "sleepy"], 0),
        read("reading", "Who did Rania celebrate with?",
             "Rania studied hard for her English exam. On the exam day, she felt nervous. She answered "
             "all the questions. Later, she got full marks! She celebrated with her family at home.",
             ["her teacher", "her family", "her coach", "nobody"], 1),
        mc("past", "Last month, Tamer ___ hard every day for his exam.", ["study", "studied", "studies", "studying"], 1,
           "study → studied (y → i + ed)"),
        mc("past", "His family ___ and said, \"Well done!\"", ["clap", "clapped", "claps", "clapping"], 1),
        order("goals", "Put the story frame in order.", ["First, I wanted to win.", "Then, I practiced.",
                                                           "After that, I tried my best.", "Finally, I felt proud."]),
        tf("goals", "\"Well done!\" is what we say when someone does a good job.", True, "Well done = أحسنت"),
    ]),
    lesson("Helping Others Succeed", [
        read("reading", "How did Hany help his friend?",
             "Hany is good at reading. His friend Sameh found reading hard. Hany read with him every "
             "day. In the class test, Sameh read very well. Both boys cheered and smiled.",
             ["He read with him every day.", "He gave him money.", "He did his homework.", "He drew a picture."], 0),
        read("reading", "What did both boys do at the end?",
             "Hany is good at reading. His friend Sameh found reading hard. Hany read with him every "
             "day. In the class test, Sameh read very well. Both boys cheered and smiled.",
             ["They cried.", "They cheered and smiled.", "They went to sleep.", "They were angry."], 1),
        tf("goals", "Helping a friend reach a goal can make us happy too.", True),
        mc("feel", "You finished a hard puzzle. You feel ...", ["proud", "bored", "scared", "angry"], 0),
        mc("punct", "Which sentence is correct?",
           ["yara is a fast runner.", "Yara is a fast runner.", "Yara is a fast runner?", "yara is a fast runner"], 1),
    ]),
    lesson("Review: Units 4, 5 and 6", [
        mc("prescont", "Look! The boys ___ in the garden.", ["run", "ran", "are running", "runs"], 2),
        mc("past", "Last night, my dad ___ dinner.", ["cook", "cooked", "cooking", "is cooking"], 1),
        mc("prescont", "Hani ___ a book right now.", ["is reading", "read", "reads", "reading"], 0),
        mc("feel", "Yara doesn't like to talk to new people. She is ...", ["shy", "excited", "bored", "proud"], 0, "Shy = خجول"),
        match("goals", "Match the word to its meaning.", ["team", "nervous", "solution"],
              ["a group working together", "a bit afraid or worried", "an answer to a problem"]),
        match("phonics", "Sort the words by sound.", ["city", "cake", "giraffe", "dog"],
              ["soft c /s/", "hard c /k/", "soft g /dʒ/", "hard g /g/"]),
        drag("team", "Choose the linking word.", "She felt strong ", " she practiced.",
             ["because", "but", "first"], "because", "Because tells the reason. (لأن)"),
    ]),
]}

COURSE = {
    "code": "eng-g3-t1", "subject": "english", "audience": "child",
    "grade_min": 3, "grade_max": 3,
    "title": "🇬🇧 English - Primary 3 (Term 1)", "level": "Term 1 2026/2027",
    "units": [U1, U2, U3, U4, U5, U6],
}
