#!/usr/bin/env python3
"""Builds the bedtime-stories + parent-follow SQL migration and the Dart copy for demo mode."""
import json, os
from bedtime_content import STORIES

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SQL_OUT = os.path.join(ROOT, "supabase/migrations/20261001000007_bedtime_and_follow.sql")
DART_OUT = os.path.join(ROOT, "apps/mobile/lib/data/bedtime/bedtime_content.g.dart")

BGS = {"night", "dusk", "garden", "home", "forest", "desert", "sea", "mountain", "river", "city"}

# Prophets stories never show a person: no people, faces, hands or body parts.
_PEOPLE = [(0x1F466, 0x1F487), (0x1F9D1, 0x1F9DF), (0x1F574, 0x1F57A), (0x1F645, 0x1F64F),
           (0x1F44A, 0x1F450), (0x1F440, 0x1F445), (0x1F590, 0x1F596), (0x270A, 0x270D),
           (0x1F918, 0x1F91F), (0x1F926, 0x1F939), (0x1F9B0, 0x1F9BB), (0x1F600, 0x1F644),
           (0x1F910, 0x1F917), (0x1F920, 0x1F925), (0x1F970, 0x1F97A), (0x1F9D0, 0x1F9D0),
           (0x1F464, 0x1F465), (0x1F5E3, 0x1F5E3), (0x1F3C3, 0x1F3CC), (0x1F4AA, 0x1F4AA),
           (0x1F6B4, 0x1F6B6), (0x1F6C0, 0x1F6C0), (0x1F6CC, 0x1F6CC), (0x1F46A, 0x1F46D),
           (0x1F48F, 0x1F491), (0x1FAC0, 0x1FAC5), (0x1FAF0, 0x1FAF8), (0x261D, 0x261D),
           (0x263A, 0x263A), (0x1F9CD, 0x1F9CF)]


def shows_person(emoji):
    return any(lo <= ord(ch) <= hi for ch in emoji for lo, hi in _PEOPLE)


def rows():
    out = []
    for i, s in enumerate(STORIES):
        words = sum(len(p["text"].split()) for p in s["pages"])
        # slow bedtime voice: about 85 words a minute plus pauses between sentences and pages
        minutes = max(3, round(words / 85 + len(s["pages"]) * 0.1))
        out.append({
            "id": s["id"], "sort": (i + 1) * 10, "title": s["title"], "emoji": s["emoji"],
            "value_code": s["value"], "value_name": s["value_name"], "kind": s["kind"],
            "minutes": minutes, "source": s.get("source", ""),
            "min_grade": s.get("min_grade", 1), "max_grade": s.get("max_grade", 12),
            "pages": s["pages"], "question": s["question"], "activity": s["activity"],
        })
    return out


def check():
    ids = set()
    for s in STORIES:
        assert s["id"] not in ids, s["id"]
        ids.add(s["id"])
        assert s["kind"] in ("value", "hadith", "prophet")
        if s["kind"] in ("hadith", "prophet"):
            assert s.get("source"), s["id"]
        assert 4 <= len(s["pages"]) <= 8, s["id"]
        for p in s["pages"]:
            assert p["bg"] in BGS, (s["id"], p["bg"])
            assert 1 <= len(p["scene"]) <= 4 and p["text"].strip()
            if s["kind"] == "prophet":
                assert not any(shows_person(e) for e in p["scene"]), (s["id"], p["scene"])
        q = s["question"]
        assert len(q["options"]) == 3 and 0 <= q["answer"] < 3, s["id"]
        assert s["activity"].strip()
        if s["kind"] == "prophet":
            assert not shows_person(s["emoji"]), s["id"]
    prophets = [s for s in STORIES if s["kind"] == "prophet"]
    assert len(prophets) == 25, len(prophets)


def content_sql():
    """Upsert of all stories (progress rows keep their story ids)."""
    js = json.dumps(rows(), ensure_ascii=False, separators=(",", ":"))
    js = js.replace('},{"id":"', '},\n{"id":"')
    assert "$json$" not in js
    return """do $$
declare
  st jsonb;
  data jsonb := $json$""" + js + """$json$;
begin
  update public.bedtime_stories set published = false;
  for st in select * from jsonb_array_elements(data) loop
    insert into public.bedtime_stories (id, sort, title, emoji, value_code, value_name, kind, minutes, source,
                                        min_grade, max_grade, pages, question, activity, published)
    values (st->>'id', (st->>'sort')::int, st->>'title', st->>'emoji', st->>'value_code', st->>'value_name',
            st->>'kind', (st->>'minutes')::int, st->>'source', (st->>'min_grade')::int, (st->>'max_grade')::int,
            st->'pages', st->'question', st->>'activity', true)
    on conflict (id) do update set sort = excluded.sort, title = excluded.title, emoji = excluded.emoji,
       value_code = excluded.value_code, value_name = excluded.value_name, kind = excluded.kind,
       minutes = excluded.minutes, source = excluded.source, min_grade = excluded.min_grade,
       max_grade = excluded.max_grade, pages = excluded.pages, question = excluded.question,
       activity = excluded.activity, published = true;
  end loop;
end $$;
"""


def build_sql():
    parts = [open(os.path.join(HERE, "bedtime_schema.sql"), encoding="utf-8").read().rstrip()]
    # the prophets stories need the 'prophet' kind (added in 0009); the first
    # install of this file only knows 'value' and 'hadith'.
    parts.append("alter table public.bedtime_stories drop constraint if exists bedtime_stories_kind_check;\n"
                 "alter table public.bedtime_stories add constraint bedtime_stories_kind_check\n"
                 "  check (kind in ('value', 'hadith', 'prophet'));")
    parts.append(content_sql())
    return "\n".join(parts)


def build_dart():
    js = json.dumps(rows(), ensure_ascii=False, indent=1)
    assert "'''" not in js
    return ("// GENERATED by content/build_bedtime.py - do not edit by hand.\n"
            "// Same stories as supabase/migrations/20261001000007_bedtime_and_follow.sql (DEMO mode and tests).\n\n"
            "const bedtimeContentJson = r'''\n" + js + "\n''';\n")


if __name__ == "__main__":
    check()
    os.makedirs(os.path.dirname(DART_OUT), exist_ok=True)
    open(SQL_OUT, "w", encoding="utf-8").write(build_sql())
    open(DART_OUT, "w", encoding="utf-8").write(build_dart())
    print(len(STORIES), "stories ->", os.path.relpath(SQL_OUT, ROOT), "+", os.path.relpath(DART_OUT, ROOT))
    for r in rows():
        print(" ", r["id"], r["minutes"], "min")
