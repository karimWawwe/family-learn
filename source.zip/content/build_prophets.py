#!/usr/bin/env python3
"""Builds migration 0010: the stories of all 25 prophets named in the Qur'an
(inside the existing bedtime-stories section). Progress, favourites and the
other stories are kept: the content is an upsert by story id."""
import os
from build_bedtime import check, content_sql

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SQL_OUT = os.path.join(ROOT, "supabase/migrations/20261004000010_prophets_stories.sql")

HEADER = """-- ============================================================================
--  Family Learn - قصص الأنبياء: the stories of the 25 prophets named in the Qur'an,
--  inside the existing «حكاية قبل النوم» section (kind 'prophet').
--
--  Needs migration 0007 (bedtime stories). Safe to run again: children's progress,
--  favourites and last page are kept (stories are upserted by id).
--  Every story is visible to both children (grades 1-12).
-- ============================================================================

alter table public.bedtime_stories drop constraint if exists bedtime_stories_kind_check;
alter table public.bedtime_stories add constraint bedtime_stories_kind_check
  check (kind in ('value', 'hadith', 'prophet'));
"""

if __name__ == "__main__":
    check()
    open(SQL_OUT, "w", encoding="utf-8").write(HEADER + "\n" + content_sql())
    print("->", os.path.relpath(SQL_OUT, ROOT))
