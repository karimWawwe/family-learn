# -*- coding: utf-8 -*-
"""
Family Learn - starter content (Phase 4).

ONE source for the lessons. `python content/build_content.py` turns it into:
  * supabase/migrations/20260926000003_phase4_starter_content.sql  (the real database)
  * apps/mobile/lib/data/learning/starter_content.g.dart           (the app's DEMO mode + tests)

Question kinds (t):
  mc    multiple choice   options, answer=index
  tf    true / false      answer=bool
  fill  fill the blank    before, after, accepted=[...]
  match matching pairs    left, right   (left[i] <-> right[i]; the app shuffles)
  order put in order      order=[...]   (the app shuffles)
  drag  drag a word       before, after, tokens, answer=token
  type  type the answer   accepted=[...]
  read  read, then answer passage, options, answer=index
  word  math word problem answer=number, unit
Optional on every question: hint, explain.
Listening and speaking arrive with audio in Phase 9.
"""

SKILLS = {
    # English, grades 1-4
    "eng.phonics.long_a": "Phonics: long a (ai, ay)",
    "eng.phonics.long_e": "Phonics: long e (ee, ea)",
    "eng.vocab.daily": "Words for my day",
    "eng.grammar.present_simple": "Present simple (he/she + s)",
    # Math, grades 1-4
    "math.time.oclock_half": "Time: o'clock and half past",
    "math.time.quarter": "Time: quarter past / to",
    "math.money.count": "Money: counting",
    "math.money.change": "Money: buying and change",
    # English, grades 5+
    "eng.grammar.past_regular": "Past simple: regular verbs",
    "eng.grammar.past_irregular": "Past simple: irregular verbs",
    "eng.reading.details": "Reading for details",
    "eng.vocab.story": "Story vocabulary",
    # Math, grades 5+
    "math.fractions.equivalent": "Equivalent fractions",
    "math.fractions.decimals": "Fractions and decimals",
    "math.ratio.basic": "Ratios",
    "math.percent.basic": "Percentages",
    # Business English
    "biz.customer.greeting": "Greeting and helping customers",
    "biz.customer.complaints": "Handling complaints",
    "biz.perfume.vocab": "Fragrance vocabulary",
    "biz.perfume.describe": "Describing a scent",
    "biz.meeting.numbers": "Sales numbers and trends",
    "biz.meeting.update": "Giving a sales update",
}

COURSES = [
    # ------------------------------------------------------------------ English 1-4
    {
        "code": "eng-lower", "subject": "english", "audience": "child", "grade_min": 1, "grade_max": 4,
        "title": "English - Grades 1-4", "level": "Starter",
        "units": [
            {"title": "Phonics: long vowels", "lessons": [
                {"title": "Long a: ai and ay", "minutes": 8, "questions": [
                    {"t": "mc", "skill": "eng.phonics.long_a", "prompt": "Which word has the long 'a' sound?",
                     "options": ["cat", "rain", "hat", "map"], "answer": 1, "hint": "Listen for 'ai' as in 'train'.",
                     "explain": "'rain' has 'ai', which says the long a sound."},
                    {"t": "fill", "skill": "eng.phonics.long_a", "prompt": "Complete the word.",
                     "before": "I like to pl", "after": " in the park.", "accepted": ["ay"],
                     "hint": "At the end of a word, long a is often 'ay'."},
                    {"t": "mc", "skill": "eng.phonics.long_a", "prompt": "Which spelling is used at the END of a word, like in 'day'?",
                     "options": ["ai", "ay", "a", "aa"], "answer": 1, "explain": "'ay' comes at the end (day, play); 'ai' is in the middle (rain, train)."},
                    {"t": "tf", "skill": "eng.phonics.long_a", "prompt": "'Stay' ends with 'ay'.", "answer": True},
                    {"t": "drag", "skill": "eng.phonics.long_a", "prompt": "Choose the right word.",
                     "before": "We wait for the ", "after": ".", "tokens": ["train", "tran", "trayn"], "answer": "train"},
                ]},
                {"title": "Long e: ee and ea", "minutes": 8, "questions": [
                    {"t": "mc", "skill": "eng.phonics.long_e", "prompt": "Which word has the long 'e' sound?",
                     "options": ["bed", "tree", "pen", "ten"], "answer": 1, "explain": "'tree' has 'ee', the long e sound."},
                    {"t": "fill", "skill": "eng.phonics.long_e", "prompt": "Complete the word.",
                     "before": "I drink t", "after": " with milk.", "accepted": ["ea"], "hint": "The drink is 't _ _'."},
                    {"t": "type", "skill": "eng.phonics.long_e", "prompt": "Type the word: the colour of grass.",
                     "accepted": ["green"], "hint": "It has 'ee' in the middle."},
                    {"t": "tf", "skill": "eng.phonics.long_e", "prompt": "'Sea' and 'see' sound the same.", "answer": True,
                     "explain": "They sound the same but mean different things."},
                    {"t": "mc", "skill": "eng.phonics.long_e", "prompt": "Which one is spelled correctly?",
                     "options": ["sleap", "sleep", "slep", "sliip"], "answer": 1},
                ]},
            ]},
            {"title": "My day", "lessons": [
                {"title": "Morning routine", "minutes": 8, "questions": [
                    {"t": "order", "skill": "eng.vocab.daily", "prompt": "Put the morning in order.",
                     "order": ["I wake up.", "I brush my teeth.", "I eat breakfast.", "I go to school."]},
                    {"t": "mc", "skill": "eng.vocab.daily", "prompt": "You use this to brush your teeth.",
                     "options": ["a spoon", "a toothbrush", "a pencil", "a ball"], "answer": 1},
                    {"t": "match", "skill": "eng.vocab.daily", "prompt": "Match the action to the thing.",
                     "left": ["wash", "eat", "wear"], "right": ["my face", "breakfast", "my uniform"]},
                    {"t": "drag", "skill": "eng.vocab.daily", "prompt": "Choose the right word.",
                     "before": "I ", "after": " up at 6 o'clock.", "tokens": ["wake", "eat", "sleep"], "answer": "wake"},
                    {"t": "tf", "skill": "eng.vocab.daily", "prompt": "We eat breakfast in the evening.", "answer": False,
                     "explain": "Breakfast is the first meal, in the morning."},
                ]},
                {"title": "Telling about my day", "minutes": 10, "questions": [
                    {"t": "mc", "skill": "eng.grammar.present_simple", "prompt": "Choose the correct sentence.",
                     "options": ["He play football.", "He plays football.", "He playing football.", "He to play football."],
                     "answer": 1, "hint": "He / she / it: add -s.", "explain": "With he, she or it we add -s: he plays."},
                    {"t": "fill", "skill": "eng.grammar.present_simple", "prompt": "Complete the sentence.",
                     "before": "My sister ", "after": " to school by bus.", "accepted": ["goes"],
                     "hint": "go -> ?", "explain": "go becomes goes with he / she / it."},
                    {"t": "drag", "skill": "eng.grammar.present_simple", "prompt": "Choose the right word.",
                     "before": "I ", "after": " my homework after lunch.", "tokens": ["do", "does", "doing"], "answer": "do"},
                    {"t": "tf", "skill": "eng.grammar.present_simple", "prompt": "'She watch TV' is correct.", "answer": False,
                     "explain": "Correct: 'She watches TV'."},
                    {"t": "type", "skill": "eng.grammar.present_simple", "prompt": "Write the verb with 'he': (to read) He ___ a book.",
                     "accepted": ["reads"]},
                ]},
            ]},
        ],
    },
    # ------------------------------------------------------------------ Math 1-4
    {
        "code": "math-lower", "subject": "math", "audience": "child", "grade_min": 1, "grade_max": 4,
        "title": "Math in English - Grades 1-4", "level": "Starter",
        "units": [
            {"title": "Telling the time", "lessons": [
                {"title": "O'clock and half past", "minutes": 8, "questions": [
                    {"t": "mc", "skill": "math.time.oclock_half", "prompt": "The long hand is on 12 and the short hand is on 3. What time is it?",
                     "options": ["12 o'clock", "3 o'clock", "half past 3", "half past 12"], "answer": 1},
                    {"t": "mc", "skill": "math.time.oclock_half", "prompt": "The long hand is on 6 and the short hand is between 7 and 8. What time is it?",
                     "options": ["6 o'clock", "7 o'clock", "half past 7", "half past 6"], "answer": 2,
                     "hint": "Long hand on 6 = half past."},
                    {"t": "match", "skill": "math.time.oclock_half", "prompt": "Match the time to the digital clock.",
                     "left": ["half past 2", "9 o'clock", "half past 11"], "right": ["2:30", "9:00", "11:30"]},
                    {"t": "tf", "skill": "math.time.oclock_half", "prompt": "Half past 4 is 4:30.", "answer": True},
                    {"t": "word", "skill": "math.time.oclock_half", "prompt": "How many minutes are in half an hour?",
                     "answer": 30, "unit": "minutes"},
                ]},
                {"title": "Quarter past and quarter to", "minutes": 10, "questions": [
                    {"t": "mc", "skill": "math.time.quarter", "prompt": "What is 'quarter past 5' on a digital clock?",
                     "options": ["5:45", "5:15", "4:45", "5:25"], "answer": 1},
                    {"t": "mc", "skill": "math.time.quarter", "prompt": "What is 'quarter to 8' on a digital clock?",
                     "options": ["8:15", "8:45", "7:45", "7:15"], "answer": 2,
                     "explain": "Quarter to 8 means 15 minutes before 8, so 7:45."},
                    {"t": "word", "skill": "math.time.quarter", "prompt": "How many minutes are in a quarter of an hour?",
                     "answer": 15, "unit": "minutes"},
                    {"t": "order", "skill": "math.time.quarter", "prompt": "Put the times in order, earliest first.",
                     "order": ["quarter past 1", "half past 1", "quarter to 2", "2 o'clock"]},
                    {"t": "mc", "skill": "math.time.quarter", "prompt": "School starts at 7:15. Omar arrives 15 minutes early. At what time does he arrive?",
                     "options": ["7:30", "7:00", "6:45", "7:15"], "answer": 1, "hint": "7:15 minus 15 minutes."},
                ]},
            ]},
            {"title": "Money", "lessons": [
                {"title": "Counting coins", "minutes": 8, "questions": [
                    {"t": "word", "skill": "math.money.count", "prompt": "You have 3 coins of 100 baisa. How many baisa do you have?",
                     "answer": 300, "unit": "baisa"},
                    {"t": "word", "skill": "math.money.count", "prompt": "You have 2 coins of 50 baisa and 1 coin of 100 baisa. How many baisa in total?",
                     "answer": 200, "unit": "baisa"},
                    {"t": "tf", "skill": "math.money.count", "prompt": "1 rial is 1000 baisa.", "answer": True},
                    {"t": "mc", "skill": "math.money.count", "prompt": "Which is more money?",
                     "options": ["500 baisa", "1 rial", "900 baisa", "750 baisa"], "answer": 1,
                     "explain": "1 rial = 1000 baisa, more than all the others."},
                    {"t": "match", "skill": "math.money.count", "prompt": "Match the coins to the total.",
                     "left": ["4 x 25 baisa", "2 x 100 baisa", "5 x 50 baisa"], "right": ["100 baisa", "200 baisa", "250 baisa"]},
                ]},
                {"title": "Buying things", "minutes": 10, "questions": [
                    {"t": "word", "skill": "math.money.change", "prompt": "A juice costs 300 baisa. You pay 500 baisa. How much change do you get?",
                     "answer": 200, "unit": "baisa"},
                    {"t": "word", "skill": "math.money.change", "prompt": "A pencil costs 150 baisa. How much do 2 pencils cost?",
                     "answer": 300, "unit": "baisa"},
                    {"t": "mc", "skill": "math.money.change", "prompt": "You have 1 rial. Can you buy a book for 1 rial 200 baisa?",
                     "options": ["Yes", "No, I need 200 baisa more", "No, I need 1 rial more", "Yes, with 200 baisa change"],
                     "answer": 1},
                    {"t": "word", "skill": "math.money.change", "prompt": "Yassin buys a sandwich for 400 baisa and water for 100 baisa. How much does he pay?",
                     "answer": 500, "unit": "baisa"},
                    {"t": "tf", "skill": "math.money.change", "prompt": "If a toy costs 700 baisa and you pay 1 rial, your change is 300 baisa.", "answer": True},
                ]},
            ]},
        ],
    },
    # ------------------------------------------------------------------ English 5+
    {
        "code": "eng-upper", "subject": "english", "audience": "child", "grade_min": 5, "grade_max": 12,
        "title": "English - Grades 5+", "level": "Grade 5+",
        "units": [
            {"title": "Past simple stories", "lessons": [
                {"title": "Regular verbs (-ed)", "minutes": 10, "questions": [
                    {"t": "mc", "skill": "eng.grammar.past_regular", "prompt": "Choose the past simple: Yesterday we ___ football.",
                     "options": ["play", "played", "playing", "plays"], "answer": 1},
                    {"t": "fill", "skill": "eng.grammar.past_regular", "prompt": "Complete with the past simple of 'watch'.",
                     "before": "Last night I ", "after": " a film with my brother.", "accepted": ["watched"]},
                    {"t": "type", "skill": "eng.grammar.past_regular", "prompt": "Write the past simple of 'study'.",
                     "accepted": ["studied"], "hint": "consonant + y -> ied", "explain": "study -> studied (y becomes ied)."},
                    {"t": "tf", "skill": "eng.grammar.past_regular", "prompt": "The past simple of 'stop' is 'stoped'.", "answer": False,
                     "explain": "Double the last letter: stopped."},
                    {"t": "match", "skill": "eng.grammar.past_regular", "prompt": "Match the verb to its past simple.",
                     "left": ["travel", "carry", "plan"], "right": ["travelled", "carried", "planned"]},
                ]},
                {"title": "Irregular verbs", "minutes": 10, "questions": [
                    {"t": "match", "skill": "eng.grammar.past_irregular", "prompt": "Match the verb to its past simple.",
                     "left": ["go", "see", "buy", "eat"], "right": ["went", "saw", "bought", "ate"]},
                    {"t": "drag", "skill": "eng.grammar.past_irregular", "prompt": "Choose the right word.",
                     "before": "Last summer we ", "after": " to Salalah.", "tokens": ["goed", "went", "go"], "answer": "went"},
                    {"t": "type", "skill": "eng.grammar.past_irregular", "prompt": "Write the past simple of 'write'.", "accepted": ["wrote"]},
                    {"t": "mc", "skill": "eng.grammar.past_irregular", "prompt": "Which sentence is correct?",
                     "options": ["I didn't went home.", "I didn't go home.", "I not went home.", "I don't went home."],
                     "answer": 1, "explain": "After 'didn't' use the base verb: didn't go."},
                    {"t": "fill", "skill": "eng.grammar.past_irregular", "prompt": "Complete with the past simple of 'take'.",
                     "before": "She ", "after": " a lot of photos at the beach.", "accepted": ["took"]},
                ]},
            ]},
            {"title": "Reading for details", "lessons": [
                {"title": "The storm", "minutes": 12, "questions": [
                    {"t": "read", "skill": "eng.reading.details", "prompt": "Why did the family stay at home?",
                     "passage": "On Friday the sky turned dark and a strong wind started to blow. The radio said a big storm was coming, so the Al-Harthy family stayed at home. They closed the windows and put the plants inside. At night the rain was very heavy, but by Saturday morning the sun was shining again.",
                     "options": ["It was a holiday.", "A storm was coming.", "Their car was broken.", "They were ill."], "answer": 1},
                    {"t": "read", "skill": "eng.reading.details", "prompt": "What did they put inside?",
                     "passage": "On Friday the sky turned dark and a strong wind started to blow. The radio said a big storm was coming, so the Al-Harthy family stayed at home. They closed the windows and put the plants inside. At night the rain was very heavy, but by Saturday morning the sun was shining again.",
                     "options": ["The car", "The chairs", "The plants", "The bicycles"], "answer": 2},
                    {"t": "tf", "skill": "eng.reading.details", "prompt": "In the story, it was still raining on Saturday morning.", "answer": False},
                    {"t": "match", "skill": "eng.vocab.story", "prompt": "Match the word to its meaning.",
                     "left": ["heavy (rain)", "blow", "shine"], "right": ["a lot of", "move air (wind)", "give light (sun)"]},
                    {"t": "order", "skill": "eng.reading.details", "prompt": "Put the events of the story in order.",
                     "order": ["The sky turned dark.", "The radio said a storm was coming.", "They closed the windows.", "The sun was shining again."]},
                ]},
                {"title": "A trip to Nizwa", "minutes": 12, "questions": [
                    {"t": "read", "skill": "eng.reading.details", "prompt": "How did they travel to Nizwa?",
                     "passage": "Last Thursday, Omar's class went on a school trip to Nizwa. They travelled by bus and left Muscat at seven o'clock. First they visited the old fort, where they climbed the big round tower. Then they walked through the souq and Omar bought a small clay pot for his mother. They came back at four in the afternoon, tired but happy.",
                     "options": ["By car", "By bus", "By plane", "On foot"], "answer": 1},
                    {"t": "read", "skill": "eng.reading.details", "prompt": "What did Omar buy?",
                     "passage": "Last Thursday, Omar's class went on a school trip to Nizwa. They travelled by bus and left Muscat at seven o'clock. First they visited the old fort, where they climbed the big round tower. Then they walked through the souq and Omar bought a small clay pot for his mother. They came back at four in the afternoon, tired but happy.",
                     "options": ["A book", "Dates", "A clay pot", "A hat"], "answer": 2},
                    {"t": "order", "skill": "eng.reading.details", "prompt": "Put the trip in order.",
                     "order": ["They left Muscat.", "They visited the fort.", "They walked through the souq.", "They came back."]},
                    {"t": "word", "skill": "math.time.oclock_half", "prompt": "They left at 7:00 and came back at 16:00 (4 pm). How many hours was the trip?",
                     "answer": 9, "unit": "hours"},
                    {"t": "tf", "skill": "eng.reading.details", "prompt": "The children were unhappy at the end of the day.", "answer": False,
                     "explain": "The text says 'tired but happy'."},
                ]},
            ]},
        ],
    },
    # ------------------------------------------------------------------ Math 5+
    {
        "code": "math-upper", "subject": "math", "audience": "child", "grade_min": 5, "grade_max": 12,
        "title": "Math in English - Grades 5+", "level": "Grade 5+",
        "units": [
            {"title": "Fractions and decimals", "lessons": [
                {"title": "Equivalent fractions", "minutes": 10, "questions": [
                    {"t": "mc", "skill": "math.fractions.equivalent", "prompt": "Which fraction is equal to 1/2?",
                     "options": ["2/3", "3/6", "2/5", "1/4"], "answer": 1},
                    {"t": "word", "skill": "math.fractions.equivalent", "prompt": "3/4 = ?/8. Find the missing number.",
                     "answer": 6, "unit": "", "hint": "4 x 2 = 8, so multiply the top by 2 too."},
                    {"t": "tf", "skill": "math.fractions.equivalent", "prompt": "2/3 and 4/6 are equivalent fractions.", "answer": True},
                    {"t": "match", "skill": "math.fractions.equivalent", "prompt": "Match the equivalent fractions.",
                     "left": ["1/3", "2/5", "3/4"], "right": ["2/6", "4/10", "9/12"]},
                    {"t": "word", "skill": "math.fractions.equivalent", "prompt": "Simplify 12/16. What is the new top number if the bottom is 4?",
                     "answer": 3, "unit": "", "explain": "12/16 = 3/4 (divide both by 4)."},
                ]},
                {"title": "Fractions to decimals", "minutes": 10, "questions": [
                    {"t": "word", "skill": "math.fractions.decimals", "prompt": "Write 1/4 as a decimal.", "answer": 0.25, "unit": ""},
                    {"t": "word", "skill": "math.fractions.decimals", "prompt": "Write 3/10 as a decimal.", "answer": 0.3, "unit": ""},
                    {"t": "mc", "skill": "math.fractions.decimals", "prompt": "Which decimal is equal to 1/2?",
                     "options": ["0.2", "0.12", "0.5", "1.2"], "answer": 2},
                    {"t": "order", "skill": "math.fractions.decimals", "prompt": "Put in order, smallest first.",
                     "order": ["0.2", "1/4", "0.5", "3/4"]},
                    {"t": "tf", "skill": "math.fractions.decimals", "prompt": "0.75 is the same as 3/4.", "answer": True},
                ]},
            ]},
            {"title": "Ratios and percentages", "lessons": [
                {"title": "Ratios", "minutes": 10, "questions": [
                    {"t": "word", "skill": "math.ratio.basic", "prompt": "In a class there are 12 boys and 8 girls. The ratio boys : girls is 3 : ?. Find the missing number.",
                     "answer": 2, "unit": "", "hint": "Divide both numbers by 4."},
                    {"t": "word", "skill": "math.ratio.basic", "prompt": "A juice uses 1 cup of mango for every 3 cups of water. How many cups of water for 4 cups of mango?",
                     "answer": 12, "unit": "cups"},
                    {"t": "mc", "skill": "math.ratio.basic", "prompt": "Which ratio is the same as 2 : 5?",
                     "options": ["4 : 10", "5 : 2", "3 : 6", "2 : 10"], "answer": 0},
                    {"t": "tf", "skill": "math.ratio.basic", "prompt": "The ratio 6 : 9 simplifies to 2 : 3.", "answer": True},
                    {"t": "word", "skill": "math.ratio.basic", "prompt": "Share 20 dates between Omar and Yassin in the ratio 3 : 1. How many dates does Omar get?",
                     "answer": 15, "unit": "dates", "explain": "3 + 1 = 4 parts; 20 / 4 = 5; Omar gets 3 x 5 = 15."},
                ]},
                {"title": "Percentages", "minutes": 12, "questions": [
                    {"t": "word", "skill": "math.percent.basic", "prompt": "What is 10% of 50?", "answer": 5, "unit": ""},
                    {"t": "word", "skill": "math.percent.basic", "prompt": "What is 25% of 80?", "answer": 20, "unit": ""},
                    {"t": "mc", "skill": "math.percent.basic", "prompt": "Which is the same as 50%?",
                     "options": ["1/5", "1/2", "2/5", "0.05"], "answer": 1},
                    {"t": "word", "skill": "math.percent.basic", "prompt": "A shirt costs 8 rials. In the sale it is 25% off. What is the new price in rials?",
                     "answer": 6, "unit": "rials", "explain": "25% of 8 = 2, so 8 - 2 = 6."},
                    {"t": "word", "skill": "math.percent.basic", "prompt": "Omar got 18 out of 20 on a test. What percentage is that?",
                     "answer": 90, "unit": "%"},
                ]},
            ]},
        ],
    },
    # ------------------------------------------------------------------ Business English (adult)
    {
        "code": "business", "subject": "business", "audience": "adult", "grade_min": None, "grade_max": None,
        "title": "Business & Sales English", "level": "B1+",
        "units": [
            {"title": "Talking to customers", "lessons": [
                {"title": "Greeting and helping", "minutes": 10, "questions": [
                    {"t": "mc", "skill": "biz.customer.greeting", "prompt": "A customer walks into the shop. What is the best first sentence?",
                     "options": ["What do you want?", "Good evening, welcome! How can I help you today?", "Yes?", "We are closing soon."],
                     "answer": 1},
                    {"t": "fill", "skill": "biz.customer.greeting", "prompt": "Complete the polite offer.",
                     "before": "Would you ", "after": " to try this fragrance?", "accepted": ["like"]},
                    {"t": "match", "skill": "biz.customer.greeting", "prompt": "Match the customer's words to a good reply.",
                     "left": ["I'm just looking.", "Is this a gift?", "Do you have something lighter?"],
                     "right": ["Of course, take your time. I'm here if you need me.", "Yes - would you like it gift-wrapped?", "Yes, let me show you our fresh citrus scents."]},
                    {"t": "order", "skill": "biz.customer.greeting", "prompt": "Put a good sales conversation in order.",
                     "order": ["Greet the customer.", "Ask what they are looking for.", "Recommend two or three products.", "Close the sale and thank them."]},
                    {"t": "tf", "skill": "biz.customer.greeting", "prompt": "'May I help you?' is more formal than 'Can I help?'", "answer": True},
                ]},
                {"title": "Handling complaints", "minutes": 12, "questions": [
                    {"t": "mc", "skill": "biz.customer.complaints", "prompt": "A customer says the bottle leaked. What do you say first?",
                     "options": ["That's not possible.", "I'm very sorry about that. Let me see what I can do.", "You must have dropped it.", "Come back tomorrow."],
                     "answer": 1, "explain": "Apologise and show you will act before explaining anything."},
                    {"t": "drag", "skill": "biz.customer.complaints", "prompt": "Choose the best word.",
                     "before": "We will ", "after": " the bottle with a new one today.", "tokens": ["replace", "repeat", "refuse"], "answer": "replace"},
                    {"t": "fill", "skill": "biz.customer.complaints", "prompt": "Complete the sentence.",
                     "before": "I completely understand your ", "after": ".", "accepted": ["frustration", "concern", "disappointment"]},
                    {"t": "match", "skill": "biz.customer.complaints", "prompt": "Match the phrase to its purpose.",
                     "left": ["I'm sorry for the trouble.", "Could you show me the receipt?", "Is there anything else I can do?"],
                     "right": ["Apologise", "Ask for information", "Check the customer is happy"]},
                    {"t": "tf", "skill": "biz.customer.complaints", "prompt": "'Defect' means a fault in a product.", "answer": True},
                ]},
            ]},
            {"title": "Presenting a perfume", "lessons": [
                {"title": "Fragrance vocabulary", "minutes": 10, "questions": [
                    {"t": "match", "skill": "biz.perfume.vocab", "prompt": "Match the note to when you smell it.",
                     "left": ["top notes", "heart notes", "base notes"],
                     "right": ["the first minutes", "after the top notes fade", "hours later, the long-lasting part"]},
                    {"t": "mc", "skill": "biz.perfume.vocab", "prompt": "Which is usually a base note?",
                     "options": ["lemon", "oud", "mint", "bergamot"], "answer": 1},
                    {"t": "tf", "skill": "biz.perfume.vocab", "prompt": "'Longevity' is how long a perfume lasts on the skin.", "answer": True},
                    {"t": "fill", "skill": "biz.perfume.vocab", "prompt": "Complete the word.",
                     "before": "How far the scent travels from the skin is called ", "after": ".", "accepted": ["sillage", "projection"]},
                    {"t": "mc", "skill": "biz.perfume.vocab", "prompt": "What is 'eau de parfum' compared with 'eau de toilette'?",
                     "options": ["Weaker", "Stronger (more concentrated)", "The same", "Only for men"], "answer": 1},
                ]},
                {"title": "Describing a scent", "minutes": 12, "questions": [
                    {"t": "match", "skill": "biz.perfume.describe", "prompt": "Match the scent family to a good describing word.",
                     "left": ["citrus", "woody", "oriental / amber", "floral"],
                     "right": ["fresh", "warm and dry", "rich and spicy", "soft and romantic"]},
                    {"t": "mc", "skill": "biz.perfume.describe", "prompt": "Choose the most professional description.",
                     "options": ["It smells nice.", "It opens with fresh bergamot and settles into warm amber and oud.", "It is very strong.", "Many people buy it."],
                     "answer": 1},
                    {"t": "drag", "skill": "biz.perfume.describe", "prompt": "Choose the best word.",
                     "before": "This fragrance is ", "after": " for evening events.", "tokens": ["ideal", "idea", "ideally"], "answer": "ideal"},
                    {"t": "order", "skill": "biz.perfume.describe", "prompt": "Put the presentation steps in order.",
                     "order": ["Spray on a blotter.", "Describe the top notes.", "Let the customer try it on the skin.", "Explain how it changes over time."]},
                    {"t": "type", "skill": "biz.perfume.describe", "prompt": "Type the opposite of 'light' when describing a scent (starts with h).",
                     "accepted": ["heavy"]},
                ]},
            ]},
            {"title": "Monthly sales meeting", "lessons": [
                {"title": "Numbers and trends", "minutes": 10, "questions": [
                    {"t": "match", "skill": "biz.meeting.numbers", "prompt": "Match the verb to its meaning.",
                     "left": ["increase", "decrease", "remain stable"], "right": ["go up", "go down", "stay the same"]},
                    {"t": "word", "skill": "biz.meeting.numbers", "prompt": "Sales went from 20,000 to 25,000 rials. What is the increase in percent?",
                     "answer": 25, "unit": "%", "explain": "5,000 / 20,000 = 0.25 = 25%."},
                    {"t": "mc", "skill": "biz.meeting.numbers", "prompt": "'Sales rose sharply' means sales went up...",
                     "options": ["a little", "a lot and quickly", "slowly", "not at all"], "answer": 1},
                    {"t": "fill", "skill": "biz.meeting.numbers", "prompt": "Complete the sentence.",
                     "before": "Compared with last month, sales ", "after": " by 10%.", "accepted": ["increased", "rose", "grew", "decreased", "fell", "dropped"]},
                    {"t": "tf", "skill": "biz.meeting.numbers", "prompt": "'Year on year' compares with the same period last year.", "answer": True},
                ]},
                {"title": "Giving an update", "minutes": 12, "questions": [
                    {"t": "order", "skill": "biz.meeting.update", "prompt": "Put a clear sales update in order.",
                     "order": ["Give the headline result.", "Explain the main reasons.", "Mention the challenges.", "Share the next steps."]},
                    {"t": "mc", "skill": "biz.meeting.update", "prompt": "Which sentence introduces the next steps?",
                     "options": ["To sum up, it was a bad month.", "Moving forward, we plan to focus on the Nizwa branch.", "Thank you for listening.", "Any questions?"],
                     "answer": 1},
                    {"t": "match", "skill": "biz.meeting.update", "prompt": "Match the phrase to its use.",
                     "left": ["The main reason was...", "On the other hand...", "Our target for next month is..."],
                     "right": ["Explain a cause", "Show a contrast", "Set a goal"]},
                    {"t": "drag", "skill": "biz.meeting.update", "prompt": "Choose the best word.",
                     "before": "We ", "after": " our target by 5% this month.", "tokens": ["exceeded", "exceed", "excess"], "answer": "exceeded"},
                    {"t": "tf", "skill": "biz.meeting.update", "prompt": "'Underperform' means doing better than expected.", "answer": False,
                     "explain": "Underperform = do worse than expected."},
                ]},
            ]},
        ],
    },
]
