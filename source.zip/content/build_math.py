#!/usr/bin/env python3
"""Builds migration 0009: math games + prophets stories + follow report with math."""
import os
from build_bedtime import check, content_sql

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SQL_OUT = os.path.join(ROOT, "supabase/migrations/20261003000009_math_games_prophets.sql")

if __name__ == "__main__":
    check()
    parts = [
        open(os.path.join(HERE, "math_schema.sql"), encoding="utf-8").read().rstrip(),
        open(os.path.join(HERE, "follow_schema.sql"), encoding="utf-8").read().rstrip(),
        "-- ---------------------------------------------------------------- stories (now with the prophets stories)",
        content_sql(),
    ]
    open(SQL_OUT, "w", encoding="utf-8").write("\n\n".join(parts))
    print("->", os.path.relpath(SQL_OUT, ROOT))
