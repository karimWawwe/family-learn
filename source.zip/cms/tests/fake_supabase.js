// Minimal stand-in for Supabase Auth + PostgREST RPC, backed by a local PostgreSQL
// that has the real migrations. Only what the CMS page uses.
const http = require('http');
const {Pool} = require('pg');

const users = {
  'junaidoman09@gmail.com': {id: '00000000-0000-0000-0000-00000000000e', password: 'password123'},
  'other@example.com': {id: '00000000-0000-0000-0000-00000000000b', password: 'password123'},
};
const b64 = o => Buffer.from(JSON.stringify(o)).toString('base64url');
const jwtFor = (u, email) => `${b64({alg: 'HS256', typ: 'JWT'})}.${b64({sub: u.id, email, role: 'authenticated', aud: 'authenticated', is_anonymous: false, exp: Math.floor(Date.now() / 1000) + 3600})}.sig`;
const userObj = (u, email) => ({id: u.id, email, aud: 'authenticated', role: 'authenticated', app_metadata: {provider: 'email'}, user_metadata: {}, identities: [{id: u.id}], created_at: new Date().toISOString()});

function start(dbName, port) {
  const pool = new Pool({host: '/var/run/postgresql', user: 'root', database: dbName});
  const server = http.createServer(async (req, res) => {
    let body = '';
    for await (const c of req) body += c;
    const url = new URL(req.url, 'http://x');
    const send = (code, obj) => { res.writeHead(code, {'content-type': 'application/json'}); res.end(obj === undefined ? '' : JSON.stringify(obj)); };
    try {
      if (url.pathname === '/auth/v1/token') {
        const {email, password} = JSON.parse(body);
        const u = users[email];
        if (!u || u.password !== password) return send(400, {error: 'invalid_grant', error_description: 'Invalid login credentials', msg: 'Invalid login credentials', code: 'invalid_credentials'});
        return send(200, {access_token: jwtFor(u, email), token_type: 'bearer', expires_in: 3600, expires_at: Math.floor(Date.now() / 1000) + 3600, refresh_token: 'r-' + u.id, user: userObj(u, email)});
      }
      if (url.pathname === '/auth/v1/user') {
        const tok = (req.headers.authorization || '').split(' ')[1];
        const p = JSON.parse(Buffer.from(tok.split('.')[1], 'base64url').toString());
        return send(200, userObj({id: p.sub}, p.email));
      }
      if (url.pathname === '/auth/v1/logout') return send(204);
      const m = /^\/rest\/v1\/rpc\/(\w+)$/.exec(url.pathname);
      if (m) {
        const tok = (req.headers.authorization || '').split(' ')[1] || '';
        let claims = {};
        try { claims = JSON.parse(Buffer.from(tok.split('.')[1], 'base64url').toString()); } catch (e) { /* anon */ }
        const args = body ? JSON.parse(body) : {};
        const names = Object.keys(args);
        const vals = names.map(k => (args[k] !== null && typeof args[k] === 'object') ? JSON.stringify(args[k]) : args[k]);
        const sql = `select public.${m[1]}(${names.map((k, i) => `${k} => $${i + 1}`).join(', ')}) as r`;
        const c = await pool.connect();
        try {
          await c.query('begin');
          await c.query(`set local role ${claims.sub ? 'authenticated' : 'anon'}`);
          await c.query(`select set_config('request.jwt.claims', $1, true)`, [JSON.stringify(claims)]);
          const r = await c.query(sql, vals);
          await c.query('commit');
          return send(200, r.rows[0].r);
        } catch (e) {
          await c.query('rollback');
          return send(400, {code: e.code, message: e.message, details: null, hint: null});
        } finally { c.release(); }
      }
      send(404, {message: 'not found ' + url.pathname});
    } catch (e) { send(500, {message: String(e)}); }
  });
  return new Promise(r => server.listen(port, () => r({server, pool})));
}
module.exports = {start};
