// End-to-end test of cms/family_learn_cms.html in Chromium against a local database.
const fs = require('fs');
const path = require('path');
const {chromium} = require('playwright');
const XLSX = require('xlsx');
const {start} = require('./fake_supabase');

const HTML = '/home/claude/p3/cms/family_learn_cms.html';
const OUT = path.join(__dirname, 'out');
fs.mkdirSync(OUT, {recursive: true});
const PORT = 54321;
let failures = 0;
const ok = (cond, what) => { if (cond) console.log('ok - ' + what); else { failures++; console.log('FAILED - ' + what); } };

(async () => {
  const {server, pool} = await start('cms_e2e', PORT);
  const q1 = async (sql, p) => (await pool.query(sql, p)).rows;
  const browser = await chromium.launch({executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});
  const ctx = await browser.newContext({acceptDownloads: true, viewport: {width: 1360, height: 900}, locale: 'ar'});
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => { if (m.type() === 'error' && !m.text().includes('status of 400')) errors.push(m.text()); });
  page.on('dialog', d => d.accept());

  await ctx.route('https://cdn.jsdelivr.net/npm/@supabase/**', r => r.fulfill({path: path.join(__dirname, 'node_modules/@supabase/supabase-js/dist/umd/supabase.js'), contentType: 'text/javascript'}));
  await ctx.route('https://cdn.jsdelivr.net/npm/xlsx@**', r => r.fulfill({path: path.join(__dirname, 'node_modules/xlsx/dist/xlsx.full.min.js'), contentType: 'text/javascript'}));
  await ctx.route('https://fonts.googleapis.com/**', r => r.fulfill({body: '', contentType: 'text/css'}));
  await ctx.route('https://dyjevtdrtoprtbiqbysm.supabase.co/**', async r => {
    const u = new URL(r.request().url());
    const resp = await fetch(`http://127.0.0.1:${PORT}${u.pathname}${u.search}`, {method: r.request().method(), headers: r.request().headers(), body: r.request().postData() || undefined});
    const text = await resp.text();
    await r.fulfill({status: resp.status, body: text, headers: {'content-type': 'application/json', 'access-control-allow-origin': '*'}});
  });

  await page.goto('file://' + HTML);
  await page.waitForSelector('#vLogin:not(.hidden)');
  ok(true, 'sign-in screen shows');

  // wrong password
  await page.fill('#email', 'junaidoman09@gmail.com'); await page.fill('#password', 'nope');
  await page.click('#loginBtn');
  await page.waitForSelector('#loginMsg .msg.bad');
  ok((await page.textContent('#loginMsg')).includes('غير صحيحة'), 'wrong password shows an Arabic error');

  // non-editor
  await page.fill('#email', 'other@example.com'); await page.fill('#password', 'password123');
  await page.click('#loginBtn');
  await page.waitForSelector('#vNoAccess:not(.hidden)');
  ok((await page.textContent('#noAccessEmail')) === 'other@example.com', 'non-editor sees the no-access page with the SQL to add them');
  await page.click('#signOutBtn');

  // editor
  await page.waitForSelector('#vLogin:not(.hidden)');
  await page.fill('#email', 'junaidoman09@gmail.com'); await page.fill('#password', 'password123');
  await page.click('#loginBtn');
  await page.waitForSelector('#courseRows tr[data-id]');
  ok((await page.$$('#courseRows tr[data-id]')).length === 5, 'course list shows 5 courses');
  await page.screenshot({path: path.join(OUT, '1_list.png')});

  // open course, edit first question
  await page.click('#courseRows tr[data-id="eng-upper"]');
  await page.waitForSelector('#tree .node.q');
  ok((await page.$$('#tree .node.q')).length === 20, 'tree shows 20 questions');
  await page.click('#tree .node.q >> nth=0');
  await page.waitForSelector('#q_prompt');
  await page.fill('#q_prompt', 'Pick the past simple: Yesterday we ___ football.');
  await page.screenshot({path: path.join(OUT, '2_question.png')});
  // add a new question of type ordering to lesson 1
  await page.click('#tree [data-add="q"] >> nth=0');
  await page.selectOption('#q_type', 'ordering');
  await page.fill('#q_prompt', 'Put the week in order.');
  await page.selectOption('#q_skill', 'eng.vocab.story');
  const itemInputs = await page.$$('#q_body input[type=text]');
  const items = ['Monday', 'Tuesday', 'Wednesday'];
  for (let i = 0; i < 3; i++) await itemInputs[i].fill(items[i]);
  ok((await page.textContent('#problemsBox')).includes('لا توجد مشاكل'), 'no problems after filling the new question');
  // an empty question makes a problem
  await page.click('#tree [data-add="q"] >> nth=0');
  await page.waitForTimeout(100);
  ok((await page.textContent('#problemsBox')).includes('نص السؤال فاضي'), 'empty new question is listed as a problem');
  await page.click('#delBtn');
  await page.keyboard.press('Control+s');
  await page.waitForFunction(() => document.querySelector('#savedAt').textContent.includes('حُفظت'));
  const draft = await q1(`select doc from public.content_drafts where course_id = 'eng-upper'`);
  ok(draft.length === 1 && draft[0].doc.units[0].lessons[0].questions.length === 6, 'draft saved with 6 questions in lesson 1');
  ok((await q1(`select prompt from public.questions where id = 'eng-upper.u1.l1.q1'`))[0].prompt.startsWith('Choose'), 'learners still see the old question');

  // publish
  await page.click('#publishBtn');
  await page.fill('#pub_note', 'E2E edit');
  await page.click('#dlgOk');
  await page.waitForFunction(() => document.querySelector('#edStatus').textContent.includes('v1'));
  ok((await q1(`select prompt from public.questions where id = 'eng-upper.u1.l1.q1'`))[0].prompt.startsWith('Pick'), 'published: learners see the edit');
  const ord = await q1(`select payload, answer_key from public.questions where prompt = 'Put the week in order.'`);
  ok(ord.length === 1 && JSON.stringify(ord[0].payload.items) !== JSON.stringify(ord[0].answer_key.order), 'new ordering question stored shuffled');

  // Excel import (with one bad row)
  const rows = [
    {unit: 'Holidays', lesson: 'At the beach', minutes: 8, type: 'mc', skill: 'eng.vocab.story', prompt: 'We swim in the ...', options: 'sea | sky | sand', answer: 1},
    {type: 'tf', skill: 'eng.vocab.story', prompt: 'Sand is wet in the sea.', answer: 'صح'},
    {type: 'word', skill: 'math.ratio.basic', prompt: 'How many days in a week?', answer: 7, unit_label: 'days'},
    {type: 'match', skill: 'eng.vocab.story', prompt: 'Match.', left: 'hot | wet', right: 'sun | rain'},
    {type: 'drag', skill: 'eng.vocab.story', prompt: 'Choose.', before: 'I wear a ', after: '.', tokens: 'hat | hot', answer: 'hat'},
    {type: 'weird', skill: 'eng.vocab.story', prompt: 'bad row'},
  ];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), 'questions');
  const xl = path.join(OUT, 'import.xlsx'); XLSX.writeFile(wb, xl);
  await page.setInputFiles('#fileInput', xl);
  await page.waitForSelector('#dlg[open]');
  const dtext = await page.textContent('#dlgForm');
  ok(dtext.includes('5') && dtext.includes('weird'), 'import added 5 questions and reported the bad row');
  await page.screenshot({path: path.join(OUT, '3_import.png')});
  await page.click('#dlgForm button[value=cancel]');
  ok((await page.textContent('#problemsBox')).includes('لا توجد مشاكل'), 'imported questions have no problems');
  await page.click('#publishBtn'); await page.click('#dlgOk');
  await page.waitForFunction(() => document.querySelector('#edStatus').textContent.includes('v2'));
  const imp = await q1(`select q.type, q.correct_text from public.questions q join public.lessons l on l.id = q.lesson_id where l.title = 'At the beach' and not q.archived order by q.position`);
  ok(imp.length === 5 && imp[0].correct_text === 'sea' && imp[1].correct_text === 'True' && imp[2].correct_text === '7 days', 'imported lesson is live with correct answers');

  // export
  const [dl] = await Promise.all([page.waitForEvent('download'), page.click('#exportBtn')]);
  const exp = path.join(OUT, 'export.xlsx'); await dl.saveAs(exp);
  const back = XLSX.utils.sheet_to_json(XLSX.readFile(exp).Sheets['questions']);
  ok(back.length === 26 && XLSX.readFile(exp).SheetNames.includes('help'), 'export has all 26 questions and a help sheet');

  // delete a lesson -> archived, versions restore
  await page.click('#tree .node.l >> nth=3');
  await page.click('#delBtn');
  await page.click('#publishBtn'); await page.click('#dlgOk');
  await page.waitForFunction(() => document.querySelector('#edStatus').textContent.includes('v3'));
  ok((await q1(`select archived from public.lessons where id = 'eng-upper.u2.l2'`))[0].archived === true, 'deleted lesson is archived (history kept)');
  await page.click('#versionsBtn');
  await page.click('#dlgForm [data-v="1"]');
  await page.waitForFunction(() => document.querySelector('#edStatus').textContent.includes('مسوّدة'));
  await page.click('#publishBtn'); await page.click('#dlgOk');
  await page.waitForFunction(() => document.querySelector('#edStatus').textContent.includes('v4'));
  ok((await q1(`select archived from public.lessons where id = 'eng-upper.u2.l2'`))[0].archived === false, 'restoring v1 brings the lesson back');

  // new course
  await page.click('#backBtn');
  await page.waitForSelector('#courseRows tr[data-id]');
  await page.click('#newCourseBtn');
  await page.fill('#nc_id', 'eng-extra'); await page.fill('#nc_title', 'Extra reading');
  await page.click('#dlgOk');
  await page.waitForSelector('#tree .node.l');
  ok((await page.textContent('#problemsBox')).includes('الدرس بدون أسئلة'), 'new course starts with a lesson that needs questions');
  await page.click('#tree [data-add="q"]');
  await page.fill('#q_prompt', 'Which is a fruit?');
  await page.selectOption('#q_skill', 'eng.vocab.daily');
  const opts = await page.$$('#q_body input[type=text]');
  await opts[0].fill('apple'); await opts[1].fill('car'); await opts[2].fill('pen');
  // new skill
  await page.click('#newSkill');
  await page.fill('#ns_code', 'eng.vocab.fruit'); await page.fill('#ns_name', 'Fruit words');
  await page.click('#dlgOk');
  await page.waitForFunction(() => document.querySelector('#q_skill').value === 'eng.vocab.fruit');
  await page.click('#tree .node >> nth=0');
  await page.fill('#c_gmin', '5'); await page.fill('#c_gmax', '7');
  await page.click('#publishBtn'); await page.click('#dlgOk');
  await page.waitForFunction(() => document.querySelector('#edStatus').textContent.includes('v1'));
  const nc = await q1(`select c.grade_min, c.grade_max, (select count(*) from public.questions q join public.lessons l on l.id = q.lesson_id where l.course_id = 'eng-extra')::int n from public.courses c where id = 'eng-extra'`);
  ok(nc.length === 1 && nc[0].grade_min === 5 && nc[0].grade_max === 7 && nc[0].n === 1, 'new course published with grades 5-7');
  await page.screenshot({path: path.join(OUT, '4_new_course.png')});

  // dark mode renders
  await page.click('#themeBtn');
  await page.screenshot({path: path.join(OUT, '5_dark.png')});

  // mobile width: no horizontal scroll
  await page.setViewportSize({width: 390, height: 844});
  await page.waitForTimeout(200);
  const wide = await page.evaluate(() => [...document.querySelectorAll('body *')].filter(e => e.getBoundingClientRect().right > window.innerWidth + 1 || e.getBoundingClientRect().left < -1).slice(0, 6).map(e => e.tagName + '#' + e.id + '.' + e.className + ' ' + Math.round(e.getBoundingClientRect().left) + '..' + Math.round(e.getBoundingClientRect().right)));
  ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'no horizontal scroll at phone width ' + JSON.stringify(wide));
  await page.screenshot({path: path.join(OUT, '6_phone.png'), fullPage: false});

  ok(errors.length === 0, 'no JavaScript errors' + (errors.length ? ': ' + errors.join(' | ') : ''));
  await browser.close(); server.close(); await pool.end();
  console.log(failures ? `${failures} FAILED` : 'ALL CMS PAGE TESTS PASSED');
  process.exit(failures ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
